"""Shadow development build. Target: Kodi 21; this candidate requires native Mac/Xbox verification."""
import os
import sys
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ROOT = ADDON.getAddonInfo('path')
sys.path.insert(0, os.path.join(ROOT, 'resources', 'lib'))
from shadow.kodi_ui import ShadowWindow


def main():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    window = ShadowWindow('Shadow.xml', ROOT, 'Default', '1080i', profile=profile)
    from shadow.privacy import Privacy
    window.privacy = Privacy(window)
    monitor = xbmc.Monitor()
    try:
        window.show()
        while window.running and not monitor.waitForAbort(.05):
            window.tick()
    finally:
        window.shutdown()
        del window


if __name__ == '__main__':
    main()
