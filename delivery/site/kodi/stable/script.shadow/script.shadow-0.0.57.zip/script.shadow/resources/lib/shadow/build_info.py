"""Runtime version; the builder verifies this against addon.xml before packaging."""
VERSION = '0.0.57'
