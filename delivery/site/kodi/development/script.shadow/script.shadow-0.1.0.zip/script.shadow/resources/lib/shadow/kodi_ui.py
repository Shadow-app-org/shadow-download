"""Kodi adapter. Explicit local login storage; workers never call GUI APIs."""
import os
import time
from datetime import datetime
import xbmc
import xbmcgui
import xbmcvfs
from .application import Session, prepare_connection, recover_account, update_filtered_selection
from .jobs import JobRunner, JobError
from .preferences import PreferencesError, PreferencesConflict
from .artwork_fetch import ArtworkCache
from .artwork_loader import ArtworkLoader, ArtworkGridLoader
from .interface import MENU, SHORTCUTS
from .xtream import display_text
from .demo import demo_connection
from .safe_errors import safe_message, provider_code, SafeError
from .test_login import TestLogin
from .saved_login import SavedLogin, LoginStorageError, error_code as login_error_code
from .provider import XtreamClient, ProviderError
from .ui_text import readable
from .build_info import VERSION


class ShadowWindow(getattr(xbmcgui, 'WindowXML', xbmcgui.WindowXMLDialog)):
    def __init__(self, *args, **kwargs):
        self.privacy = None
        self.profile = kwargs.pop('profile')
        self.addon_path = args[1] if len(args) > 1 else ''
        # Kodi constructs the native window before this Python initializer.
        self.running = True
        self.session = Session()
        self.jobs = JobRunner()
        self.page = 'Home'
        self.rows = []
        self.programmes = []
        self.channel = None
        self.last_programme = None
        self.art_token = None
        self.demo = False
        self.row_focus = None
        self.watch_later_rows = {'movies': [], 'series': []}
        self.watch_later_loaders = {}
        self.watch_later_tokens = {}
        self.watch_later_batches = {}
        self.watch_later_view_identity = None
        self.watch_later_catalogue_runners = {kind:JobRunner() for kind in ('movies','series')}
        self.watch_later_catalogue_jobs = {}
        self.watch_later_catalogue_errors = set()
        self.live_favourites = False
        self.artwork = None
        self.overviews = None
        self.overview_token = None
        self.initialized = False
        self.next_preferences_check = 0
        self.playback = None
        self.playback_hidden = False
        self._playback_return = None
        self.test_login = TestLogin()
        self._row_batch = None
        self.saved_login = SavedLogin(self.profile)
        from .connection_permissions import ConnectionPermissions
        self.connection_permissions = ConnectionPermissions(self.profile)
        self.permission_identity = None
        self.permission_connection = None
        self.hero_index = 0
        self.hero_channel = None
        self.hero_token = None
        self.hero_next = 0
        self.hero_identity = None
        self.recent_channels = []
        self.watching_channel = None
        self.guide_job = None
        self.guide_runner = JobRunner()
        self.guide_retry_at = 0
        self.overlay = None
        self.osd_latched = False
        self._overlay_stop_pending = None
        self.loading_cover = None
        self.cover_handoff_deadline = 0
        self.playing_channel = None
        self.switch_state = None
        self.reconnect_context = None
        self.switch_jobs = JobRunner()
        self.playing_media = None
        self.media_connection = None
        self.media_last_sample = None
        self.media_saved_at = 0
        self.media_next_sample = 0
        self._vod_controller = False
        self.recent_media = {'movies': [], 'series': []}
        self._recent_media_identity = None
        self.recent_artwork = []
        self.recent_art_tokens = [None] * 4
        self.recent_art_identity = None
        self.playback_start_pending = False
        self.fullscreen_requested = False
        self.handoff_next_attempt = 0
        self.handoff_attempts = 0
        self.busy_close_requests = 0
        self.busy_next_close = 0
        self.playback_clock = None
        self.subtitles_initialized = False
        self.view_states = {}
        self.search_query = ''
        self.search_scope = 0
        self.continue_rows = []
        self.pending_row_selection = None
        self.return_page = 'Home'
        self.next_end_pending = None
        self.next_countdown = None
        self.now_next_identity = None
        self._watched_cache = None
        self.connection_failed = False
        self.next_header_update = 0
        self.handoff_deadline = 0
        self.poster_token = None
        self.poster_row = None
        self.overview_token = None
        self.poster_grid = None
        self.poster_grid_token = None
        self.catalogue_filters = {}
        self.catalogue_connection = None
        self.catalogue_rows = []
        self.font_coverage = None
        self.browse_artwork = None
        self.browse_art_token = None
        self.browse_art_connection = None
        self.browse_art_rows = None
        self.browse_art_start = -1
        self.media_art_indexes = {}
        self.chosen_browse_languages = None

    def safe_text(self, value, description=False):
        from .ui_text import readable
        return readable(value, self.font_coverage, 'Description unavailable in the current font.' if description else 'Title unavailable in the current font.')

    def setProperty(self, key, value):
        text_keys = ('shadow.programme', 'shadow.artwork.fallback', 'shadow.hero.title', 'shadow.hero.description')
        if key in text_keys or (key.startswith(('shadow.recent.', 'shadow.movies.', 'shadow.series.')) and key.count('.') == 2 and key.rsplit('.',1)[-1].isdigit()):
            from .ui_text import readable
            value = readable(value, getattr(self,'font_coverage',None), 'Text unavailable in the current font.')
        super().setProperty(key, value)

    def onInit(self):
        if self.initialized or not self.running:
            return
        self.initialized = True
        self.dialog = xbmcgui.Dialog()
        from .ui_text import load_estuary_coverage
        self.font_coverage = load_estuary_coverage(xbmc, xbmcvfs)
        try:
            os.makedirs(self.profile, exist_ok=True)
        except (OSError, AttributeError, NotImplementedError):
            self.dialog.ok('Shadow ' + VERSION + ' - Settings - S401', safe_message('S401') + ' Check Kodi profile storage access, then reopen Shadow.')
            self.shutdown()
            return
        cache = ArtworkCache(os.path.join(self.profile, 'artwork'), max_cache_bytes=2*1024*1024)
        self.media_poster_cache=ArtworkCache(os.path.join(self.profile,'media-posters'),max_cache_bytes=16*1024*1024)
        from .cinemeta import ArtworkSources
        self.tvmaze = ArtworkSources()
        from .overviews import OverviewLoader
        self.overviews = OverviewLoader(self.tvmaze)
        from .channel_logos import ChannelLogos
        self.channel_logos = ChannelLogos()
        self.channel_logos.cache=ArtworkCache(os.path.join(self.profile,'channel-logos'),max_cache_bytes=8*1024*1024)
        self.artwork = ArtworkLoader(cache, self.tvmaze, self.channel_logos)
        self.artwork.poster_cache=self.media_poster_cache
        self.recent_artwork = [ArtworkLoader(ArtworkCache(os.path.join(self.profile, 'recent-artwork', str(i)), max_cache_bytes=2*1024*1024), logos=self.channel_logos) for i in range(4)]
        self.poster_grid = ArtworkGridLoader(self.media_poster_cache, self.tvmaze)
        self.browse_artwork = ArtworkGridLoader(self.media_poster_cache, self.tvmaze)
        self.watch_later_loaders = {kind: ArtworkGridLoader(self.media_poster_cache,self.tvmaze) for kind in ('movies','series')}
        self.setProperty('shadow.page', 'Home')
        self.setProperty('shadow.status', 'Disconnected')
        self.setProperty('shadow.background', 'FF090909')
        self.update_header()
        self.setFocusId(100)
        self.on_startup_assets()
        self.on_startup()

    def on_startup_assets(self):
        pass

    def on_startup(self):
        choice = self.dialog.select('Welcome to Shadow', ['Connect saved provider' if self.saved_login.exists() else 'Connect provider', 'Explore offline demo', 'Close', 'Test local video and audio', 'Import M3U playlist link', 'Check local storage', 'Temporary live-TV test (no saved settings)', 'Check hostname lookup', 'Retry last connection', 'Forget test login'])
        if choice == 0:
            if self.saved_login.exists():
                self.connect_saved_provider()
            else:
                self.connect_provider()
        elif choice == 1:
            self.session.adopt(demo_connection(self.profile))
            self.demo = True
            self.after_connect()
        elif choice == 3:
            self.test_playback()
        elif choice == 4:
            self.connect_playlist()
        elif choice == 5:
            self.check_storage()
        elif choice == 6:
            self.temporary_test()
        elif choice == 7:
            self.check_hostname()
        elif choice == 8:
            self.retry_connection()
        elif choice == 9:
            self.forget_test_login()
        else:
            self.shutdown()

    def run_job(self, title, operation, dispose=lambda value: None):
        job = self.jobs.submit(operation, dispose)
        progress = None
        try:
            collection = title == 'Loading collection...'
            status = None
            if collection:
                from .collection_progress import CollectionStatus
                status = getattr(operation, 'collection_status', None) or CollectionStatus()
            progress = CollectionProgress('ShadowCollection.xml',self.addon_path,'Default','1080i') if collection else xbmcgui.DialogProgress()
            progress.create('Shadow', title)
            monitor = xbmc.Monitor()
            next_update = 0
            while not job.done.is_set():
                if progress.iscanceled() or monitor.waitForAbort(.05):
                    job.cancel()
                    return None
                if status is not None:
                    status.check()
                    if time.monotonic() >= next_update:
                        progress.update_status(*status.view())
                        next_update = time.monotonic() + .25
            if progress.iscanceled():
                job.cancel()
                return None
            if status is not None:
                status.check()
            return job.take()
        except SafeError as failure:
            job.cancel()
            error = JobError('Collection could not be completed')
            error.code = provider_code(failure.code)
            error.stage = 'catalogue'
            raise error from None
        except BaseException:
            job.cancel()
            raise
        finally:
            if progress is not None:
                try:
                    progress.close()
                except Exception:
                    pass  # A dialog cleanup error must not orphan an adopted result.

    def credentials(self, consolidated=False):
        base = self.dialog.input('Provider address - https://... or http://...').strip()
        if not base:
            return None
        allow_http = False
        if base.lower().startswith('http://') and not consolidated:
            allow_http = self.dialog.yesno('Unencrypted provider connection', 'For this session, HTTP sends your provider login and TV streams without encryption. Others on the network may read or alter them. Allow HTTP login and playback?')
            if not allow_http:
                return None
        username = self.dialog.input('Provider username')
        if not username:
            return None
        password = self.dialog.input('Provider password', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return None
        return base, username, password, allow_http

    def temporary_test(self):
        choice = self.dialog.select('Temporary live-TV test - choose connection',
                                    ['M3U playlist link', 'Xtream provider login'])
        if choice not in (0, 1):
            return
        self.stop_playback()
        self.dialog.ok('Temporary test - settings stay in memory',
                       'Start with no channels selected. This test login stays in memory for Retry last connection until disconnect, Forget test login or closing Shadow. Existing saved settings are untouched. Connection options control HTTP and redirects.')
        if choice == 0:
            self.connect_playlist(temporary=True)
        else:
            self.connect_provider(temporary=True)

    def retry_connection(self):
        if not self.running:
            return
        kind = self.test_login.kind
        if kind == 'xtream':
            self.connect_provider(temporary=True, retry=True)
        elif kind == 'm3u':
            self.connect_playlist(temporary=True, retry=True)
        else:
            self.dialog.ok('No test login to retry', 'Enter a connection through Temporary live-TV test first. Closing Shadow or Kodi clears the remembered test login.')

    def forget_test_login(self):
        self.test_login.clear()
        self.jobs.close()
        self.stop_playback()
        self.clear_guide()
        self.session.close()
        self.rows = []
        self.getControl(300).reset()
        self.open_page('Home')
        self.setProperty('shadow.status', 'Disconnected')
        self.dialog.ok('Test login forgotten', 'Disconnected. Retry details have been released from memory. Enter a new connection to continue.')

    def connection_options(self, base='', temporary=False, current=None, remember=False):
        """Review new grants or edit current grants; reconnect reuse is handled separately."""
        keys, labels, selected = [], [], []
        if current is None and not temporary:
            keys.append('remember'); labels.append('Remember login on this device (stored unencrypted)')
            if remember: selected.append(0)
        keys.extend(('redirects', 'http_redirects'))
        labels.extend(('Allow provider playback redirects to public servers',
                       'Allow unencrypted HTTP playback redirects (may expose login/tokens)'))
        if base.lower().startswith('http://'):
            keys.append('http_login'); labels.append('Allow unencrypted HTTP provider login and streams')
        if current is not None:
            if current.client._allow_stream_redirects is True: selected.append(keys.index('redirects'))
            if current.client._allow_http_redirects is True: selected.append(keys.index('http_redirects'))
        indices = self.multiselect('Connection options', labels, selected)
        if not isinstance(indices, list) or any(type(i) is not int or not 0 <= i < len(keys) for i in indices):
            return None
        options = {key: i in indices for i, key in enumerate(keys)}
        if options.get('http_redirects') and not options.get('redirects'):
            self.dialog.ok('Connection options', 'Select provider playback redirects as well as HTTP playback redirects, or leave both off.')
            return None
        if base.lower().startswith('http://') and not options.get('http_login'):
            self.dialog.ok('Connection options', 'This address uses HTTP. Allow HTTP provider login to connect, or use your provider’s HTTPS address.')
            return None
        return options

    def connect_saved_provider(self):
        try:
            details = self.saved_login.load()
        except LoginStorageError as error:
            self.dialog.ok('Saved login unavailable', 'Enter the provider again or use Forget saved login. No connection was attempted. Code: ' + login_error_code(error))
            return
        if details is None:
            self.connect_provider()
            return
        self.connect_provider(saved_details=details)

    def forget_saved_login(self):
        # Revoke active playback and memory copies even if disk removal fails.
        self.test_login.clear()
        self.jobs.close()
        self.stop_playback()
        self.clear_guide()
        self.session.close()
        self.recent_channels = []
        self.open_page('Home')
        self.setProperty('shadow.status', 'Disconnected')
        try:
            self.saved_login.forget()
        except LoginStorageError as error:
            self.dialog.ok('Login removal failed', 'Disconnected, but the local saved login could not be deleted. It has not been forgotten on disk. Code: ' + login_error_code(error))
        else:
            self.dialog.ok('Saved login forgotten', 'Disconnected and removed the saved login. Account channel selections are retained separately.')
        self.permission_identity = None
        self.permission_connection = None
        try:self.connection_permissions.clear()
        except LoginStorageError:
            self.dialog.ok('Connection permissions', 'Remembered permission choices could not be cleared. Disable remembering in Settings before saving this connection again.')

    def connect_provider(self, temporary=False, retry=False, saved_details=None):
        if retry:
            if temporary is not True:
                return
            details = self.test_login.snapshot('xtream')
        elif saved_details is not None:
            details = tuple(saved_details) + (False,)
        else:
            details = self.credentials(consolidated=True)
        if details is None:
            return
        from .connection_permissions import identity as permission_identity
        key = None
        if not temporary:
            try:key = permission_identity(details[:3])
            except LoginStorageError:pass  # Let the existing connection validation report invalid input.
        options = None
        if key:
            try:options = self.connection_permissions.lookup(key)
            except LoginStorageError:pass  # Unreadable choices require explicit approval.
        if options is None:
            options = self.connection_options(details[0], temporary=temporary, remember=saved_details is not None)
        if options is None:
            return
        details = tuple(details[:3]) + (options.get('http_login', False),)
        if temporary is True:
            self.test_login.remember('xtream', details)
        else:
            self.test_login.clear()
        try:
            while self.running:
                try:
                    connection = self.run_job('Connecting and reading channels...', lambda args=details: prepare_connection(self.profile, *args, allow_http_playback=args[3], temporary=temporary), lambda c: c.close())
                    break
                except JobError as error:
                    self.provider_error(error, temporary=temporary)
                    self.setProperty('shadow.status', 'Connection incomplete - see diagnostic')
                    if not self.dialog.yesno('Retry connection', 'Retry the same connection now? Choose No to return to Settings > Provider connection or Check local storage. Existing selections are retained.'):
                        return
            else:
                return
            if connection is None:
                self.setProperty('shadow.status', 'Connection cancelled - settings retained')
                if self.running:
                    self.dialog.ok('Connection cancelled', 'No new connection was adopted. Use Settings > Provider connection to try again. Existing selections are retained.')
                return
            if not self.running:
                connection.close()
                return
            connection.client.set_stream_redirects(options['redirects'])
            connection.client.set_http_stream_redirects(options['http_redirects'])
            self.clear_guide()
            self.stop_playback()
            self.session.adopt(connection)
            self.permission_identity = key
            self.permission_connection = connection
            self.recent_channels = []
            self.demo = False
            if not temporary:
                try:
                    if key:self.connection_permissions.remember(key, options)
                except LoginStorageError as error:
                    self.dialog.ok('Connection permissions', 'Connected, but these choices could not be remembered. You may be asked again next time. Code: ' + login_error_code(error))
                try:
                    if options.get('remember'):
                        self.saved_login.save(details[:3])
                    else:
                        self.saved_login.forget()
                except LoginStorageError as error:
                    self.dialog.ok('Login storage unavailable', 'Connected, but the remember-login choice could not be saved. Any previously saved login may still exist. Use Forget saved login to remove it. Code: ' + login_error_code(error))
            self.after_connect()
        except (JobError, PreferencesError) as error:
            self.provider_error(error, temporary=temporary)
            self.setProperty('shadow.status', 'Setup incomplete - see diagnostic')
        finally:
            details = None

    def provider_error(self, error, temporary=False):
        from .safe_errors import provider_code, provider_stage, PROVIDER_STAGES
        code = provider_code(getattr(error, 'code', None))
        stage = PROVIDER_STAGES['settings' if isinstance(error, PreferencesError) else provider_stage(getattr(error, 'stage', None))]
        message = safe_message(code, getattr(error, 'http_status', None))
        if temporary is True:
            message += '\nNo saved account settings were used.'
        if self.test_login.kind:
            message += '\nUse Settings > Retry last connection to retry without typing. Forget test login disconnects and clears it.'
        self.dialog.ok('Shadow ' + VERSION + ' - Xtream - ' + stage + ' - ' + code, message)

    def after_connect(self, interactive=True):
        # Existing accounts had no shared language field. Infer only an
        # unambiguous language from already-approved channels, never approvals.
        if self.session.connected and self.session.prefs.get('browse_languages') is None:
            from .selection import canonical_language,language_for_channel
            names={str(c.get('category_id')):c.get('category_name','') for c in self.session.connection.categories}
            allowed=set(self.session.prefs['approved_channel_ids'])
            inferred={canonical_language(language_for_channel(c['name'],names.get(c.get('category_id'),''))) for c in self.session.channels if c['stream_id'] in allowed}
            if len(inferred)==1 and 'Other' not in inferred:
                try:
                    self.session.save({'browse_languages':sorted(inferred)})
                except PreferencesError as error:
                    self.provider_error(error)

        self.recent_channels = list(self.session.history.live) if self.session.history else []
        self.connection_failed = False
        self.view_states = {}
        self.watching_channel = None
        self.rows = []
        self.getControl(300).reset()
        self.open_page('Home')
        self.update_header()
        self.apply_theme()
        if interactive and not self.session.prefs['setup_completed']:
            try:
                self.setup()
            except PreferencesError as error:
                self.provider_error(error)
                self.setProperty('shadow.status', 'Setup incomplete - saved settings retained')

    def check_storage(self):
        from .storage_diagnostic import diagnose_storage
        self.stop_playback()
        try:
            result = self.run_job('Checking isolated local storage - no provider connection...',
                                  lambda: diagnose_storage(self.profile))
            if result is not None:
                self.dialog.ok('Shadow ' + VERSION + ' - Storage diagnostic',
                               '\n'.join(label + ': ' + code for label, code in result) +
                               '\nAccount, login and permission checks only; other save features remain unverified. Send a photo.')
            else:
                self.dialog.ok('Shadow ' + VERSION + ' - Check cancelled',
                               'Storage check cancelled. No result was accepted. Saved settings were not changed.')
        except JobError as error:
            from .safe_errors import STORAGE_CODES
            code = getattr(error, 'code', None)
            code = code if isinstance(code, str) and code in STORAGE_CODES else 'S413'
            self.dialog.ok('Shadow ' + VERSION + ' - ' + code, safe_message(code))

    def check_hostname(self):
        from .dns_check import check_hostname, server_target
        from .safe_errors import SafeError
        self.dialog.ok('Hostname check - no login',
                       'Enter only your provider server address and optional port, not the full playlist link. Leave blank for local numeric checks only. No HTTP request or settings save is performed.')
        address = self.dialog.input('Server address only (blank = local checks)',
                                    type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
        try:
            server_target(address)
            result = self.run_job('Checking Python hostname lookup - no login...',
                                  lambda: check_hostname(address))
            if result is not None:
                self.dialog.ok('Shadow ' + VERSION + ' - Hostname check',
                               '\n'.join(label + ': ' + code for label, code in result) +
                               '\nSend this result screen. PASS means address lookup only; provider login and playback have not been tested.')
        except (SafeError, JobError) as error:
            code = 'D400' if type(error) is SafeError and error.code == 'D400' else 'D499'
            self.dialog.ok('Shadow ' + VERSION + ' - ' + code, safe_message(code))
        finally:
            address = None

    def is_playlist(self):
        return bool(self.session.connection and getattr(self.session.connection.client, 'is_m3u', False) is True)

    def connect_playlist(self, recover=False, temporary=False, retry=False):
        from .m3u import prepare_playlist
        if recover and (temporary is True or self.session.temporary):
            self.dialog.ok('Temporary test', 'There is no backup for temporary settings. Disconnect before using saved-settings recovery.')
            return
        if retry:
            if temporary is not True or recover:
                return
            saved = self.test_login.snapshot('m3u')
            if saved is None:
                return
            link, allow_http = saved
            saved = None
        else:
            link = self.dialog.input('Full M3U link - kept only for this session',
                                     type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
            if not link:
                return
            allow_http = self.dialog.yesno('Allow HTTP for this M3U session?',
                                           'HTTP playlist links and TV streams are unencrypted. Login details or tokens may be read or altered on the network. Choose No for HTTPS only. This choice is not saved.')
        if link.lower().startswith('http://') and not allow_http:
            self.dialog.ok('HTTP not enabled', 'Nothing was downloaded. Use an HTTPS link or import again and explicitly allow HTTP.')
            return
        if temporary is True:
            self.test_login.remember('m3u', (link, allow_http))
        else:
            self.test_login.clear()
        try:
            connection = self.run_job('Downloading and validating M3U channels...',
                                      lambda: prepare_playlist(self.profile, link, recover=recover, allow_http=allow_http, temporary=temporary), lambda c: c.close())
            if connection is not None:
                self.adopt_playlist(connection)
        except JobError as error:
            self.playlist_error(error)
        finally:
            link = None

    def playlist_error(self, error):
        code = getattr(error, 'code', None)
        from .safe_errors import MESSAGES
        code = code if isinstance(code, str) and code in MESSAGES else 'M399'
        message = safe_message(code)
        if self.test_login.kind:
            message += '\nUse Settings > Retry last connection to retry without typing. Forget test login disconnects and clears it.'
        self.dialog.ok('Shadow ' + VERSION + ' - M3U - ' + code, message)

    def adopt_playlist(self, connection):
        self.stop_playback()
        self.clear_guide()
        self.session.adopt(connection)
        self.demo = False
        counts = connection.client.counts
        summary = 'Loaded %s channel candidates. Actual MPEG-TS format is checked when you choose Watch. New channels are unselected.' % len(connection.channels)
        labels = [('http', 'HTTP'), ('hls_or_manifest', 'HLS/manifests'), ('other_format', 'other formats'),
                  ('unsafe', 'unsafe addresses'), ('player_options', 'special player options'),
                  ('malformed', 'malformed entries'), ('duplicate', 'duplicates')]
        excluded = ['%s %s' % (counts.get(key, 0), label) for key, label in labels if counts.get(key)]
        if excluded:
            summary += '\nExcluded: ' + ', '.join(excluded) + '.'
        summary += '\nGroups without a recognised language appear under Other. Playlist guide data is not supported yet.'
        self.dialog.ok('M3U imported', summary)
        self.after_connect()

    def refresh_playlist(self):
        if not self.is_playlist():
            self.dialog.ok('M3U', 'Import a playlist link first.')
            return
        self.stop_playback()
        client = self.session.connection.client
        try:
            connection = self.run_job('Refreshing M3U channels...', lambda: client.reconnect(self.profile), lambda c: c.close())
            if connection is not None:
                self.adopt_playlist(connection)
        except JobError as error:
            self.playlist_error(error)

    def apply_theme(self):
        theme = self.session.prefs['theme'] if self.session.prefs else 'obsidian'
        self.setProperty('shadow.background', 'FF191919' if theme == 'charcoal' else 'FF090909')

    def multiselect(self, title, labels, selected=()):
        if not labels:
            return []
        return self.dialog.multiselect(title, labels, preselect=list(selected))

    def choose_channels(self, current):
        from .selection import channels_for_groups
        grouped = self.session.languages()
        languages = sorted(grouped)
        indices = self.multiselect('Choose languages', languages)
        if indices is None:
            return None
        from .selection import canonical_language
        self.chosen_browse_languages=list(dict.fromkeys(canonical_language(languages[i]) for i in indices))
        groups = [g for i in indices for g in grouped[languages[i]]]
        indices = self.multiselect('Choose channel groups', [g['name'] for g in groups])
        if indices is None:
            return None
        candidates = channels_for_groups(self.session.channels, [groups[i] for i in indices])
        pages = [candidates[i:i+250] for i in range(0, len(candidates), 250)]
        draft = list(current)
        while pages:
            page_index = 0
            if len(pages) > 1:
                page_index = self.dialog.select('Choose a channel page', ['Review selection'] + ['Channels %s-%s' % (i*250+1, min((i+1)*250, len(candidates))) for i in range(len(pages))])
                if page_index < 0:
                    return None
                if page_index == 0:
                    break
                page_index -= 1
            page = pages[page_index]
            indices = self.multiselect('Approve channels', [c['name'] for c in page], [i for i,c in enumerate(page) if c['stream_id'] in draft])
            if indices is None:
                return None
            draft = update_filtered_selection(draft, page, [page[i]['stream_id'] for i in indices])
            if len(pages) == 1:
                break
        return draft

    def setup_cancelled(self):
        self.setProperty('shadow.status', 'Setup cancelled - saved settings retained')
        self.dialog.ok('Setup not completed', 'No setup changes were saved. Resume with Settings > Run setup wizard. If you exit, reconnect this provider to resume setup.')
        return False

    def setup(self):
        if not self.session.connected:
            return False
        types = ('live',) if self.is_playlist() else ('live','movies','series')
        labels = ['Live TV'] if self.is_playlist() else ['Live TV', 'Movies', 'Series']
        values = self.multiselect('Choose content', labels, [i for i,value in enumerate(types) if value in self.session.prefs['content_types']])
        if values is None or not values:
            return self.setup_cancelled()
        content = [types[i] for i in values]
        channels = self.choose_channels(self.session.prefs['approved_channel_ids']) if 'live' in content else []
        if channels is None:
            return self.setup_cancelled()
        theme = self.dialog.select('Appearance', ['Obsidian', 'Charcoal'])
        if theme < 0:
            return self.setup_cancelled()
        artwork = False if self.session.temporary else self.dialog.yesno('Programme artwork', 'Show artwork from TVmaze for series, Cinemeta for movies and your provider? Title searches go to these services; your login is never sent. Channel logos and title cards remain available.')
        review = ('Use %s explicitly approved channels for this temporary session? Selections are cleared on disconnect or exit.' if self.session.temporary else
                  'Save %s explicitly approved channels? You can change these in Settings > Manage Channels.')
        if not self.dialog.yesno('Review setup', review % len(channels)):
            return self.setup_cancelled()
        changes = {'browse_languages':self.chosen_browse_languages if 'live' in content else self.session.prefs.get('browse_languages'),'approved_channel_ids':channels,'content_types':content,'theme':('obsidian','charcoal')[theme], 'programme_artwork':artwork, 'setup_completed':True}
        while self.running:
            try:
                self.session.save(changes)
            except PreferencesConflict:
                self.dialog.ok('Settings changed', 'Another write changed the saved settings. Use Settings > Reload settings, then Run setup wizard. The draft was not saved over newer preferences.')
                self.setProperty('shadow.status', 'Setup incomplete - reload settings')
                return False
            except PreferencesError as error:
                self.provider_error(error)
                self.setProperty('shadow.status', 'Setup incomplete - save failed')
                if not self.dialog.yesno('Retry setup save', 'Retry saving these selections? Choose No to keep existing saved settings and return to Settings > Run setup wizard. No automatic reset or backup rollback will occur.'):
                    return False
            else:
                self.apply_theme()
                self.setProperty('shadow.status', 'Setup complete')
                return True
        return False

    def onClick(self, control):
        if self.playback_start_pending:
            return
        try:
            if 100 <= control <= 108:
                self.open_page(MENU[control-100])
            elif 200 <= control <= 203:
                self.open_page(SHORTCUTS[control-200])
            elif 620 <= control <= 623:
                index = control - 620
                if index < len(self.recent_channels):
                    self.watch(self.recent_channels[index])
                else:
                    self.open_page('Live TV')
            elif control == 210:
                if self.hero_channel:
                    self.watch(self.hero_channel['stream_id'])
                else:
                    self.open_page('Live TV')
            elif control == 211:
                self.open_page('Live TV')
            elif control in (212, 213):
                self.refresh_hero(step=-1 if control == 212 else 1)
            elif 600 <= control <= 603 or 610 <= control <= 613:
                kind = 'movies' if control < 610 else 'series'
                index = control - (600 if kind == 'movies' else 610)
                rows = self.recent_media[kind]
                if index < len(rows):
                    self.revisit_media(rows[index])
                else:
                    self.open_page('Movies' if kind == 'movies' else 'TV Series')
            elif control == 329:
                self.catalogue_view_options()
            elif 320 <= control <= 325:
                self.filter_catalogue(control)
            elif control in (327, 328):
                self.page_rows(-1 if control == 327 else 1)
            elif control in (420,421):
                kind = 'movies' if control == 420 else 'series'
                rows = self.watch_later_rows[kind]
                index = self.getControl(control).getSelectedPosition()
                if 0 <= index < len(rows):self.select_title(rows[index])
            elif control == 422:
                self.live_favourites = not self.live_favourites
                self.rows = self.session.visible(favourites=self.live_favourites)
                self.setProperty('shadow.live.filter', 'All channels' if self.live_favourites else 'Channel favourites')
                self.render_rows()
            elif control == 300:
                self.channel_action()
            elif control == 301:
                self.show_programme(force=True)
                if self.channel:
                    self.watch(self.channel['stream_id'])
        except PreferencesConflict:
            self.dialog.ok('Settings changed', 'Another window saved changes. Reload settings before trying again.')
        except (PreferencesError, JobError):
            self.dialog.ok('Shadow', 'The operation could not be completed. Existing saved selections were preserved.')
        except Exception:
            self.dialog.ok('Shadow', 'The operation could not be completed. Try reconnecting or reloading settings.')

    def onAction(self, action):
        if action.getId() == 117:
            self.channel_context()
            return
        if action.getId() in (9,10,13,92,216,247,257):
            if self.switch_state is not None:
                self.stop_playback()
                return
            if self._playback_return is not None:
                return  # Repeated Back during stop must not exit the add-on.
            if self.playback and self.playback.url:
                self.stop_playback()
                return
            if action.getId() == 13:
                return  # Stop without active playback must not navigate or exit.
            if self.page != 'Home':
                self.open_page('Home')
            else:
                self.shutdown()

    def remember_view(self):
        if self.page in ('Movies', 'TV Series', 'Search', 'Continue Watching', 'Live TV', 'Favourites', 'TV Guide'):
            self.view_states[self.page] = self.getControl(300).getSelectedPosition()

    def ensure_catalogue(self, kind, force=False):
        stamp = self.session.media_loaded.get(kind)
        if not force and stamp is not None and time.monotonic() - stamp < 1800:
            return True
        operation = None
        try:
            operation = self.session.media_request(kind)
            result = self.run_job('Loading collection...', operation)
            if result is not None:
                self.connection_failed = False
                return self.session.accept_media(result)
            self.dialog.ok('Collection cancelled', 'Loading was cancelled. Your existing collection and saved selections were kept. Open the collection or use Refresh catalogue to retry.')
            return stamp is not None
        except (JobError, ProviderError) as error:
            self.connection_failed = True
            code = provider_code(getattr(error, 'code', None))
            status = getattr(operation, 'collection_status', None)
            detail = safe_message(code, getattr(error, 'http_status', None))
            if status is not None:
                detail += '\n' + status.message()
            if stamp is not None:
                self.dialog.ok('Refresh unavailable - ' + code, detail + '\nShowing the previous catalogue. Use Refresh catalogue to try again.')
                return True
            self.dialog.ok('Catalogue unavailable - ' + code, detail + '\nOpen the collection again to retry.')
        return False

    def open_page(self, page):
        if page not in ('Watch Later','Settings'):
            self.cancel_watch_later_catalogues()
        self.remember_view()
        previous_page = self.page
        if page == 'Settings':
            self.settings()
            return
        if page != 'Home' and not self.session.connected:
            self.connect_provider()
            if not self.session.connected:
                return
        if self.is_playlist() and page in ('Movies', 'TV Series'):
            self.dialog.ok('M3U', 'This playlist build supports live channels. Movies and Series playback are not included.')
            return
        needed = 'movies' if page == 'Movies' else 'series' if page == 'TV Series' else 'live' if page in ('Live TV','TV Guide','Favourites') else None
        if needed and needed not in self.session.prefs['content_types']:
            self.dialog.ok('Shadow', 'Enable this content in Settings > Content types, or complete setup.')
            return
        self.clear_guide()
        self._row_batch = None
        self.page = page
        self.setProperty('shadow.page', page)
        self.setProperty('shadow.heading', page)
        if page == 'Home':
            if not self.session.connected:
                self.catalogue_rows = []
                self.catalogue_filters = {}
                self.catalogue_connection = None
            self.hero_identity = None
            self.refresh_hero()
            self.setFocusId(100)
            return
        if page == 'Watch Later':
            self.render_watch_later()
            return
        if page in ('Movies','TV Series'):
            kind = 'movies' if page == 'Movies' else 'series'
            if not self.ensure_catalogue(kind):
                self.page = previous_page
                self.setProperty('shadow.page', previous_page)
                self.setProperty('shadow.heading', previous_page)
                return
            if self.catalogue_connection is not self.session.connection:
                self.catalogue_filters = {}
                self.catalogue_connection = self.session.connection
            self.catalogue_rows = getattr(self.session,kind)
            self.apply_catalogue_filters()
        elif page == 'Search':
            scope = self.dialog.select('Search in', ['All content', 'Channels', 'Movies', 'Series'])
            if scope < 0:
                self.page = previous_page
                self.setProperty('shadow.page', previous_page)
                self.setProperty('shadow.heading', previous_page)
                return
            self.search_scope = scope
            self.search_query = self.dialog.input('Search', defaultt=self.search_query)[:100].strip()
            self.rows = self.search_results()
        elif page == 'Continue Watching':
            history = self.session.history
            self.continue_rows = sorted([row for kind in ('movies', 'series')
                if kind in self.session.prefs['content_types']
                for row in (history.recent(kind) if history else []) if not row['completed'] and row['position'] > 0],
                key=lambda row: row['updated'], reverse=True)
            self.rows = [item for item in (self.media_art_row(row) for row in self.continue_rows) if self.matches_browse_language(item)]
        else:
            self.rows = self.session.visible(favourites=page=='Favourites' or (page=='Live TV' and self.live_favourites))
            self.setProperty('shadow.live.filter', 'All channels' if self.live_favourites else 'Channel favourites')
        self.render_rows()
        self.setFocusId(300 if self.rows else 100+(MENU.index(page) if page in MENU else 1))

    def render_rows(self):
        self.browse_art_start = -1
        self.queue_browse_art()
        self.row_focus = None
        control = self.getControl(300)
        control.reset()
        # Keep list and scrollbar geometry in XML. Kodi 21 cannot expose an
        # XML scrollbar through Window.getControl ("Unknown control type").
        # The native list still scrolls through every row without page buttons.
        self.pending_row_selection = self.view_states.get(self.page, 0)
        self._row_batch = (self.rows, self.session.connection, 0)
        self.populate_rows()
        self.getControl(311).setText('Highlight a channel for its guide. Select to watch live.' if self.rows and self.page not in ('Movies','TV Series') else 'Select a title to view details.' if self.rows else 'No titles match. Use Search or Reset to change the filters.' if self.page in ('Movies', 'TV Series') else 'No items available. Use Settings to connect a provider or manage channels.')

    def populate_rows(self):
        """At most 250 native ListItems per GUI tick; no catalogue cutoff."""
        if self._row_batch is None:
            return
        rows, connection, start = self._row_batch
        if not self.running or self.rows is not rows or self.session.connection is not connection or self.page == 'Home':
            self._row_batch = None
            return
        end = min(start + 250, len(rows))
        self.getControl(300).addItems([xbmcgui.ListItem(label=self.row_label(row)) for row in rows[start:end]])
        if self.pending_row_selection is not None and (self.pending_row_selection < end or end == len(rows)):
            if rows:
                self.getControl(300).selectItem(min(self.pending_row_selection, len(rows)-1))
            self.pending_row_selection = None
        self._row_batch = (rows, connection, end) if end < len(rows) else None
        self.setProperty('shadow.list.count', '%s titles%s' % (len(rows), ' / loading list...' if end < len(rows) else '') if self.page in ('Movies', 'TV Series', 'Continue Watching', 'Search') else '%s channels' % len(rows))

    def catalogue_view_options(self):
        if self.page not in ('Movies','TV Series'):return
        state=self.catalogue_filters.setdefault(self.page,{})
        choice=self.dialog.select('Catalogue view',[
            'Hide watched: '+('On' if self.session.prefs.get('hide_watched') else 'Off'),
            'Recently added only: '+('On' if state.get('recent_only') else 'Off'),
            'Show all titles'])
        if choice==0:self.session.save({'hide_watched':not self.session.prefs.get('hide_watched',False)})
        elif choice==1:state['recent_only']=not state.get('recent_only',False)
        elif choice==2:
            self.session.save({'hide_watched':False});state['recent_only']=False
        else:return
        self.apply_catalogue_filters();self.render_rows()
        self.setFocusId(300 if self.rows else 329)

    def apply_catalogue_filters(self):
        from .catalogue import filter_rows
        state = self.catalogue_filters.setdefault(self.page, {})
        kind='movies' if self.page=='Movies' else 'series'
        state['hide_watched']=self.session.prefs.get('hide_watched',False)
        state['watched_ids']={row['id'] for row in self.catalogue_rows if self.is_title_watched(row)}
        state['recent_ids']=self.session.discovery.recent_ids(kind) if self.session.discovery else []
        self.setProperty('shadow.filter.view','View: '+('Recent' if state.get('recent_only') else 'All')+(' / Unwatched' if state['hide_watched'] else ''))
        state['language']=''
        state['languages']=list(self.session.prefs.get('browse_languages') or [])
        result = self.run_job('Filtering titles...', lambda: filter_rows(self.catalogue_rows, dict(state)))
        if result is not None:
            self.rows = result
        defaults = {'query': 'Search titles', 'language': 'All languages',
                    'genre': 'All genres', 'year': 'Any year', 'sort': 'Default order'}
        for key, default in defaults.items():
            value = ', '.join(state.get('languages',[])) if key=='language' else state.get(key, '')
            label = ('Search: ' + value if key == 'query' else
                     'Year: ' + value if key == 'year' else str(value)) if value else default
            if value == 'Not supplied':
                label = 'Unknown language' if key == 'language' else 'Unknown genre' if key == 'genre' else 'Unknown year'
            self.setProperty('shadow.filter.'+key, label[:23] + '...' if len(label) > 26 else label)
        count = len(self.rows)
        noun = 'title' if count == 1 else 'titles'
        filtered = bool(state.get('languages')) or any(state.get(key) for key in ('query', 'language', 'genre', 'year','recent_only','hide_watched'))
        self.setProperty('shadow.filter.summary',
                         ('No matching titles' if filtered else 'No titles available') if not count else
                         ('{:,} {} found'.format(count, noun) if filtered else 'All {:,} {}'.format(count, noun)))

    def filter_catalogue(self, control):
        if self.page not in ('Movies', 'TV Series') or self.session.connection is not self.catalogue_connection:
            return
        from .catalogue import options
        state = self.catalogue_filters.setdefault(self.page, {})
        if control == 325:
            state.clear()
            self.session.save({'hide_watched':False})
        elif control == 320:
            # Empty input clears the search; every filter remains local to this connection.
            state['query'] = self.dialog.input('Search '+self.page, defaultt=state.get('query', ''))[:100].strip()
        else:
            key = {321:'language', 322:'genre', 323:'year', 324:'sort'}[control]
            values = ['Provider order', 'Title A-Z', 'Newest first', 'Oldest first'] if key == 'sort' else ['All']+(self.run_job('Reading filter options...', lambda: options(self.catalogue_rows, key)) or [])
            choice = self.dialog.select({'language':'Language', 'genre':'Genre', 'year':'Release year', 'sort':'Sort titles'}[key], values)
            if choice < 0:
                return
            state[key] = '' if choice == 0 else values[choice]
            if key=='language':
                from .selection import canonical_language
                self.session.save({'browse_languages':[] if choice==0 else [canonical_language(values[choice])]})
        self.apply_catalogue_filters()
        self.render_rows()
        self.setFocusId(300 if self.rows else 320)

    def page_rows(self, direction):
        # Explicit mouse/controller paging as well as Kodi's native scrolling.
        # Wait for incremental population before selecting an uncreated item.
        if not self.rows:
            return
        control = self.getControl(300)
        target = max(0, min(len(self.rows)-1, control.getSelectedPosition()+direction*8))
        if self._row_batch and target >= self._row_batch[2]:
            self.populate_rows()
        control.selectItem(target)
        self.setFocusId(300)

    def channel_action(self):
        if self.page in ('Search', 'Continue Watching'):
            index = self.getControl(300).getSelectedPosition()
            if 0 <= index < len(self.rows):
                row = self.rows[index]
                if self.page == 'Continue Watching':
                    self.revisit_media(row)
                elif row.get('kind') in ('movies', 'series'):
                    self.select_title(row)
                else:
                    self.watch(row['stream_id'])
            return
        if self.page in ('Movies', 'TV Series'):
            index = self.getControl(300).getSelectedPosition()
            if 0 <= index < len(self.rows):
                self.select_title(self.rows[index])
            return
        index = self.getControl(300).getSelectedPosition()
        if 0 <= index < len(self.rows):
            self.watch(self.rows[index]['stream_id'])

    def channel_context(self):
        if self.page == 'Watch Later':
            control = self.getFocusId()
            if control in (420,421):
                kind = 'movies' if control==420 else 'series'
                index = self.getControl(control).getSelectedPosition()
                if 0<=index<len(self.watch_later_rows[kind]):self.toggle_watch_later(self.watch_later_rows[kind][index])
            return
        if self.page in ('Home', 'Movies', 'TV Series'):
            return
        choice = self.dialog.select('Channel options', ['Refresh programme guide', 'Stop playback'])
        if choice == 0:
            self.open_row(force=True)
        elif choice == 1:
            self.stop_playback()

    def playback_controller(self, prepared=None):
        media = getattr(prepared, 'media', None)
        is_vod = media is not None
        if prepared is not None and self.playback is not None and self._vod_controller != is_vod:
            self.playback.close()
            self.playback = None
        if self.playback is None:
            from .player_control import PlaybackController
            from .next_episode import make_player
            def item(url):
                value = xbmcgui.ListItem(label=self.playing_media['name'] if self.playing_media else 'Shadow Live TV', path=url)
                from .vod import MIMES
                value.setMimeType(MIMES.get(self.playing_media.get('extension'), 'application/octet-stream') if self.playing_media else 'video/mp2t')
                if self.playing_media and self.playing_media.get('resume', 0):
                    value.setProperty('StartOffset', str(self.playing_media['resume']))
                value.setContentLookup(False)
                value.setProperty('IsPlayable', 'true')
                return value
            from .vod_relay import VODRelay
            from .playback import PlaybackRelay
            self._vod_controller = is_vod
            self.playback = PlaybackController(
                make_player(xbmc.Player), item, relay_factory=VODRelay if is_vod else PlaybackRelay,
                stop_player=lambda: xbmc.executebuiltin('PlayerControl(Stop)', False), windowed=True)
        return self.playback

    def watch_later_identity(self,row):
        kind = row.get('kind')
        value = (row.get('series_id') or row.get('id')) if kind=='series' else row.get('id')
        return kind, str(value) if value is not None else ''

    def watch_later_label(self,row):
        kind,value = self.watch_later_identity(row)
        return 'Remove from Watch Later' if value in self.session.prefs.get('watch_later_'+kind,[]) else 'Add to Watch Later'

    def toggle_watch_later(self,row):
        kind,value = self.watch_later_identity(row)
        if kind not in ('movies','series') or not value:return
        key = 'watch_later_'+kind
        values = list(self.session.prefs.get(key,[]))
        if value in values:values.remove(value)
        elif len(values)>=1000:
            self.dialog.ok('Watch Later','This list is full. Remove a title before adding another.')
            return
        else:values.append(value)
        self.session.save({key:values})
        if self.page=='Watch Later':self.render_watch_later(load=False)

    def select_title(self,row):
        if row.get('kind')=='series' and not row.get('series_id'):
            choice = self.dialog.select(row['name'], ['Browse episodes',self.watch_later_label(row),self.watched_label(row)])
            if choice==1:self.toggle_watch_later(row)
            elif choice==2:self.toggle_watched(row)
            elif choice==0:self.choose_media(row)
        else:self.choose_media(row)

    def render_watch_later(self,load=True):
        focused = self.getFocusId()
        self._row_batch = None
        self.rows = []
        for kind,control in (('movies',420),('series',421)):
            enabled = kind in self.session.prefs['content_types'] and not self.is_playlist()
            saved = self.session.prefs.get('watch_later_'+kind,[])
            stamp = self.session.media_loaded.get(kind)
            if load and enabled and saved and (stamp is None or time.monotonic()-stamp>=1800) and kind not in self.watch_later_catalogue_jobs:
                self.watch_later_catalogue_errors.discard(kind)
                try:
                    job=self.watch_later_catalogue_runners[kind].submit(self.session.media_request(kind))
                    self.watch_later_catalogue_jobs[kind]=(self.session.connection,job)
                except JobError:self.watch_later_catalogue_errors.add(kind)
            by_id = {row['id']:row for row in getattr(self.session,kind)} if enabled else {}
            self.watch_later_rows[kind] = [by_id[value] for value in self.session.prefs.get('watch_later_'+kind,[]) if value in by_id]
            rows = self.watch_later_rows[kind]
            widget=self.getControl(control);position=widget.getSelectedPosition();widget.reset()
            widget.addItems([xbmcgui.ListItem(label=self.safe_text(row['name'])) for row in rows])
            if rows:widget.selectItem(max(0,min(position,len(rows)-1)))
            empty = ''
            if not rows:
                empty = ('Enable Movies in Settings > Content types.' if kind=='movies' else 'Enable TV Series in Settings > Content types.') if not enabled else ('No saved movies available. Select a movie and choose Add to Watch Later.' if kind=='movies' else 'No saved series available. Select a series and choose Add to Watch Later.')
            if enabled and saved and not rows:
                if kind in self.watch_later_catalogue_jobs:empty='Loading saved titles... You can keep browsing.'
                elif kind in self.watch_later_catalogue_errors:empty='Collection unavailable. Reopen Watch Later to retry. Your saved list is unchanged.'
            self.setProperty('shadow.watchlater.'+kind+'.empty', empty)
            self.watch_later_batches.pop(kind,None)
        self.setFocusId(focused if (not load and 100<=focused<=108) or (focused in (420,421) and self.watch_later_rows['movies' if focused==420 else 'series']) else 420 if self.watch_later_rows['movies'] else 421 if self.watch_later_rows['series'] else 105)
        self.watch_later_view_identity = (id(self.session.connection),self.session.prefs['revision'])
        self.poll_watch_later()

    def cancel_watch_later_catalogues(self):
        for connection,job in self.watch_later_catalogue_jobs.values():job.cancel()
        self.watch_later_catalogue_jobs.clear()
        self.watch_later_catalogue_errors.clear()

    def poll_watch_later_catalogues(self):
        changed=False
        for kind,(connection,job) in list(self.watch_later_catalogue_jobs.items()):
            if connection is not self.session.connection or kind not in self.session.prefs['content_types']:
                job.cancel();del self.watch_later_catalogue_jobs[kind];changed=True
            elif job.done.is_set():
                del self.watch_later_catalogue_jobs[kind]
                try:
                    result=job.take()
                    if result is not None:self.session.accept_media(result)
                except JobError:self.watch_later_catalogue_errors.add(kind)
                changed=True
        if changed:self.render_watch_later(load=False)

    def poll_watch_later(self):
        for kind,control in (('movies',420),('series',421)):
            loader=self.watch_later_loaders.get(kind)
            if not loader:continue
            rows=self.watch_later_rows[kind]
            start=max(0,self.getControl(control).getSelectedPosition()//6*6)
            identity=(id(self.session.connection),self.session.prefs['revision'],start,self.session.prefs['programme_artwork'])
            if self.watch_later_batches.get(kind)!=identity:
                self.watch_later_batches[kind]=identity
                images={str(index):self.media_art_row(row) for index,row in enumerate(rows[start:start+8],start)} if self.session.prefs['programme_artwork'] and not self.session.temporary else {}
                self.watch_later_tokens[kind]=loader.select(images)
            result=loader.poll()
            if result is not None and result[0]==self.watch_later_tokens.get(kind):
                for index,path in result[1].items():
                    try:self.getControl(control).getListItem(int(index)).setArt({'thumb':path})
                    except Exception:pass

    def is_title_watched(self,row):
        from .discovery import WatchedIndex,is_watched
        history=self.session.history
        if history and not isinstance(getattr(history,'rows',None),dict):
            return is_watched(row,self.session.prefs,history)
        prefs=self.session.prefs or {}
        key=(id(self.session.connection),prefs.get('provider_scope'),prefs.get('revision'),id(history),getattr(history,'generation',0))
        if self._watched_cache is None or self._watched_cache[0]!=key:
            self._watched_cache=(key,WatchedIndex(prefs,history))
        return self._watched_cache[1].contains(row)

    def watched_label(self,row):
        return 'Mark unwatched' if self.is_title_watched(row) else 'Mark watched'

    def toggle_watched(self,row):
        kind,value=self.watch_later_identity(row)
        if kind not in ('movies','series') or not value:return
        was=self.is_title_watched(row)
        key='watched_'+kind;values=list(self.session.prefs.get(key,[]))
        episode=kind=='series' and bool(row.get('series_id'))
        if was:values=[v for v in values if v!=value]
        elif not episode and value not in values:values.append(value)
        self.session.save({key:values})
        history=self.session.history
        if history:
            if episode:
                if was:history.remove(row)
                else:
                    old=history.find(row) or {};duration=old.get('duration') or 1
                    history.update(row,duration,duration,persist=True)
            else:
                for old in list(history.rows.values()):
                    if old['kind']==kind and (old.get('series_id') if kind=='series' else old['id'])==value:history.remove(old)
        self._recent_media_identity=None
        if self.page in ('Movies','TV Series'):
            self.apply_catalogue_filters();self.render_rows()

    def choose_media(self, row):
        if row['kind'] == 'series' and 'series_id' not in row:
            from .media import episodes_from_payload
            connection = self.session.connection
            payload = self.run_job('Reading seasons and episodes...', lambda: connection.client.series_info(row['id']))
            if payload is None or self.session.connection is not connection:
                return
            episodes = episodes_from_payload(payload, row)
            seasons = sorted({entry['season'] for entry in episodes})
            if not seasons:
                self.dialog.ok('Series', 'No episodes were supplied for this series.')
                return
            selected = self.dialog.select(row['name'] + ' - season', ['Season ' + str(number) for number in seasons])
            if not 0 <= selected < len(seasons):
                return
            episodes = [entry for entry in episodes if entry['season'] == seasons[selected]]
            selected = self.dialog.select('Choose episode', ['%s / %s' % (entry['episode'], entry['name']) for entry in episodes])
            if not 0 <= selected < len(episodes):
                return
            row = episodes[selected]
        history = self.session.history
        previous = history.find(row) if history else None
        resumable = previous and not previous['completed'] and previous['position'] > 0
        labels = ['Resume / %d minutes' % (previous['position'] // 60), 'Start over'] if resumable else ['Play again' if previous else 'Play']
        next_choice = None
        if row['kind'] == 'series' and row.get('series_id'):
            next_choice = len(labels)
            labels.append('Choose next episode')
        history_choice = len(labels) if previous else None
        if previous:
            labels.append('Remove from watch history')
        later_choice = len(labels)
        labels.append(self.watch_later_label(row))
        watched_choice=len(labels)
        labels.append(self.watched_label(row))
        selected = self.dialog.select(row['name'], labels)
        if selected < 0:
            return
        if next_choice is not None and selected == next_choice:
            self.choose_next_episode(row)
            return
        if selected == watched_choice:
            self.toggle_watched(row)
            return
        if selected == later_choice:
            self.toggle_watch_later(row)
            return
        if previous and selected == history_choice:
            history.remove(row)
            self.refresh_recent_media()
            return
        self.watch_media(row, previous['position'] if resumable and selected == 0 else 0)

    def find_next_episode(self, row, quiet=False):
        from .media import episodes_from_payload
        if not self.ensure_catalogue('series'):
            return
        series = next((s for s in self.session.series if s['id'] == row['series_id']), None)
        if series is None:
            self.dialog.ok('Series unavailable', 'Refresh the series catalogue and try again.')
            return
        connection = self.session.connection
        payload = self.run_job('Reading next episode...', lambda: connection.client.series_info(series['id']))
        if payload is None or connection is not self.session.connection:
            return
        episodes = episodes_from_payload(payload, series)
        position = next((i for i, item in enumerate(episodes) if item['id'] == row['id']), None)
        if position is None or position+1 >= len(episodes):
            if not quiet:self.dialog.ok('Next episode', 'No later episode was supplied by this provider.')
            return
        return episodes[position+1]

    def choose_next_episode(self,row):
        following=self.find_next_episode(row)
        if following:self.choose_media(following)

    def watch_media(self, row, resume=0):
        self.cancel_next_episode()
        from .media import prepare_media
        self.stop_playback()
        try:
            prepared = self.run_job('Preparing title...', lambda: prepare_media(self.session, row), dispose=lambda value: value.close())
        except JobError as error:
            self.playback_error(error)
            return
        if prepared is not None:
            if not getattr(prepared.source, 'seekable', True):
                if not self.dialog.yesno('Play from beginning?', 'This server does not support seeking. Resume and seeking are unavailable for this title. Try playing from the beginning?'):
                    prepared.close()
                    return
                resume = 0
            prepared.media['resume'] = resume
            self.begin_playback(prepared)

    def revisit_media(self, remembered):
        kind = remembered['kind']
        if not self.session.connected or kind not in self.session.prefs['content_types']:
            self.dialog.ok('Shadow', 'Connect this account and enable the content type first.')
            return
        if not self.ensure_catalogue(kind):
            return
        identity = remembered.get('series_id') if kind == 'series' else remembered['id']
        title = next((row for row in getattr(self.session, kind) if row['id'] == identity), None)
        if title is None:
            self.dialog.ok('Title unavailable', 'This title is no longer present in the account catalogue.')
            return
        if kind == 'series':
            from .media import episodes_from_payload
            connection = self.session.connection
            payload = self.run_job('Refreshing episode...', lambda: connection.client.series_info(identity))
            if payload is None or connection is not self.session.connection:
                return
            title = next((row for row in episodes_from_payload(payload, title) if row['id'] == remembered['id']), None)
            if title is None:
                self.dialog.ok('Episode unavailable', 'This episode is no longer present in the series.')
                return
        self.choose_media(title)

    def cancel_next_episode(self):
        self.next_end_pending=None
        countdown,self.next_countdown=self.next_countdown,None
        if countdown:
            try:countdown[2].close()
            except Exception:pass  # A dismissed native dialog must not prevent relay cleanup.

    def next_player_idle(self):
        # Automatic progression must not even cover unrelated Kodi media.
        if self.playback is None:return True
        try:return self.playback.player.isPlaying() is False
        except Exception:return False

    def poll_next_episode(self):
        from .next_episode import natural_end
        if self.next_countdown:
            row,connection,dialog,deadline=self.next_countdown
            if connection is not self.session.connection or not self.running or not (self.session.prefs or {}).get('autoplay_next',False) or 'series' not in (self.session.prefs or {}).get('content_types',[]) or not self.next_player_idle():
                self.cancel_next_episode();return
            seconds=max(0,int(deadline-time.monotonic()+.999))
            dialog.getControl(950).setText(self.safe_text(row.get('series_name',row['name']))+' / '+self.safe_text(row['name'])+'\nStarting in '+str(seconds)+' seconds')
            if dialog.decision is not None or seconds==0:
                play=dialog.decision is True or (dialog.decision is None and seconds==0)
                self.cancel_next_episode()
                if play:self.watch_media(row,0)
            return
        pending=self.next_end_pending
        if not pending:return
        row,connection,events,deadline=pending
        if connection is not self.session.connection or time.monotonic()>deadline or events['stopped'].is_set():
            self.next_end_pending=None;return
        if self.playback_hidden or self._playback_return is not None:return
        if not natural_end(events):return
        self.next_end_pending=None
        if not self.next_player_idle():return
        if not self.session.connected or 'series' not in self.session.prefs['content_types']:return
        try:following=self.find_next_episode(row,quiet=True)
        except (JobError,PreferencesError):
            self.dialog.ok('Next episode unavailable','The next episode could not be loaded. Your series progress is saved.');return
        if not following or connection is not self.session.connection:return
        if self.session.prefs.get('autoplay_next',False):
            dialog=NextEpisodeDialog('ShadowNext.xml',self.addon_path,'Default','1080i')
            dialog.show();self.next_countdown=(following,connection,dialog,time.monotonic()+10)
        elif self.dialog.yesno('Next episode',self.safe_text(following.get('series_name',''))+' / '+self.safe_text(following['name'])+'\nPlay the next episode?'):
            self.watch_media(following,0)

    def sample_media(self):
        if not self.playing_media or self.media_connection is not self.session.connection or not self.playback or not self.playback.url or time.monotonic() < self.media_next_sample:
            return
        self.media_next_sample = time.monotonic() + 1
        try:
            player = self.playback.player
            if not player.isPlaying() or player.getPlayingFile() != self.playback.url or not self.playback.permitted():
                return
            position, duration = player.getTime(), player.getTotalTime()
            import math
            if type(position) not in (int, float) or type(duration) not in (int, float) or not math.isfinite(position) or not math.isfinite(duration) or not 0 <= position <= duration or duration <= 0:
                return
            self.media_last_sample = (position, duration)
            history = self.session.history
            if history:
                persist = time.monotonic() >= self.media_saved_at
                history.update(self.playing_media, position, duration, persist=persist)
                if persist:
                    self.media_saved_at = time.monotonic() + 15
        except Exception:
            pass  # Never retain Kodi exception text or a playing URL.

    def finish_media(self):
        if self.playing_media and self.media_connection is self.session.connection and self.session.history:
            if self.media_last_sample:
                self.session.history.update(self.playing_media, *self.media_last_sample, persist=True)
        self.playing_media = self.media_connection = self.media_last_sample = None

    def queue_browse_art(self, index=0):
        if self.browse_artwork is None:
            return
        start = max(0,index)//8*8
        identity = (self.session.connection, self.rows, start)
        if (self.browse_art_connection is identity[0] and self.browse_art_rows is identity[1]
                and self.browse_art_start == start):
            return
        self.browse_art_connection,self.browse_art_rows,self.browse_art_start = identity
        images = {}
        if self.session.connected and not self.session.temporary and self.session.prefs['programme_artwork']:
            images = {str(i): self.media_art_row(self.rows[i]) for i in range(start,min(start+8,len(self.rows)))
                      if self.rows[i].get('kind') in ('movies','series')}
        self.browse_art_token = self.browse_artwork.select(images)

    def poll_browse_art(self):
        if self.browse_artwork is None:
            return
        result = self.browse_artwork.poll()
        if (result is None or result[0] != self.browse_art_token or
                self.session.connection is not self.browse_art_connection or self.rows is not self.browse_art_rows
                or not self.session.connected or self.session.temporary or not self.session.prefs['programme_artwork']):
            return
        for key,path in result[1].items():
            try:
                self.getControl(300).getListItem(int(key)).setArt({'thumb':path})
            except Exception:
                pass

    def media_art_row(self, row):
        kind = row.get('kind')
        if kind not in ('movies', 'series'):
            return row
        parent = (row.get('series_id') or row.get('id')) if kind == 'series' else row.get('id')
        catalogue = getattr(self.session, kind)
        entry = self.media_art_indexes.get(kind)
        if entry is None or entry[0] is not catalogue:
            entry = (catalogue, {item['id']: item for item in catalogue})
            self.media_art_indexes[kind] = entry
        metadata = entry[1].get(parent, {})
        result=dict(metadata, **row)
        from .catalogue import metadata as infer_metadata
        inferred=infer_metadata(row,row.get('series_name') or row.get('name',''))
        for key,value in inferred.items():
            if not result.get(key):result[key]=value
        result['artwork_key']='v2:%s:%s:%s' % ((self.session.prefs or {}).get('provider_scope',''),kind,parent) if parent is not None else ''
        return result

    def matches_browse_language(self,row):
        from .selection import canonical_language
        languages=(self.session.prefs or {}).get('browse_languages') or []
        return not languages or row.get('kind') not in ('movies','series') or canonical_language(row.get('language')) in languages

    def refresh_recent_media(self):
        history = self.session.history
        identity = (id(history), history.generation if history else None, history.error if history else None,
                    tuple(self.session.prefs['content_types']) if self.session.connected else (),
                    tuple(self.session.media_loaded.items()), tuple((self.session.prefs or {}).get('browse_languages') or []), (self.session.prefs or {}).get('programme_artwork', False), self.session.temporary)
        if identity == self._recent_media_identity:
            return
        self._recent_media_identity = identity
        poster_images = {}
        for kind in ('movies', 'series'):
            enabled = self.session.connected and kind in self.session.prefs['content_types']
            rows = history.recent(kind)[:4] if history and enabled else []
            catalogue = {r['id']: r for r in getattr(self.session, kind)}
            rows = [self.media_art_row(dict(row,kind=kind)) for row in rows]
            rows = [row for row in rows if self.matches_browse_language(row)]
            self.recent_media[kind] = rows
            for index in range(4):
                label, progress = ('Browse movies' if kind == 'movies' else 'Browse series'), ''
                percent = 0
                if index < len(rows):
                    row = rows[index]
                    label = row['name'] if kind == 'movies' else row['series_name'] + ' / S%d E%d' % (row['season'], row['episode'])
                    percent = 100 if row['completed'] else max(0, min(100, int(100 * row['position'] / row['duration'])))
                    progress = str(percent) + '%'
                key = kind + '.' + str(index)
                self.setProperty('shadow.poster.' + key, '')
                if index < len(rows) and self.session.prefs['programme_artwork'] and not self.session.temporary:
                    poster_images[key] = dict(rows[index], kind=kind)
                self.setProperty('shadow.' + kind + '.' + str(index), label)
                self.setProperty('shadow.' + kind + '.progress.' + str(index), progress)
                self.setProperty('shadow.' + kind + '.percent.' + str(index), str(percent))
            self.setProperty('shadow.' + kind + '.empty', '' if rows else 'Your recently watched titles will appear here')
        if self.poster_grid:
            self.poster_grid_token = self.poster_grid.select(poster_images)
        self.setProperty('shadow.history.status', history.error or '' if history else '')

    def watch(self, channel_id):
        from .playback import prepare_playback
        if self.demo:
            self.dialog.ok('Offline demo', 'Demo channel listings are not provider streams. Use Settings > Test local video and audio.')
            return
        self.stop_playback()
        try:
            prepared = self.run_job('Checking approved channel and stream...',
                                    lambda: prepare_playback(self.session, channel_id), lambda p: p.close())
        except JobError as error:
            if self.is_playlist():
                self.playlist_error(error)
                return
            self.playback_error(error)
            return
        if prepared is not None:
            self.arm_reconnect(channel_id)
            self.watching_channel = channel_id
            self.playing_channel = channel_id
            self.begin_playback(prepared)

    def playback_error(self, error, stage=None):
        from .safe_errors import playback_code, playback_stage, PLAYBACK_STAGES
        code = playback_code(getattr(error, 'code', None))
        label = PLAYBACK_STAGES[playback_stage(stage or getattr(error, 'stage', None))]
        if (code in ('N440', 'P461') and label == 'Stream' and self.session.connected and
                not self.demo and isinstance(self.session.connection.client, XtreamClient) and
                ((code == 'N440' and not self.session.connection.client._allow_stream_redirects) or
                 (code == 'P461' and not self.session.connection.client._allow_http_redirects))):
            self.configure_http_playback()
            return
        message = safe_message(code, getattr(error, 'http_status', None))
        attempts = getattr(error, 'reconnect_attempts', 0)
        if type(attempts) is int and 1 <= attempts <= 3:
            message += '\nAutomatic reconnect stopped after %d attempt(s). Select the channel to try again.' % attempts
        if code == 'P454':
            from .range_diagnostics import describe_range, clean_range
            details = clean_range(getattr(error, 'details', None))
            if details.get('reason') == 'http-status' and details.get('http_status') == 400:
                message = 'The provider rejected this movie or episode (HTTP 400).'
                if details.get('request_mode') == 'full-file':
                    message += ' A request without seeking was also rejected, so Play from beginning is unavailable.'
                else:
                    message += ' No playable media was returned. Play from beginning is available only when the provider supplies a valid stream.'
            detail = describe_range(details)
            if detail:
                message += '\n' + detail
        if code == 'N440' and not self.is_playlist() and label == 'Stream':
            message += '\nTo allow provider-directed stream redirects for this connection, use Settings > Connection options.'
        message += '\nYour connection and saved selections are unchanged.'
        if code in ('N441', 'X401', 'X402', 'X406'):
            self.connection_failed = True
            self.update_header()
        self.dialog.ok('Shadow ' + VERSION + ' - Playback - ' + label + ' - ' + code, message)

    def configure_connection(self):
        if not self.session.connected or self.demo or self.is_playlist():
            self.dialog.ok('Connection options', 'Connect an Xtream provider first.')
            return
        connection = self.session.connection
        options = self.connection_options(current=connection)
        if options is None:
            return
        self.stop_playback()
        if self.running and self.session.connection is connection:
            connection.client.set_stream_redirects(options['redirects'])
            connection.client.set_http_stream_redirects(options['http_redirects'])
            if self.permission_identity and self.permission_connection is connection and not self.session.temporary:
                try:
                    saved = self.connection_permissions.lookup(self.permission_identity)
                    if saved is not None:
                        saved.update({k: options[k] for k in ('redirects','http_redirects')})
                        self.connection_permissions.remember(self.permission_identity,saved)
                except LoginStorageError:
                    self.dialog.ok('Connection permissions', 'Choices apply now, but could not be remembered for reconnect.')

    def configure_http_playback(self):
        # Older entry points share the same consolidated screen.
        self.configure_connection()

    def begin_playback(self, prepared):
        privacy = getattr(self, 'privacy', None)
        if privacy is None and self.session.prefs.get('privacy_channel_id'):
            from .privacy import Privacy
            self.privacy = privacy = Privacy(self)
        if privacy is not None:
            privacy.arm()
        self.clear_guide()
        self.close_overlay()
        self.osd_latched = False
        try:
            self.connection_failed = False
            self.remember_view()
            self.return_page = self.page
            self.playing_media = getattr(prepared, 'media', None)
            self.media_connection = self.session.connection if self.playing_media else None
            self.media_last_sample = None
            self.media_next_sample = 0
            controller = self.playback_controller(prepared)
            self._playback_return = None
            self.last_playback_return = {}
            # Keep the opaque Shadow window over Kodi while the player buffers.
            # Yield through the normal tick loop; hand focus over only once playing.
            self.playback_hidden = True
            self.playback_start_pending = True
            self.fullscreen_requested = False
            self.cover_handoff_deadline = 0
            self.handoff_next_attempt = 0
            self.handoff_attempts = 0
            self.busy_close_requests = 0
            self.busy_next_close = 0
            self.handoff_deadline = time.monotonic() + 8
            self.subtitles_initialized = False
            self.setProperty('shadow.loading', 'true')
            self.show_loading_cover()
            controller.start(prepared)
        except Exception:
            prepared.close()
            if privacy is not None and privacy.state:
                privacy.fail('Privacy target could not start. The privacy shortcut returns; B exits.')
                return
            self.stop_playback()
            self.dialog.ok('Playback unavailable', 'Local playback could not start. No direct provider fallback was attempted.')

    def show_loading_cover(self):
        privacy = getattr(self, 'privacy', None)
        if privacy is not None and privacy.state:
            privacy.show_cover()
            return
        if self.loading_cover is None:
            self.loading_cover = LoadingCover('ShadowLoading.xml', self.addon_path, 'Default', '1080i')
            self.loading_cover.show()

    def close_loading_cover(self):
        cover, self.loading_cover = self.loading_cover, None
        if cover is not None:
            cover.close()

    def initialize_media_subtitles(self):
        if self.playing_media and not self.subtitles_initialized:
            try:
                self.playback.player.showSubtitles(bool((self.session.prefs or {}).get('subtitles_default', False)))
                self.subtitles_initialized = True
                language = (self.session.prefs or {}).get('audio_language', '')
                if language:
                    streams = self.playback.player.getAvailableAudioStreams()
                    code = {'English':'eng', 'French':'fra', 'German':'deu', 'Spanish':'spa', 'Italian':'ita', 'Portuguese':'por'}.get(language, '')
                    selected = next((i for i, name in enumerate(streams) if language.casefold() in str(name).casefold() or (code and str(name).casefold() == code)), None)
                    if selected is not None:
                        self.playback.player.setAudioStream(selected)
                self.subtitles_initialized = True
            except Exception:
                pass  # Retry after streams become available, not after success.

    def dismiss_startup_busy(self):
        if not self.playback_start_pending or not self.playback or not self.playback.url:
            return
        now = time.monotonic()
        if now < self.busy_next_close:
            return
        try:
            player = self.playback.player
            # Empty/not-yet-playing is our pending start. A different active item
            # belongs to somebody else and must retain its dialogs.
            if player.isPlaying() and player.getPlayingFile() != self.playback.url:
                return
            self.busy_next_close = now + .2
            for name in ('busydialog', 'busydialognocancel'):
                if xbmc.getCondVisibility('Window.IsVisible(%s)' % name):
                    xbmc.executebuiltin('Dialog.Close(%s,true)' % name, False)
                    self.busy_close_requests += 1
        except Exception:
            pass

    def update_playback_clock(self):
        if not self.playback or not self.playback.started or self.playback_start_pending:
            return
        try:
            if self.playback_clock is None:
                if xbmc.getSkinDir() != 'skin.estuary':
                    return
                from .playback_clock import PlaybackClock
                self.playback_clock = PlaybackClock(xbmcgui, self.addon_path)
            self.playback_clock.update(self.playback.player)
        except Exception:
            pass  # Skin differences must never stop the video.

    def clear_playback_clock(self):
        if self.playback_clock is not None:
            self.playback_clock.close()
            self.playback_clock = None

    def dismiss_owned_playback_busy(self):
        # Do not touch a native dialog while another player/item owns the screen.
        try:
            player = self.playback.player
            if not self.playback.url or player.getPlayingFile() != self.playback.url or not player.isPlayingVideo():
                return False
        except Exception:
            return False
        # These are Kodi's playback busy indicators, never all dialogs or progress.
        # Limit retries so a broken native state cannot cause a command flood.
        if self.busy_close_requests < 12:
            for name in ('busydialog', 'busydialognocancel'):
                if xbmc.getCondVisibility('Window.IsVisible(%s)' % name):
                    xbmc.executebuiltin('Dialog.Close(%s,true)' % name, False)
                    self.busy_close_requests += 1
        return True

    def complete_playback_handoff(self):
        self.initialize_media_subtitles()
        if self.loading_cover is not None:
            now = time.monotonic()
            if not self.cover_handoff_deadline:
                self.cover_handoff_deadline = now + 8
            if now > self.cover_handoff_deadline:
                self.stop_playback()
                self.dialog.ok('Playback screen unavailable',
                    'The video screen did not become ready. Playback was stopped. Please retry.')
                return
            if self.dismiss_owned_playback_busy() and not any(
                    xbmc.getCondVisibility('Window.IsVisible(%s)' % name)
                    for name in ('busydialog', 'busydialognocancel')):
                self.close_loading_cover()
            return  # Always yield through the modal close before fullscreen.

        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            self.dismiss_owned_playback_busy()
            self.playback_start_pending = False
            self.setProperty('shadow.loading', '')
            return
        now = time.monotonic()
        if not self.fullscreen_requested:
            self.fullscreen_requested = True
            self.handoff_deadline = now + 8
        if now > self.handoff_deadline:
            # Numeric window IDs and booleans only; never capture playing URLs.
            self.last_handoff = {'attempts': self.handoff_attempts,
                                 'busy_close_requests': self.busy_close_requests}
            self.stop_playback()
            self.dialog.ok('Playback screen unavailable',
                'Kodi could not switch to the video screen. Playback was stopped. '
                'Fullscreen requests: %d; busy-indicator close requests: %d. '
                'Please report these counts.' % (self.last_handoff['attempts'], self.last_handoff['busy_close_requests']))
            return
        if now < self.handoff_next_attempt:
            return
        self.handoff_next_attempt = now + .5
        if not self.dismiss_owned_playback_busy():
            return  # Audio alone or a replaced player is not enough to take over.
        # Use Kodi's native video-screen action after requesting busy-dialog close.
        # A refused activation is retried on a later tick, not assumed complete.
        if not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            xbmc.executebuiltin('Action(FullScreen)', False)
            self.handoff_attempts += 1

    def close_overlay(self):
        if self.overlay is not None:
            self.overlay.dismiss()

    def poll_overlay(self):
        # Observe Kodi's native OSD. Optional privacy adds only a temporary selected-button
        # mapping and a short-lived intent dispatcher; no skin/service change.
        privacy = getattr(self, 'privacy', None)
        if privacy is not None and privacy.state:
            return
        visible = xbmc.getCondVisibility('Window.IsVisible(videoosd)')
        if not visible:
            self.osd_latched = False
        if self.overlay and self.overlay.active:
            self.overlay.tick()
            return
        if (visible and not self.osd_latched and self.playback.started and
                self.playing_channel and self.session.connected):
            self.osd_latched = True
            try:
                self.session.ensure_current()
                if self.playing_channel not in self.session.prefs['approved_channel_ids']:
                    return
                if self.overlay is None:
                    self.overlay = ChannelOverlay('ShadowChannels.xml', self.addon_path, 'Default', '1080i')
                self.overlay.privacy_request = privacy.request if privacy is not None and privacy.enabled else None
                self.overlay.privacy_actions = (18, 34) if self.session.prefs.get('privacy_button', 'y') == 'y' else ()
                self.overlay.font_coverage = self.font_coverage
                self.overlay.prepare(self.session, self.playing_channel)
                xbmc.executebuiltin('Dialog.Close(videoosd)', False)
                self.overlay.active = True
                self.overlay.show()
            except Exception:
                # If a skin/runtime cannot open the overlay, retain playback and
                # let the user access Kodi's native controls.
                self.close_overlay()
                xbmc.executebuiltin('ActivateWindow(videoosd)', False)

    def poll_overlay_action(self):
        if self.overlay is None:
            return
        event = self.overlay.event
        self.overlay.event = None
        if event is None:
            return
        kind, value, connection = event
        if connection is not self.session.connection:
            return
        if kind == 'stop':
            self.close_overlay()
            self._overlay_stop_pending = connection
            return True  # Yield once after the modal close before requesting Stop.
        elif kind == 'switch':
            try:
                self.request_switch(value)
            except PreferencesError:
                self.stop_playback()
            return True  # Let Kodi process chooser dismissal and queued Stop first.

    def arm_reconnect(self, channel_id):
        from .live_reconnect import RetryBudget
        self.reconnect_context = None
        if (self.session.connected and not self.demo and
                self.session.prefs.get('auto_reconnect_live') is True):
            self.reconnect_context = {'connection': self.session.connection,
                                      'channel': channel_id,
                                      'revision': self.session.prefs['revision'],
                                      'budget': RetryBudget()}

    def schedule_reconnect(self, error, old_url, preparing=False):
        privacy = getattr(self, 'privacy', None)
        if privacy is not None and privacy.state:
            return False
        context = getattr(self, 'reconnect_context', None)
        if (not context or not self.running or self.playing_media or self.demo or
                self.session.connection is not context['connection']):
            return False
        try:
            self.session.ensure_current()
            prefs = self.session.prefs
            if (prefs.get('auto_reconnect_live') is not True or
                    prefs['revision'] != context['revision'] or
                    'live' not in prefs['content_types'] or
                    context['channel'] not in prefs['approved_channel_ids']):
                return False
        except PreferencesError as storage_error:
            from .safe_errors import playback_code
            error.code, error.stage = playback_code(storage_error.code), 'approval'
            error.http_status = None
            return False
        events = getattr(self.playback.player, 'shadow_events', None)
        if (not preparing and isinstance(events, dict) and
                events.get('stopped') is not None and events['stopped'].is_set()):
            return False
        delay = context['budget'].next_delay(error)
        if delay is None:
            return False
        self.cancel_switch()
        self.close_overlay()
        self.close_loading_cover()
        self.clear_playback_clock()
        self._playback_return = None
        self.setProperty('shadow.loading', 'true')
        self.switch_state = {'connection': context['connection'], 'channel': context['channel'],
                             'old_url': old_url, 'deadline': time.monotonic()+delay+30,
                             'retry_at': time.monotonic()+delay,
                             'retry_attempt': context['budget'].attempts,
                             'job': None, 'phase': 'stopping'}
        return True

    def update_reconnect_status(self, state):
        if self.loading_cover is not None and state.get('retry_attempt'):
            import math
            seconds = max(0, math.ceil(state['retry_at']-time.monotonic()))
            message = ('Reconnecting Live TV - attempt %d of 3' % state['retry_attempt'])
            message += (' in %d seconds' % seconds) if seconds else ' - checking stream'
            self.loading_cover.setProperty('shadow.reconnect.status', message)

    def request_switch(self, channel_id):
        if (self.switch_state is not None or not self.running or not self.session.connected or
                not self.playback or not self.playback.url):
            return
        self.session.ensure_current()
        if channel_id not in {row['stream_id'] for row in self.session.visible()}:
            return
        if channel_id == self.playing_channel:
            self.close_overlay()
            return
        self.arm_reconnect(channel_id)
        old_url = self.playback.url
        self.close_overlay()
        self.clear_playback_clock()
        self.setProperty('shadow.loading', 'true')
        # Opening any Shadow window during native teardown can stall Kodi.
        # Revoke and queue Stop now; poll_switch opens the cover only after idle.
        self.playback.stop()
        self._playback_return = None
        self.switch_state = {'connection': self.session.connection, 'channel': channel_id,
                             'old_url': old_url, 'deadline': time.monotonic()+30, 'job': None, 'phase': 'stopping'}

    def cancel_switch(self):
        state, self.switch_state = self.switch_state, None
        if state and state['job'] is not None:
            state['job'].cancel()
        self.switch_jobs.close()

    def poll_switch(self):
        from .playback import prepare_playback
        state = self.switch_state
        if state is None:
            return
        prepared = None
        try:
            if not self.running or self.session.connection is not state['connection']:
                self.cancel_switch()
                self.return_from_playback()
                return
            self.session.ensure_current()
            if ('live' not in self.session.prefs['content_types'] or
                    state['channel'] not in self.session.prefs['approved_channel_ids']):
                raise PreferencesConflict('Channel approval changed')
            if state.get('retry_attempt'):
                context = self.reconnect_context
                if (context is None or self.session.prefs.get('auto_reconnect_live') is not True or
                        self.session.prefs['revision'] != context['revision']):
                    raise PreferencesConflict('Reconnect approval changed')
            if time.monotonic() >= state['deadline']:
                error = JobError('Channel switch timed out')
                error.code, error.stage = ('P482', 'preparation') if state.get('retry_attempt') and state['phase'] == 'stopping' else ('N409', 'stream')
                raise error
            # Check both before preparation and immediately before handoff.
            # A query error is not permission to replace another Kodi player.
            try:
                playing = (self.playback.player.getPlayingFile()
                           if self.playback.player.isPlaying() else None)
            except Exception:
                raise JobError('Player state is unavailable') from None
            if playing is not None and playing != state['old_url']:
                self.cancel_switch()
                self.return_from_playback()
                return
            if state['phase'] == 'stopping':
                if not self.playback.return_ready() or playing is not None:
                    return
                self.show()
                self.show_loading_cover()
                self.update_reconnect_status(state)
                state['phase'] = 'preparing'
                return  # Yield after native window activation before starting work.
            self.update_reconnect_status(state)
            if time.monotonic() < state.get('retry_at', 0):
                return
            if state['job'] is None:
                if not self.playback.return_ready():
                    return
                active = self.switch_jobs.active
                if active is not None and not active.done.is_set():
                    return
                state['job'] = self.switch_jobs.submit(
                    lambda: prepare_playback(self.session, state['channel'], expected_connection=state['connection']),
                    lambda value: value.close())
                return
            if not state['job'].done.is_set():
                return
            if playing is not None:
                return
            prepared = state['job'].take()
            self.switch_state = None
            if prepared is not None:
                if not prepared.permitted():
                    raise PreferencesConflict('Channel approval changed')
                self.watching_channel = self.playing_channel = state['channel']
                self.begin_playback(prepared)
                prepared = None  # The controller now owns disposal.
            else:
                self.return_from_playback()
        except Exception as error:
            if prepared is not None:
                try:
                    prepared.close()
                except Exception:
                    pass
            self.cancel_switch()
            if isinstance(error, PreferencesError):
                error = JobError('Channel approval changed')
                error.code, error.stage = 'P401', 'approval'
            if state.get('retry_attempt') and self.schedule_reconnect(error, state['old_url'], preparing=True):
                return
            self.return_from_playback(failed=True, error=error)

    def test_playback(self):
        from .playback import PreparedPlayback
        from .streaming import LocalSample
        import xbmcaddon
        choice = self.dialog.select('Synthetic local test - no provider needed', ['Test channel 1 - colour bars and tone', 'Test channel 2 - blue screen and tone'])
        if choice < 0:
            return
        self.stop_playback()
        path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'test-media', 'channel-%s.ts' % (choice+1))
        try:
            self.begin_playback(PreparedPlayback(LocalSample(path), lambda: self.running))
        except Exception:
            self.dialog.ok('Local test unavailable', 'Check the installation package. Provider details are not needed for this test.')

    def stop_playback(self):
        privacy = getattr(self, 'privacy', None)
        if privacy is not None and privacy.state:
            privacy.exit()
            return
        if privacy is not None:
            privacy.disarm()
        self.reconnect_context = None
        self.cancel_next_episode()
        self.sample_media()
        self.finish_media()
        self.cancel_switch()
        self._overlay_stop_pending = None
        self.close_loading_cover()
        self.close_overlay()
        self.watching_channel = self.playing_channel = None
        if self.playback:
            self.playback.stop()  # Revoke sockets before any modal close/animation.
        self.close_overlay()
        self.return_from_playback()

    def return_from_playback(self, failed=False, error=None):
        privacy = getattr(self, 'privacy', None)
        if privacy is not None and privacy.state:
            privacy.fail('Privacy playback ended. The privacy shortcut returns to previous content; B exits.')
            return
        if privacy is not None:
            privacy.disarm()
        context = getattr(self, 'reconnect_context', None)
        retry_count = context['budget'].attempts if context else 0
        self.reconnect_context = None
        self.close_loading_cover()
        self.clear_playback_clock()
        self.finish_media()
        self.close_overlay()
        # Schedule only. In 0.0.22 show() immediately after queued Stop took
        # 29,121 ms on the Mac. Let the outer loop yield and Kodi finish stopping
        # before reopening the modal window; no worker calls any Kodi API.
        if self.playback_hidden and self.running:
            if self._playback_return is None:
                self._playback_return = {'begun': time.monotonic(), 'failed': failed,
                                         'checks': 0, 'check_ms': 0}
            elif failed:
                self._playback_return['failed'] = True
            if error is not None:
                # Retain allowlisted fields only, never the exception/traceback.
                from .live_reconnect import diagnostic
                self._playback_return['error'] = diagnostic(error)
                self._playback_return['reconnect_attempts'] = retry_count

    def poll_playback_return(self):
        pending = self._playback_return
        if pending is None or not self.running:
            return
        checked = time.monotonic()
        ready = self.playback is None or self.playback.return_ready()
        pending['checks'] += 1
        pending['check_ms'] = max(pending['check_ms'], round((time.monotonic()-checked)*1000))
        if not ready:
            return
        self._playback_return = None
        begun = time.monotonic()
        self.show()
        shown = time.monotonic()
        self.playback_hidden = False
        self.playback_start_pending = False
        self.setProperty('shadow.loading', '')
        if self.return_page == 'Search':
            self.page = 'Search'
            self.rows = self.search_results()
            self.setProperty('shadow.page', 'Search')
            self.render_rows()
            self.setFocusId(300 if self.rows else 107)
        else:
            self.open_page(self.return_page)
        self.last_playback_return = {
            'wait_ms': round((begun-pending['begun'])*1000),
            'checks': pending['checks'], 'check_ms': pending['check_ms'],
            'show_ms': round((shown-begun)*1000),
            'home_ms': round((time.monotonic()-shown)*1000),
        }
        if pending.get('error'):
            error = JobError('Playback could not be prepared')
            error.code, error.stage, error.http_status = pending['error']
            error.reconnect_attempts = pending.get('reconnect_attempts', 0)
            self.playback_error(error)
        elif pending['failed']:
            self.dialog.ok('Playback ended', 'The stream failed, timed out or its approval changed. You can reconnect and try again.')

    def playback_exit_diagnostics(self):
        timing = self.playback.last_stop if self.playback else None
        if timing is None:
            self.dialog.ok('Shadow ' + VERSION + ' - Playback exit timing', 'No playback exit measured in this Shadow session.')
            return
        returned = getattr(self, 'last_playback_return', {})
        self.dialog.ok('Shadow ' + VERSION + ' - Playback exit timing',
                       'Ownership check: %d ms; relay revoke: %d ms\n'
                       'Stop request: %d ms; stop total: %d ms\n'
                       'Show window: %s ms; build Home: %s ms\n'
                       'Wait for player: %s ms; checks: %s; longest check: %s ms\n'
                       'Owned: %s; stop requested: %s\n'
                       'Playing observed: %s; fullscreen observed: %s\n'
                       'Local timings only; excludes key delivery and native stop completion.' % (
                           timing['ownership_ms'], timing['relay_ms'], timing['request_ms'], timing['total_ms'],
                           returned.get('show_ms', 'not measured'), returned.get('home_ms', 'not measured'),
                           returned.get('wait_ms', 'not measured'), returned.get('checks', 'not measured'), returned.get('check_ms', 'not measured'),
                           timing['owned'], timing['requested'], timing['started'], timing['fullscreen_seen']))

    def clear_guide(self):
        if self.guide_job is not None:
            self.guide_job.cancel()
            self.guide_job = None
        self.guide_retry_at = 0
        self.hero_token = None
        self.poster_token = None
        self.poster_row = None
        self.overview_token = None
        self.channel = None
        self.programmes = []
        self.last_programme = None
        if self.artwork:
            self.art_token = self.artwork.select({}, {}, [])
        self.setProperty('shadow.artwork', '')
        self.setProperty('shadow.programme', '')
        self.setProperty('shadow.time', '')
        self.getControl(301).reset()
        self.getControl(311).setText('')

    def open_row(self, force=False):
        index = self.getControl(300).getSelectedPosition()
        if not 0 <= index < len(self.rows):
            return
        row = self.rows[index]
        if self.page in ('Movies','TV Series'):
            self.setProperty('shadow.programme', row['name'])
            self.getControl(311).setText(self.safe_text(row['plot'], True) if row['plot'] else 'No description supplied. Select this title to play or browse episodes.')
            return
        self.clear_guide()
        self.channel = row
        try:
            result = self.run_job('Reading programme guide...', self.session.epg_request(row['stream_id'], force=force))
        except JobError as error:
            self.playback_error(error, stage='guide')
            self.getControl(311).setText('Programme information is unavailable. Select the channel to watch live.')
            return
        if result is not None and self.session.accept_epg(result):
            self.programmes = self.session.epg.get(row['stream_id'], [])
        self.render_guide()
        if self.programmes:
            self.getControl(301).selectItem(0)
            self.show_programme(force=True)
            self.setFocusId(301)
        else:
            self.setProperty('shadow.programme', row['name'])
            self.getControl(311).setText('Programme information is currently unavailable.')

    def render_guide(self):
        now = time.time()
        self.programmes = [p for p in self.programmes if p['end'] > now]
        self.getControl(301).reset()
        self.getControl(301).addItems([xbmcgui.ListItem(label=
            ('NOW  ' if p['start'] <= now < p['end'] else '') +
            self.time_label(p['start']) + '-' + self.time_label(p['end']) + '  ' + self.safe_text(p['title']))
            for p in self.programmes])
        self.last_programme = None

    def refresh_guide_background(self):
        if self.guide_job is not None:
            if not self.guide_job.done.is_set():
                return
            job, self.guide_job = self.guide_job, None
            try:
                result = job.take()
                if result is not None and self.session.accept_epg(result) and self.channel and result[1] == self.channel['stream_id']:
                    self.programmes = result[2]
                    self.render_guide()
                    if self.programmes:
                        self.show_programme(force=True)
                    else:
                        self.getControl(311).setText('No programme information supplied. Watch live is still available.')
            except JobError:
                # Keep any cached listings; avoid repeated error popups/retries.
                self.guide_retry_at = time.monotonic() + 300
                self.getControl(311).setText('Guide refresh unavailable. Showing cached listings; retry in five minutes or refresh manually.')
            return
        if (self.channel and self.page not in ('Home', 'Movies', 'TV Series') and
                time.monotonic() >= self.guide_retry_at and
                not self.session.epg_fresh(self.channel['stream_id'])):
            active = self.guide_runner.active
            if active is None or active.done.is_set():
                self.guide_job = self.guide_runner.submit(self.session.epg_request(self.channel['stream_id'], force=True))

    def refresh_hero(self, step=0):
        self.refresh_recent_media()
        connection = self.session.connection
        identity = (id(connection), self.session.prefs['revision'] if connection else None)
        if not step and identity == self.hero_identity and time.monotonic() < self.hero_next:
            return
        rows = self.session.visible() if connection and 'live' in self.session.prefs['content_types'] else []
        by_id = {r['stream_id']: r for r in rows}
        self.recent_channels = [i for i in self.recent_channels if i in by_id]
        recent = set(self.recent_channels)
        rows = [by_id[i] for i in self.recent_channels] + [r for r in rows if r['stream_id'] not in recent]
        self.hero_identity = identity
        self.hero_next = time.monotonic() + 8
        self.hero_index = (self.hero_index + step) % len(rows) if rows else 0
        self.hero_channel = rows[self.hero_index] if rows else None
        self.setProperty('shadow.hero.artwork', '')
        self.hero_token = None
        self.refresh_recent_art(by_id)
        for index in range(4):
            name = by_id[self.recent_channels[index]]['name'] if index < len(self.recent_channels) else ''
            initials = ''.join(word[0] for word in name.split()[:2]).upper()
            self.setProperty('shadow.recent.initial.'+str(index), initials)
            self.setProperty('shadow.recent.'+str(index), by_id[self.recent_channels[index]]['name'] if index < len(self.recent_channels) else '')
        self.setProperty('shadow.recent.empty', '' if self.recent_channels else 'Your recently watched channels will appear here')
        if not self.hero_channel:
            self.setProperty('shadow.hero.eyebrow', 'LIVE TV')
            self.setProperty('shadow.hero.title', 'Choose something to watch')
            self.setProperty('shadow.hero.subtitle', 'Connect your provider and select your channels to get started.')
            self.setProperty('shadow.hero.description', '')
            self.setProperty('shadow.hero.position', '')
            return
        channel = self.hero_channel
        programmes = self.session.epg.get(channel['stream_id'], [])
        now = time.time()
        programme = next((p for p in programmes if p['start'] <= now < p['end']), {})
        self.setProperty('shadow.hero.eyebrow', 'RECENTLY WATCHED / LIVE NOW' if channel['stream_id'] in recent else 'FROM YOUR CHANNELS')
        self.setProperty('shadow.hero.title', programme.get('title') or channel['name'])
        self.setProperty('shadow.hero.subtitle', channel['name'] if programme else 'Watch the current live broadcast')
        self.setProperty('shadow.hero.description', programme.get('description', '')[:220])
        self.setProperty('shadow.hero.position', str(self.hero_index+1)+' / '+str(len(rows)))
        if self.artwork and not self.session.temporary:
            self.hero_token = None  # Carousel is intentionally disabled; recent-title rows remain active.

    def refresh_recent_art(self, by_id):
        channels = [by_id[i] for i in self.recent_channels[:4]]
        now = time.time()
        programmes = [next((p for p in self.session.epg.get(c['stream_id'], [])
                            if p['start'] <= now < p['end']), {}) for c in channels]
        prefs = self.session.prefs or {}
        identity = (id(self.session.connection), tuple(c['stream_id'] for c in channels),
                    tuple((c.get('name'), c.get('stream_icon'), c.get('epg_channel_id')) for c in channels), prefs.get('programme_artwork', False),
                    tuple(prefs.get('approved_channel_ids', [])), self.session.temporary)
        if identity == self.recent_art_identity:
            return
        self.recent_art_identity = identity
        for index, loader in enumerate(self.recent_artwork):
            self.setProperty('shadow.recent.art.' + str(index), '')
            channel = channels[index] if index < len(channels) else {}
            programme = programmes[index] if index < len(programmes) else {}
            self.recent_art_tokens[index] = loader.select(
                {}, channel if not self.session.temporary else {},
                prefs.get('approved_channel_ids', []), prefs.get('programme_artwork', False))

    def poll_recent_art(self):
        for index, loader in enumerate(self.recent_artwork):
            result = loader.poll()
            if result is None or result[0] != self.recent_art_tokens[index]:
                continue
            self.session.ensure_current()
            if (self.session.connected and not self.session.temporary and index < len(self.recent_channels) and
                    self.recent_channels[index] in self.session.prefs['approved_channel_ids']):
                self.setProperty('shadow.recent.art.' + str(index), result[1])

    def update_now_next(self):
        from .guide_summary import now_next
        entries=self.session.epg.get(self.channel['stream_id'],[]) if self.channel and self.session.connected else []
        identity=(self.channel.get('stream_id') if self.channel else None,id(entries),int(time.time()))
        if identity==self.now_next_identity:return
        self.now_next_identity=identity
        current,following,percent=now_next(entries,time.time())
        text=('Now '+str(percent)+'%: '+current['title']) if current else 'Now: Programme information unavailable'
        text+='\nNext: '+(following['title'] if following else 'Not supplied')
        self.setProperty('shadow.guide.now_next','\n'.join(self.safe_text(line) for line in text.split('\n')))
        self.setProperty('shadow.guide.progress',str(percent))

    @staticmethod
    def time_label(timestamp):
        try:
            return datetime.fromtimestamp(timestamp).strftime('%H:%M')
        except (OverflowError, ValueError, OSError):
            return '--:--'

    def show_programme(self, force=False):
        index = self.getControl(301).getSelectedPosition()
        if self.channel is None:
            return
        if not 0 <= index < len(self.programmes):
            identity = (self.channel['stream_id'], None)
            if identity != self.last_programme or force:
                self.last_programme = identity
                self.setProperty('shadow.artwork', '')
                if not self.session.temporary:
                    self.art_token = self.artwork.select({}, self.channel, self.session.prefs['approved_channel_ids'], self.session.prefs['programme_artwork'])
            return
        identity = (self.channel['stream_id'], index)
        if identity == self.last_programme and not force:
            return
        self.session.ensure_current()
        self.last_programme = identity
        programme = self.programmes[index]
        self.setProperty('shadow.programme', programme['title'])
        self.setProperty('shadow.time', self.time_label(programme['start'])+' - '+self.time_label(programme['end']))
        self.getControl(311).setText(self.safe_text(programme['description'], True) if programme['description'] else 'No description supplied.')
        self.setProperty('shadow.artwork', '')
        if self.session.temporary:
            return
        self.art_token = self.artwork.select(programme, self.channel, self.session.prefs['approved_channel_ids'], self.session.prefs['programme_artwork'])

    def tick(self):
        if not self.running:
            return
        privacy = getattr(self, 'privacy', None)
        if privacy is not None and privacy.tick():
            return
        self.update_header()
        self.update_now_next()
        try:self.poll_next_episode()
        except Exception:
            self.cancel_next_episode()
            self.dialog.ok('Next episode unavailable','The automatic next-episode offer could not be completed. You can choose an episode from the series page.')
        if self.loading_cover and self.loading_cover.cancelled:
            self.stop_playback()
            return
        if self._overlay_stop_pending is not None:
            connection, self._overlay_stop_pending = self._overlay_stop_pending, None
            if connection is self.session.connection:
                self.stop_playback()
            return
        if self.poll_overlay_action():
            return  # Yield to Kodi after Stop; never reopen Home on this tick.
        if self.switch_state is not None:
            self.poll_switch()
            return
        # This tick follows the outer Monitor.waitForAbort yield. Do not reopen
        # the modal from the key callback or from the tick that requested Stop.
        if self._playback_return is not None:
            self.poll_playback_return()
            return
        if self.playback and self.playback.url:
            self.dismiss_startup_busy()
            self.update_playback_clock()
            self.sample_media()
            old_url = self.playback.url
            outcome = self.playback.tick(xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') or
                                         xbmc.getCondVisibility('Window.IsVisible(videoosd)') or
                                         bool(self.overlay and self.overlay.active))
            if self.playback.started and self.watching_channel:
                identity = self.watching_channel
                self.recent_channels = ([identity] + [i for i in self.recent_channels if i != identity])[:20]
                if self.session.history:
                    self.session.history.remember_channel(identity)
                self.watching_channel = None
                self.hero_index = 0
                self.hero_identity = None
            if self.playback.started and not outcome:
                self.initialize_media_subtitles()
            if self.playback_start_pending and self.playback.started and not outcome:
                self.complete_playback_handoff()
            if outcome:
                failure = getattr(self.playback, 'last_failure', None)
                error = None
                if outcome in ('failed', 'timeout') and failure is not None:
                    from .streaming import PlaybackError
                    error = PlaybackError(code=failure[0], stage=failure[1], http_status=failure[2])
                    if self.schedule_reconnect(error, old_url):
                        return
                events=getattr(self.playback.player,'shadow_events',None)
                if outcome=='finished' and self.media_last_sample and self.media_last_sample[0]>=self.media_last_sample[1]*.95 and self.playing_media and self.playing_media.get('series_id') and self.media_connection is self.session.connection and isinstance(events,dict):
                    self.next_end_pending=(dict(self.playing_media),self.session.connection,events,time.monotonic()+15)
                self.return_from_playback(failed=outcome in ('failed', 'timeout'), error=error)
                return
            elif self.playback_hidden:
                self.poll_overlay()
                return
        if self.playback_hidden:
            return
        self.populate_rows()
        if not self.running or not self.artwork:
            return
        try:
            if self.session.connected and time.monotonic() >= self.next_preferences_check:
                self.next_preferences_check = time.monotonic() + 1
                self.session.ensure_current()
            if self.page=='Watch Later' and self.session.connected:
                self.poll_watch_later_catalogues()
                if self.watch_later_view_identity!=(id(self.session.connection),self.session.prefs['revision']):self.render_watch_later(load=False)
                else:self.poll_watch_later()
            if self.page == 'Home':
                focused = self.getFocusId() in (210, 211, 212, 213)
                if focused:
                    self.hero_next = time.monotonic() + 8
                rotate = False  # Homepage intentionally uses the static shortcut layout.
                self.refresh_hero(step=1 if rotate and not focused and self.hero_identity is not None and time.monotonic() >= self.hero_next else 0)
            if self.getFocusId() == 300:
                index = self.getControl(300).getSelectedPosition()
                identity = (self.page, index)
                if identity != self.row_focus and 0 <= index < len(self.rows):
                    self.queue_browse_art(index)
                    row = self.rows[index]
                    if self.channel is None or self.channel.get('stream_id') != row.get('stream_id'):
                        self.clear_guide()
                        self.setProperty('shadow.artwork', '')
                        self.setProperty('shadow.programme', row['name'])
                        self.setProperty('shadow.artwork.fallback', row['name'])
                        if self.page in ('Movies', 'TV Series'):
                            self.setProperty('shadow.time', ' / '.join(str(v) for v in (row.get('language'), row.get('year'), ', '.join(row.get('genres', ()))) if v))
                        self.getControl(311).setText(self.safe_text(row.get('plot'), True) if row.get('plot') else
                            ('Select a title to view details.' if self.page in ('Movies', 'TV Series')
                             else 'Loading programme guide...'))
                        self.overview_token = None
                        if row.get('kind') in ('movies', 'series'):
                            self.poster_row = self.media_art_row(row)
                            self.overview_token = None
                            if not row.get('plot'):
                                self.getControl(311).setText('Loading overview...')
                                if self.overviews and not self.session.temporary and self.session.prefs['programme_artwork']:
                                    self.overview_token = self.overviews.select(self.poster_row)
                                else:
                                    self.getControl(311).setText('No overview available for this title.')
                            self.poster_token = self.artwork.select(self.poster_row, {'stream_id': 'poster'}, ['poster'], True) if not self.session.temporary and self.session.prefs['programme_artwork'] else None
                        if self.page not in ('Movies', 'TV Series', 'Continue Watching', 'Search'):
                            self.channel = row
                            self.programmes = []
                            self.show_programme(force=True)
                            self.guide_retry_at = time.monotonic() + .25
                            cached = self.session.epg.get(row['stream_id'])
                            if cached is not None:
                                self.programmes = cached
                                self.render_guide()
                                if self.programmes:
                                    self.show_programme(force=True)
                                else:
                                    self.getControl(311).setText('No programme information supplied. Select to watch live.')
                    self.row_focus = identity
            elif self.getFocusId() == 301:
                self.show_programme()
            self.poll_recent_art()
            self.poll_browse_art()
            if self.poster_grid:
                grid_result = self.poster_grid.poll()
                if grid_result is not None and grid_result[0] == self.poster_grid_token and self.session.connected and not self.session.temporary:
                    self.session.ensure_current()
                    if self.session.prefs['programme_artwork']:
                        for key, path in grid_result[1].items():
                            self.setProperty('shadow.poster.' + key, path)
            self.refresh_guide_background()
            overview = self.overviews.poll() if self.overviews else None
            if (overview is not None and overview[0] == self.overview_token and self.poster_row
                    and self.session.connected and not self.session.temporary and self.session.prefs['programme_artwork']
                    and self.page in ('Movies', 'TV Series', 'Continue Watching', 'Search')):
                self.getControl(311).setText(self.safe_text(overview[1], True) if overview[1] else 'No overview available for this title.')
            result = self.artwork.poll()
            if result is not None and result[0] == self.poster_token and self.poster_row and self.session.connected and not self.session.temporary and self.session.prefs['programme_artwork']:
                self.setProperty('shadow.artwork', result[1])
                # Apply only to the still-focused item, never a superseded row.
                try:
                    index = self.getControl(300).getSelectedPosition()
                    if 0 <= index < len(self.rows) and self.rows[index].get('id') == self.poster_row.get('id'):
                        self.getControl(300).getListItem(index).setArt({'thumb': result[1]})
                except Exception:
                    pass
            if result is not None and result[0] == self.hero_token and self.page == 'Home' and self.hero_channel and self.hero_channel['stream_id'] in self.session.prefs['approved_channel_ids']:
                self.session.ensure_current()
                self.setProperty('shadow.hero.artwork', result[1])
            if result is not None and result[0] == self.art_token and self.channel and self.channel['stream_id'] in self.session.prefs['approved_channel_ids']:
                self.session.ensure_current()
                self.setProperty('shadow.artwork', result[1])
        except PreferencesConflict:
            self.stop_playback()
            self.clear_guide()
            try:
                self.session.reload()
            except PreferencesError:
                self.settings_unavailable()
                return
            self.rows = []
            self.getControl(300).reset()
            self.open_page('Home')
            self.apply_theme()
            self.dialog.ok('Settings updated', 'Channel selections changed in another window. The latest settings have been loaded.')
        except PreferencesError:
            self.settings_unavailable()

    def settings_unavailable(self):
        self.test_login.clear()
        self.stop_playback()
        self.clear_guide()
        self.session.close()
        self.rows = []
        self.getControl(300).reset()
        self.open_page('Home')
        self.setProperty('shadow.status', 'Disconnected')
        self.dialog.ok('Settings unavailable', 'The saved settings could not be read. Reconnect or use Settings > Recover settings.')

    def update_header(self):
        if time.monotonic() < self.next_header_update:
            return
        self.next_header_update = time.monotonic() + 1
        client = self.session.connection.client if self.session.connected else None
        valid = True
        if client is not None and hasattr(client, 'playback_session_valid'):
            try:
                valid = bool(client.playback_session_valid())
            except Exception:
                valid = False
        connected = self.session.connected and valid and not self.connection_failed and not self.demo
        self.setProperty('shadow.connection', 'Connected' if connected else 'Disconnected')
        self.setProperty('shadow.connection.colour', 'FF49C87A' if connected else 'FFE56464')
        self.setProperty('shadow.clock', datetime.now().strftime('%H:%M'))
        self.setProperty('shadow.date', datetime.now().strftime('%a %d %b').replace(' 0', ' '))
        self.setProperty('shadow.mode', 'Offline demo' if self.demo else 'Temporary session' if self.session.temporary else '')

    def row_label(self, row):
        if row.get('kind') == 'series' and 'season' in row:
            return self.safe_text('%s / S%d E%d / %s' % (row.get('series_name', row['name']), row['season'], row['episode'], row['name']))
        prefix='Watched / ' if row.get('kind') in ('movies','series') and self.is_title_watched(row) else ''
        return self.safe_text(prefix+row['name'])

    def search_results(self):
        if not self.search_query:
            return []
        from .search import ranked
        enabled = (self.session.prefs or {}).get('content_types', [])
        result = self.session.visible(query=self.search_query) if self.search_scope in (0,1) and 'live' in enabled else []
        for scope, kind in ((2,'movies'), (3,'series')):
            if self.search_scope in (0,scope) and kind in enabled and self.ensure_catalogue(kind):
                result += ranked(getattr(self.session, kind),self.search_query)
        return ranked([row for row in result if self.matches_browse_language(row) and (not self.session.prefs.get('hide_watched') or not self.is_title_watched(row))],self.search_query)

    def extra_setting(self, action):
        if not self.session.connected:
            self.dialog.ok('Shadow', 'Connect a provider first.')
            return
        if action == -1:
            choice = self.dialog.select('Subtitles at the start of each title', ['Off', 'On'])
            if choice >= 0:
                self.session.save({'subtitles_default': bool(choice)})
        elif action == -2:
            languages = ['Automatic', 'English', 'French', 'German', 'Spanish', 'Italian', 'Portuguese']
            choice = self.dialog.select('Preferred audio language', languages)
            if choice >= 0:
                self.session.save({'audio_language': '' if choice == 0 else languages[choice]})
        elif action == -3:
            self.session.save({'rotate_featured': not self.session.prefs.get('rotate_featured', True)})
        elif action == -4:
            for kind in ('movies', 'series'):
                if kind in self.session.prefs['content_types']:
                    self.ensure_catalogue(kind, force=True)
            if self.page in ('Movies', 'TV Series'):
                self.open_page(self.page)
        elif action == -7:
            loaders = [self.artwork] + self.recent_artwork
            messages = ['Details: ' + getattr(loaders[0], 'status', 'Not requested')] if loaders[0] else []
            messages += ['Channel tile %d: %s' % (i+1, getattr(loader, 'status', 'Not requested')) for i, loader in enumerate(self.recent_artwork)]
            self.dialog.ok('Artwork status', '\n'.join(messages))
        elif action in (-5,-6):
            from .settings_transfer import export_settings, import_settings
            if self.session.temporary:
                self.dialog.ok('Temporary session', 'Import and export are unavailable during a temporary test.')
                return
            if action == -5:
                folder = self.dialog.browse(0, 'Export settings folder', 'files')
                if folder:
                    path = export_settings(xbmcvfs.translatePath(folder), self.session.prefs)
                    self.dialog.ok('Settings exported', 'A new settings backup was created without login details.')
            else:
                path = self.dialog.browse(1, 'Choose Shadow settings backup', 'files', '.json')
                if path and self.dialog.yesno('Import settings?', 'Replace this account settings with the selected backup? Channel approvals will be reviewed against the current catalogue.'):
                    changes = import_settings(xbmcvfs.translatePath(path), self.session.prefs['provider_scope'])
                    known = {c['stream_id'] for c in self.session.channels}
                    changes['approved_channel_ids'] = [i for i in changes['approved_channel_ids'] if i in known]
                    self.session.save(changes)
                    self.clear_guide()
                    self.open_page('Home')

    def personal_backup(self,restore=False):
        if not self.session.connected or self.session.temporary:
            self.dialog.ok('Personal backup','Connect your saved provider account first.');return
        from .personal_backup import export_personal,read_personal,restore_personal
        try:
            if not restore:
                folder=self.dialog.browse(0,'Choose personal backup folder','files','',False,True)
                if not folder:return
                path=export_personal(xbmcvfs.translatePath(folder),self.session)
                self.dialog.ok('Personal backup saved','Watch Later, channel favourites, watched choices and progress saved. No login or connection permissions included.\n'+path)
            else:
                path=self.dialog.browse(1,'Choose personal backup','files','.json',False,False)
                if not path:return
                data=read_personal(xbmcvfs.translatePath(path),self.session)
                if not self.dialog.yesno('Restore personal backup','Replace Watch Later, favourites, watched choices and viewing progress for this provider account? Existing channel approvals and login are retained.'):return
                self.stop_playback()
                from .personal_backup import FIELDS,binding
                from copy import deepcopy
                before={'binding':binding(self.session),'settings':{key:deepcopy(self.session.prefs[key]) for key in FIELDS},'history':list(self.session.history.rows.values()) if self.session.history else [],'recent_channels':list(self.session.history.live) if self.session.history else []}
                try:
                    restore_personal(self.session,data)
                    history=self.session.history
                    if history and self.run_job('Saving restored progress...',lambda:history.wait_saved()) is not True:
                        raise PreferencesError('Restored progress could not be saved')
                except (PreferencesError,ValueError):
                    try:restore_personal(self.session,before)
                    except Exception:pass
                    self.dialog.ok('Restore not completed','The restored data could not be saved completely. Check local storage before retrying. The backup file is unchanged.')
                    return
                self.recent_channels=list(self.session.history.live) if self.session.history else []
                self._recent_media_identity=None
                self.open_page('Home')
                self.dialog.ok('Personal backup restored','Personal lists and progress restored. Channel favourites were limited to currently approved channels.')
        except (PreferencesError,OSError,ValueError):
            self.dialog.ok('Personal backup unavailable','Backup or restore could not be completed. Check the selected file, provider account and local storage.')

    def show_about(self):
        credits = ('Artwork and overviews: TVmaze (series, CC BY-SA 4.0), '
                   'Cinemeta / Stremio (movies). Channel identities and logos: IPTV-org.\n\n'
                   'https://www.tvmaze.com/\nhttps://www.tvmaze.com/api\n'
                   'https://creativecommons.org/licenses/by-sa/4.0/\n'
                   'https://v3-cinemeta.strem.io/manifest.json\n'
                   'https://github.com/iptv-org/database\n\n'
                   'Images remain the property of their respective rights holders. '
                   'Provider artwork is supplied by your configured provider.')
        try:
            with open(os.path.join(self.addon_path, 'ARTWORK-CREDITS.txt'), encoding='utf-8') as handle:
                credits = handle.read(16384)
        except OSError:
            pass
        self.dialog.textviewer('About Shadow', 'Shadow ' + VERSION + '\n\n' + credits)

    def privacy_settings(self):
        # Diagnose the exact setup stage without leaking paths, channel names,
        # URLs, credentials, or raw exception messages. A privacy failure must
        # never reset the main list or the user's approved channels.
        self._privacy_setup_stage = 'I570'
        try:
            self.configure_privacy()
        except Exception as error:
            stages = {
                'I570': 'checking the connection',
                'I571': 'opening the shortcut controller',
                'I572': 'reading saved settings',
                'I573': 'displaying the channel chooser',
                'I574': 'displaying the button chooser',
                'I575': 'checking or cleaning up the shortcut',
                'I576': 'saving the privacy choice',
                'I577': 'displaying the result',
            }
            code = self._privacy_setup_stage
            kind = next((name for cls, name in (
                (PreferencesConflict, 'settings conflict'),
                (PreferencesError, 'settings storage'),
                (OSError, 'filesystem'),
                (AttributeError, 'unsupported API'),
                (TypeError, 'API arguments'),
                (RuntimeError, 'runtime API')) if isinstance(error, cls)), 'unexpected failure')
            xbmc.log('Shadow privacy setup: %s / %s' % (code, kind), xbmc.LOGWARNING)
            self.dialog.ok('Privacy setup unavailable - ' + code,
                'Stopped while %s (%s). Your channel selections have not been reset. '
                'Leave privacy off for now and send this code with your build number.' % (stages[code], kind))

    def configure_privacy(self):
        if not self.session.connected or self.demo:
            self.dialog.ok('Privacy channel', 'Connect a provider and approve Live TV channels first.')
            return
        from .privacy import Privacy
        self._privacy_setup_stage = 'I571'
        if self.privacy is None:
            self.privacy = Privacy(self)
        self._privacy_setup_stage = 'I572'
        self.session.ensure_current()
        approved = set(self.session.prefs['approved_channel_ids'])
        rows = [r for r in self.session.connection.channels if r['stream_id'] in approved]
        if 'live' not in self.session.prefs['content_types']:
            rows = []
        current = self.session.prefs.get('privacy_channel_id', '')
        self._privacy_setup_stage = 'I573'
        selected = self.dialog.select('Privacy channel — choose a channel, then a shortcut',
            ['Off', 'Shortcut status / cleanup'] + [self.safe_text(r['name']) for r in rows],
            preselect=next((i+2 for i,r in enumerate(rows) if r['stream_id']==current),0))
        if selected == 1:
            self._privacy_setup_stage = 'I575'
            from .privacy_input import BUTTONS
            label = BUTTONS[self.session.prefs.get('privacy_button', 'y')][0]
            status = self.privacy.mailbox.last_status
            configured = bool(current)
            self.privacy.disarm()
            try:
                self.privacy.mapping.recover()
            except Exception as error:
                from .privacy_input import MappingError
                self.privacy.report(str(error) if isinstance(error,MappingError) else 'Keymap cleanup unavailable.')
            self.dialog.ok('Privacy shortcut', ('Channel selected: %s. Shortcut: %s.\n%s\n%s' % ('Yes' if configured else 'No — select a privacy channel first', label, status, self.privacy.last_error or 'Shortcut cleaned up. Start playback to re-arm. Xbox input still requires testing.')))
        elif selected == 0:
            self._privacy_setup_stage = 'I576'
            self.session.save({'privacy_channel_id': ''})
            self._privacy_setup_stage = 'I575'
            self.privacy.disarm()
        elif 2 <= selected < len(rows)+2:
            # Check the selected shortcut without overwriting custom mappings.
            from .privacy_input import MappingError, BUTTONS
            buttons = ('y', 'rightthumb')
            self._privacy_setup_stage = 'I574'
            choice = self.dialog.select('Privacy shortcut',
                ['Y', 'Press right stick (R3) — alternative'],
                preselect=buttons.index(self.session.prefs.get('privacy_button', 'y')))
            if choice not in (0, 1):
                return
            button = buttons[choice]
            try:
                self._privacy_setup_stage = 'I575'
                self.privacy.disarm()
                self.privacy.mapping.button = button
                self.privacy.mapping.install()
                self.privacy.mapping.remove()
                self._privacy_setup_stage = 'I576'
                self.session.save({'privacy_channel_id': rows[selected-2]['stream_id'], 'privacy_button': button})
                self._privacy_setup_stage = 'I577'
                self.dialog.ok('Privacy channel saved', 'During Shadow playback, %s switches to this channel; press it again to return. A silent BBC News image remains if loading fails. B exits the cover. Resume depends on provider seek support.' % BUTTONS[button][0])
            except MappingError as error:
                self.privacy.report(str(error))
                self.dialog.ok('Privacy shortcut unavailable', str(error))

    def settings(self):
        labels = ['Manage Channels','Provider connection','Disconnect','Programme artwork','Theme','Custom categories','Channel order','Channel favourites','Recover Xtream settings','Reload settings','Content types','Run setup wizard','Test local video and audio','Stop playback','Import M3U playlist link','Refresh M3U playlist','Recover M3U settings','Check local storage','Temporary live-TV test (no saved settings)','Check hostname lookup','Retry last connection','Forget test login','Connection options (redirects and HTTP)','Connect saved provider','Playback exit timing','Forget saved login','Clear Movies and Series watch history','Remember connection permissions','Autoplay next episode','Backup personal lists and progress','Restore personal lists and progress','Auto reconnect Live TV','Privacy channel and shortcut']
        groups = [('Connection', [1,23,22,2,14,15,25,27]),
                  ('Content', [0,5,6,7,10,11,26,29,30]),
                  ('Playback', [13,-1,-2,28,31,32]), ('Appearance', [3,4]),
                  ('Help and diagnostics', [12,-8,17,19,20,21,18,24,8,16,9,-4,-5,-6,-7])]
        group = self.dialog.select('Shadow - Settings', [name for name, actions in groups] + ['About'])
        if group == len(groups):
            self.show_about()
            return
        if group < 0:
            return
        actions = groups[group][1]
        extra = {-1:'Subtitle default', -2:'Preferred audio language', -3:'Rotate featured content',
                 -4:'Refresh catalogues', -5:'Export advanced settings (no progress)', -6:'Import advanced settings (same account)', -7:'Artwork status', -8:'Explore offline demo'}
        selected = self.dialog.select(groups[group][0], [extra[i] if i < 0 else labels[i] for i in actions])
        if selected < 0:
            return
        choice = actions[selected]
        if choice < 0:
            self.extra_setting(choice)
            return
        if choice < 0:
            return
        if choice == 32:
            self.privacy_settings()
            return
        if choice == 31:
            if not self.session.connected:
                self.dialog.ok('Auto reconnect Live TV', 'Connect a provider first.')
                return
            current = self.session.prefs.get('auto_reconnect_live') is True
            selected = self.dialog.select('Auto reconnect Live TV',
                ['Off', 'On - up to 3 retries per selected channel; B cancels'], preselect=int(current))
            if selected in (0, 1) and (selected == 1) != current:
                self.session.save({'auto_reconnect_live': selected == 1})
            return
        if choice == 28:
            if not self.session.connected:return
            selected=self.dialog.select('Autoplay next episode',['Off - ask after each episode','On - 10 second cancellable countdown'])
            if selected in (0,1):self.session.save({'autoplay_next':selected==1})
            return
        if choice in (29,30):
            self.personal_backup(choice==30)
            return
        if choice == 27:
            try:
                try:enabled = self.connection_permissions.enabled()
                except LoginStorageError:enabled = None
                selected = self.dialog.select('Remember connection permissions', ['Enabled - reuse choices for the same connection', 'Disabled - ask each time'], preselect=0 if enabled else 1)
                if selected in (0,1) and (enabled is None or (selected == 0) != enabled):
                    self.connection_permissions.set_enabled(selected == 0)
            except LoginStorageError:
                self.dialog.ok('Connection permissions', 'Remembered choices could not be read or saved. Reconnecting will require approval.')
            return
        if choice == 26:
            if self.session.history and self.dialog.yesno('Clear watch history', 'Remove this account’s movie and episode progress and recently watched entries?'):
                self.session.history.clear()
                self.session.save({'watched_movies':[],'watched_series':[]})
                self.refresh_recent_media()
            return
        if choice == 24:
            self.playback_exit_diagnostics()
            return
        if choice == 25:
            self.forget_saved_login()
            return
        if choice == 23:
            self.connect_saved_provider()
            return
        if choice == 22:
            self.configure_connection()
            return
        if choice == 20:
            self.retry_connection()
            return
        if choice == 21:
            self.forget_test_login()
            return
        if choice == 19:
            self.check_hostname()
            return
        if choice == 18:
            self.temporary_test()
            return
        if self.session.temporary and choice in (8, 16):
            self.dialog.ok('Temporary test', 'Temporary settings have no saved backup. Disconnect before using saved-settings recovery.')
            return
        if choice == 17:
            self.check_storage()
            return
        if choice == 14:
            self.connect_playlist(temporary=self.session.temporary)
            return
        if choice == 15:
            self.refresh_playlist()
            return
        if choice == 16:
            if self.dialog.yesno('Recover M3U settings', 'Restore the previous revision for this playlist link? Earlier channel approvals may reappear; review Manage Channels afterwards.'):
                self.connect_playlist(recover=True)
            return
        if choice == 12:
            self.test_playback()
            return
        if choice == 13:
            self.stop_playback()
            return
        self.stop_playback()
        if choice == 1:
            self.connect_provider(temporary=self.session.temporary)
            return
        if choice == 2:
            self.test_login.clear()
            self.jobs.close()
            self.clear_guide();self.session.close();self.open_page('Home')
            self.setProperty('shadow.status', 'Disconnected')
            return
        if choice == 8:
            if self.dialog.yesno('Recover settings', 'Restore the previous saved revision? Previously revoked approvals may reappear. Review Manage Channels afterwards.'):
                details = self.credentials()
                if details is not None:
                    try:
                        result = self.run_job('Recovering account settings...',lambda args=details:recover_account(self.profile,*args[:3],confirmed=True,allow_http=args[3]))
                        if result:
                            self.clear_guide();self.session.close();self.open_page('Home')
                            self.setProperty('shadow.status','Settings recovered - reconnect provider')
                    except JobError as error:
                        self.provider_error(error)
                        self.setProperty('shadow.status', 'Recovery incomplete - see diagnostic')
                    finally:
                        details = None
            return
        if not self.session.connected:
            self.dialog.ok('Shadow', 'Connect a provider first.')
            return
        prefs = self.session.prefs
        changes = {}
        if choice == 0:
            selected = self.choose_channels(prefs['approved_channel_ids'])
            if selected is None:
                return
            review = ('Use %s approved channels for this temporary session? Approvals outside the chosen groups are preserved until disconnect or exit.' if self.session.temporary else
                      'Save %s approved channels? Approvals outside the chosen groups are preserved.')
            if not self.dialog.yesno('Review channels', review % len(selected)):
                return
            changes['approved_channel_ids'] = selected
            changes['browse_languages'] = self.chosen_browse_languages
        elif choice == 3:
            if self.session.temporary:
                self.dialog.ok('Temporary test', 'Programme artwork is disabled during this test to avoid artwork cache writes.')
                return
            changes['programme_artwork'] = not prefs['programme_artwork']
        elif choice == 4:
            selected = self.dialog.select('Theme', ['Obsidian','Charcoal'])
            if selected < 0:return
            changes['theme'] = ('obsidian','charcoal')[selected]
        elif choice == 5:
            self.categories()
            return
        elif choice == 6:
            rows = self.session.visible()
            index = self.dialog.select('Move channel to top', [r['name'] for r in rows])
            if index < 0:return
            changes['channel_order'] = [rows[index]['stream_id']]+[r['stream_id'] for i,r in enumerate(rows) if i!=index]
        elif choice == 7:
            rows = self.session.visible()
            indices = self.multiselect('Channel favourites', [r['name'] for r in rows], [i for i,r in enumerate(rows) if r['stream_id'] in prefs['favourites']])
            if indices is None:return
            changes['favourites'] = [rows[i]['stream_id'] for i in indices]
        elif choice == 9:
            self.session.reload();self.clear_guide();self.open_page('Home');self.apply_theme()
            return
        elif choice == 11:
            self.setup()
            return
        elif choice == 10:
            types = ('live',) if self.is_playlist() else ('live','movies','series')
            labels = ['Live TV'] if self.is_playlist() else ['Live TV','Movies','Series']
            selected = self.multiselect('Content types', labels, [i for i,v in enumerate(types) if v in prefs['content_types']])
            if not selected:return
            changes['content_types'] = [types[i] for i in selected]
        self.session.save(changes)
        self.apply_theme()
        self.clear_guide()
        if self.page != 'Home':
            self.open_page('Home')

    def categories(self):
        categories = dict(self.session.prefs['custom_categories'])
        choice = self.dialog.select('Custom categories', ['Create category','Edit channels','Rename category','Delete category','Browse category'])
        if choice < 0:return
        name = None
        if choice:
            names = sorted(categories)
            index = self.dialog.select('Choose category', names)
            if index < 0:return
            name = names[index]
        if choice in (0,2):
            new_name = display_text(self.dialog.input('Category name'), 64)
            if not new_name:return
            if new_name in categories and new_name != name:
                self.dialog.ok('Shadow', 'A category with this name already exists.');return
            categories[new_name] = categories.pop(name) if name else []
        elif choice == 1:
            rows = self.session.visible()
            indices = self.multiselect('Category channels', [r['name'] for r in rows], [i for i,r in enumerate(rows) if r['stream_id'] in categories[name]])
            if indices is None:return
            categories[name] = [rows[i]['stream_id'] for i in indices]
        elif choice == 3:
            if not self.dialog.yesno('Delete category', 'Delete '+name+'? Channel approvals are retained.'):return
            del categories[name]
        elif choice == 4:
            self.clear_guide();self.page='Live TV';self.setProperty('shadow.page',self.page)
            self.setProperty('shadow.heading',name);self.rows=self.session.visible(category=name)
            self.render_rows();self.setFocusId(300 if self.rows else 101);return
        self.session.save({'custom_categories':categories})

    def shutdown(self):
        privacy = getattr(self, 'privacy', None)
        if privacy is not None:
            privacy.close()
        self.reconnect_context = None
        self.cancel_next_episode()
        self.close_loading_cover()
        self.clear_playback_clock()
        self.sample_media()
        self.finish_media()
        self.test_login.clear()
        if not self.running:return
        self.running = False
        self._playback_return = None
        self._row_batch = None
        self.cancel_switch()
        self.close_overlay()
        if self.guide_job is not None:
            self.guide_job.cancel()
        self.cancel_watch_later_catalogues()
        for runner in self.watch_later_catalogue_runners.values():runner.close()
        for loader in self.watch_later_loaders.values():
            loader.close()
        for loader in self.recent_artwork:
            loader.close()
        if self.poster_grid:
            self.poster_grid.close()
        if self.browse_artwork:
            self.browse_artwork.close()
        for resource in (self.overviews, self.guide_runner, self.switch_jobs, self.jobs, self.playback, self.artwork, self.session):
            if resource is not None:
                try:
                    resource.close()
                except Exception:
                    pass  # Complete the other cleanup even if one owner fails.
        self.close()


class ChannelOverlay(xbmcgui.WindowXMLDialog):
    """Same-process playback chooser. Callbacks queue intent; owner tick switches."""
    PAGE_SIZE = 100

    def __init__(self, *args, **kwargs):
        self.active = False
        self.busy = False
        self.event = None
        self.session = None
        self.connection = None
        self.rows = []
        self.page = 0
        self.current = None
        self.focused = None
        self.selected = None
        self.guide_due = 0
        self.guide_jobs = JobRunner()
        self.guide_job = None
        self.font_coverage = None

    def setProperty(self, key, value):
        if key in ('shadow.switch.current','shadow.switch.selected','shadow.switch.guide'):
            from .ui_text import readable
            value=readable(value,getattr(self,'font_coverage',None),'Programme text unavailable in the current font.')
        super().setProperty(key,value)

    def prepare(self, session, current):
        self.guide_jobs.close()
        self.session, self.connection = session, session.connection
        self.rows = session.visible()
        self.current = current
        position = next((i for i, row in enumerate(self.rows) if row['stream_id'] == current), 0)
        self.page = position // self.PAGE_SIZE
        self.initial_position = position % self.PAGE_SIZE
        self.event = None
        self.busy = False
        self.focused = self.selected = None
        self.guide_job = None

    def update_clock(self):
        now = datetime.now()
        self.setProperty('shadow.switch.clock', now.strftime('%H:%M'))
        self.setProperty('shadow.switch.date', now.strftime('%a %d %b').replace(' 0', ' '))

    def onInit(self):
        self.update_clock()
        self.setProperty('shadow.switch.status', 'CHOOSE A CHANNEL')
        current = next((r['name'] for r in self.rows if r['stream_id'] == self.current), '')
        self.setProperty('shadow.switch.current', current)
        self.render_page(self.initial_position)
        self.setFocusId(500)

    def render_page(self, selected=0):
        self.focused = self.selected = None
        self.guide_jobs.close()
        self.guide_job = None
        start = self.page*self.PAGE_SIZE
        page = self.rows[start:start+self.PAGE_SIZE]
        self.getControl(500).reset()
        self.getControl(500).addItems([xbmcgui.ListItem(label=('Now watching / ' if r['stream_id'] == self.current else '')+readable(r['name'],self.font_coverage,'Channel name unavailable in the current font.')) for r in page])
        self.getControl(500).selectItem(min(selected, max(0, len(page)-1)))
        self.setProperty('shadow.switch.page', '%d-%d of %d channels' % (start+1 if page else 0, start+len(page), len(self.rows)))
        self.setProperty('shadow.switch.selected', '')
        self.setProperty('shadow.switch.guide', '')

    def onClick(self, control):
        if control == 504:
            self.queue_stop()
            return
        if self.busy:
            return
        if control == 500:
            index = self.page*self.PAGE_SIZE+self.getControl(500).getSelectedPosition()
            if 0 <= index < len(self.rows):
                self.event = ('switch', self.rows[index]['stream_id'], self.connection)
        elif control in (501, 502):
            pages = max(1, (len(self.rows)+self.PAGE_SIZE-1)//self.PAGE_SIZE)
            self.page = (self.page+(-1 if control == 501 else 1)) % pages
            self.render_page()
            self.setFocusId(500)
        elif control == 503:
            self.dismiss()

    def onAction(self, action):
        value = action.getId()
        if value in getattr(self, 'privacy_actions', (18, 34)) and getattr(self, 'privacy_request', None):
            self.privacy_request()
            return
        if value == 13:  # ACTION_STOP
            self.queue_stop()
        elif value in (9, 10, 92, 216, 247, 257):
            if self.busy:
                self.queue_stop()
            else:
                self.dismiss()  # Back closes this overlay, not the stream.

    def queue_stop(self):
        connection = self.connection
        self.dismiss()
        self.event = ('stop', None, connection)

    def paint_guide(self, entries):
        now = time.time()
        items = [p for p in entries if p['end'] > now][:3]
        lines = [('NOW  ' if p['start'] <= now < p['end'] else '')+
                 ShadowWindow.time_label(p['start'])+'-'+ShadowWindow.time_label(p['end'])+'  '+p['title'] for p in items]
        self.setProperty('shadow.switch.guide', '\n'.join(lines) if lines else 'No programme information supplied. Select to watch live.')

    def tick(self):
        if not self.active:
            return
        self.update_clock()
        if self.busy:
            return
        if not self.session or self.session.connection is not self.connection:
            self.dismiss()
            return
        try:
            self.session.ensure_current()
            index = self.page*self.PAGE_SIZE+self.getControl(500).getSelectedPosition()
            if not 0 <= index < len(self.rows):
                return
            row = self.rows[index]
            if row['stream_id'] not in self.session.prefs['approved_channel_ids']:
                self.dismiss()
                return
            if index != self.focused:
                self.guide_jobs.close()
                self.guide_job = None
                self.focused, self.selected = index, row['stream_id']
                self.guide_due = time.monotonic()+.25
                self.setProperty('shadow.switch.selected', row['name'])
                self.setProperty('shadow.switch.guide', 'Loading programme guide...')
                if self.selected in self.session.epg:
                    self.paint_guide(self.session.epg[self.selected])
            if self.guide_job is not None:
                if not self.guide_job.done.is_set():
                    return
                job, self.guide_job = self.guide_job, None
                try:
                    result = job.take()
                    if result is not None and result[1] == self.selected and self.session.accept_epg(result):
                        self.paint_guide(result[2])
                except JobError:
                    self.guide_due = time.monotonic()+300
                    self.setProperty('shadow.switch.guide', 'Guide unavailable. Select to watch live.')
                return
            active = self.guide_jobs.active
            if (time.monotonic() >= self.guide_due and not self.session.epg_fresh(self.selected) and
                    (active is None or active.done.is_set())):
                self.guide_job = self.guide_jobs.submit(self.session.epg_request(self.selected))
        except PreferencesError:
            self.dismiss()

    def dismiss(self):
        was_active, self.active = self.active, False
        self.guide_jobs.close()
        self.guide_job = None
        self.busy = False
        self.session = self.connection = None
        self.rows = []
        if was_active:
            self.close()


class LoadingCover(xbmcgui.WindowXMLDialog):
    """Only a visual/loading input cover; no synchronous playback operations."""
    def __init__(self, *args, **kwargs):
        self.cancelled = False

    def onAction(self, action):
        if action.getId() in (9, 10, 13, 92, 216, 247, 257):
            self.cancelled = True


class CollectionProgress(xbmcgui.WindowXMLDialog):
    """Measured stage progress. Unknown download sizes show counters only."""
    def __init__(self,*args,**kwargs):
        self.cancelled=False
    def create(self,heading,message):
        self.setProperty('shadow.collection.status', 'Waiting for provider response - 0s')
        self.show()
    def update_status(self,message,percent):
        self.setProperty('shadow.collection.status',message)
        control = self.getControl(920)
        control.setVisible(percent is not None)
        if percent is not None:
            control.setPercent(percent)
    def iscanceled(self):
        return self.cancelled
    def onClick(self,identity):
        if identity==910:self.cancelled=True
    def onAction(self,action):
        if action.getId() in (9,10,92,216,247,257):self.cancelled=True


class NextEpisodeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):self.decision=None
    def onClick(self,identity):
        if identity in (951,952):self.decision=identity==951
    def onAction(self,action):
        if action.getId() in (9,10,92,216,247,257):self.decision=False
