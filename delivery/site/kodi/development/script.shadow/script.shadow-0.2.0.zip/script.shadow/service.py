"""One automatic opening per Kodi profile session; never a window watchdog."""
import time
import xbmc
import xbmcaddon
import xbmcgui

def main():
    addon=xbmcaddon.Addon('script.shadow')
    if addon.getSetting('autolaunch') != 'true':return
    home=xbmcgui.Window(10000)
    key='shadow.autolaunch.attempted'
    if home.getProperty(key):return
    # Mark BEFORE launching: service restart or failed startup must not loop.
    home.setProperty(key,'true')
    monitor=xbmc.Monitor()
    deadline=time.monotonic()+30
    while not monitor.waitForAbort(.25):
        if time.monotonic()>=deadline:return
        if xbmc.Player().isPlaying():return  # Preserve resumed playback.
        if xbmc.getCondVisibility('Window.IsActive(home)') and not xbmc.getCondVisibility('System.HasActiveModalDialog'):
            xbmc.executebuiltin('RunScript(script.shadow)')
            return

if __name__=='__main__':
    try:main()
    except Exception:xbmc.log('Shadow automatic opening safely skipped.',xbmc.LOGWARNING)
