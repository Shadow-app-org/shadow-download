"""Short-lived input dispatcher; rejected owned requests never exit playback."""
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
root = xbmcaddon.Addon('script.shadow').getAddonInfo('path')
sys.path.insert(0, os.path.join(root, 'resources', 'lib'))
from shadow.privacy_input import dispatch, should_fallback, Keymap, PREFIX

window = xbmcgui.Window(10000)
player = xbmc.Player()
dialog = xbmcgui.getCurrentWindowDialogId()
if not dispatch(window, player, current_dialog=dialog):
    xbmc.log('Shadow privacy: shortcut request rejected; check Privacy shortcut status.', xbmc.LOGWARNING)
    if should_fallback(window, player, current_dialog=dialog):
        try:
            Keymap(xbmcvfs.translatePath('special://profile/keymaps'), [],
                   lambda: xbmc.executebuiltin('Action(reloadkeymaps)')).recover()
        except Exception:
            xbmc.log('Shadow privacy: orphan keymap cleanup failed; review zz-shadow-privacy.xml.', xbmc.LOGWARNING)
        gamepad = len(sys.argv) > 1 and sys.argv[1] == 'gamepad'
        right_stick = len(sys.argv) > 2 and sys.argv[2] == 'rightthumb'
        if right_stick:
            action = 'AspectRatio' if not gamepad and xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') else 'ActivateWindow(ShutdownMenu)'
            xbmc.executebuiltin('Action(AspectRatio)' if action == 'AspectRatio' else action)
        else:
            action = 'AspectRatio' if gamepad and xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') else ('Queue' if gamepad else 'FullScreen')
            xbmc.executebuiltin('Action(%s)' % action)
