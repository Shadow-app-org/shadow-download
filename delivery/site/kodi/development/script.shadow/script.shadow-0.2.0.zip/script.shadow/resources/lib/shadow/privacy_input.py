"""Temporary privacy mapping and a credential-free, expiring GUI intent mailbox.

Only our exact keymap bytes may be removed. User keymaps are never rewritten.
This is input routing, not an authentication boundary between Kodi add-ons.
"""
import hashlib
import math
import os
import stat
import time
import uuid
import xml.etree.ElementTree as ET
from .local_files import read_regular_bytes

PREFIX = 'shadow.privacy.'
FILENAME = 'zz-shadow-privacy.xml'
ACTION = 'RunScript(special://home/addons/script.shadow/privacy_shortcut.py,{})'
CONTEXTS = ('FullscreenVideo', 'FullscreenLiveTV', 'VideoOSD', 'addon')


BUTTONS = {'y': ('Y', 'y', 'y'), 'rightthumb': ('Right stick (R3)', 'rightthumb', 'rightthumbbutton')}


def keymap_bytes(button='y'):
    if button not in BUTTONS:
        raise ValueError('Unknown privacy button')
    _, joystick_button, gamepad_button = BUTTONS[button]
    suffix = '' if button == 'y' else ',' + button
    root = ET.Element('keymap')
    for name in CONTEXTS:
        window = ET.SubElement(root, name)
        joystick = ET.SubElement(window, 'joystick', {'profile': 'game.controller.default'})
        ET.SubElement(joystick, joystick_button).text = ACTION.format('joystick' + suffix)
        ET.SubElement(ET.SubElement(window, 'gamepad'), gamepad_button).text = ACTION.format('gamepad' + suffix)
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding='utf-8')


class MappingError(Exception):
    """Fixed messages only; filesystem exceptions may contain private paths."""


class Keymap:
    def __init__(self, directory, scan_directories, reload):
        self.directory = directory
        self.directories = list(dict.fromkeys([directory] + list(scan_directories)))
        self.path = os.path.join(directory, FILENAME)
        self.reload = reload
        self.installed = False
        self.button = 'y'

    def _read(self):
        if os.lstat(self.path).st_nlink != 1:
            raise MappingError('Privacy keymap has unexpected links; left unchanged.')
        return read_regular_bytes(self.path, 262144)

    def recover(self):
        try:
            data = self._read()
        except FileNotFoundError:
            return False
        except (OSError, ValueError):
            raise MappingError('Privacy keymap could not be inspected; left unchanged.') from None
        if data not in tuple(keymap_bytes(button) for button in BUTTONS):
            raise MappingError('Privacy keymap was changed or interrupted; left unchanged. Review zz-shadow-privacy.xml in Kodi keymaps.')
        try:
            os.unlink(self.path)
            self.reload()
        except Exception:
            raise MappingError('Privacy keymap cleanup failed. Disable the shortcut and restart Kodi after removing zz-shadow-privacy.xml.') from None
        self.installed = False
        return True

    def install(self):
        if self.installed:
            return
        if self.button not in BUTTONS:
            raise MappingError('Unknown privacy shortcut. Select Y or Right stick in Privacy settings.')
        try:
            for directory in self.directories:
                if not os.path.exists(directory):
                    continue
                if not stat.S_ISDIR(os.lstat(directory).st_mode):
                    raise MappingError('A Kodi keymap directory is not a regular directory.')
                scanned = 0
                for folder, dirs, names in os.walk(directory, followlinks=False):
                    for child in dirs:
                        if not stat.S_ISDIR(os.lstat(os.path.join(folder, child)).st_mode):
                            raise MappingError('A custom keymap directory cannot be inspected safely.')
                    for name in names:
                        if not name.lower().endswith('.xml'):
                            continue
                        scanned += 1
                        if scanned > 512:
                            raise MappingError('Too many custom keymaps to check safely.')
                        path = os.path.join(folder, name)
                        body = read_regular_bytes(path, 262144)
                        if len(body) > 262144:
                            raise MappingError('A custom keymap is too large to check safely.')
                        root = ET.fromstring(body)
                        # Conservative: a selected-button mapping outside video also needs review.
                        keys = dict(zip(('joystick', 'gamepad'), BUTTONS[self.button][1:]))
                        if any(parent.tag.lower() in keys and any(child.tag.lower() == keys[parent.tag.lower()] for child in parent) for parent in root.iter()):
                            raise MappingError('A custom mapping for the selected privacy button already exists. Choose another button.')
            os.makedirs(self.directory, exist_ok=True)
            if not stat.S_ISDIR(os.lstat(self.directory).st_mode):
                raise MappingError('Kodi keymap directory is not a regular directory.')
            # Non-secret routing configuration: no credential writer or durability
            # protection is changed. Exclusive creation prevents overwriting files.
            with open(self.path, 'xb') as target:
                target.write(keymap_bytes(self.button))
                target.flush()
            if self._read() != keymap_bytes(self.button):
                raise MappingError('Privacy keymap verification failed.')
            self.installed = True
            self.reload()
        except MappingError:
            raise
        except Exception:
            raise MappingError('Privacy shortcut could not be installed. Existing keymaps were preserved.') from None

    def remove(self):
        if self.installed:
            self.recover()


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest() if value else ''


class Mailbox:
    def __init__(self, window, clock=time.monotonic):
        self.window, self.clock = window, clock
        self.token = uuid.uuid4().hex
        self.seen = ''
        self.last_status = 'No shortcut press received.'

    def publish(self, url, cover_id=0):
        self.window.setProperty(PREFIX + 'owner', self.token)
        self.window.setProperty(PREFIX + 'url', digest(url))
        self.window.setProperty(PREFIX + 'cover', str(cover_id) if type(cover_id) is int and cover_id >= 13000 else '')
        self.window.setProperty(PREFIX + 'heartbeat', str(self.clock()))

    def take(self):
        status = self.window.getProperty(PREFIX + 'input_status')
        if status in INPUT_STATUS.values():
            self.last_status = status
        request = self.window.getProperty(PREFIX + 'request')
        if request and request != self.seen:
            self.seen = request
            return request.startswith(self.token + ':')
        return False

    def close(self):
        if self.window.getProperty(PREFIX + 'owner') == self.token:
            for name in ('owner', 'url', 'cover', 'heartbeat', 'request', 'input_status'):
                self.window.clearProperty(PREFIX + name)


INPUT_STATUS = {
    'accepted': 'I560: Shortcut reached Shadow.',
    'stale': 'I561: Shortcut owner is not responding. Restart Shadow.',
    'mismatch': 'I562: Shortcut playback ownership did not match.',
    'error': 'I563: Shortcut state could not be read.',
}


def dispatch(window, player, clock=time.monotonic, current_dialog=None):
    """Never starts/stops playback or opens a provider. Owner must still match."""
    try:
        owner = window.getProperty(PREFIX + 'owner')
        heartbeat = float(window.getProperty(PREFIX + 'heartbeat'))
        age = clock() - heartbeat
        if (len(owner) != 32 or not all(c in '0123456789abcdef' for c in owner)
                or not math.isfinite(age) or not 0 <= age <= 2):
            window.setProperty(PREFIX + 'input_status', INPUT_STATUS['stale'])
            return False
        expected = window.getProperty(PREFIX + 'url')
        cover = window.getProperty(PREFIX + 'cover')
        owned_cover = bool(type(current_dialog) is int and current_dialog >= 13000 and cover == str(current_dialog))
        if not owned_cover and (not expected or not player.isPlaying() or digest(player.getPlayingFile()) != expected):
            window.setProperty(PREFIX + 'input_status', INPUT_STATUS['mismatch'])
            return False
        window.setProperty(PREFIX + 'input_status', INPUT_STATUS['accepted'])
        window.setProperty(PREFIX + 'request', owner + ':' + uuid.uuid4().hex)
        return True
    except Exception:
        # Only fixed messages, never raw player errors/URLs.
        try:
            window.setProperty(PREFIX + 'input_status', INPUT_STATUS['error'])
        except Exception:
            pass  # Caller logs the fixed failure if the property API itself is unavailable.
        return False


def should_fallback(window, player, clock=time.monotonic, current_dialog=None):
    """Default actions are only safe outside a live owner or its retained playback.

    A rejected privacy request must not become FullScreen and end the channel.
    Any unreadable state blocks fallback; the caller logs a fixed diagnostic.
    """
    try:
        owner = window.getProperty(PREFIX + 'owner')
        if not owner:
            return True
        if len(owner) != 32 or not all(c in '0123456789abcdef' for c in owner):
            return False
        try:
            age = clock() - float(window.getProperty(PREFIX + 'heartbeat'))
        except (TypeError, ValueError):
            age = float('inf')
        if math.isfinite(age) and 0 <= age <= 2:
            return False
        cover = window.getProperty(PREFIX + 'cover')
        if type(current_dialog) is int and current_dialog >= 13000 and cover == str(current_dialog):
            return False
        expected = window.getProperty(PREFIX + 'url')
        if expected and player.isPlaying() and digest(player.getPlayingFile()) == expected:
            return False
        return True
    except Exception:
        return False
