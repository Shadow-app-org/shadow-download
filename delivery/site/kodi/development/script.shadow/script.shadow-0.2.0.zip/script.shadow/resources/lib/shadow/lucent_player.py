"""Shadow playback controls. Input queues player intents on the owning tick."""
import time
import xbmcgui
from .lucent_dialogs import BACK
class PlayerSurface(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        self.owner=kwargs.pop('owner');self.active=False;self.event=None;self.connection=self.owner.session.connection;self.next_tick=0
    def onInit(self):self.active=True;self.setFocusId(801);self.tick()
    def dismiss(self):self.active=False;self.close()
    def onAction(self,action):
        if action.getId() in BACK:self.dismiss()
        elif action.getId()==13:self.event=('stop',None,self.connection);self.dismiss()
    def onClick(self,identity):
        if identity==806:self.event=('stop',None,self.connection);self.dismiss()
        else:self.event=('player',identity,self.connection)
    def tick(self):
        if time.monotonic()<self.next_tick:return
        self.next_tick=time.monotonic()+.5
        owner=self.owner
        if owner.session.connection is not self.connection or not owner.playback:self.dismiss();return
        title=(owner.playing_media or {}).get('name') or owner.getProperty('shadow.programme') or 'Live TV'
        self.setProperty('player.title',owner.safe_text(title))
        try:
            position=owner.playback.player.getTime();duration=owner.playback.player.getTotalTime()
            self.setProperty('player.time','%d:%02d / %d:%02d' % (position//60,position%60,duration//60,duration%60))
        except Exception:self.setProperty('player.time','Live')
