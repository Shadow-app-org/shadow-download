"""Process lifetime guard. OS releases the socket even after a script crash."""
import hashlib
import socket

class LaunchGuard:
    def __init__(self, profile):
        self.port = 42000 + int(hashlib.sha256(profile.encode()).hexdigest()[:6], 16) % 16000
        self.socket = None
    def acquire(self):
        handle = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            handle.bind(('127.0.0.1', self.port))
            handle.listen(1)
        except OSError:
            handle.close()
            return False
        self.socket = handle
        return True
    def close(self):
        if self.socket is not None:
            self.socket.close()
            self.socket = None

class IntroState:
    DURATION = 2.7
    def __init__(self, clock, enabled=True):
        self.clock = clock
        self.started = clock()
        self.finished = not enabled
    def skip(self): self.finished = True
    def tick(self):
        if self.clock() - self.started >= self.DURATION: self.finished = True
        return not self.finished
