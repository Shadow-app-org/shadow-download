"""Four digit UI lock, separate from provider credentials and licence state.

This is an accidental-change/household access guard, not credential encryption.
No default/shared PIN is shipped. Owner creates one on first protected access.
"""
import hashlib
import hmac
import json
import os
import time
from .preferences import atomic_bytes

class ConnectionLock:
    def __init__(self, profile, clock=time.time):
        self.path = os.path.join(profile, 'connection-lock.json')
        self.clock = clock
        self.unlocked = False
        self.data = None
        self.broken = False
        try:
            with open(self.path, 'rb') as f:
                raw = f.read(4097)
            if len(raw) > 4096: raise ValueError()
            self.data = json.loads(raw)
            if (self.data.get('version') != 1 or len(bytes.fromhex(self.data['salt'])) != 16
                    or len(bytes.fromhex(self.data['digest'])) != 32
                    or type(self.data.get('failures')) is not int
                    or not isinstance(self.data.get('retry_at'), (int,float))): raise ValueError()
        except FileNotFoundError: pass
        except Exception: self.broken = True
    @staticmethod
    def valid(pin): return isinstance(pin,str) and len(pin)==4 and pin.isascii() and pin.isdigit()
    @staticmethod
    def digest(pin, salt): return hashlib.pbkdf2_hmac('sha256',pin.encode(),bytes.fromhex(salt),120000).hex()
    def save(self): atomic_bytes(self.path,json.dumps(self.data,separators=(',',':')).encode())
    def create(self, pin, confirmation):
        if self.broken or self.data is not None or not self.valid(pin) or pin != confirmation: return False
        salt=os.urandom(16).hex()
        self.data=dict(version=1,salt=salt,digest=self.digest(pin,salt),failures=0,retry_at=0)
        try: self.save()
        except Exception:
            self.data=None
            return False
        self.unlocked=True
        return True
    def verify(self, pin):
        self.unlocked=False
        if self.broken or not self.data or self.clock()<self.data['retry_at'] or not self.valid(pin):return False
        accepted=hmac.compare_digest(self.digest(pin,self.data['salt']),self.data['digest'])
        self.data['failures']=0 if accepted else self.data['failures']+1
        self.data['retry_at']=self.clock()+30 if self.data['failures']>=5 else 0
        if self.data['failures']>=5:self.data['failures']=0
        try:self.save()
        except Exception:return False
        self.unlocked=accepted
        return accepted
    def lock(self):self.unlocked=False
