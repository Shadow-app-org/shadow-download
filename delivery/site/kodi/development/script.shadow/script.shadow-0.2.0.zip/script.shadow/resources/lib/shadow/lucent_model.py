"""Deterministic shelves, no invented trending data or new network dependency."""
from datetime import date

def shelves(rows, history, prefs, kind):
    by_id={r['id']:r for r in rows}
    continued=[]
    for old in history.recent(kind) if history else []:
        parent=old.get('series_id') or old.get('id')
        if parent in by_id and not old.get('completed') and old.get('position',0)>0:
            continued.append(dict(by_id[parent],**old))
    popular=sorted((r for r in rows if r.get('rating',0)>0),key=lambda r:(-r['rating'],r['name'].casefold()))[:20]
    # Only genuine provider/title release years; catalogue arrival != release date.
    released=sorted((r for r in rows if str(r.get('year','')).isdigit() and int(r['year'])<=date.today().year),key=lambda r:(-int(r['year']),r['name'].casefold()))[:20]
    saved=set(prefs.get('watch_later_'+kind,[]))
    favourites=[r for r in rows if r['id'] in saved]
    return {700:continued,701:popular,702:released,703:favourites}

def now_next(programmes,now):
    ordered=sorted((p for p in programmes if p.get('end',0)>now),key=lambda p:p.get('start',0))
    current=next((p for p in ordered if p.get('start',0)<=now<p.get('end',0)),None)
    next_up=next((p for p in ordered if p.get('start',0)>now),None)
    return current,next_up

def guide_layout(programmes,start,end,width=1372):
    """A time-proportional, gap-preserving guide row, bounded to eight cells."""
    entries=sorted((p for p in programmes if p.get('end',0)>start and p.get('start',end)<end),key=lambda p:p.get('start',0))
    cells=[];cursor=start
    for programme in entries:
        left=max(start,cursor,programme['start']);right=min(end,programme['end'])
        if right<=left:continue
        if left>cursor:cells.append({'start':cursor,'end':left,'title':'No listing supplied'})
        cells.append(dict(programme,start=left,end=right));cursor=right
        if len(cells)>=7:break
    if cursor<end:cells.append({'start':cursor,'end':end,'title':'No listing supplied'})
    return [dict(p,x=round((p['start']-start)/(end-start)*width),width=max(1,round((p['end']-p['start'])/(end-start)*width))) for p in cells[:8]]
