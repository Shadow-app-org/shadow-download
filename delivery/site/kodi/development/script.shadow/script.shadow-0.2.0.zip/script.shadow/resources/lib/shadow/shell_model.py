"""SHK-004 presentation and restoration policy; no Kodi APIs or new storage."""
from dataclasses import dataclass
from .application import prepare_connection
from .connection_permissions import identity

DOCK = ((100, 'Home'), (101, 'Live TV'), (103, 'Movies'),
        (104, 'TV Series'), (105, 'Watch Later'))


def continuing(history, enabled, permitted=lambda row: True):
    rows = []
    for kind in ('movies', 'series'):
        if kind in enabled and history:
            rows.extend(dict(row, kind=kind) for row in history.recent(kind)
                        if not row.get('completed') and row.get('position', 0) > 0 and permitted(row))
    rows.sort(key=lambda row: (-row.get('updated', 0), row['kind'], str(row.get('key', row.get('id', '')))))
    seen, result = set(), []
    for row in rows:
        key = (row['kind'], row.get('series_id'), row.get('id'), row.get('season'), row.get('episode'))
        if key not in seen:
            seen.add(key); result.append(row)
    return result[:2]


def progress(row):
    duration = row.get('duration', 0)
    return max(0, min(100, int(100 * row.get('position', 0) / duration))) if duration > 0 else 0


@dataclass(repr=False)
class Restored:
    state: str
    key: str = ''
    options: object = None
    connection: object = None

    def close(self):
        if self.connection is not None:
            connection, self.connection = self.connection, None
            connection.close()


def restore(profile, saved, permissions, prepare=prepare_connection):
    """Worker: reuse explicit grants only. Result owns its connection until adopted."""
    details = saved.load()
    if details is None:
        return Restored('empty')
    key = identity(details)
    options = permissions.lookup(key)
    if (options is None or not options.get('remember') or
            (details[0].lower().startswith('http://') and not options.get('http_login'))):
        return Restored('review')
    connection = prepare(profile, *details, allow_http=options['http_login'],
                         allow_http_playback=options['http_login'])
    result = Restored('ready', key, dict(options), connection)
    try:
        connection.client.set_stream_redirects(options['redirects'])
        connection.client.set_http_stream_redirects(options['http_redirects'])
        return result
    except BaseException:
        result.close()
        raise


def still_authorized(result, saved, permissions):
    details = saved.load()
    return (details is not None and identity(details) == result.key and
            permissions.lookup(result.key) == result.options)
