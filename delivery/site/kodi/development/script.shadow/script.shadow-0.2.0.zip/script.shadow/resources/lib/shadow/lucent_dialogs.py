"""Branded selectors, confirmations and controller keyboard within Shadow."""
import os
import xbmcgui

BACK=(9,10,92,216,247,257)
KEYS=list('1234567890qwertyuiopasdfghjkl:zxcvbnm./@-_?=&%+!~#')
class Surface(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        self.title=kwargs.pop('title','Shadow');self.message=kwargs.pop('message','')
        self.mode=kwargs.pop('mode','list');self.items=kwargs.pop('items',[])
        self.multiple=kwargs.pop('multiple',False);self.chosen=set(kwargs.pop('selected',[]))
        self.text=kwargs.pop('text','');self.secret=kwargs.pop('secret',False)
        self.limit=kwargs.pop('limit',2048);self.shift=False;self.symbols=False;self.result=None;self.preselect=kwargs.pop('preselect',0)
        self.accept=kwargs.pop('accept','Done');self.cancelled=False
        self.initialized=False;self.rendered=False
    def onInit(self):
        if self.initialized:return
        self.initialized=True
        for key,value in [('title',self.title),('message',self.message),('mode',self.mode),('accept',self.accept)]:self.setProperty('dialog.'+key,str(value))
        if self.mode=='list':
            self.render()
            self.setFocusId(50 if self.items else 60)
        elif self.mode in ('keyboard','pin'):
            self.paint_text();self.setFocusId(270 if self.mode=='pin' else 200)
        else:self.setFocusId(60)
    def render(self):
        control=self.getControl(50);position=control.getSelectedPosition() if self.rendered else self.preselect
        self.rendered=True
        control.reset()
        control.addItems([xbmcgui.ListItem(label=('✓  ' if i in self.chosen else '○  ' if self.multiple else '')+str(label)) for i,label in enumerate(self.items)])
        if self.items:control.selectItem(max(0,min(self.preselect if position<0 else position,len(self.items)-1)))
    def paint_text(self):
        value='•'*len(self.text) if self.secret else self.text
        if self.mode=='pin':value=' '.join('●' if i<len(self.text) else '○' for i in range(4))
        self.setProperty('dialog.message',self.message+'\n'+value)
    def onClick(self,id):
        if id==61:self.cancelled=True;self.close()
        elif id==50:
            index=self.getControl(50).getSelectedPosition()
            if not 0<=index<len(self.items):return
            if self.multiple:
                self.chosen.symmetric_difference_update({index});self.render()
            else:self.result=index;self.close()
        elif id==60:
            if self.mode=='pin' and len(self.text)!=4:return
            self.result=sorted(self.chosen) if self.multiple else self.text if self.mode in ('keyboard','pin') else self.getControl(50).getSelectedPosition() if self.mode=='list' else True
            self.close()
        elif 200<=id<250 and self.mode in ('keyboard','pin'):
            value=(list('[]{}()<>$^*\\|;,\'\"`')+KEYS)[id-200] if self.symbols else KEYS[id-200]
            if self.mode=='pin' and id>=210:return
            if len(self.text)<self.limit:self.text+=value.upper() if self.shift else value
            self.paint_text()
            if self.mode=='pin' and len(self.text)==4:self.setFocusId(60)
        elif 270<=id<=279 and self.mode=='pin':
            if len(self.text)<4:self.text+=str(id-269 if id<279 else 0)
            self.paint_text()
            if len(self.text)==4:self.setFocusId(60)
        elif id==264:
            self.symbols=not self.symbols
            values=(list('[]{}()<>$^*\\|;,\'\"`')+KEYS)[:50] if self.symbols else KEYS
            for i,key in enumerate(values):self.getControl(200+i).setLabel(key.upper() if self.shift else key)
        elif id==260 and len(self.text)<self.limit:self.text+=' ';self.paint_text()
        elif id==261:
            self.shift=not self.shift
            values=(list('[]{}()<>$^*\\|;,\'\"`')+KEYS)[:50] if self.symbols else KEYS
            for i,key in enumerate(values):self.getControl(200+i).setLabel(key.upper() if self.shift else key)
        elif id in (262,263):self.text=self.text[:-1];self.paint_text()
    def onAction(self,action):
        if action.getId() in BACK:self.cancelled=True;self.close()

class GlassDialog:
    def __init__(self,root):self.root=root
    def _show(self,**kwargs):
        window=Surface('LucentDialog.xml',self.root,'Default','1080i',**kwargs)
        try:window.doModal();return window.result
        finally:
            window.text='';window.setProperty('dialog.message','');window.close()
    def select(self,heading,list,autoclose=0,preselect=0,useDetails=False):
        result=self._show(title=heading,items=list,preselect=preselect,accept='Select')
        return result if type(result) is int else -1
    def multiselect(self,heading,options,autoclose=0,preselect=None,useDetails=False):
        return self._show(title=heading,items=options,multiple=True,selected=preselect or [])
    def ok(self,heading,message='',*lines,**kwargs):
        return self._show(title=heading,message='\n'.join([str(message)]+[str(s) for s in lines]),mode='message',accept='OK') is True
    def yesno(self,heading,message='',*lines,**kwargs):
        return self._show(title=heading,message='\n'.join([str(message)]+[str(s) for s in lines]),mode='message',accept=kwargs.get('yeslabel') or 'Confirm') is True
    def input(self,heading,defaultt='',type=0,option=0,autoclose=0):
        secret=bool(option & getattr(xbmcgui,'ALPHANUM_HIDE_INPUT',1)) or any(s in heading.lower() for s in ('password','passcode','pin'))
        result=self._show(title=heading,mode='keyboard',text=defaultt,secret=secret)
        return result if isinstance(result,str) else ''
    def pin(self,title,message=''):
        return self._show(title=title,message=message,mode='pin',secret=True,limit=4,accept='Unlock' if 'Unlock' in title else 'Continue')
    def numeric(self,type,heading,defaultt=''):return self.input(heading,defaultt)
    def notification(self,heading,message,*args,**kwargs):return self.ok(heading,message)
    def textviewer(self,heading,text,**kwargs):return self._show(title=heading,items=str(text).splitlines(),accept='Close')
    def browse(self,*args,**kwargs):
        # OS/Kodi storage picker: boundary required for explicit backup destination selection.
        return xbmcgui.Dialog().browse(*args,**kwargs)
    def browseSingle(self,*args,**kwargs):return xbmcgui.Dialog().browseSingle(*args,**kwargs)

class GlassProgress(Surface):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,title=kwargs.pop('title','Shadow'),message='Working…',mode='progress',accept='Cancel')
    def create(self,heading,message):self.title=heading;self.message=message;self.show()
    def update(self,percent,message=''):
        self.setProperty('dialog.message',str(message or self.message)+(('  '+str(percent)+'%') if percent else ''))
    def update_status(self,message,percent):self.update(percent,message)
    def iscanceled(self):return self.cancelled
    def onClick(self,id):
        if id in (60,61):self.cancelled=True;self.close()
