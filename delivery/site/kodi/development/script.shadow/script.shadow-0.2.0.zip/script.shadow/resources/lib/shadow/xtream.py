"""Pure-Python Xtream metadata normalization. No network or Kodi dependency."""
import base64
import binascii
import html
import re
import unicodedata
from .cancellation import checkpoint

_TAG = re.compile(r'<[^>]*>')

def channels_from_payload(payload):
    """Return sanitized live streams; preserve provider IDs for approvals."""
    if not isinstance(payload, list):
        return []
    result = []
    seen = set()
    for item in payload:
        checkpoint()
        if not isinstance(item, dict):
            continue
        stream_id = item.get('stream_id')
        if isinstance(stream_id, bool) or stream_id is None or not str(stream_id).isascii() or not str(stream_id).isdigit() or len(str(stream_id)) > 64:
            continue
        key = str(stream_id)
        if key in seen:
            continue
        seen.add(key)
        result.append({'stream_id': key, 'name': display_text(item.get('name'), 180) or 'Unnamed channel',
                       'category_id': str(item.get('category_id', ''))[:128],
                       'stream_icon': str(item.get('stream_icon') or ''),
                       'epg_channel_id': str(item.get('epg_channel_id') or '')})
    return result

def _description(value):
    if not isinstance(value, str):
        return ''
    return display_text(value, 2000)

def _decode_text(value):
    if not isinstance(value, str):
        return ''
    try:
        raw = base64.b64decode(value, validate=True)
        decoded = raw.decode('utf-8')
        if any(ord(c) < 32 and c not in '\r\n\t' for c in decoded):
            return value[:2000]
        return decoded[:2000]
    except (ValueError, binascii.Error, UnicodeError):
        return value[:2000]

def _epoch(item, key, alt):
    value = item.get(key, item.get(alt))
    if isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return None

def programmes_from_short_epg(payload, now=None):
    """Normalize Xtream get_short_epg response; reject invalid time intervals."""
    if isinstance(payload, dict):
        entries = payload.get('epg_listings', [])
    else:
        entries = []
    if not isinstance(entries, list):
        return []
    out = []
    for item in entries:
        if not isinstance(item, dict):
            continue
        start = _epoch(item, 'start_timestamp', 'start_ts')
        end = _epoch(item, 'stop_timestamp', 'stop_ts')
        if start is None or end is None or start < 0 or end > 253402300799 or end <= start or end - start > 86400 * 3:
            continue
        if now is not None and end < now:
            continue
        title = _decode_text(item.get('title', '')) or 'Programme information unavailable'
        description = _description(_decode_text(item.get('description', '')))
        image = next((item[k] for k in ('image', 'icon', 'artwork') if isinstance(item.get(k), str) and item[k]), '')
        out.append({'title': _description(title)[:250], 'description': description,
                    'start': start, 'end': end, 'image': image})
    return sorted(out, key=lambda x: (x['start'], x['end']))

def guide_rows(channels, approved_ids, epg_by_stream_id):
    """Guide is approval-only even if provider returns more channels."""
    from .artwork import visible_channels
    rows = []
    for channel in visible_channels(channels, approved_ids):
        rows.append({'channel': channel, 'programmes': epg_by_stream_id.get(str(channel['stream_id']), [])})
    return rows


def display_text(value, limit=250):
    if not isinstance(value, str):
        return ''
    value = unicodedata.normalize('NFKC', _TAG.sub('', html.unescape(value[:8000])))
    value = value.replace('\ufffd', '').replace('\ufe0f', '').replace('\ufe0e', '')
    value = ''.join(c for c in value if unicodedata.category(c) not in ('Cc', 'Cf', 'Cs', 'Co', 'Cn', 'So') or c in '\r\n\t')
    return ' '.join(value.replace('[', '(').replace(']', ')').split())[:limit]


def media_from_payload(payload, kind):
    from .catalogue import metadata
    from .collection_progress import report, check_deadline
    if not isinstance(payload, list):
        return []
    key = 'stream_id' if kind == 'movies' else 'series_id'
    seen, result = set(), []
    for index, item in enumerate(payload):
        checkpoint()
        if index % 128 == 0:
            check_deadline()
            report('processing', processed=index, total=len(payload))
        if not isinstance(item, dict):
            continue
        identity = item.get(key)
        if isinstance(identity, bool) or identity is None or not str(identity).isascii() or not str(identity).isdigit() or len(str(identity)) > 64:
            continue
        identity = str(identity)
        if identity in seen:
            continue
        seen.add(identity)
        result.append({'id': identity, 'name': display_text(item.get('name'), 180) or 'Untitled',
                       'plot': display_text(item.get('plot'), 2000), 'kind': kind})
        result[-1].update(metadata(item, result[-1]['name']))
        try:
            rating=float(item.get('rating') or float(item.get('rating_5based') or 0)*2)
            result[-1]['rating']=rating if 0<=rating<=10 else 0
        except (TypeError,ValueError):result[-1]['rating']=0
        from .artwork import image_candidates
        images = image_candidates(item)
        result[-1]['artwork'] = images[0] if images else ''
        result[-1]['artwork_candidates'] = images
        imdb = str(item.get('imdb_id') or item.get('imdb') or '')
        if re.fullmatch(r'tt[0-9]{5,12}', imdb):
            result[-1]['imdb_id'] = imdb
        if kind == 'movies':
            result[-1]['extension'] = str(item.get('container_extension') or '').strip().lower().lstrip('.')
    check_deadline()
    report('processing', processed=len(payload), total=len(payload))
    return result
