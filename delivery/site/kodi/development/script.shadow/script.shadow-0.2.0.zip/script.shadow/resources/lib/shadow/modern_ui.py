"""SHK-004 shell on the retained .57 playback adapter."""
import time
from .kodi_ui import ShadowWindow
from .jobs import JobRunner
from .shell_model import continuing, progress, restore, still_authorized


class ModernShadowWindow(ShadowWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.restore_runner = JobRunner()
        self.restore_job = None
        self.home_rows = []
        self.home_favourites = []
        self.home_owner = None
        self.home_token = None
        self.home_identity = None
        self.live_category = None
        self.live_owner = None
        self.next_shell_refresh = 0

    def on_startup(self):
        self.setProperty('shadow.heading', 'Home')
        self.setProperty('shadow.home.title.0', 'Your next watch starts here')
        self.setProperty('shadow.home.title.1', 'More from your collection')
        self.start_restore()

    def cancel_restore(self):
        self.restore_runner.close()
        self.restore_job = None
        self.setProperty('shadow.restore.busy', 'false')

    def start_restore(self):
        self.cancel_restore()
        self.setProperty('shadow.restore.message', 'Restoring your saved provider...')
        try:
            self.restore_job = self.restore_runner.submit(
                lambda: restore(self.profile, self.saved_login, self.connection_permissions),
                lambda result: result.close())
            self.setProperty('shadow.restore.busy', 'true')
        except Exception:
            self.setProperty('shadow.restore.message', 'Previous connection is finishing. Retry or open Settings.')

    def poll_restore(self):
        job = self.restore_job
        if job is None or not job.done.is_set():
            return
        self.restore_job = None
        self.setProperty('shadow.restore.busy', 'false')
        result = None
        adopted = None
        try:
            result = job.take()
            if result is None or not self.running or self.session.connected:
                return
            if result.state != 'ready':
                self.setProperty('shadow.restore.message',
                    'Add your provider in Settings to get started.' if result.state == 'empty' else
                    'Review saved connection permissions in Settings > Connection > Connect saved provider.')
                return
            if not still_authorized(result, self.saved_login, self.connection_permissions):
                self.setProperty('shadow.restore.message', 'Connection settings changed. Review them in Settings.')
                return
            focused = self.getFocusId()
            connection = result.connection
            try:
                self.session.adopt(connection)
            except Exception:
                # adopt assigns ownership before creating history/discovery.
                if self.session.connection is connection:
                    result.connection = None
                    self.session.close()
                raise
            result.connection = None
            adopted = connection
            self.permission_identity = result.key
            self.permission_connection = connection
            self.demo = False
            self.after_connect(interactive=False)
            self.setFocusId(focused if focused in (100,101,103,104,105,107,108) else 100)
            self.setProperty('shadow.restore.message', '' if self.session.prefs['setup_completed'] else
                             'Connected. Finish setup in Settings > Content > Run setup wizard.')
        except Exception:
            if adopted is not None and self.session.connection is adopted:
                self.session.close()
                self.permission_identity = None
                self.permission_connection = None
            self.setProperty('shadow.restore.message', 'Saved provider could not be restored. Retry or open Settings.')
        finally:
            if result is not None: result.close()

    def after_connect(self, interactive=True):
        self.home_identity = None
        self.live_category = None
        self.live_owner = self.session.connection
        super().after_connect(interactive=interactive)
        self.setProperty('shadow.restore.message', '' if self.session.prefs['setup_completed'] else
                         'Connected. Finish setup in Settings > Content > Run setup wizard.')
        self.refresh_shell()

    def connect_provider(self, *args, **kwargs):
        self.cancel_restore()
        return super().connect_provider(*args, **kwargs)

    def connect_playlist(self, *args, **kwargs):
        self.cancel_restore()
        return super().connect_playlist(*args, **kwargs)

    def settings(self):
        if self.restore_job is not None:
            self.cancel_restore()
            self.setProperty('shadow.restore.message', 'Restoration cancelled. Retry or choose a connection in Settings.')
        return super().settings()

    def extra_setting(self, action):
        if action == -8:
            from .demo import demo_connection
            self.cancel_restore()
            self.stop_playback()
            self.session.adopt(demo_connection(self.profile))
            self.demo = True
            self.after_connect()
        else:
            super().extra_setting(action)

    def open_page(self, page):
        if self.restore_job is not None and page not in ('Home', 'Settings'):
            self.setProperty('shadow.restore.message', 'Connecting in the background. Open Settings to change connection.')
            return
        super().open_page(page)
        if self.page == 'Live TV': self.apply_live_category()
        if self.page == 'Continue Watching':
            self.setFocusId(300 if self.rows else 100)
        self.setProperty('shadow.heading', 'My List' if self.page == 'Watch Later' else self.page)

    def apply_live_category(self):
        if self.live_owner is not self.session.connection:
            self.live_owner = self.session.connection
            self.live_category = None
        rows = self.session.visible(favourites=self.live_favourites)
        self.rows = [r for r in rows if self.live_category is None or str(r.get('category_id')) == self.live_category]
        names = {str(c['category_id']): c.get('category_name','Other')
                 for c in self.session.connection.categories} if self.session.connected else {}
        self.setProperty('shadow.live.category', names.get(self.live_category, 'All categories'))
        self.render_rows()

    def choose_live_category(self):
        if not self.session.connected:return
        rows = self.session.visible(favourites=self.live_favourites)
        ids = {str(r.get('category_id')) for r in rows}
        categories = [(str(c['category_id']), c.get('category_name','Other'))
                      for c in self.session.connection.categories if str(c['category_id']) in ids]
        categories.sort(key=lambda x:x[1].casefold())
        choice = self.dialog.select('Channel category', ['All categories'] + [c[1] for c in categories])
        if choice < 0:return
        self.live_category = None if choice == 0 else categories[choice-1][0]
        self.apply_live_category()
        self.setFocusId(300 if self.rows else 423)

    def refresh_shell(self):
        connected = self.session.connected
        self.setProperty('shadow.connected', 'true' if connected else 'false')
        prefs = self.session.prefs or {}
        history = self.session.history
        identity = (id(self.session.connection), prefs.get('revision'),
                    history.generation if history else None, tuple(prefs.get('content_types', [])),
                    tuple(prefs.get('browse_languages') or []), self._recent_media_identity)
        if identity != self.home_identity:
            self.home_identity = identity
            self.home_owner = self.session.connection
            self.home_rows = [self.media_art_row(row) for row in continuing(
                history, prefs.get('content_types', []),
                lambda row: self.matches_browse_language(self.media_art_row(row)))]
            self.home_favourites = self.session.visible(favourites=True)[:4] if connected and 'live' in prefs.get('content_types',[]) else []
            images = {}
            for index in range(2):
                row = self.home_rows[index] if index < len(self.home_rows) else None
                title = self.row_label(row) if row else ('Your next watch starts here' if index == 0 else 'More from your collection')
                self.setProperty('shadow.home.title.'+str(index), self.safe_text(title))
                self.setProperty('shadow.home.subtitle.'+str(index), 'Resume your movie or episode' if row else 'Unfinished titles will appear here.')
                self.setProperty('shadow.home.percent.'+str(index), str(progress(row)) if row else '0')
                self.setProperty('shadow.home.art.'+str(index), '')
                self.setProperty('shadow.home.action.'+str(index), 'Resume' if row else 'Browse movies')
                if row and prefs.get('programme_artwork') and not self.session.temporary:
                    images['home.'+str(index)] = self.media_art_row(row)
            for index in range(4):
                title = self.home_favourites[index]['name'] if index < len(self.home_favourites) else 'Browse Live TV'
                self.setProperty('shadow.home.favourite.'+str(index), self.safe_text(title))
            # Dedicated loader avoids interfering with the original recent-title grid.
            self.home_token = self.home_artwork.select(images)
        result = self.home_artwork.poll()
        if result and result[0] == self.home_token and self.home_owner is self.session.connection and connected:
            self.session.ensure_current()
            for key, path in result[1].items():self.setProperty('shadow.home.art.'+key.split('.')[-1], path)
        if self.channel and connected:
            self.setProperty('shadow.live.channel', self.safe_text(self.channel['name']))
            self.setProperty('shadow.live.star', 'Starred' if self.channel['stream_id'] in prefs.get('favourites',[]) else 'Star')
        else:
            self.setProperty('shadow.live.channel', 'Choose a channel')
            self.setProperty('shadow.live.star', 'Star')

    def on_startup_assets(self):
        from .artwork_loader import ArtworkGridLoader
        self.home_artwork = ArtworkGridLoader(self.media_poster_cache, self.tvmaze)

    def onClick(self, control):
        if self.playback_start_pending:return
        try:
            if control == 111:
                if not self.session.connected:self.start_restore()
            elif control == 112:self.settings()
            elif control in (650,651):
                self.session.ensure_current()
                index=control-650
                if self.home_owner is self.session.connection and index<len(self.home_rows):self.revisit_media(self.home_rows[index])
                else:self.open_page('Movies')
            elif 660<=control<=663:
                self.session.ensure_current()
                index=control-660
                if self.home_owner is self.session.connection and index<len(self.home_favourites):self.watch(self.home_favourites[index]['stream_id'])
                else:self.open_page('Live TV')
            elif control == 423:self.choose_live_category()
            elif control == 426:
                self.session.ensure_current()
                if self.channel and self.channel['stream_id'] in self.session.prefs['approved_channel_ids']:
                    ids=list(self.session.prefs['favourites']);key=self.channel['stream_id']
                    ids.remove(key) if key in ids else ids.append(key)
                    self.session.save({'favourites':ids})
                    if self.live_favourites:self.apply_live_category()
            elif control == 427:
                if self.channel:self.watch(self.channel['stream_id'])
            else:
                super().onClick(control)
                if control == 422:self.apply_live_category()
        except Exception:
            self.dialog.ok('Shadow', 'This action could not be completed. Your saved settings have not been reset.')

    def onAction(self, action):
        if self.restore_job is not None and action.getId() in (9,10,92,216,247,257):
            self.cancel_restore()
            self.setProperty('shadow.restore.message', 'Restoration cancelled. Retry or open Settings.')
            return
        super().onAction(action)

    def tick(self):
        self.poll_restore()
        super().tick()
        if self.running and self.initialized and time.monotonic() >= self.next_shell_refresh:
            self.next_shell_refresh=time.monotonic()+.5
            try:self.refresh_shell()
            except Exception:pass  # A presentation refresh must not interrupt playback.

    def shutdown(self):
        self.cancel_restore()
        if hasattr(self,'home_artwork'):self.home_artwork.close()
        super().shutdown()
