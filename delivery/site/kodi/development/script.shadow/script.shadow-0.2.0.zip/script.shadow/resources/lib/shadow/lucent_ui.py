"""Artwork Glass presentation on the accepted .57 account/playback adapter."""
import os
import time
import xbmc
import xbmcaddon
import xbmcgui
from .modern_ui import ModernShadowWindow
from .kodi_ui import ShadowWindow
from .lucent_dialogs import GlassDialog, BACK
from .glass import GlassCache
from .launch_state import IntroState
from .connection_lock import ConnectionLock
from .lucent_model import shelves, now_next, guide_layout
from .artwork_loader import ArtworkGridLoader
from .jobs import JobRunner

SETTINGS=[
 ('Connection',[(1,'Provider connection'),(23,'Connect saved provider'),(22,'Connection permissions'),(2,'Disconnect'),(14,'Import M3U playlist'),(15,'Refresh playlist'),(25,'Forget saved connection'),(27,'Remember permissions')]),
 ('Content',[(0,'Manage channels'),(7,'Favourite channels'),(5,'Custom categories'),(6,'Channel order'),(10,'Content types'),(11,'Setup wizard'),(26,'Clear watch history'),(29,'Backup personal data'),(30,'Restore personal data')]),
 ('Playback',[(-1,'Subtitle default'),(-2,'Preferred audio language'),(28,'Next episode'),(31,'Automatic reconnect'),(32,'Privacy shortcut · Coming soon'),(13,'Stop playback')]),
 ('Appearance',[(1001,'Open Shadow when Kodi starts'),(1002,'Startup animation'),(3,'Programme artwork')]),
 ('Help',[(12,'Test local video and audio'),(-8,'Explore offline demo'),(17,'Check local storage'),(19,'Check hostname lookup'),(-4,'Refresh catalogues'),(-7,'Artwork status'),(24,'Playback diagnostics')]),
 ('About',[(1003,'Shadow version and credits')])]
PROTECTED={1,2,8,14,15,16,18,20,21,22,23,25,27,30,-6}

class LucentShadowWindow(ModernShadowWindow):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.lucent_mode='home';self.list_rows={};self.list_art={};self.list_loaders={};self.list_tokens={};self.list_ranges={}
        self.art_owner=None;self.glass=None;self.glass_paths={};self.glass_token=0;self.selected_art=''
        self.detail=None;self.detail_return='Home';self.episodes=[];self.season=None
        self.settings_group=0;self.connection_lock=ConnectionLock(self.profile);self.unlock_deadline=0
        self.intro=None;self.next_lucent_tick=0;self.last_focus=None;self.collection_view=False
        self.guide_jobs=JobRunner();self.guide_pending=None;self.guide_retry={};self.home_signature=None
        self.addon=xbmcaddon.Addon('script.shadow')
        self.resume_settings=False;self.list_batches={};self.guide_top=0;self.guide_cells={};self.next_grid_paint=0

    def raw_focus(self):return xbmcgui.WindowXML.getFocusId(self)
    def getFocusId(self):
        focus=self.raw_focus()
        return 300 if focus in (740,741,750) or 1100<=focus<=1104 or 1200<=focus<=1239 else focus
    def setFocusId(self,id):
        if id==300:id={'guide':1100,'live':741,'collection':750,'catalogue':700}.get(self.lucent_mode,100)
        elif id==301:id=1100 if self.lucent_mode=='guide' else 741
        elif id in (420,421):id=750
        return xbmcgui.WindowXML.setFocusId(self,id)
    def on_startup_assets(self):
        super().on_startup_assets()
        self.dialog=GlassDialog(self.addon_path)
        try:self.glass=GlassCache(self.profile,self.addon_path)
        except Exception:self.glass=None
        enabled=self.addon.getSetting('launch_animation')!='false'
        required=('eclipse-sun.png','eclipse-moon.png','eclipse-glint.png','lucent-wordmark.png')
        enabled=enabled and all(os.path.isfile(os.path.join(self.addon_path,'resources','skins','Default','media',p)) for p in required)
        self.intro=IntroState(time.monotonic,enabled)
        self.setProperty('lucent.intro','true' if enabled else 'false')
        self.set_mode('home');self.setProperty('lucent.nav','Home')
    def on_startup(self):
        super().on_startup();self.setProperty('shadow.heading','Continue watching')
    def set_mode(self,mode):
        self.lucent_mode=mode;self.setProperty('lucent.mode',mode)
    def allow_connection(self):
        if self.connection_lock.unlocked and time.monotonic()<self.unlock_deadline:return True
        lock=self.connection_lock;lock.lock()
        if lock.broken:
            self.dialog.ok('Connection locked','The passcode record could not be read. Existing provider settings are preserved. Restore the original passcode file from your private backup.');return False
        if lock.data is None:
            first=self.dialog.pin('Create connection passcode','Choose four digits to protect connection changes.')
            if first is None:return False
            second=self.dialog.pin('Confirm connection passcode')
            accepted=lock.create(first,second);first=second=None
        else:
            pin=self.dialog.pin('Unlock connection settings','Enter your four-digit passcode.')
            if pin is None:return False
            accepted=lock.verify(pin);pin=None
        if accepted:self.unlock_deadline=time.monotonic()+120
        else:self.dialog.ok('Connection locked','Passcode not accepted. After five incorrect attempts, wait 30 seconds.')
        return accepted
    def connect_provider(self,*a,**k):
        if self.allow_connection():return super().connect_provider(*a,**k)
    def connect_playlist(self,*a,**k):
        if self.allow_connection():return super().connect_playlist(*a,**k)
    def configure_connection(self):
        if self.allow_connection():return super().configure_connection()
    def forget_saved_login(self):
        if self.allow_connection():return super().forget_saved_login()
    def privacy_settings(self):self.dialog.ok('Privacy shortcut','Coming soon. We are working on this feature.')
    def configure_privacy(self):return self.privacy_settings()
    def settings(self):
        self.cancel_restore();self.connection_lock.lock();self.page='Settings'
        self.setProperty('shadow.page','Settings');self.setProperty('shadow.heading','Settings');self.set_mode('settings')
        self.show_settings_group(0);self.setFocusId(900)
    def show_settings_group(self,index):
        if index!=self.settings_group:self.connection_lock.lock()
        self.settings_group=index;title,actions=SETTINGS[index]
        self.setProperty('lucent.settings.title',title)
        message='Connection changes require your four-digit passcode.' if index==0 else 'Black / silver Artwork Glass' if index==3 else 'Your Shadow experience'
        self.setProperty('lucent.settings.description',message)
        control=self.getControl(920);control.reset()
        labels=[]
        for action,name in actions:
            if action in (1001,1002):name+=' · '+('On' if self.addon.getSetting('autolaunch' if action==1001 else 'launch_animation')!='false' else 'Off')
            labels.append(xbmcgui.ListItem(label=name))
        control.addItems(labels)
    def setting_action(self):
        position=self.getControl(920).getSelectedPosition();actions=SETTINGS[self.settings_group][1]
        if not 0<=position<len(actions):return
        action=actions[position][0]
        if action in PROTECTED and not self.allow_connection():return
        if action in (1001,1002):
            key='autolaunch' if action==1001 else 'launch_animation'
            self.addon.setSetting(key,'false' if self.addon.getSetting(key)!='false' else 'true')
        elif action==1003:self.show_about()
        elif action<0:self.extra_setting(action)
        else:self.execute_setting(action)
        self.connection_lock.lock()
        if self.running and not self.playback_hidden:
            self.page='Settings';self.setProperty('shadow.page','Settings');self.setProperty('shadow.heading','Settings');self.set_mode('settings');self.show_settings_group(self.settings_group);self.setFocusId(920)
    def execute_setting(self,choice):
        if choice in PROTECTED and not self.allow_connection():return
        if choice==32:return self.privacy_settings()
        return super().execute_setting(choice)
    def open_page(self,page):
        if page=='Settings':return self.settings()
        if page=='Search':return self.global_search()
        self.connection_lock.lock()
        self.detail=None;self.collection_view=False
        if page=='Live TV':page='TV Guide'
        if page in ('Watch Later','Favourites Hub'):return self.open_favourites()
        self.set_mode('guide' if page=='TV Guide' else 'live' if page=='Favourites' else 'catalogue' if page in ('Movies','TV Series') else 'home' if page=='Home' else 'collection')
        super().open_page(page)
        if self.page!=page:
            self.set_mode('home' if self.page=='Home' else 'collection');return
        self.setProperty('lucent.nav','Live TV' if page in ('TV Guide','Favourites') else page)
        self.setProperty('shadow.heading','Live TV' if page in ('TV Guide','Favourites') else 'Continue watching' if page=='Home' else page)
        if page in ('Movies','TV Series'):self.refresh_shelves();self.setFocusId(700 if self.list_rows.get(700) else 701 if self.list_rows.get(701) else 680)
        elif page in ('TV Guide','Favourites'):
            self.sync_visible_rows()
            if page=='TV Guide':self.guide_top=0;self.paint_time_grid()
            self.setFocusId(1100 if page=='TV Guide' and self.rows else 741 if self.rows else 102)
        elif page not in ('Home','Settings'):self.sync_visible_rows()
    def global_search(self):
        if not self.session.connected:return self.settings()
        query=self.dialog.input('Search Live TV, Movies and TV Series',defaultt=self.search_query).strip()[:100]
        if not query:return
        self.connection_lock.lock();self.search_query=query;self.search_scope=0
        self.rows=self.search_results();self.page='Search';self.setProperty('shadow.page','Search');self.setProperty('shadow.heading','Search')
        self.set_mode('search');self.setProperty('lucent.search.query',self.safe_text(query))
        self.bind_grouped_results(self.rows)
    def bind_grouped_results(self,rows):
        self.rows=rows
        for identity,kind in ((760,None),(761,'movies'),(762,'series')):
            group=[row for row in rows if row.get('kind')==kind]
            self.bind_list(identity,group)
            self.setProperty('lucent.empty.'+str(identity),'No results in this section.' if not group else '')
        self.setFocusId(next((identity for identity in (760,761,762) if self.list_rows.get(identity)),107))
    def open_favourites(self):
        if not self.session.connected:return self.settings()
        self.connection_lock.lock();self.set_mode('search');self.page='Favourites Hub'
        self.setProperty('shadow.page',self.page);self.setProperty('shadow.heading','Favourites');self.setProperty('lucent.nav','Favourites')
        rows=list(self.session.visible(favourites=True))
        for kind in ('movies','series'):
            if kind in self.session.prefs.get('content_types',[]) and not self.is_playlist():
                if self.ensure_catalogue(kind):
                    saved=set(self.session.prefs.get('watch_later_'+kind,[]));rows.extend(r for r in getattr(self.session,kind) if r['id'] in saved)
        self.setProperty('lucent.search.query','Saved channels, movies and series');self.bind_grouped_results(rows)
    def apply_live_category(self):
        self.live_favourites=self.page=='Favourites'
        super().apply_live_category()
    def choose_live_category(self):
        self.live_favourites=self.page=='Favourites'
        super().choose_live_category()
        self.guide_top=0;self.sync_visible_rows();self.paint_time_grid()
    def render_rows(self):
        super().render_rows()
        if self.lucent_mode!='catalogue':self.sync_visible_rows()
    def populate_rows(self):
        super().populate_rows()
    def sync_visible_rows(self):
        id={'guide':740,'live':741,'collection':750}.get(self.lucent_mode)
        if id:self.bind_list(id,self.rows)
    def bind_list(self,id,rows):
        self.list_rows[id]=list(rows);self.list_art[id]={}
        control=self.getControl(id);control.reset()
        # Bounded shelf sizes; full catalogue is incrementally populated separately.
        items=[]
        for row in rows[:250]:
            item=xbmcgui.ListItem(label=self.row_label(row),label2=row.get('plot','')[:100])
            if row.get('stream_id'):
                now,next_up=now_next(self.session.epg.get(row['stream_id'],[]),time.time())
                item.setProperty('now',(now or {}).get('title','Guide unavailable'))
                item.setProperty('next',(next_up or {}).get('title','No listing supplied'))
            items.append(item)
        control.addItems(items)
        self.list_batches[id]=250 if len(rows)>250 else None
        self.list_ranges.pop(id,None)
        self.request_list_art(id,0)
    def refresh_shelves(self):
        if not self.session.connected:return
        kind='movies' if self.page=='Movies' else 'series'
        data=shelves(self.rows,self.session.history,self.session.prefs,kind)
        for id,rows in data.items():
            self.bind_list(id,rows)
            messages={700:'Your unfinished titles will appear here.',701:'No provider ratings available. Browse your full collection above.',702:'No release dates supplied by your provider.',703:'Save titles from their details page to see them here.'}
            self.setProperty('lucent.empty.'+str(id),messages[id] if not rows else '')
        self.setProperty('lucent.shelves.empty','No titles available. Use Browse / filters to explore your collection.' if not any(data.values()) else '')
    def populate_lucent_lists(self):
        for identity,start in list(self.list_batches.items()):
            if start is None:continue
            rows=self.list_rows.get(identity,[]);end=min(start+250,len(rows))
            items=[]
            for row in rows[start:end]:
                item=xbmcgui.ListItem(label=self.row_label(row),label2=row.get('plot','')[:100])
                if row.get('stream_id'):
                    current,next_up=now_next(self.session.epg.get(row['stream_id'],[]),time.time())
                    item.setProperty('now',(current or {}).get('title','Guide unavailable'))
                    item.setProperty('next',(next_up or {}).get('title','No listing supplied'))
                items.append(item)
            self.getControl(identity).addItems(items)
            self.list_batches[identity]=end if end<len(rows) else None
    def request_list_art(self,id,index):
        if not self.session.connected or self.session.temporary or not self.session.prefs.get('programme_artwork'):return
        start=max(0,index)//5*5;rows=self.list_rows.get(id,[])
        if self.list_ranges.get(id)==(self.session.connection,start):return
        self.list_ranges[id]=(self.session.connection,start)
        if id not in self.list_loaders:self.list_loaders[id]=ArtworkGridLoader(self.media_poster_cache,self.tvmaze)
        images={str(i):(self.media_art_row(rows[i]) if rows[i].get('kind') in ('movies','series') else {'artwork':rows[i].get('stream_icon','')}) for i in range(start,min(start+8,len(rows)))}
        self.list_tokens[id]=self.list_loaders[id].select(images)
    def after_connect(self,interactive=True):
        self.reset_presentation();super().after_connect(interactive)
        if not interactive:self.setFocusId(650)
    def reset_presentation(self):
        for loader in self.list_loaders.values():loader.close()
        self.list_loaders={};self.list_tokens={};self.list_ranges={};self.list_art={};self.list_rows={};self.list_batches={};self.glass_paths={};self.home_signature=None
        if self.glass:self.glass.reset()
        self.selected_art='';self.guide_top=0;self.guide_cells={}
        for key in ('background','detail.art','home.0','home.1','panel.510.928.900.112','panel.64.266.1792.198','panel.706.274.1150.600','panel.455.215.1400.665'):
            self.setProperty('lucent.'+key,'')
        xbmcgui.Window(10000).setProperty('shadow.dialog.background','')
        self.art_owner=self.session.connection
    def refresh_shell(self):
        super().refresh_shell()
        if self.art_owner is not self.session.connection:self.reset_presentation()
        signature=(self.session.connection,(self.session.prefs or {}).get('revision'))
        if signature!=self.home_signature:
            self.home_signature=signature
            favourites=list(self.session.visible(favourites=True))[:20] if self.session.connected else []
            for kind in ('movies','series'):
                saved=set((self.session.prefs or {}).get('watch_later_'+kind,[]))
                favourites.extend(r for r in getattr(self.session,kind,[]) if r['id'] in saved)
            self.bind_list(660,favourites[:40])
            self.setProperty('lucent.home.empty','Star channels or save movies and series to see them here.' if not favourites else '')
        for i in range(2):
            path=self.getProperty('shadow.home.art.'+str(i))
            if path:self.glass_paths['home.'+str(i)]=path
            else:
                self.glass_paths.pop('home.'+str(i),None);self.setProperty('lucent.home.'+str(i),'')
            if i<len(self.home_rows):
                row=self.home_rows[i];remaining=max(0,row.get('duration',0)-row.get('position',0))
                if remaining:self.setProperty('shadow.home.subtitle.'+str(i),str(max(1,int((remaining+59)//60)))+' min remaining')
        self.setProperty('lucent.description',self.getControl(311).getText())
    def matches_browse_language(self,row):
        return True if row.get('kind')=='series' else super().matches_browse_language(row)
    def select_title(self,row):return self.show_detail(row)
    def choose_media(self,row):return self.show_detail(row)
    def show_detail(self,row):
        self.detail_return=self.page if self.lucent_mode!='details' else self.detail_return
        self.detail=dict(row);self.detail_owner=self.session.connection;self.episodes=[];self.season=None
        if row.get('kind')=='series' and not row.get('series_id'):
            from .media import episodes_from_payload
            owner=self.session.connection
            payload=self.run_job('Loading episodes…',lambda:owner.client.series_info(row['id']))
            if payload is None or owner is not self.session.connection:return
            self.episodes=episodes_from_payload(payload,row)
            if self.episodes:self.season=self.episodes[0]['season']
        self.page='TV Series' if row.get('kind')=='series' else 'Movies'
        self.set_mode('details');self.setProperty('shadow.page','Details')
        self.setProperty('shadow.heading','TV Series' if row.get('kind')=='series' else 'Movies')
        self.setProperty('lucent.detail.title',self.safe_text(row['name']))
        self.setProperty('lucent.detail.plot',self.safe_text(row.get('plot') or 'No description supplied.',True))
        previous=self.session.history.find(row) if self.session.history else None
        self.setProperty('lucent.detail.play','Resume' if previous and previous.get('position',0)>0 and not previous.get('completed') else 'Play')
        self.setProperty('lucent.detail.art',self.selected_art)
        self.setProperty('shadow.artwork','')
        self.poster_row=self.media_art_row(row)
        if not self.session.temporary and self.session.prefs.get('programme_artwork'):
            self.poster_token=self.artwork.select(self.poster_row,{'stream_id':'poster'},['poster'],True)
            if not row.get('plot'):self.overview_token=self.overviews.select(self.poster_row)
        self.getControl(311).setText(row.get('plot') or 'No description supplied.')
        self.setProperty('lucent.detail.series','true' if self.episodes else 'false')
        self.setProperty('lucent.detail.expanded','false');self.setProperty('lucent.detail.view','All episodes')
        self.render_episodes();self.setFocusId(850)
    def render_episodes(self):
        self.setProperty('lucent.detail.season','Season '+str(self.season) if self.season is not None else 'Back to collection')
        rows=[r for r in self.episodes if r['season']==self.season]
        self.bind_list(860,rows);self.bind_list(861,rows)
    def play_detail(self,row=None,start_over=False):
        row=row or self.detail
        if not row or getattr(self,'detail_owner',None) is not self.session.connection:return
        self.session.ensure_current()
        if row.get('kind')=='series' and not row.get('series_id'):
            candidates=self.list_rows.get(860,[])
            if not candidates:self.dialog.ok('Episodes unavailable','No episodes were supplied.');return
            row=candidates[0]
        old=self.session.history.find(row) if self.session.history else None
        self.watch_media(row,0 if start_over else old['position'] if old and not old.get('completed') else 0)
    def onClick(self,control):
        if self.intro and not self.intro.finished:self.skip_intro();return
        if self.playback_start_pending:return
        try:
            if control in self.list_rows or control in (850,851,852,853,854) or 1100<=control<=1104 or 1200<=control<=1239:
                if not self.session.connected or self.art_owner is not self.session.connection:return
                self.session.ensure_current()
            if 1100<=control<=1104:
                index=self.guide_top+control-1100
                if index<len(self.rows):self.watch(self.rows[index]['stream_id'])
                return
            if 1200<=control<=1239:
                row=(control-1200)//8;index=self.guide_top+row
                if index<len(self.rows):self.watch(self.rows[index]['stream_id'])
                return
            if control in (102,101):return self.open_page('TV Guide')
            if control==422:return self.open_page('Favourites')
            if control==105:return self.open_favourites()
            if control==108:return self.settings()
            if 900<=control<=905:self.show_settings_group(control-900);self.setFocusId(920);return
            if control==920:return self.setting_action()
            if control==680:
                options=['Browse all titles','Search titles','Genre','Release year','Sort','Reset filters']
                selected=self.dialog.select('Movies / Series',options)
                if selected<0:return
                if selected:self.filter_catalogue({1:320,2:322,3:323,4:324,5:325}[selected])
                self.set_mode('collection');self.collection_view=True;self.sync_visible_rows();self.setFocusId(750 if self.rows else 751);return
            if control==751:
                if self.page in ('Movies','TV Series'):return self.onClick(680)
                return self.open_page('Search')
            if control in self.list_rows:
                index=self.getControl(control).getSelectedPosition();rows=self.list_rows[control]
                if not 0<=index<len(rows):return
                row=rows[index]
                self.selected_art=self.list_art.get(control,{}).get(index,self.selected_art)
                if control in (860,861):return self.play_detail(row)
                if row.get('kind') in ('movies','series'):return self.show_detail(row)
                return self.watch(row['stream_id'])
            if control==850:return self.play_detail()
            if control==851:
                if getattr(self,'detail_owner',None) is not self.session.connection:return
                if self.detail:self.toggle_watch_later(self.detail)
                return
            if control==852:
                if getattr(self,'detail_owner',None) is not self.session.connection:return
                selection=self.dialog.select('Title options',['Start over','Mark watched / unwatched','Remove watch progress'])
                if selection==0:self.play_detail(start_over=True)
                elif selection==1:self.toggle_watched(self.detail)
                elif selection==2 and self.session.history:self.session.history.remove(self.detail)
                return
            if control==854:
                expanded=self.getProperty('lucent.detail.expanded')!='true'
                self.setProperty('lucent.detail.expanded','true' if expanded else 'false')
                self.setProperty('lucent.detail.view','Episode cards' if expanded else 'All episodes')
                self.setFocusId(861 if expanded else 860);return
            if control==853:
                if self.episodes:
                    seasons=sorted({r['season'] for r in self.episodes});selected=self.dialog.select('Season',['Season '+str(s) for s in seasons])
                    if selected>=0:self.season=seasons[selected];self.render_episodes();self.setFocusId(860)
                else:self.open_page(self.detail_return)
                return
            super().onClick(control)
        except Exception:self.dialog.ok('Shadow','This action could not be completed. Your saved preferences are preserved.')
    def skip_intro(self):
        if self.intro:self.intro.skip()
        self.setProperty('lucent.intro','false')
    def onAction(self,action):
        if self.intro and not self.intro.finished:
            if action.getId() in BACK+(7,):self.skip_intro()
            return
        if action.getId() in BACK and self.lucent_mode=='details' and not self.playback_hidden and not self._playback_return:return self.open_page(self.detail_return)
        if action.getId() in BACK and self.collection_view and self.page in ('Movies','TV Series'):return self.open_page(self.page)
        super().onAction(action)
    def poll_overlay(self):
        visible=xbmc.getCondVisibility('Window.IsVisible(videoosd)')
        if not visible:self.osd_latched=False
        if self.overlay and self.overlay.active:self.overlay.tick();return
        if visible and not self.osd_latched and self.playback and self.playback.started:
            from .lucent_player import PlayerSurface
            self.osd_latched=True
            self.overlay=PlayerSurface('LucentPlayer.xml',self.addon_path,'Default','1080i',owner=self)
            xbmc.executebuiltin('Dialog.Close(videoosd)',False)
            self.overlay.show()
    def poll_overlay_action(self):
        if self.overlay and self.overlay.event and self.overlay.event[0]=='player':
            _,identity,owner=self.overlay.event;self.overlay.event=None
            if owner is not self.session.connection or not self.playback:return True
            player=self.playback.player
            try:
                if identity==801:player.pause()
                elif identity in (800,802):
                    position=player.getTime()+(-10 if identity==800 else 10)
                    player.seekTime(max(0,min(position,max(0,player.getTotalTime()-1))))
                elif identity==803:
                    names=player.getAvailableAudioStreams();selected=self.dialog.select('Audio',names)
                    if selected>=0:player.setAudioStream(selected)
                elif identity==804:
                    names=player.getAvailableSubtitleStreams();selected=self.dialog.select('Subtitles',['Off']+names)
                    if selected==0:player.showSubtitles(False)
                    elif selected>0:player.setSubtitleStream(selected-1);player.showSubtitles(True)
                elif identity==805:
                    rows=self.session.visible();selected=self.dialog.select('Channels',[r['name'] for r in rows])
                    if selected>=0:self.overlay.dismiss();self.request_switch(rows[selected]['stream_id'])
            except Exception:self.dialog.ok('Playback','That control is unavailable for this stream.')
            return True
        return super().poll_overlay_action()
    def paint_time_grid(self):
        if self.lucent_mode!='guide':return
        self.guide_top=max(0,min(self.guide_top,max(0,len(self.rows)-5)))
        self.setProperty('lucent.guide.more','true' if self.guide_top+5<len(self.rows) else 'false')
        self.setProperty('lucent.guide.previous','true' if self.guide_top else 'false')
        start=int(time.time()//1800)*1800;end=start+7200
        for i in range(4):self.setProperty('lucent.guide.time.'+str(i),time.strftime('%H:%M',time.localtime(start+i*1800)))
        self.setProperty('lucent.guide.empty','No approved channels. Manage channels in Settings > Content.' if not self.rows else '')
        self.guide_cells={};targets=[]
        for r in range(5):
            index=self.guide_top+r;present=index<len(self.rows)
            self.setProperty('lucent.guide.row.'+str(r),'true' if present else 'false')
            cells=guide_layout(self.session.epg.get(self.rows[index]['stream_id'],[]),start,end) if present else []
            if present:self.setProperty('lucent.guide.channel.'+str(r),self.safe_text(self.rows[index]['name']))
            ids=[]
            for col in range(8):
                identity=1200+r*8+col;exists=col<len(cells)
                self.setProperty('lucent.guide.cell.'+str(identity),'true' if exists else 'false')
                if exists:
                    cell=cells[col];control=self.getControl(identity);control.setPosition(484+cell['x'],536+r*66);control.setWidth(max(1,cell['width']-6));control.setLabel(self.safe_text(cell['title']))
                    self.guide_cells[identity]=cell;ids.append(identity)
            targets.append(ids)
        for r,ids in enumerate(targets):
            if not ids:continue
            channel=self.getControl(1100+r)
            channel.setNavigation(self.getControl((1106 if self.guide_top else 102) if r==0 else 1099+r),self.getControl(1101+r if r<4 and self.guide_top+r+1<len(self.rows) else 1105 if self.guide_top+5<len(self.rows) else 101),self.getControl(102),self.getControl(ids[0]))
            for col,identity in enumerate(ids):
                up=targets[r-1][min(col,len(targets[r-1])-1)] if r>0 and targets[r-1] else 1106 if self.guide_top else 102
                down=targets[r+1][min(col,len(targets[r+1])-1)] if r<4 and targets[r+1] else 1105 if self.guide_top+5<len(self.rows) else 101
                self.getControl(identity).setNavigation(self.getControl(up),self.getControl(down),channel if col==0 else self.getControl(ids[col-1]),self.getControl(ids[col+1]) if col+1<len(ids) else self.getControl(422))
        self.getControl(1180).setPosition(484+round((time.time()-start)/(end-start)*1372),530)
    def onFocus(self,control):
        if self.lucent_mode=='guide' and control in (1105,1106):
            self.guide_top+=1 if control==1105 else -1
            self.paint_time_grid();self.setFocusId(1104 if control==1105 else 1100)
            self.onFocus(1104 if control==1105 else 1100);return
        if self.lucent_mode=='guide' and (1100<=control<=1104 or 1200<=control<=1239):
            row=control-1100 if control<1200 else (control-1200)//8
            index=self.guide_top+row
            if index<len(self.rows):
                self.getControl(300).selectItem(index);self.getControl(740).selectItem(index)
    def poll_guide_rows(self):
        if self.lucent_mode!='guide' or not self.session.connected:return
        if self.guide_pending:
            job,owner,key=self.guide_pending
            if not job.done.is_set():return
            self.guide_pending=None
            try:
                result=job.take()
                if owner is self.session.connection and result:self.session.accept_epg(result)
            except Exception:self.guide_retry[key]=time.monotonic()+300
            rows=self.list_rows.get(740,[])
            for i,row in enumerate(rows[:self.getControl(740).size()]):
                if row['stream_id']==key:
                    current,next_up=now_next(self.session.epg.get(key,[]),time.time())
                    item=self.getControl(740).getListItem(i);item.setProperty('now',(current or {}).get('title','Guide unavailable'));item.setProperty('next',(next_up or {}).get('title','No listing supplied'))
        start=self.guide_top
        for row in self.rows[start:start+5]:
            key=row['stream_id']
            if not self.session.epg_fresh(key) and time.monotonic()>=self.guide_retry.get(key,0):
                self.guide_retry[key]=time.monotonic()+60
                try:self.guide_pending=(self.guide_jobs.submit(self.session.epg_request(key)),self.session.connection,key)
                except Exception:pass
                break
    def tick(self):
        if self.intro:self.setProperty('lucent.intro','true' if self.intro.tick() else 'false')
        if self.connection_lock.unlocked and (time.monotonic()>self.unlock_deadline or xbmc.getCondVisibility('System.ScreenSaverActive') or xbmc.getCondVisibility('System.DPMSActive')):self.connection_lock.lock()
        focus=self.raw_focus()
        if focus in (740,741,750):
            position=self.getControl(focus).getSelectedPosition()
            if 0<=position<len(self.rows):self.getControl(300).selectItem(position)
        self.populate_lucent_lists()
        super().tick()
        if not self.running or self.playback_hidden:return
        if time.monotonic()<self.next_lucent_tick:return
        self.next_lucent_tick=time.monotonic()+.12
        try:
            if self.art_owner is not self.session.connection:self.reset_presentation()
            focus=self.raw_focus();selected=None
            if self.lucent_mode=='details' and getattr(self,'detail_owner',None) is self.session.connection:
                detail_art=self.getProperty('shadow.artwork')
                if detail_art:self.setProperty('lucent.detail.art',detail_art)
                self.setProperty('lucent.detail.plot',self.getControl(311).getText())
            if focus in self.list_rows:
                index=self.getControl(focus).getSelectedPosition();self.request_list_art(focus,index)
                selected=self.list_art.get(focus,{}).get(index)
            elif focus in (650,651):selected=self.getProperty('shadow.home.art.'+str(focus-650))
            if not selected:selected=self.getProperty('shadow.artwork') or self.getProperty('shadow.home.art.0')
            if selected:
                self.selected_art=selected;self.glass_paths['background']=selected
                for rect in ('510.928.900.112','64.266.1792.198','706.274.1150.600','455.215.1400.665'):
                    self.glass_paths['panel.'+rect]=selected
            for id,loader in self.list_loaders.items():
                result=loader.poll()
                if not result or result[0]!=self.list_tokens.get(id):continue
                for key,path in result[1].items():
                    index=int(key);self.list_art.setdefault(id,{})[index]=path
                    self.getControl(id).getListItem(index).setArt({'thumb':path})
                    self.glass_paths[str(id)+'.'+key]=path
            if self.glass:
                # Bound the working set to visible selections and recent item textures.
                if len(self.glass_paths)>64:self.glass_paths={k:v for k,v in self.glass_paths.items() if k in ('background','home.0','home.1') or k.startswith('panel.')}
                self.glass_token=self.glass.select(self.glass_paths)
                for token,key,path in self.glass.poll():
                    if token!=self.glass_token:continue
                    if key in ('background','home.0','home.1') or key.startswith('panel.'):
                        self.setProperty('lucent.'+key,path)
                        if key=='background':xbmcgui.Window(10000).setProperty('shadow.dialog.background',path)
                    else:
                        id,index=map(int,key.split('.'));self.getControl(id).getListItem(index).setProperty('glass',path)
            self.poll_guide_rows()
            if self.lucent_mode=='guide' and time.monotonic()>=self.next_grid_paint:
                self.paint_time_grid();self.next_grid_paint=time.monotonic()+1
            if focus in self.guide_cells:
                cell=self.guide_cells[focus];self.setProperty('shadow.programme',self.safe_text(cell['title']))
                self.setProperty('lucent.description',self.safe_text(cell.get('description') or 'Select to watch this channel live.'))
        except Exception:pass  # Presentation failures must never interrupt playback.
    def shutdown(self):
        self.connection_lock.lock()
        xbmcgui.Window(10000).setProperty('shadow.dialog.background','')
        if self.glass:self.glass.close()
        for loader in self.list_loaders.values():loader.close()
        self.guide_jobs.close();super().shutdown()
