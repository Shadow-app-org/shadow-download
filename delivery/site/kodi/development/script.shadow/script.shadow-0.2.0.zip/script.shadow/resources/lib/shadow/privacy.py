"""GUI-thread privacy switching; provider work stays in the existing job runner.

The cover is local. Only a deliberate return may reopen the saved original.
Snapshots contain catalogue identities, never provider URLs or credentials.
"""
import json
import math
import time
import xbmc
import xbmcgui
import xbmcvfs
from .jobs import JobRunner
from .privacy_input import Keymap, Mailbox, MappingError


class PrivacyCover(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.intent = None
        self.window_id = 0

    def onInit(self):
        self.window_id = xbmcgui.getCurrentWindowDialogId()

    def onAction(self, action):
        value = action.getId()
        if value in getattr(self, 'return_actions', (18, 34)):  # Default Y fallback only when Y is selected.
            self.intent = 'return'
        elif value in (9, 10, 13, 92, 216, 247, 257):
            self.intent = 'exit'


def mute(value=None):
    method = 'Application.GetProperties' if value is None else 'Application.SetMute'
    params = {'properties': ['muted']} if value is None else {'mute': value}
    result = json.loads(xbmc.executeJSONRPC(json.dumps(
        {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    answer = result.get('result')
    answer = answer.get('muted') if value is None and isinstance(answer, dict) else answer
    if type(answer) is not bool or (value is not None and answer != value):
        raise RuntimeError('Audio state unavailable')
    return answer


class Privacy:
    def __init__(self, owner, clock=time.monotonic):
        self.owner, self.clock = owner, clock
        self.mapping = Keymap(xbmcvfs.translatePath('special://profile/keymaps'),
            [xbmcvfs.translatePath('special://masterprofile/keymaps')],
            lambda: xbmc.executebuiltin('Action(reloadkeymaps)'))
        self.mailbox = Mailbox(xbmcgui.Window(10000), clock)
        self.jobs = JobRunner()
        self.state = None
        self.cover = None
        self.previous_mute = None
        self.last_request = float('-inf')
        self.last_error = ''
        self.enabled = False
        try:
            from .privacy_input import PREFIX
            heartbeat = float(self.mailbox.window.getProperty(PREFIX + 'heartbeat'))
            fresh_owner = 0 <= clock() - heartbeat <= 2
        except (ValueError, TypeError):
            fresh_owner = False
        if fresh_owner:
            self.report('Another Shadow window owns the shortcut. Close it before enabling privacy here.')
            return
        try:
            self.mapping.recover()
        except MappingError as error:
            self.report(str(error))

    def report(self, message):
        self.last_error = message
        xbmc.log('Shadow privacy: ' + message, xbmc.LOGWARNING)

    def arm(self):
        if self.state:
            return
        selected = self.owner.session.prefs.get('privacy_channel_id', '')
        if not selected:
            self.disarm()
            return
        try:
            button = self.owner.session.prefs.get('privacy_button', 'y')
            if self.mapping.installed and self.mapping.button != button:
                self.mapping.remove()
            self.mapping.button = button
            self.mapping.install()
            self.enabled = True
        except MappingError as error:
            self.enabled = False
            self.report(str(error))
            self.owner.dialog.ok('Privacy shortcut unavailable', str(error))

    def disarm(self):
        self.enabled = False
        self.mailbox.close()
        try:
            self.mapping.remove()
        except MappingError as error:
            self.report(str(error))

    def show_cover(self):
        if self.cover is None:
            self.cover = PrivacyCover('ShadowPrivacy.xml', self.owner.addon_path, 'Default', '1080i')
            self.cover.return_actions = (18, 34) if self.owner.session.prefs.get('privacy_button', 'y') == 'y' else ()
            self.cover.show()

    def hide_cover(self):
        cover, self.cover = self.cover, None
        if cover is not None:
            cover.close()

    def silence(self):
        if self.previous_mute is None:
            self.previous_mute = mute()
        mute(True)

    def restore_audio(self):
        if self.previous_mute is not None:
            mute(self.previous_mute)
            self.previous_mute = None

    def owned(self):
        p = self.owner.playback
        return bool(p and p.url and p.player.isPlaying() and p.player.getPlayingFile() == p.url)

    def valid(self):
        w, s = self.owner, self.state
        if not s or w.session.connection is not s['connection']:
            return False
        w.session.ensure_current()
        return w.session.prefs['revision'] == s['revision']

    def request(self):
        now = self.clock()
        if now - self.last_request < .75:
            return
        self.last_request = now
        w = self.owner
        try:
            if self.state:
                # Do not queue repeated toggles while a switch is in flight.
                if self.state['phase'] in ('active', 'failed'):
                    if not self.valid():
                        self.fail('Account or approval changed. Exit privacy and reconnect.')
                        return
                    self.state['returning'] = True
                    self.transition()
                return
            if (not self.enabled or not self.owned() or not w.playback.started or
                    w.playback_start_pending or w.switch_state is not None):
                return
            channel = w.session.prefs.get('privacy_channel_id', '')
            media = dict(w.playing_media) if w.playing_media else None
            if media is None and not w.playing_channel:
                return
            self.state = {'connection': w.session.connection, 'revision': w.session.prefs['revision'],
                          'channel': channel, 'original_channel': w.playing_channel,
                          'media': media, 'position': None if media else 0, 'returning': False,
                          'phase': 'stopping', 'job': None}
            w.session.ensure_current()
            if ('live' not in w.session.prefs['content_types'] or
                    channel not in w.session.prefs['approved_channel_ids']):
                self.fail('Selected privacy channel is no longer approved. B exits; choose another in Settings > Playback.')
                return
            if media:
                position = w.playback.player.getTime()
                if type(position) not in (int, float) or not math.isfinite(position) or position < 0:
                    raise ValueError('Invalid resume position')
                self.state['position'] = position
            self.transition()
        except Exception:
            if self.state:
                self.fail('Privacy switch could not be prepared. B exits; the privacy shortcut retries the return.')
            else:
                self.report('Privacy could not capture the current player state.')

    def transition(self):
        w, s = self.owner, self.state
        self.jobs.close()
        w.reconnect_context = None
        w.cancel_next_episode()
        w.cancel_switch()
        w.sample_media()
        w.finish_media()
        w.close_overlay()
        w.clear_playback_clock()
        s.update(phase='stopping', job=None, deadline=self.clock() + 30)
        try:
            self.silence()
            self.show_cover()
        finally:
            # Revoke even when a native UI/audio capability fails.
            if w.playback:
                w.playback.stop()
        w._playback_return = None

    def fail(self, message):
        self.report(message)
        if self.state is None:
            return
        self.jobs.close()
        self.state['phase'] = 'failed'
        self.state['job'] = None
        self.owner.reconnect_context = None
        try:
            self.silence()
        except Exception:
            self.report('Privacy mute failed; playback stop requested. Do not rely on this runtime for immediate privacy.')
        try:
            self.show_cover()
        except Exception:
            self.report('Privacy cover failed; playback stop requested. Do not rely on this runtime for immediate privacy.')
        if self.owner.playback:
            self.owner.playback.stop()

    def exit(self):
        if self.state:
            self.jobs.close()
            self.owner.reconnect_context = None
            self.state['phase'] = 'exiting'
            if self.owner.playback:
                self.owner.playback.stop()

    def clear(self):
        self.jobs.close()
        try:
            self.restore_audio()
        except Exception:
            self.report('Audio restoration failed. Restore Kodi volume manually.')
        self.state = None
        self.hide_cover()
        self.disarm()

    def tick(self):
        w = self.owner
        if self.enabled:
            self.mailbox.publish(w.playback.url if w.playback else None, getattr(self.cover, 'window_id', 0) if self.cover else 0)
            if self.mailbox.take():
                self.request()
        if self.cover and self.cover.intent:
            intent, self.cover.intent = self.cover.intent, None
            self.exit() if intent == 'exit' else self.request()
        s = self.state
        if s is None:
            return False
        if s['phase'] == 'active':
            # Normal playback polling still detects transport/approval failures.
            try:
                if not self.valid():
                    self.fail('Account or approval changed. B exits privacy.')
                    return True
            except Exception:
                self.fail('Account settings unavailable. B exits privacy.')
                return True
            return False
        prepared = None
        try:
            p = w.playback
            if s['phase'] == 'exiting':
                if p and not p.return_ready():
                    return True
                self.clear()
                w.stop_playback()
                return True
            if s['phase'] == 'failed':
                return True
            if not self.valid():
                raise RuntimeError('Approval changed')
            if self.clock() >= s['deadline']:
                raise RuntimeError('Switch deadline')
            if s['phase'] == 'stopping':
                if p and (not p.return_ready() or p.player.isPlaying()):
                    return True
                s.update(phase='preparing', deadline=self.clock() + 90)
                return True
            if s['phase'] == 'preparing':
                if p and p.player.isPlaying():
                    raise RuntimeError('Another player started')
                if s['job'] is None:
                    if self.jobs.active and not self.jobs.active.done.is_set():
                        return True
                    def prepare():
                        if w.session.connection is not s['connection']:
                            raise RuntimeError('Account changed')
                        if s['returning'] and s['media']:
                            from .media import prepare_media
                            if s['position'] is None:
                                raise RuntimeError('Original resume position unavailable')
                            value = prepare_media(w.session, s['media'])
                            if not getattr(value.source, 'seekable', True) and s['position'] > 0:
                                value.close()
                                raise RuntimeError('Original title cannot resume')
                            value.media['resume'] = s['position']
                            return value
                        from .playback import prepare_playback
                        channel = s['original_channel'] if s['returning'] else s['channel']
                        return prepare_playback(w.session, channel, expected_connection=s['connection'])
                    s['job'] = self.jobs.submit(prepare, lambda value: value.close())
                    return True
                if not s['job'].done.is_set():
                    return True
                prepared = s['job'].take()
                if prepared is None or not self.valid() or not prepared.permitted():
                    raise RuntimeError('Preparation cancelled or revoked')
                w.watching_channel = w.playing_channel = (s['original_channel'] if s['returning'] else s['channel']) if not getattr(prepared, 'media', None) else None
                s.update(phase='starting', deadline=self.clock() + 35)
                w.begin_playback(prepared)
                prepared = None
                return True
            if s['phase'] == 'starting':
                if not p or not p.url or p.tick(True):
                    raise RuntimeError('Target playback failed')
                if p.started and self.owned() and p.player.isPlayingVideo():
                    # Old stream is stopped; only the newly prepared stream can
                    # be revealed. Native fullscreen handoff continues normally.
                    self.restore_audio()
                    self.hide_cover()
                    p.fullscreen_seen = False
                    if s['returning']:
                        self.state = None
                    else:
                        s['phase'] = 'active'
                    return False
                return True
        except Exception as error:
            if prepared is not None:
                prepared.close()
            from .live_reconnect import diagnostic
            code, stage, status = diagnostic(error)
            detail = '%s/%s%s' % (code, stage, (' HTTP %d' % status) if status is not None else '')
            self.fail('Privacy transition failed (%s). Original content remains stopped. The privacy shortcut returns; B exits.' % detail)
        return True

    def close(self):
        self.jobs.close()
        if self.state and self.owner.playback:
            self.owner.playback.stop()
        # Do not unmute a still-stopping original stream on shutdown.
        if self.previous_mute is not None:
            try:
                if not self.owner.playback or not self.owner.playback.player.isPlaying():
                    self.restore_audio()
                else:
                    self.report('Kodi remains muted until playback stops; restore volume manually if needed.')
            except Exception:
                self.report('Audio restoration unavailable during exit.')
        self.state = None
        self.hide_cover()
        self.disarm()
