"""Shadow development build. Target: Kodi 21; this candidate requires native Mac/Xbox verification."""
import os
import sys
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ROOT = ADDON.getAddonInfo('path')
sys.path.insert(0, os.path.join(ROOT, 'resources', 'lib'))
from shadow.lucent_ui import LucentShadowWindow as ShadowWindow


def main():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    from shadow.launch_state import LaunchGuard
    guard = LaunchGuard(profile)
    if not guard.acquire():
        xbmc.log('Shadow is already open or its local launch guard is unavailable.', xbmc.LOGINFO)
        return
    window = None
    try:
        window = ShadowWindow('Shadow.xml', ROOT, 'Default', '1080i', profile=profile)
        window.privacy = None
        monitor = xbmc.Monitor()
        window.show()
        while window.running and not monitor.waitForAbort(.05):
            window.tick()
    except Exception:
        xbmc.log('Shadow could not finish opening. Kodi remains available.', xbmc.LOGERROR)
    finally:
        try:
            if window is not None:window.shutdown()
        finally:
            guard.close()


if __name__ == '__main__':
    main()
