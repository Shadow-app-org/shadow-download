"""Local artwork frosting. One bounded worker, latest selection wins, no network."""
import hashlib
import os
import time
from queue import Queue, Empty
from threading import Thread, Lock


def render_glass(source, destination, key="background"):
    from PIL import Image, ImageFilter, ImageEnhance, ImageOps
    if os.path.getsize(source) > 12 * 1024 * 1024:
        raise ValueError('Image too large')
    with Image.open(source) as image:
        if image.width * image.height > 20000000:
            raise ValueError('Image dimensions exceed limit')
        image.draft('RGB', (320, 180))
        image = ImageOps.fit(image.convert('RGB'), (320, 180))
        image = image.filter(ImageFilter.GaussianBlur(14))
        image = ImageEnhance.Color(image).enhance(.72)
        image = ImageEnhance.Brightness(image).enhance(.62)
        if key.startswith('panel.'):
            x,y,w,h=map(int,key.split('.')[1:])
            image=image.resize((960,540)).crop((x//2,y//2,(x+w)//2,(y+h)//2))
        elif key.startswith('home.') or (key.count('.')==1 and key.split('.')[0].isdigit()):
            image=image.crop((0,125,320,180))
        temporary = destination + '.tmp'
        image.save(temporary, format='JPEG', quality=87)
        os.replace(temporary, destination)
    return destination


class GlassCache:
    def __init__(self, profile, addon):
        try:
            from PIL import Image, ImageFilter, ImageOps
            self.available = True
        except ImportError:
            self.available = False
        self.root = os.path.join(profile, 'lucent-glass')
        self.allowed = tuple(os.path.realpath(p) + os.sep for p in (profile, addon))
        self.lock = Lock()
        self.generation = 0
        self.results = []
        self.pending = Queue(maxsize=1)
        self.closed = False
        self.last = None
        os.makedirs(self.root, exist_ok=True)
        self.worker = Thread(target=self._work, name='ShadowGlass', daemon=True)
        self.worker.start()

    def select(self, paths):
        if not self.available:
            return self.generation
        paths = {str(k): str(v) for k, v in paths.items() if v}
        signature = tuple(sorted(paths.items()))
        with self.lock:
            if signature == self.last or self.closed:
                return self.generation
            self.last = signature
            self.generation += 1
            token = self.generation
            self.results = []
            try: self.pending.get_nowait()
            except Empty: pass
            self.pending.put_nowait((token, paths))
            return token

    def reset(self):
        with self.lock:
            self.last = None
            self.generation += 1
            self.results = []
            try: self.pending.get_nowait()
            except Empty: pass

    def poll(self):
        with self.lock:
            results, self.results = self.results, []
            return results

    def close(self):
        with self.lock:
            self.closed = True
            self.generation += 1
            self.results = []
            try: self.pending.get_nowait()
            except Empty: pass
            self.pending.put_nowait(None)

    def _work(self):
        while True:
            request = self.pending.get()
            if request is None: return
            token, paths = request
            for key, source in paths.items():
                with self.lock:
                    if self.closed or token != self.generation: break
                try:
                    real = os.path.realpath(source)
                    if not any(real.startswith(root) for root in self.allowed): continue
                    stamp = os.stat(real)
                    digest = hashlib.sha256((real + key + str(stamp.st_mtime_ns) + str(stamp.st_size)).encode()).hexdigest()
                    destination = os.path.join(self.root, digest + '.jpg')
                    if not os.path.isfile(destination): render_glass(real, destination, key)
                    os.utime(destination, None)
                    with self.lock:
                        if not self.closed and token == self.generation:
                            self.results.append((token, key, destination))
                except Exception:
                    # Missing Pillow/corrupt art never blocks navigation or playback.
                    continue
            try:
                files = sorted((os.path.join(self.root, f) for f in os.listdir(self.root) if f.endswith('.jpg')), key=os.path.getmtime, reverse=True)
                for path in files[64:]: os.remove(path)
            except OSError: pass
