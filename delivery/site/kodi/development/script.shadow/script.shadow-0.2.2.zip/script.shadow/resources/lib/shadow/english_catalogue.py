"""English-category requests at the network boundary, never a full-feed fallback."""
import re
from .application import Session
from .provider import XtreamClient, ProviderError
from .collection_progress import CollectionStatus
from .cancellation import checkpoint
from .xtream import media_from_payload

ENGLISH = re.compile(r'(?<![a-z0-9])(?:en|eng|english|uk)(?![a-z0-9])', re.I)
MIXED = re.compile(r'(?<![a-z0-9])(?:multi(?:lingual)?|international|french|fr|german|de|spanish|es|italian|it|portuguese|pt|arabic|ar|hindi|hi)(?![a-z0-9])', re.I)


def english_categories(payload):
    if not isinstance(payload, list):
        raise ProviderError(code='X412', stage='catalogue')
    selected = []
    for row in payload:
        checkpoint()
        if not isinstance(row, dict):
            continue
        identity = str(row.get('category_id', ''))
        name = row.get('category_name', '')
        if (re.fullmatch(r'[0-9]{1,20}', identity) and identity != '0'
                and isinstance(name, str) and ENGLISH.search(name)
                and not MIXED.search(name) and identity not in selected):
            selected.append(identity)
    return selected


class EnglishStatus(CollectionStatus):
    def __init__(self):
        super().__init__()
        self.category = self.category_total = 0
        self.note = ''

    def view(self):
        text, percent = super().view()
        with self.lock:
            if self.note:
                return self.note, None
            category, total = self.category, self.category_total
        if total:
            return 'English / UK category %s of %s · %s' % (category, total, text), None if self.phase != 'ready' else 100
        return 'Reading English / UK category list · ' + text, None

    def fail(self, message):
        with self.lock:
            self.note = message
        raise ProviderError(code='X412', stage='catalogue')


class EnglishSession(Session):
    """Live TV, playlists, saved preferences and playback remain in the base session."""
    def media_request(self, kind):
        if not self.connection or kind not in ('movies', 'series'):
            return super().media_request(kind)
        connection = self.connection
        # Offline demo/playlist adapters keep their own small local catalogues.
        if not isinstance(connection.client, XtreamClient):
            return super().media_request(kind)
        status = EnglishStatus()

        def fetch():
            with status.active():
                checkpoint(); status.check()
                client = connection.client
                categories = english_categories(client.request(
                    'get_vod_categories' if kind == 'movies' else 'get_series_categories'))
                if not categories:
                    status.fail('No clearly labelled EN / ENG / English / UK categories were supplied. '
                                'No title catalogue was downloaded. Provider category mapping is needed; '
                                'US and mixed-language groups are not selected automatically.')
                items, seen = [], set()
                status.category_total = len(categories)
                action = 'get_vod_streams' if kind == 'movies' else 'get_series'
                for index, identity in enumerate(categories, 1):
                    checkpoint(); status.check()
                    with status.lock:
                        status.category = index
                        status.received = status.records = status.processed = status.total = 0
                        status.expected_bytes = None
                    status.update('connecting')
                    payload = client.request(action, category_id=identity)
                    checkpoint(); status.check()
                    if not isinstance(payload, list):
                        status.fail('The provider returned an invalid English / UK category. Existing saved selections were kept.')
                    # Do not accept or continue a provider that demonstrably ignores the filter.
                    for row in payload:
                        checkpoint()
                        if isinstance(row, dict) and row.get('category_id') not in (None, '') and str(row['category_id']) != identity:
                            status.fail('The provider returned titles from outside the requested English / UK category. '
                                        'Sync stopped. This provider needs a different category mapping or API fix.')
                    status.update('processing', total=len(payload))
                    for item in media_from_payload(payload, kind):
                        checkpoint()
                        if item['id'] not in seen:
                            seen.add(item['id']); items.append(item)
                    del payload
                checkpoint(); status.check()
                status.update('ready')
                return connection, kind, items
        fetch.collection_status = status
        return fetch
