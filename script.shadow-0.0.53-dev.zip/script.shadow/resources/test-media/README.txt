Shadow synthetic playback samples, authored for this checkpoint using FFmpeg's
colour-pattern and sine generators. No provider content or third-party footage.

Channel 1: SMPTE colour bars with a 440 Hz tone.
Channel 2: blue screen with a 660 Hz tone.
Both: approximately 30 seconds, 320x180, 12 fps, H.264 video, AAC 48 kHz audio,
MPEG-TS container. Images are intentionally static.

The included bytes require no external tool at runtime. Developer-only generation
and decode commands are in tools/generate_test_media.py and
tools/validate_synthetic_playback.py in the complete handover.
