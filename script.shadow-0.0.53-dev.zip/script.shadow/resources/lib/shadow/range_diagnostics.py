"""Allowlisted numeric diagnostics only; never URLs, headers or exception text."""
REASONS = {'http-status','range-ignored','range-bounds','offset-mismatch','range-overrun','length-mismatch'}
NUMBERS = {'http_status','requested_start','requested_end','first','last','total','length'}

def clean_range(value):
    if not isinstance(value,dict):return {}
    result={}
    reason=value.get('reason')
    if isinstance(reason,str) and reason in REASONS:result['reason']=reason
    mode=value.get('request_mode')
    if isinstance(mode,str) and mode in ('full-file','byte-range'):result['request_mode']=mode
    for key in NUMBERS:
        item=value.get(key)
        if type(item) is int and 0 <= item <= 2**63-1:result[key]=item
    return result

def describe_range(value):
    value=clean_range(value)
    if not value:return ''
    parts=[]
    if 'reason' in value:parts.append(value['reason'])
    if 'http_status' in value:parts.append('HTTP %d'%value['http_status'])
    if value.get('request_mode')=='full-file':parts.append('full-file request without Range')
    elif value.get('request_mode')=='byte-range':parts.append('byte-range request')
    if 'requested_start' in value and 'requested_end' in value:parts.append('requested %d-%d'%(value['requested_start'],value['requested_end']))
    if all(key in value for key in ('first','last','total')):parts.append('reported %d-%d/%d'%(value['first'],value['last'],value['total']))
    if 'length' in value:parts.append('length %d'%value['length'])
    return 'Range diagnostic: '+'; '.join(parts)
