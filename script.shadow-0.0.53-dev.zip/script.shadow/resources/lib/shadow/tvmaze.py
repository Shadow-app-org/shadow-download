"""Account-free TVmaze primary series artwork. Called only by artwork workers.

Searches send a cleaned series title only. No login, stream URL or account ID.
Ambiguous names retain the local title card. Images use the normal bounded cache.
"""
import json
import re
import time
import unicodedata
from threading import Lock
from urllib.parse import quote, urlsplit, unquote
from .transport import request_bytes
from .artwork import image_candidates


def series_title(row):
    value = row.get('series_name') or row.get('name') or ''
    if not isinstance(value,str):return ''
    # Public title search must never forward URL-shaped or credential-shaped metadata.
    probe=unquote(unquote(value[:2048]))
    if re.search(r'(?i)://|\bwww\.|\b(?:username|password|token|api_key|authorization)\s*[=:]',probe):return ''
    text = value[:180]
    text = re.sub(r'^(?:[A-Z]{2,3})\s*[:|\-]\s*', '', text)
    text = re.sub(r'\s*\((?:US|UK|GB|CA|AU|NZ)\)\s*$', '', text)
    text = re.sub(r'\s*[\[(](?:19|20)\d{2}[\])]\s*$', '', text)
    text = re.sub(r'\s*(?:\||\[)(?:4K|UHD|FHD|HD|SD)\]?\s*$', '', text, flags=re.I)
    return text.strip()


def normalized(text):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(text)).casefold() if c.isalnum())


class TVMaze:
    def __init__(self, fetch=request_bytes, clock=time.monotonic):
        self.fetch, self.clock = fetch, clock
        self.cache = {}
        self.summaries = {}
        self.lock = Lock()
        self.next_request = 0

    def poster(self, row):
        if row.get('kind') != 'series':
            return ''
        title = series_title(row)
        if not title or len(title) < 2:
            return ''
        year = str(row.get('year') or '')
        key = (title.casefold(), year)
        with self.lock:
            now = self.clock()
            cached = self.cache.get(key)
            if cached and now < cached[0]:
                return cached[1]
            # Shared between detail and Home workers; no burst or blocking sleep.
            if now < self.next_request:
                time.sleep(min(.5, self.next_request - now))
            self.next_request = self.clock() + .5
            image = ''
            summary = ''
            try:
                payload = json.loads(self.fetch('https://api.tvmaze.com/search/shows?q=' + quote(title, safe=''),
                    timeout=5, max_bytes=512*1024, public_only=True))
                matches = []
                for entry in payload[:30] if isinstance(payload, list) else []:
                    show = entry.get('show') if isinstance(entry, dict) else None
                    if not isinstance(show, dict) or normalized(show.get('name', '')) != normalized(title):
                        continue
                    if year and str(show.get('premiered') or '')[:4] != year:
                        continue
                    matches.append(show)
                if len(matches) == 1:
                    from .overviews import clean_overview
                    summary = clean_overview(matches[0].get('summary'))
                    value = (matches[0].get('image') or {}).get('medium', '')
                    parts = urlsplit(value)
                    if (parts.scheme == 'https' and parts.hostname == 'static.tvmaze.com'
                            and parts.path.startswith('/uploads/images/medium_portrait/')
                            and not parts.query and not parts.fragment and not parts.username and not parts.password
                            and parts.port in (None, 443)):
                        image = value
            except Exception:
                pass  # Do not leak remote responses or query text into logs.
            if len(self.cache) >= 256:
                old = next(iter(self.cache))
                self.cache.pop(old)
                self.summaries.pop(old, None)
            self.summaries[key] = summary
            self.cache[key] = (now + (86400 if image or summary else 300), image)
            return image

    def overview(self, row):
        if row.get('kind') != 'series':return ''
        self.poster(row)
        with self.lock:
            return self.summaries.get((series_title(row).casefold(), str(row.get('year') or '')), '')


def load_poster(cache, row, tvmaze, is_current=None):
    """Try the configured public source before the provider, with a bounded negative URL cache."""
    active=is_current or (lambda:True)
    if not active():return ''
    if isinstance(row, str):
        row = {'artwork': row}
    key=row.get('artwork_key','')
    if key and hasattr(type(cache),'media_get'):
        path=cache.media_get(key)
        if path:return path
    failed = getattr(cache, '_poster_failures', None)
    if failed is None:
        failed = cache._poster_failures = {}
    def load(url):
        if not active():return ''
        if time.monotonic() < failed.get(url, 0):
            return ''
        try:
            path=cache.get(url)
            if key and hasattr(type(cache),'media_remember'):cache.media_remember(key,path)
            return path
        except Exception:
            if len(failed) >= 128:
                failed.clear()
            failed[url] = time.monotonic() + 300
            return ''
    if not active():return ''
    url = tvmaze.poster(row)
    if not active():return ''
    if url:
        path = load(url)
        if path:
            return path
    for url in image_candidates(row):
        if not active():break
        path = load(url)
        if path:
            return path
    return ''
