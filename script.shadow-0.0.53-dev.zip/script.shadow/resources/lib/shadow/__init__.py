"""Shadow core."""
