"""Bounded background artwork worker. Poll results on the Kodi/UI thread.

One current request and one pending request. Superseded requests may finish but
cannot publish into a newer selection. Never call Kodi APIs on this worker.
"""
from queue import Queue, Empty
from threading import Thread, Lock
from .artwork import resolve_artwork


def logo_key(channel):
    return 'channel-logo-v1:' + repr(tuple(channel.get(k, '') for k in ('stream_id', 'name', 'epg_channel_id', 'stream_icon')))


class ArtworkLoader:
    def __init__(self, cache, tvmaze=None, logos=None):
        self.cache = cache
        self.tvmaze = tvmaze
        self.logos = logos
        self._queue = Queue(maxsize=1)
        self._lock = Lock()
        self._generation = 0
        self._result = None
        self._closed = False
        self.status = 'Not requested'
        self._failed_urls = {}
        self._worker = Thread(target=self._run, name='ShadowArtwork', daemon=True)
        self._worker.start()

    def select(self, programme, channel, approved_ids, enabled=True):
        with self._lock:
            self._generation += 1
            token = self._generation
            self._result = None
            if self._closed:
                return token
            try:
                self._queue.get_nowait()
            except Empty:
                pass
            self.status = 'No approved image selection'
            if not isinstance(channel, dict) or str(channel.get('stream_id', '')) not in {str(x) for x in approved_ids}:
                return token
            if self.logos and hasattr(type(getattr(self.logos, 'cache', None)), 'media_get') and (programme or {}).get('kind') not in ('movies', 'series'):
                cached = self.logos.cache.media_get(logo_key(channel))
                if cached:
                    self._result = (token, cached)
            programme_art = resolve_artwork(programme if enabled else {}, channel)
            channel_art = resolve_artwork({}, channel)
            candidates = list(dict.fromkeys(a.value for a in (programme_art, channel_art) if a.value))
            self.status = 'Loading image' if candidates else 'No supported HTTPS image supplied'
            self._queue.put_nowait((token, candidates, dict(programme or {}) if enabled else {}, dict(channel)))
            return token

    def current(self,token):
        with self._lock:
            return not self._closed and token==self._generation

    def poll(self):
        with self._lock:
            result = self._result
            self._result = None
            return result

    def close(self):
        with self._lock:
            self._closed = True
            self._generation += 1
            self._result = None
            try:
                self._queue.get_nowait()
            except Empty:
                pass
            self._queue.put_nowait(None)
        # Don't block navigation waiting for DNS/network completion.

    def _run(self):
        while True:
            request = self._queue.get()
            if request is None:
                return
            token, candidates, row, channel = request
            import time
            path = ''
            preview = ''
            if self.logos and hasattr(self.logos,'cache') and row.get('kind') not in ('movies','series'):
                # Reuse the Home logo cache and publish before slower programme searches.
                provider=resolve_artwork({},channel).value
                preview=self.logos.cache.peek(provider)
                urls=[provider]
                if not preview:
                    urls += self.logos.candidates(channel)
                    preview=next((path for path in (self.logos.cache.peek(url) for url in urls) if path),'')
                if not preview:
                    for url in urls:
                        with self._lock:
                            if self._closed or token != self._generation:break
                        if not url or time.monotonic()<self._failed_urls.get(url,0):continue
                        try:
                            preview=self.logos.cache.get(url)
                            break
                        except Exception:
                            if len(self._failed_urls)>=128:self._failed_urls.clear()
                            self._failed_urls[url]=time.monotonic()+300
                if preview:
                    if hasattr(type(self.logos.cache), 'media_remember'):
                        self.logos.cache.media_remember(logo_key(channel), preview)
                    with self._lock:
                        if not self._closed and token==self._generation:self._result=(token,preview)
            programme_mode = bool(row.get('title')) and row.get('kind') not in ('movies','series')
            if programme_mode:
                programme_image = resolve_artwork(row, {}).value
                candidates = [programme_image] if programme_image else []
            if row.get('kind') in ('movies', 'series') and self.tvmaze:
                with self._lock:
                    current = not self._closed and token == self._generation
                if current:
                    from .tvmaze import load_poster
                    path = load_poster(getattr(self,'poster_cache',self.cache), row, self.tvmaze, is_current=lambda:self.current(token))
                candidates = []
            import time
            for url in candidates:
                if time.monotonic() < self._failed_urls.get(url, 0):
                    continue
                with self._lock:
                    if self._closed or token != self._generation:
                        break
                try:
                    path = self.cache.get(url)
                    break
                except Exception:
                    # Cache/network errors are not sent to UI/logs.
                    if len(self._failed_urls) >= 128:
                        self._failed_urls.clear()
                    self._failed_urls[url] = time.monotonic() + 300
                    continue
            with self._lock:
                current = not self._closed and token == self._generation
            if not path and current and programme_mode and self.tvmaze:
                try:
                    url = self.tvmaze.programme_poster(row)
                    if url:
                        path = self.cache.get(url)
                except Exception:
                    pass
            if not path and preview:
                path=preview
            if not path and current and row.get('kind') not in ('movies', 'series'):
                urls = [resolve_artwork({}, channel).value]
                # Provider logos get the first attempt, public matching only if needed.
                for url in urls:
                    if url and time.monotonic() >= self._failed_urls.get(url,0):
                        try:
                            path = self.cache.get(url)
                        except Exception:
                            pass
                if not path and self.logos:
                    for url in self.logos.candidates(channel):
                        if time.monotonic() < self._failed_urls.get(url,0):
                            continue
                        with self._lock:
                            if self._closed or token != self._generation:
                                break
                        try:
                            path = self.cache.get(url)
                            break
                        except Exception:
                            if len(self._failed_urls)>=128:
                                self._failed_urls.clear()
                            self._failed_urls[url]=time.monotonic()+300
            with self._lock:
                if not self._closed and token == self._generation:
                    self.status = 'Image ready' if path else 'Image unavailable or unsupported' if candidates else 'No supported HTTPS image supplied'
                    self._result = (token, path)


class ArtworkGridLoader:
    """One background worker, one replaceable batch, at most eight provider posters."""
    def __init__(self, cache, tvmaze=None):
        self.cache = cache
        self.tvmaze = tvmaze
        self._queue = Queue(1)
        self._lock = Lock()
        self._generation = 0
        self._result = None
        self._closed = False
        self._failures = {}
        self._worker = Thread(target=self._run, name='ShadowPosters', daemon=True)
        self._worker.start()

    def select(self, images):
        from .artwork import safe_remote_image
        with self._lock:
            self._generation += 1
            token = self._generation
            self._result = None
            if self._closed:
                return token
            try:
                self._queue.get_nowait()
            except Empty:
                pass
            items = [(key, row) for key, row in list(images.items())[:8] if isinstance(row, dict) or safe_remote_image(row)]
            self._queue.put_nowait((token, items))
            return token

    def current(self,token):
        with self._lock:
            return not self._closed and token==self._generation

    def poll(self):
        with self._lock:
            result, self._result = self._result, None
            return result

    def close(self):
        with self._lock:
            self._closed = True
            self._result = None
            try:
                self._queue.get_nowait()
            except Empty:
                pass
            self._queue.put_nowait(None)

    def _run(self):
        import time
        while True:
            entry = self._queue.get()
            if entry is None:
                return
            token, items = entry
            result = {}
            for key, url in items:
                with self._lock:
                    if self._closed or token != self._generation:
                        break
                if isinstance(url, str) and time.monotonic() < self._failures.get(url, 0):
                    continue
                try:
                    if self.tvmaze:
                        from .tvmaze import load_poster
                        path = load_poster(self.cache, url, self.tvmaze, is_current=lambda:self.current(token))
                        if path:
                            result[key] = path
                    else:
                        result[key] = self.cache.get(url)
                except Exception:
                    if len(self._failures) >= 128:
                        self._failures.clear()
                    if isinstance(url, str):
                        self._failures[url] = time.monotonic() + 300
                with self._lock:
                    if not self._closed and token == self._generation:
                        self._result = (token, dict(result))
