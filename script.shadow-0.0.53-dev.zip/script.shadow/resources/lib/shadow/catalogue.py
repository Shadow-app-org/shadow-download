"""Local catalogue facets; no new service, provider requests or title limits."""
import re
from .cancellation import checkpoint

UNKNOWN = 'Not supplied'
_YEAR = re.compile(r'(?<!\d)((?:18|19|20|21)\d{2})(?!\d)')


def metadata(item, title):
    from .xtream import display_text
    from .selection import LANGUAGES, language_for_group
    raw = display_text(item.get('language'), 80)
    codes = dict(LANGUAGES, IR='Persian', FA='Persian', RU='Russian', HI='Hindi', HE='Hebrew', EL='Greek', GR='Greek', RO='Romanian', SV='Swedish', SE='Swedish', DA='Danish', DK='Danish', NO='Norwegian', FI='Finnish', CS='Czech', CZ='Czech', HU='Hungarian', JA='Japanese', JP='Japanese', KO='Korean', KR='Korean', ZH='Chinese', CN='Chinese')
    language = codes.get(raw.upper(), raw)
    if not language:
        language = language_for_group(title)
        if language == 'Other':
            prefix = re.match(r'^([A-Za-z]{2})(?:\s*[:|\-]\s*|\s+)', title)
            language = codes.get(prefix[1].upper(), UNKNOWN) if prefix else UNKNOWN
    raw_genre = item.get('genre')
    if isinstance(raw_genre, list):
        raw_genre = ', '.join(v for v in raw_genre if isinstance(v, str))
    genres = tuple(dict.fromkeys(v.strip() for v in re.split(r'[,/|;]', display_text(raw_genre, 250)) if v.strip()))
    year, source = '', ''
    for key in ('releaseDate', 'release_date', 'year'):
        value = item.get(key)
        if isinstance(value, (str, int)) and not isinstance(value, bool):
            match = _YEAR.search(str(value)[:40])
            if match:
                year, source = match[1], 'provider'
                break
    if not year:
        match = re.search(r'[\[(]((?:18|19|20|21)\d{2})[\])]', title)
        if match:
            year, source = match[1], 'title'
    return {'language': language, 'genres': genres, 'year': year, 'year_source': source}


def options(rows, key):
    values = set()
    for row in rows:
        checkpoint()
        if key == 'genre':
            values.update(row.get('genres') or (UNKNOWN,))
        else:
            values.add(row.get(key) or UNKNOWN)
    return sorted(values, key=lambda value: (value == UNKNOWN, -int(value) if key == 'year' and value.isdigit() else value.casefold()))


def filter_rows(rows, state):
    query = state.get('query', '').strip().casefold()
    result = []
    for row in rows:
        checkpoint()
        if state.get('hide_watched') and row.get('id') in state.get('watched_ids',()):continue
        if state.get('recent_only') and row.get('id') not in state.get('recent_ids',()):continue
        from .search import score, ranked
        if query and score(row['name'], query) is None:
            continue
        from .selection import canonical_language
        if state.get('languages') and canonical_language(row.get('language') or UNKNOWN) not in state['languages']:
            continue
        if state.get('language') and canonical_language(state['language']) != canonical_language(row.get('language') or UNKNOWN):
            continue
        if state.get('genre') and state['genre'] not in (row.get('genres') or (UNKNOWN,)):
            continue
        if state.get('year') and state['year'] != (row.get('year') or UNKNOWN):
            continue
        result.append(row)
    if query:result = ranked(result,query)
    if state.get('recent_only'):
        positions={value:index for index,value in enumerate(state.get('recent_ids',[]))}
        result.sort(key=lambda row:positions.get(row.get('id'),len(positions)))
    order = state.get('sort')
    if order in ('Title A–Z', 'Title A-Z'):
        result.sort(key=lambda row: row['name'].casefold())
    elif order in ('Newest first', 'Oldest first'):
        sign = -1 if order == 'Newest first' else 1
        result.sort(key=lambda row: (not bool(row.get('year')), sign*int(row.get('year') or 0), row['name'].casefold()))
    return result
