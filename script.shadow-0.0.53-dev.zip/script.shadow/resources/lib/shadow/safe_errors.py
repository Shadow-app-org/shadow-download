"""Allowlisted user-facing diagnostics; never format provider data into errors."""
MESSAGES = {
    'S420': 'The Python native-call module could not be imported. Saving remains blocked.',
    'S421': 'The restricted Windows system-library loader failed. Saving remains blocked.',
    'S422': 'Native CreateFile2 lookup or signature setup failed. Saving remains blocked.',
    'S423': 'Native GetFileType lookup or signature setup failed. Saving remains blocked.',
    'S424': 'Native FlushFileBuffers lookup or signature setup failed. Saving remains blocked.',
    'S425': 'Native CloseHandle lookup or signature setup failed. Saving remains blocked.',
    'P454': 'The server returned an inconsistent media range. This title could not be opened safely; try another title or retry later.',
    'P455': 'The media file changed between requests. Stop and reopen the title.',
    'P456': 'The provider supplied a missing or unsupported file type for this title. Try another title; the provider may need to correct its metadata.',
    'P460': 'The provider sent a missing, ambiguous or invalid stream redirect address. It was not followed.',
    'P461': 'The stream redirect would downgrade HTTPS to HTTP or use HTTP without consent. It was not followed.',
    'P462': 'The stream redirect chain repeated an address or exceeded three redirects. It was stopped.',
    'P400': 'The channel identifier was invalid. No stream was opened.',
    'P401': 'The channel approval or account session is no longer valid. Review your selections or reconnect.',
    'P402': 'The playback address or HTTP playback consent failed validation. No direct fallback was attempted.',
    'P450': 'The response was not the expected supported media format.',
    'P451': 'The opening stream data was not three complete MPEG-TS packets. No playback URL was passed to Kodi.',
    'P452': 'The declared stream length was not compatible with complete MPEG-TS packets.',
    'P453': 'The stream ended early or contained invalid media data.',
    'P480': 'Kodi did not start local playback within 30 seconds. Try the packaged local video test; automatic reconnect was stopped.',
    'P482': 'Kodi did not release the previous stream within the reconnect time limit. No new stream was opened. Exit playback before trying again.',
    'P481': 'The local playback relay failed unexpectedly. Report this code; automatic reconnect was stopped.',
    'P499': 'Playback preparation failed unexpectedly. Report the stage and code; no provider details are included.',
    'X400': 'The Xtream address, credentials or connection options failed local validation. No successful login is established.',
    'X401': 'The Xtream API did not accept authentication. This does not by itself identify why access was refused.',
    'X402': 'The Xtream API reported an account status other than Active. Shadow did not enable playback.',
    'X403': 'The response was not valid UTF-8 JSON. No server response text is included in this diagnostic.',
    'X404': 'This Xtream metadata response exceeded its 8 MiB limit. Live-channel lists have no total byte limit. No partial response was accepted.',
    'X405': 'The login response did not contain the expected user_info object.',
    'X406': 'The account expiry value was expired or invalid. Shadow did not enable playback.',
    'X407': 'The live-category response was not the expected list.',
    'X408': 'The live-channel response was not the expected list.',
    'X409': 'The provider session has been cleared. Enter a connection again.',
    'X410': 'Channel catalogue preparation failed after the channel response. This does not establish a login failure.',
    'X411': 'Local account settings preparation failed unexpectedly. Run Settings > Check local storage and report its code. Saved selections were not reset. Retry after resolving the storage error; temporary testing avoids saved account settings.',
    'X412': 'The movie or series response was not the expected catalogue list. No partial catalogue was accepted.',
    'X413': 'Loading the catalogue reached its five-minute overall limit and was cancelled. Report the stage and counts shown here. No partial catalogue was imported; saved selections were preserved.',
    'X416': 'The catalogue download timed out waiting for data (30-second inactivity limit). Check the connection and retry. No partial catalogue was imported.',
    'X417': 'Reading the catalogue response was interrupted by a connection or HTTP read error. Retry when the connection is stable. No partial catalogue was imported.',
    'X418': 'The catalogue response ended before its declared content was complete. No partial catalogue was imported. Retry or report this code if it repeats.',
    'X419': 'The catalogue response was incomplete or not valid UTF-8 JSON. No partial catalogue was imported. This alone does not identify whether the provider or connection caused the problem.',
    'X414': 'The collection could not be prepared from the provider response. Report the stage and counts; no provider details are included.',
    'X415': 'An earlier request is still finishing. Wait briefly and retry. If it remains blocked, exit and reopen Shadow; saved selections were preserved.',
    'X490': 'The Xtream downloader failed outside the recognised network-error path.',
    'X499': 'The Xtream operation failed unexpectedly. Report the stage and code; no provider details are included.',
    'M300': 'Enter a complete HTTP or HTTPS M3U link. HTTP requires session consent. Embedded header options and unsafe addresses are not supported.',
    'M301': 'The playlist could not be downloaded. Check the address, access allowance and network. Certificate errors, redirects and timeouts are rejected.',
    'M302': 'The response is not a supported UTF-8 M3U channel playlist. It may be an error page or a malformed playlist.',
    'M303': 'This is an HLS playback manifest, not a channel playlist. HLS playback is not supported in this build.',
    'M304': 'The playlist exceeds the supported size, line or channel limit.',
    'M305': 'No supported MPEG-TS channel entries were found. HTTP requires session consent; HLS, special player options and other formats are excluded.',
    'M306': 'Playlist setup failed before completion. This does not establish damaged settings or a provider rejection. Run Check local storage and report its result.',
    'M307': 'This channel is no longer present at the same address in the refreshed playlist. Re-import the playlist and review channel approvals.',
    'M308': 'The playlist session has ended. Import your playlist link again.',
    'M309': 'The selected playlist stream could not be opened as an allowed MPEG-TS stream. The provider may require another format, a redirect, or different access permissions.',
    'S401': 'Could not create the local account folder. No provider credentials are included in this diagnostic.',
    'S402': 'The account settings lock already exists, possibly after interrupted setup. Close other Shadow windows and retry. If it persists after restarting Kodi, report this code. Do not delete the lock or reset settings blindly.',
    'S403': 'Could not create the local settings lock.',
    'S404': 'Could not read the local account identity key.',
    'S405': 'The local account identity key has an invalid length. Existing data was left unchanged.',
    'S406': 'Could not create a temporary file in the local settings folder.',
    'S407': 'The local file-permission operation failed. Security checks have not been bypassed.',
    'S408': 'Could not write or flush the local temporary file.',
    'S409': 'The local file-sync operation failed. Durability checks have not been bypassed.',
    'S410': 'Could not atomically replace the local settings file.',
    'S411': 'Could not release the local settings lock.',
    'S412': 'Could not read or validate saved settings. Existing files were preserved. Retry after resolving storage access, or explicitly use Settings > Recover Xtream settings to restore a valid backup. Recovery can restore older approvals. This is not a provider failure.',
    'S413': 'The local settings operation failed. No files were automatically reset or recovered.',
    'S414': 'The isolated storage check did not reproduce its saved data correctly.',
    'S416': 'Native Windows file-sync APIs are unavailable in this runtime. Saving remains blocked.',
    'S417': 'Native sync could not open the existing private temporary disk file. Saving remains blocked.',
    'S418': 'Native Windows file flushing failed. Saving remains blocked.',
    'S419': 'Native sync could not close its file handle. Saving remains blocked.',
    'S415': 'Could not remove the isolated storage-check files.',
    'M310': 'Playlist account identity setup failed unexpectedly. Run Check local storage; no provider success is established.',
    'M311': 'Playlist catalogue construction failed unexpectedly. Report this code without sharing the playlist.',
    'M312': 'Playlist settings recovery failed. No automatic reset was attempted.',
    'M313': 'Playlist settings loading failed unexpectedly. Run Check local storage.',
    'M399': 'The playlist operation could not be completed. Your saved channel selections were preserved.',
    'N400': 'The download address, HTTP consent or request options failed validation. No connection was made.',
    'N409': 'The request exceeded its time limit. No security checks were bypassed.',
    'N410': 'The system address resolver reported an unclassified lookup error. This does not establish a login failure.',
    'N411': 'DNS resolution exceeded the request time limit.',
    'N412': 'The bounded DNS worker is still busy with an earlier request. Wait before retrying.',
    'N413': 'The resolved destination failed the permitted-address checks. Private and unsafe addresses remain blocked for M3U and stream redirect targets.',
    'N414': 'The system resolver reported name/address not found. Check the server spelling; this does not establish a login failure.',
    'N415': 'The system resolver reported a temporary lookup failure. No provider login was attempted at this stage.',
    'N416': 'The runtime denied permission for address lookup. No security checks were bypassed.',
    'N417': 'A required Python address-lookup operation is unavailable in this runtime.',
    'N418': 'Address lookup rejected the argument type, value or encoding. This may be a runtime compatibility problem.',
    'N419': 'An unexpected runtime error occurred during address lookup. No provider details are included.',
    'D400': 'Enter only the server address, optionally with HTTP/HTTPS and a port. Do not include a playlist path, username, password or query.',
    'D499': 'The hostname diagnostic could not complete. No settings were changed and no provider login was attempted.',
    'N420': 'The socket connection to the resolved address failed. This does not establish a login failure.',
    'N421': 'The socket connection timed out before a response could be requested.',
    'N422': 'HTTPS certificate verification failed. The certificate or hostname was not accepted; verification remains enabled.',
    'N423': 'HTTPS context setup or TLS negotiation failed. No HTTP downgrade was attempted.',
    'N424': 'The HTTPS context did not require certificate and hostname verification. The request was blocked.',
    'N426': 'The HTTPS handshake exceeded the request time limit.',
    'N427': 'The runtime denied permission for the socket connection. No broader access was requested.',
    'N428': 'A required Python networking operation was unavailable in this runtime. Report this code.',
    'N430': 'Sending the HTTP request failed before response headers were read.',
    'N431': 'The HTTP response headers could not be read or parsed.',
    'N432': 'Waiting for the HTTP response headers exceeded the request time limit.',
    'N433': 'The HTTP response headers exceeded the supported size limit.',
    'N440': 'The server returned an HTTP redirect. Shadow did not follow it or forward credentials to another address.',
    'N441': 'The server returned HTTP 401 or 403. Access was refused; this alone does not prove the password is wrong.',
    'N442': 'The server returned HTTP 429 (too many requests). Wait before retrying.',
    'N443': 'The server returned an HTTP 5xx error. The download did not complete.',
    'N500': 'The server returned HTTP 500. The download did not complete; no response body was imported.',
    'N501': 'The server returned HTTP 501. The download did not complete; no response body was imported.',
    'N502': 'The server returned HTTP 502. The download did not complete; no response body was imported.',
    'N503': 'The server returned HTTP 503. The download did not complete; no response body was imported.',
    'N504': 'The server returned HTTP 504. The download did not complete; no response body was imported.',
    'N505': 'The server returned HTTP 505. The download did not complete; no response body was imported.',
    'N506': 'The server returned HTTP 506. The download did not complete; no response body was imported.',
    'N507': 'The server returned HTTP 507. The download did not complete; no response body was imported.',
    'N508': 'The server returned HTTP 508. The download did not complete; no response body was imported.',
    'N510': 'The server returned HTTP 510. The download did not complete; no response body was imported.',
    'N511': 'The server returned HTTP 511. The download did not complete; no response body was imported.',
    'N444': 'The server returned an unsupported HTTP status instead of 200. No response body was imported.',
    'N445': 'The server returned HTTP 404 (not found). Check the complete playlist address locally.',
    'N450': 'The server sent an unsupported compressed response despite the request for identity encoding.',
    'N451': 'The HTTP response had invalid or conflicting length/transfer headers. The response was rejected.',
    'N452': 'This download exceeded its configured byte limit. It was not imported. Xtream live-channel lists have no total byte limit.',
    'N453': 'The download ended before the declared response was complete. No partial playlist was imported.',
    'N454': 'Reading the response body exceeded the request time limit (12 seconds for M3U). No partial playlist was imported.',
    'N455': 'Reading the response body failed. No partial playlist was imported.',
    'N456': 'The response content type did not match the requested image format.',
    'N457': 'The network response or connection could not be closed normally. The operation was not accepted as complete.',
    'N499': 'An unexpected network operation failed. No provider details are included in this diagnostic.',
}


MESSAGES.update({
    'S430': 'The account database could not be opened or validated. Keep all add-on data and report this code; no older settings were substituted.',
    'S431': 'The account transaction did not complete normally. Close other Shadow windows, check free space and retry after reloading settings.',
    'S432': 'The database durability settings could not be verified. Saving remains blocked; report this code.',
    'S433': 'Database cleanup could not be confirmed. Reopen Shadow and reload settings before retrying; do not reset account data.',
    'S434': 'Older settings files changed after migration. Keep both copies and use this Shadow version; report this code before attempting recovery.',
    'S436': 'The SQLite module could not be imported. Saving remains blocked; report this code.',
    'S437': 'Account database initialization is incomplete. Keep add-on data and report this code for recovery; no identity was regenerated.',
    'S438': 'The account database reached its safety limit. Keep existing data and report this code.',
    'S450': 'The account directory could not be created. Keep existing data and report this code.',
    'S451': 'Account-directory metadata could not be verified. Saving remains blocked; report this code.',
    'S452': 'The account migration marker could not be created. Keep existing data and report this code.',
    'S453': 'Migration-marker metadata could not be verified. Keep existing data and report this code.',
    'S455': 'Database or journal file metadata could not be read. Saving remains blocked; report this code.',
    'S456': 'The database or journal is not reported as a regular file. Saving remains blocked; report this code.',
    'S457': 'The database or journal link count could not be accepted. Saving remains blocked; report this code.',
    'S458': 'The database or journal file size is outside its safety limit. Keep existing data and report this code.',
    'S459': 'The local database path could not be prepared for SQLite. Keep existing data and report this code.',
    'S460': 'SQLite could not open the account database. Keep existing data and report this code.',
    'S461': 'The account database schema could not be verified. No older settings were substituted; report this code.',
    'S462': 'The account database version is not supported. Keep existing data and report this code.',
    'S463': 'The account database integrity check did not pass. Keep existing data and report this code.',
    'S464': 'Private database permissions could not be set. Saving remains blocked; report this code.',
})

STORAGE_CODES = frozenset(code for code in MESSAGES if code.startswith('S'))
NETWORK_CODES = frozenset(code for code in MESSAGES if code.startswith('N'))
PROVIDER_CODES = NETWORK_CODES | STORAGE_CODES | frozenset(code for code in MESSAGES if code.startswith('X'))
PROVIDER_STAGES = {'connection': 'Connection', 'setup': 'Input', 'login': 'Login',
                   'settings': 'Settings', 'categories': 'Categories', 'channels': 'Channels',
                   'catalogue': 'Catalogue'}
PLAYBACK_CODES = PROVIDER_CODES | frozenset(code for code in MESSAGES if code.startswith('P'))
PLAYBACK_STAGES = {'approval': 'Approval', 'address': 'Address', 'login': 'Login recheck',
                   'stream': 'Stream', 'read': 'Stream read', 'guide': 'Programme guide',
                   'preparation': 'Preparation'}


def playback_code(code):
    return code if isinstance(code, str) and code in PLAYBACK_CODES else 'P499'


def playback_stage(stage):
    return stage if isinstance(stage, str) and stage in PLAYBACK_STAGES else 'preparation'


def provider_code(code):
    return code if isinstance(code, str) and code in PROVIDER_CODES else 'X499'


def provider_stage(stage):
    return stage if isinstance(stage, str) and stage in PROVIDER_STAGES else 'connection'

def clean_http_status(code, value):
    """Only a built-in integer matching the allowlisted HTTP error may cross layers."""
    if not isinstance(code, str) or type(value) is not int:
        return None
    if code in NETWORK_CODES and code == 'N' + str(value) and 500 <= value <= 599:
        return value
    if ((code == 'N443' and 500 <= value <= 599) or
            (code == 'N440' and value in (301, 302, 303, 307, 308)) or
            (code == 'N441' and value in (401, 403)) or
            (code == 'N442' and value == 429) or
            (code == 'N445' and value == 404) or
            (code == 'N444' and 100 <= value <= 599 and value != 200)):
        return value
    return None


def safe_message(code, http_status=None):
    message = MESSAGES.get(code, MESSAGES['M399']) if isinstance(code, str) else MESSAGES['M399']
    status = clean_http_status(code, http_status)
    if status is not None:
        if 500 <= status <= 599:
            return ('The server returned HTTP %s. The provider or an upstream server failed to complete the request. '
                    'Wait and retry; this does not establish invalid credentials. No response text or address is included.' % status)
        message += ' HTTP status: %s.' % status
    return message


_STORAGE_ERROR_TYPES = (FileExistsError, ModuleNotFoundError, ImportError,
                        PermissionError, FileNotFoundError, NotImplementedError,
                        AttributeError, OSError, ValueError, TypeError)
_STORAGE_ERROR_LABELS = frozenset(kind.__name__ for kind in _STORAGE_ERROR_TYPES) | {'Error'}


def storage_failure_detail(error):
    """Carry only a fixed category and bounded numeric codes, never error text."""
    label = next((kind.__name__ for kind in _STORAGE_ERROR_TYPES
                  if isinstance(error, kind)), 'Error')
    numbers = []
    for name in ('errno', 'winerror', 'sqlite_errorcode'):
        number = getattr(error, name, None)
        numbers.append(number if type(number) is int and 0 <= number <= 65535 else None)
    return (label,) + tuple(numbers)


def format_storage_failure(detail):
    if type(detail) is not tuple or len(detail) != 4:
        return ''
    label, *numbers = detail
    if type(label) is not str or label not in _STORAGE_ERROR_LABELS:
        return ''
    if any(number is not None and (type(number) is not int or not 0 <= number <= 65535)
           for number in numbers):
        return ''
    return label + ''.join(' (%s=%s)' % (name, number)
                          for name, number in zip(('errno', 'winerror', 'sqlite'), numbers)
                          if number is not None)


class SafeError(Exception):
    def __init__(self, code):
        self.code = code if isinstance(code, str) and code in MESSAGES else 'M399'
        super().__init__(self.code + ': ' + safe_message(self.code))
