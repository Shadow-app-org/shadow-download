"""Bounded, credential-free comparison of Python address-lookup call forms.

Uses the existing resolver worker and system DNS only. No HTTP, stream, account
file, external resolver, native API, proxy or alternative transport is used.
Positional calls are diagnostic only, never an automatic playback fallback.
"""
import re
import socket
from urllib.parse import urlsplit
from .transport import _DNS, Deadline, TransportError, checked_addresses
from .safe_errors import NETWORK_CODES, SafeError


def server_target(value):
    try:
        if not isinstance(value, str) or len(value) > 512:
            raise ValueError()
        value = value.strip()
        if not value:
            return None
        if any(ord(c) < 33 or ord(c) == 127 for c in value) or any(c in value for c in '\\?#@|'):
            raise ValueError()
        parts = urlsplit(value if '://' in value else 'https://' + value)
        if (parts.scheme not in ('http', 'https') or parts.path not in ('', '/')
                or not parts.hostname or parts.username is not None or parts.password is not None):
            raise ValueError()
        host = parts.hostname.rstrip('.').encode('idna').decode('ascii')
        # DNS hostnames only: the fixed numeric checks already cover IP literals.
        if len(host) > 253 or not all(re.fullmatch(r'[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?', label)
                                      for label in host.split('.')):
            raise ValueError()
        port = parts.port if parts.port is not None else (443 if parts.scheme == 'https' else 80)
        if not 1 <= port <= 65535:
            raise ValueError()
        return host, port
    except Exception:
        raise SafeError('D400') from None


def check_hostname(value='', dns=None, resolver=None):
    """Return fixed labels/codes only; no hostname, IP, URL or exception text."""
    target = server_target(value)
    dns = _DNS if dns is None else dns
    resolver = socket.getaddrinfo if resolver is None else resolver
    budget = Deadline(8)

    def positional(host, port, type):
        return resolver(host, port, socket.AF_UNSPEC, type)

    checks = [('Numeric / normal', '127.0.0.1', 443, resolver, False),
              ('Numeric / positional', '127.0.0.1', 443, positional, False)]
    if target:
        checks += [('Provider / normal', target[0], target[1], resolver, True),
                   ('Provider / positional', target[0], target[1], positional, True)]
    results = []
    for label, host, port, call, public in checks:
        try:
            answers = dns.resolve(host, port, budget, call)
            checked_addresses(answers, public_only=public)
            code = 'PASS'
        except TransportError as error:
            code = error.code if type(error) is TransportError and error.code in NETWORK_CODES else 'N419'
        except Exception:
            code = 'N419'
        results.append((label, code))
        if code in ('N411', 'N412'):
            break  # Do not queue work behind a timed-out system resolver.
    return tuple(results)
