"""One explicitly entered temporary test login, held in memory only.

Not a vault. Clearing releases references; Python strings cannot be securely wiped.
Never serialize this object, put it in Kodi settings, or print its contents.
"""


class TestLogin:
    __slots__ = ('_kind', '_details')

    def __init__(self):
        self.clear()

    def __repr__(self):
        return 'TestLogin(<redacted>)'

    def remember(self, kind, details):
        self.clear()
        if kind not in ('xtream', 'm3u') or not isinstance(details, tuple):
            raise ValueError('Invalid test login')
        expected = 4 if kind == 'xtream' else 2
        if len(details) != expected or type(details[-1]) is not bool or not all(isinstance(v, str) and v for v in details[:-1]):
            raise ValueError('Invalid test login')
        self._kind, self._details = kind, details

    def snapshot(self, kind):
        return self._details if self._kind == kind else None

    @property
    def kind(self):
        return self._kind

    def clear(self):
        self._kind, self._details = None, None

    def __reduce_ex__(self, protocol):
        raise TypeError('Test logins must not be serialized')
