"""Approved movie/episode selection and private range playback preparation."""
import threading
import time
from .cancellation import checkpoint
from .xtream import display_text
from .streaming import stream_id, PlaybackError
from .playback import PreparedPlayback
from .vod import VODResource, MIMES
from .provider import ProviderError


def episodes_from_payload(payload, series):
    groups = payload.get('episodes', {}) if isinstance(payload, dict) else {}
    if not isinstance(groups, dict):
        return []
    result, seen = [], set()
    for season, entries in groups.items():
        if not str(season).isascii() or not str(season).isdigit() or len(str(season)) > 6 or not isinstance(entries, list):
            continue
        for entry in entries:
            checkpoint()
            if not isinstance(entry, dict):
                continue
            identity = entry.get('id')
            try:
                identity = stream_id(str(identity))
            except PlaybackError:
                continue
            if identity in seen:
                continue
            seen.add(identity)
            number = entry.get('episode_num', 0)
            number = int(number) if str(number).isascii() and str(number).isdigit() and len(str(number)) <= 6 else 0
            result.append({'id': identity, 'kind': 'series', 'series_id': series['id'],
                           'series_name': series['name'], 'season': int(season), 'episode': number,
                           'name': display_text(entry.get('title'), 180) or 'Episode ' + str(number),
                           'extension': str(entry.get('container_extension') or '').strip().lower().lstrip('.'),
                           'artwork': series.get('artwork', ''),
                           'plot': display_text((entry.get('info') or {}).get('plot'), 2000) if isinstance(entry.get('info'), dict) else ''})
    return sorted(result, key=lambda row: (row['season'], row['episode'], row['id']))


def prepare_media(session, selected, opener=VODResource):
    connection = session.connection
    kind = selected.get('kind')
    if connection is None or kind not in ('movies', 'series'):
        raise PlaybackError(code='P401', stage='approval')
    revision = connection.prefs['revision']
    identity = stream_id(selected.get('id'))
    parent = selected.get('series_id') if kind == 'series' else identity
    consent = tuple(getattr(connection.client, name, False) for name in ('_allow_stream_redirects', '_allow_http_redirects', '_allow_http_playback'))
    catalogue = getattr(session, kind)
    if not any(row['id'] == parent for row in catalogue):
        raise PlaybackError(code='P401', stage='approval')

    storage_lock = threading.Lock()
    storage_check = [0.0, False]

    def stored_revision_current():
        # Persistent settings can be large. Match the existing 200ms relay
        # guard interval, while in-memory account/revision checks stay per-read.
        if hasattr(connection.store, 'matches_revision'):
            return connection.store.matches_revision(revision)
        with storage_lock:
            now = time.monotonic()
            if now >= storage_check[0]:
                storage_check[1] = connection.store.load()['revision'] == revision
                storage_check[0] = now + .2
            return storage_check[1]

    def permitted():
        try:
            return (session.connection is connection and connection.client.playback_session_valid() and
                    connection.prefs['revision'] == revision and
                    tuple(getattr(connection.client, name, False) for name in ('_allow_stream_redirects', '_allow_http_redirects', '_allow_http_playback')) == consent and kind in connection.prefs['content_types'] and
                    getattr(session, kind) is catalogue and
                    stored_revision_current())
        except Exception:
            return False

    source = None
    try:
        if not permitted():
            raise PlaybackError(code='P401', stage='approval')
        connection.client.authenticate()
        if kind == 'series':
            series = next(row for row in session.series if row['id'] == parent)
            candidates = episodes_from_payload(connection.client.series_info(parent), series)
        else:
            # Recheck the selected catalogue entry; caller cannot supply a URL,
            # arbitrary extension or an ID outside the fetched provider list.
            candidates = session.movies
        row = next((row for row in candidates if row['id'] == identity), None)
        if row is None or not permitted():
            raise PlaybackError(code='P401', stage='approval')
        if kind == 'movies' and not row.get('extension') and hasattr(connection.client, 'movie_info'):
            details = connection.client.movie_info(identity)
            details = details.get('movie_data', {}) if isinstance(details, dict) else {}
            row = dict(row, extension=str(details.get('container_extension') or '').strip().lower().lstrip('.'))
        if row.get('extension') not in MIMES:
            raise PlaybackError(code='P456', stage='preparation')
        source = connection.client.open_media_stream(kind, identity, row['extension'], opener)
        if not permitted():
            raise PlaybackError(code='P401', stage='approval')
        prepared = PreparedPlayback(source, permitted)
        prepared.media = dict(row)
        return prepared
    except BaseException as error:
        if source is not None:
            source.close()
        if not isinstance(error, Exception):
            raise
        code = error.code if type(error) in (PlaybackError, ProviderError) else 'P499'
        from .range_diagnostics import clean_range
        safe = PlaybackError(code=code, stage='stream')
        safe.details = clean_range(getattr(error, 'details', None)) if code == 'P454' else {}
        raise safe from None
