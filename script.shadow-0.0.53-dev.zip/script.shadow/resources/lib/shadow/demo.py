"""Clearly labelled local demonstration; no network requests or playback URLs."""
import time
from .application import Connection
from .accounts import AccountStore
import os


class DemoClient:
    def close(self):
        pass

    def short_epg(self, stream_id):
        now = int(time.time())
        return {'epg_listings': [{'start_timestamp':now-300,'stop_timestamp':now+3300,'title':'Demonstration programme!', 'description':'Offline preview of the programme guide. No live stream is connected.'}]}

    def movies(self):
        return [{'stream_id':1,'name':'Demonstration movie','plot':'Offline catalogue example. No video is included.'}]

    def series(self):
        return [{'series_id':1,'name':'Demonstration series','plot':'Offline catalogue example. No episodes are included.'}]


def demo_connection(profile):
    store = AccountStore(os.path.join(profile,'accounts'),'https://shadow-demo.invalid/player_api.php','offline-preview')
    return Connection(DemoClient(),store,store.load(),
                      [{'category_id':'1','category_name':'EN | Demo channels'},{'category_id':'2','category_name':'FR | Demo channels'}],
                      [{'stream_id':'1','category_id':'1','name':'Demo channel 1','stream_icon':''},{'stream_id':'2','category_id':'2','name':'Demo channel 2','stream_icon':''}])
