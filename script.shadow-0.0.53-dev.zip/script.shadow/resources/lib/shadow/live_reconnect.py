"""Finite retries for a manually selected live channel; no credentials retained."""
from .safe_errors import playback_code, playback_stage, clean_http_status


def diagnostic(error):
    code = playback_code(getattr(error, 'code', None))
    return (code, playback_stage(getattr(error, 'stage', None)),
            clean_http_status(code, getattr(error, 'http_status', None)))


def retryable(error):
    code, stage, status = diagnostic(error)
    # Never retry a login recheck, failed approval, TLS error, redirect rejection,
    # rate limit or unknown failure. Every retry still uses full preparation.
    if stage not in ('stream', 'read'):
        return False
    if code == 'N443':
        return status in (500, 502, 503, 504)
    return (code in ('N409', 'N411', 'N415', 'N420', 'N421', 'N430',
                     'N431', 'N432', 'N453', 'N454', 'N455') or
            (code == 'P453' and stage == 'read'))


class RetryBudget:
    DELAYS = (2, 5, 10)

    def __init__(self):
        self.attempts = 0

    def next_delay(self, error):
        if not retryable(error) or self.attempts >= len(self.DELAYS):
            return None
        delay = self.DELAYS[self.attempts]
        self.attempts += 1
        return delay
