"""Pure setup-wizard state model; UI adapters must explicitly commit approvals."""
from dataclasses import dataclass, field

STEPS = ('provider', 'content', 'languages', 'groups', 'channels', 'organise', 'appearance', 'review')
CONTENT_TYPES = frozenset(('live', 'movies', 'series'))

@dataclass
class SetupState:
    step: int = 0
    content_types: set = field(default_factory=set)
    selected_languages: set = field(default_factory=set)
    selected_group_ids: set = field(default_factory=set)
    selected_channel_ids: set = field(default_factory=set)
    theme: str = 'obsidian'
    completed: bool = False

    def navigate(self, direction):
        if direction not in (-1, 1):
            raise ValueError('Invalid navigation')
        self.step = min(len(STEPS) - 1, max(0, self.step + direction))
        return STEPS[self.step]

    def set_content(self, values):
        values = set(values)
        if not values <= CONTENT_TYPES:
            raise ValueError('Unknown content type')
        self.content_types = values

    def select_channels(self, ids, known_ids, selected=True):
        known = {str(v) for v in known_ids}
        requested = {str(v) for v in ids}
        if not requested <= known:
            raise ValueError('Unknown channel')
        if selected:
            self.selected_channel_ids.update(requested)
        else:
            self.selected_channel_ids.difference_update(requested)

    def commit(self, known_ids):
        """Persist only explicitly selected IDs that still exist in provider inventory."""
        if self.step != len(STEPS) - 1:
            raise ValueError('Wizard must reach review before completion')
        if not self.content_types:
            raise ValueError('Select at least one content type')
        known = {str(v) for v in known_ids}
        approved = sorted(self.selected_channel_ids & known, key=lambda v: (not v.isdigit(), int(v) if v.isdigit() else v))
        self.completed = True
        return {'approved_channel_ids': approved, 'theme': self.theme,
                'content_types': sorted(self.content_types), 'setup_completed': True}
