"""Cooperative cancellation for the existing single job worker; no GUI calls."""
from threading import Event, Lock, local
import socket

_worker = local()


class Cancelled(Exception):
    def __init__(self):
        super().__init__('Operation cancelled')


class Cancellation:
    def __init__(self):
        self.event = Event()
        self.lock = Lock()
        self.callbacks = {}

    def check(self):
        if self.event.is_set():
            raise Cancelled()

    def watch(self, callback):
        key = object()
        with self.lock:
            cancelled = self.event.is_set()
            if not cancelled:
                self.callbacks[key] = callback
        if cancelled:
            callback()
            self.check()
        def remove():
            with self.lock:
                self.callbacks.pop(key, None)
        return remove

    def cancel(self):
        with self.lock:
            self.event.set()
            callbacks = list(self.callbacks.values())
            self.callbacks.clear()
        for callback in callbacks:
            try:
                callback()
            except Exception:
                pass  # Never print endpoint or exception details.

    def detach(self):
        with self.lock:
            self.callbacks.clear()


def current():
    return getattr(_worker, 'token', None)


def bind(token):
    _worker.token = token


def checkpoint():
    token = current()
    if token is not None:
        token.check()


def watch_socket(token, sock):
    def interrupt():
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
    return token.watch(interrupt) if token is not None else lambda: None
