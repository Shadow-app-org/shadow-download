"""Device-local remembered choices, bound to a fingerprint of exact login details.
No provider URL, username, password or media ticket is stored in this file.
"""
import hashlib,json,os,stat,tempfile
from .file_sync import sync_file
from . import sqlite_local_state as local_state
from .saved_login import LoginStorageError,validate

_KEYS={'remember','redirects','http_redirects','http_login'}

def identity(details):
    return hashlib.sha256(json.dumps(validate(details),ensure_ascii=False).encode('utf-8')).hexdigest()

class ConnectionPermissions:
    def __init__(self,profile):self.path=os.path.join(profile,'connection-permissions.json')
    def _sqlite(self):return local_state.selected(os.path.dirname(self.path),'permissions')
    def _document(self):return local_state.LocalDocument(os.path.dirname(self.path),'permissions')
    def _validate(self,data):
        if not isinstance(data,dict) or set(data)!={'version','enabled','entries'} or type(data['version']) is not int or data['version']!=1 or type(data['enabled']) is not bool or not isinstance(data['entries'],dict) or len(data['entries'])>32:raise LoginStorageError()
        for key,options in data['entries'].items():
            if type(key) is not str or len(key)!=64 or any(c not in '0123456789abcdef' for c in key) or not isinstance(options,dict) or set(options)!=_KEYS or any(type(v) is not bool for v in options.values()) or options['http_redirects'] and not options['redirects']:raise LoginStorageError()
        if not data['enabled'] and data['entries']:raise LoginStorageError()
        return data
    def _encode(self,data):
        raw=json.dumps(self._validate(data),ensure_ascii=True).encode('utf-8')
        if len(raw)>32768:raise LoginStorageError()
        return raw
    def _decode(self,raw):
        if type(raw) is not bytes or len(raw)>32768:raise LoginStorageError()
        return self._validate(json.loads(raw))
    def _mutate(self,operation):
        try:
            if not self._sqlite():
                data=operation(self._legacy_read());self._write(data);return data
            raw=self._document().mutate(lambda:self._encode(self._legacy_read()),
                lambda old:self._encode(operation(self._decode(old))))
            local_state.remove_legacy(self.path,'.shadow-permissions-')
            return self._decode(raw)
        except Exception as error:raise LoginStorageError(getattr(error,'code','L500')) from None
    def _read(self):
        try:
            if not self._sqlite():return self._legacy_read()
            return self._mutate(lambda data:data)
        except Exception as error:raise LoginStorageError(getattr(error,'code','L500')) from None
    def _legacy_read(self):
        if not local_state._exists(self.path):return {'version':1,'enabled':True,'entries':{}}
        try:
            if not stat.S_ISREG(os.lstat(self.path).st_mode):raise ValueError()
            fd=os.open(self.path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
            with os.fdopen(fd,'rb') as f:
                if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):raise ValueError()
                raw=f.read(32769)
            if len(raw)>32768:raise ValueError()
            data=json.loads(raw)
            return self._validate(data)
        except Exception:raise LoginStorageError() from None
    def _write(self,data):
        temp=None
        try:
            os.makedirs(os.path.dirname(self.path),exist_ok=True)
            fd,temp=tempfile.mkstemp(prefix='.shadow-permissions-',suffix='.tmp',dir=os.path.dirname(self.path))
            with os.fdopen(fd,'w') as f:
                if hasattr(os,'fchmod'):os.fchmod(f.fileno(),0o600)
                json.dump(data,f);f.flush();sync_file(f,temp)
            os.replace(temp,self.path);temp=None
        except Exception:raise LoginStorageError() from None
        finally:
            if temp:
                try:os.unlink(temp)
                except OSError:pass
    def enabled(self):return self._read()['enabled']
    def set_enabled(self,enabled):
        if type(enabled) is not bool:raise LoginStorageError()
        # Revocation and disabling never import corrupt or old grants.
        data={'version':1,'enabled':enabled,'entries':{}}
        try:
            if self._sqlite():
                self._document().mutate(lambda:None,lambda old:self._encode(data))
                local_state.remove_legacy(self.path,'.shadow-permissions-')
            else:self._write(data)
        except Exception as error:raise LoginStorageError(getattr(error,'code','L500')) from None
    def lookup(self,key):
        data=self._read()
        return dict(data['entries'][key]) if data['enabled'] and key in data['entries'] else None
    def remember(self,key,options):
        if type(key) is not str or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):raise LoginStorageError()
        if not isinstance(options,dict) or any(type(options.get(k,False)) is not bool for k in _KEYS):raise LoginStorageError()
        values={k:options.get(k,False) for k in _KEYS}
        if values['http_redirects'] and not values['redirects']:raise LoginStorageError()
        def update(data):
            if not data['enabled']:return data
            if key not in data['entries'] and len(data['entries'])>=32:data['entries'].pop(next(iter(data['entries'])))
            data['entries'][key]=values
            return data
        self._mutate(update)
    def clear(self):
        def update(data):
            data['entries']={}
            return data
        self._mutate(update)
