"""Private, transactional local documents for remembered login and consent.

Login remains opt-in plaintext, as disclosed by the existing UI. No history or
backup table is created. Deleted/updated content uses verified secure_delete.
"""
import os
from pathlib import Path
import stat
from .sqlite_accounts import _exists, _regular

KINDS = {'login': 'remembered-login-v1', 'permissions': 'connection-consent-v1'}
LIMIT = 32768
MAX_DATABASE = 1024 * 1024
SCHEMA = 'CREATE TABLE document (id INTEGER PRIMARY KEY CHECK(id=1), body BLOB)'
CODES = frozenset('L' + str(n) for n in range(500, 510))


class LocalStateError(Exception):
    def __init__(self, code='L500'):
        self.code = code if code in CODES else 'L500'
        super().__init__('Local remembered state unavailable (' + self.code + ')')


def paths(profile, kind):
    stem = KINDS[kind]
    directory = os.path.join(os.path.abspath(profile), stem)
    return directory, os.path.join(directory, 'state.sqlite3'), os.path.join(directory, '.initialized')


def selected(profile, kind):
    try:
        directory, database, marker = paths(profile, kind)
        return (_exists(database) or _exists(marker) or
                (os.name == 'nt' and not callable(getattr(os, 'fsync', None))))
    except Exception:
        raise LocalStateError('L501') from None


class LocalDocument:
    def __init__(self, profile, kind):
        self.directory, self.path, self.marker = paths(profile, kind)

    def __repr__(self):
        return 'LocalDocument(<redacted>)'

    def _configure(self, db):
        if db.execute('PRAGMA journal_mode=DELETE').fetchone() != ('delete',):
            raise LocalStateError('L504')
        for pragma, value in (('synchronous', 3), ('secure_delete', 1)):
            db.execute('PRAGMA ' + pragma + '=' + str(value))
            if db.execute('PRAGMA ' + pragma).fetchone() != (value,):
                raise LocalStateError('L504')
        db.execute('PRAGMA temp_store=MEMORY')
        size = db.execute('PRAGMA page_size').fetchone()[0]
        if type(size) is not int or not 512 <= size <= 65536:
            raise LocalStateError('L504')
        db.execute('PRAGMA max_page_count=' + str(MAX_DATABASE // size))

    def mutate(self, initial, transform):
        """Read/migrate and transform under one write transaction, then commit.

A NULL body is a persistent forgotten-login tombstone. It never reimports a
legacy login. Callers remove legacy files only after this method commits.
"""
        db = None
        stage = 'L501'
        try:
            import sqlite3
            # Validate a legacy document before claiming a fresh destination.
            # Bad legacy data must not leave an empty migrated database behind.
            initial_value = None
            if not _exists(self.path) and not _exists(self.marker):
                stage = 'L505'
                initial_value = initial()
            stage = 'L501'
            os.makedirs(self.directory, mode=0o700, exist_ok=True)
            if not stat.S_ISDIR(os.lstat(self.directory).st_mode):
                raise LocalStateError(stage)
            owned = False
            if not _exists(self.marker):
                try:
                    os.mkdir(self.marker, 0o700)
                    owned = True
                except FileExistsError:
                    pass
            if not stat.S_ISDIR(os.lstat(self.marker).st_mode):
                raise LocalStateError(stage)
            created = not _exists(self.path)
            if created and not owned:
                raise LocalStateError('L502')
            if not created:
                _regular(self.path, MAX_DATABASE)
            for suffix in ('-journal', '-wal', '-shm'):
                if _exists(self.path + suffix):
                    _regular(self.path + suffix, MAX_DATABASE)
            stage = 'L503'
            uri = Path(self.path).as_uri() + ('?mode=rwc' if created else '?mode=rw')
            db = sqlite3.connect(uri, uri=True, timeout=1, isolation_level=None)
            if created:
                stage = 'L501'
                _regular(self.path, MAX_DATABASE)
                os.chmod(self.path, 0o600)
            stage = 'L505'
            objects = db.execute("SELECT name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").fetchall()
            if created:
                if objects:
                    raise LocalStateError(stage)
            elif (objects != [('document', SCHEMA)] or
                  db.execute('PRAGMA user_version').fetchone() != (1,) or
                  db.execute('PRAGMA quick_check').fetchall() != [('ok',)]):
                raise LocalStateError(stage)
            stage = 'L504'
            self._configure(db)
            stage = 'L506'
            db.execute('BEGIN IMMEDIATE')
            if created:
                db.execute(SCHEMA)
                db.execute('PRAGMA user_version=1')
                current = initial_value
            else:
                sizes = db.execute('SELECT id, length(body) FROM document').fetchall()
                if (len(sizes) != 1 or sizes[0][0] != 1 or
                        (sizes[0][1] is not None and sizes[0][1] > LIMIT)):
                    raise LocalStateError('L505')
                current = db.execute('SELECT body FROM document WHERE id=1').fetchone()[0]
            body = transform(current)
            if body is not None and (type(body) is not bytes or len(body) > LIMIT):
                raise LocalStateError('L505')
            if created:
                db.execute('INSERT INTO document VALUES (1, ?)', (body,))
            elif body != current:
                db.execute('UPDATE document SET body=? WHERE id=1', (body,))
            stage = 'L507'
            db.execute('COMMIT')
            return body
        except BaseException as error:
            if db is not None and db.in_transaction:
                try:
                    db.execute('ROLLBACK')
                except Exception:
                    raise LocalStateError('L508') from None
            if isinstance(error, LocalStateError) or not isinstance(error, Exception):
                raise
            raise LocalStateError(stage) from None
        finally:
            if db is not None:
                try:
                    db.close()
                except Exception:
                    raise LocalStateError('L508') from None


def remove_legacy(path, prefix):
    """Remove old login/consent files only after authoritative commit; no following links."""
    failed = False
    try:
        os.unlink(path)
    except FileNotFoundError:
        pass
    except Exception:
        failed = True
    try:
        with os.scandir(os.path.dirname(path)) as entries:
            for entry in entries:
                if entry.name.startswith(prefix):
                    try:
                        os.unlink(entry.path)
                    except FileNotFoundError:
                        pass
                    except Exception:
                        failed = True
    except FileNotFoundError:
        pass
    except Exception:
        failed = True
    if failed:
        raise LocalStateError('L509') from None
