"""Bounded regular-file reads and exclusive new-file exports.

No provider URLs are accepted by these local filesystem helpers.
"""
import errno
import os
import stat


def read_regular_bytes(path, limit):
    """Refuse links/devices/pipes and recheck the opened descriptor."""
    if not stat.S_ISREG(os.lstat(path).st_mode):
        raise OSError(errno.EINVAL, 'Expected a regular local file')
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) |
                         getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(descriptor, 'rb') as source:
        if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
            raise OSError(errno.EINVAL, 'Expected a regular local file')
        return source.read(limit + 1)


def write_new_bytes(path, body):
    """Reserve without overwrite, sync via the shared platform writer, clean up failures."""
    from .preferences import atomic_bytes
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'wb') as reserved:
        identity = os.fstat(reserved.fileno())
    try:
        atomic_bytes(path, body)
    except BaseException:
        # Remove only this reservation, never an existing or replaced file.
        try:
            current = os.lstat(path)
            if (current.st_dev, current.st_ino) == (identity.st_dev, identity.st_ino):
                os.unlink(path)
        except OSError:
            pass
        raise
