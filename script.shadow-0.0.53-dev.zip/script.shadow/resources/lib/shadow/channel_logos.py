"""Public channel identities and logo references only; no stream API access."""
import json,re,time,unicodedata
from threading import Lock
from urllib.parse import urlsplit
from .transport import request_bytes
from .artwork import safe_remote_image
from .tvmaze import normalized


def channel_name(row):
    name=unicodedata.normalize('NFKC',str(row.get('name') or '')[:180])
    match=re.match(r'^([A-Z]{2,3})\s*[:|]\s*(.*)$',name)
    country=''
    if match:
        country={'UK':'GB','USA':'US'}.get(match[1],match[1]);name=match[2]
    name=re.sub(r'(?:\s+(?:HD|FHD|UHD|SD|4K|RAW))+\s*$', '', name, flags=re.I)
    return normalized(name),country


class ChannelLogos:
    def __init__(self,fetch=request_bytes,clock=time.monotonic):
        self.fetch,self.clock=fetch,clock
        self.lock=Lock();self.until=0;self.ids={};self.names={};self.images={}

    def _load(self):
        now=self.clock()
        if now < self.until:return
        self.until=now+300
        try:
            channels=json.loads(self.fetch('https://iptv-org.github.io/api/channels.json',timeout=8,max_bytes=8*1024*1024,public_only=True))
            logos=json.loads(self.fetch('https://iptv-org.github.io/api/logos.json',timeout=8,max_bytes=8*1024*1024,public_only=True))
            if not isinstance(channels,list) or not isinstance(logos,list) or len(channels)>40000 or len(logos)>60000:return
            ids,names,images={},{},{}
            for row in channels:
                if not isinstance(row,dict) or row.get('closed'):continue
                identity=row.get('id');country=row.get('country');country={'UK':'GB','USA':'US'}.get(country,country)
                if not isinstance(identity,str) or len(identity)>180:continue
                ids[identity.casefold()]=identity
                aliases=[row.get('name','')]+(row.get('alt_names',[])[:8] if isinstance(row.get('alt_names'),list) else [])
                for name in aliases:
                    if isinstance(name,str) and len(name)<=180:
                        key=normalized(name)
                        names.setdefault((key,country),set()).add(identity)
                        names.setdefault((key,''),set()).add(identity)
            for row in logos:
                if not isinstance(row,dict) or not row.get('in_use') or row.get('feed'):continue
                url=safe_remote_image(row.get('url'))
                # GitHub's raw/blob links redirect. Resolve their documented raw
                # asset spelling without enabling redirects to arbitrary hosts.
                parts=urlsplit(url)
                match=re.fullmatch(r'/([^/]+)/([^/]+)/(?:raw|blob)/(.+)',parts.path) if parts.hostname=='github.com' else None
                if match:
                    url=safe_remote_image('https://raw.githubusercontent.com/'+match[1]+'/'+match[2]+'/'+match[3])
                if url and row.get('format') in ('PNG','JPEG'):
                    images.setdefault(row.get('channel'),[])
                    if len(images[row.get('channel')])<3:images[row.get('channel')].append(url)
            self.ids,self.names,self.images=ids,names,images
            self.until=now+86400
        except Exception:pass

    def candidates(self,row):
        with self.lock:
            self._load()
            identity=self.ids.get(str(row.get('epg_channel_id') or '').casefold())
            if not identity:
                name,country=channel_name(row)
                matches=self.names.get((name,country),set())
                if len(matches)!=1:return []
                identity=next(iter(matches))
            return self.images.get(identity,[])[:3]
