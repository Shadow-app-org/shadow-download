"""Local punctuation/spacing/accent tolerant search with bounded typo matching."""
import unicodedata
from functools import lru_cache

@lru_cache(maxsize=8192)
def words(value):
    value = unicodedata.normalize('NFKD',value[:300]).casefold()
    value = ''.join(c for c in value if not unicodedata.combining(c))
    return tuple(''.join(c if c.isalnum() else ' ' for c in value).split())

@lru_cache(maxsize=8192)
def _distance(a,b,limit):
    if abs(len(a)-len(b))>limit or len(set(a)-set(b))>limit or len(set(b)-set(a))>limit:return limit+1
    previous=list(range(len(b)+1));older=None
    for i,x in enumerate(a,1):
        current=[i]
        for j,y in enumerate(b,1):
            value=min(current[-1]+1,previous[j]+1,previous[j-1]+(x!=y))
            if older is not None and i>1 and j>1 and x==b[j-2] and a[i-2]==y:
                value=min(value,older[j-2]+1)
            current.append(value)
        older,previous=previous,current
    return previous[-1]

def score(title,query):
    title_words,query_words=words(str(title)),words(str(query))
    needle=''.join(query_words);haystack=''.join(title_words)
    if not needle:return None if str(query).strip() else 0
    if needle==haystack:return 0
    if needle in haystack:return 1
    if not 4<=len(needle)<=64:return None
    limit=1 if len(needle)<9 else 2
    best=limit+1
    for start in range(min(32,len(title_words))):
        candidate=''
        for word in title_words[start:start+len(query_words)+2]:
            candidate+=word
            if len(candidate)>len(needle)+limit:break
            if abs(len(candidate)-len(needle))<=limit:
                best=min(best,_distance(candidate,needle,limit))
    return 2+best if best<=limit else None

def ranked(rows,query):
    matches=[(score(row.get('name',''),query),index,row) for index,row in enumerate(rows)]
    return [row for value,index,row in sorted((item for item in matches if item[0] is not None),key=lambda item:(item[0],item[1]))]
