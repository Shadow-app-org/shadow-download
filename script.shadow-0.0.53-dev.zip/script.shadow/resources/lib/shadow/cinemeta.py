"""Anonymous Cinemeta movie posters, using the documented Stremio addon API.

Only a cleaned movie title or validated public IMDb ID leaves this module.
No stream requests, accounts, provider credentials or bulk catalogues.
"""
import json
import re
import time
from threading import Lock
from urllib.parse import quote, urlsplit
from .transport import request_bytes
from .tvmaze import TVMaze, series_title, normalized
from .artwork import safe_remote_image


class Cinemeta:
    def __init__(self, fetch=request_bytes, clock=time.monotonic):
        self.fetch, self.clock = fetch, clock
        self.cache, self.lock, self.next_request = {}, Lock(), 0
        self.summaries, self.matched_ids = {}, {}

    def poster(self, row):
        if row.get('kind') != 'movies':
            return ''
        title, year = series_title(row), str(row.get('year') or '')
        identity = row.get('imdb_id', '')
        identity = identity if isinstance(identity, str) and re.fullmatch(r'tt[0-9]{5,12}', identity) else ''
        if len(title) < 2 and not identity:
            return ''
        key = (title.casefold(), year, identity)
        with self.lock:
            now = self.clock()
            cached = self.cache.get(key)
            if cached and now < cached[0]:
                return cached[1]
            if now < self.next_request:
                time.sleep(min(.5, self.next_request-now))
            self.next_request = self.clock()+.5
            image = ''
            summary, matched_id = '', ''
            try:
                endpoint = ('meta/movie/'+identity+'.json' if identity else
                            'catalog/movie/top/search='+quote(title, safe='')+'.json')
                payload = json.loads(self.fetch('https://v3-cinemeta.strem.io/'+endpoint,
                    timeout=5, max_bytes=1024*1024, public_only=True))
                candidates = [payload.get('meta')] if identity else payload.get('metas', [])
                matches = []
                for entry in candidates[:30] if isinstance(candidates,list) else []:
                    if not isinstance(entry,dict) or entry.get('type', 'movie') != 'movie':
                        continue
                    if identity:
                        if entry.get('id') != identity:
                            continue
                    elif normalized(entry.get('name','')) != normalized(title):
                        continue
                    if year and str(entry.get('releaseInfo') or entry.get('year') or '')[:4] != year:
                        continue
                    matches.append(entry)
                if len(matches) == 1:
                    from .overviews import clean_overview
                    summary = clean_overview(matches[0].get('description'))
                    matched_id = str(matches[0].get('id') or '')
                    value = safe_remote_image(matches[0].get('poster'))
                    parts = urlsplit(value)
                    if (parts.hostname in ('m.media-amazon.com', 'image.tmdb.org', 'images.metahub.space')
                            and not parts.query and not parts.fragment):
                        image = value
            except Exception:
                pass
            if len(self.cache) >= 256:
                old = next(iter(self.cache))
                self.cache.pop(old)
                self.summaries.pop(old, None)
                self.matched_ids.pop(old, None)
            self.summaries[key] = summary
            self.matched_ids[key] = matched_id
            self.cache[key] = (now + (86400 if image or summary else 300), image)
            return image

    def overview(self, row):
        if row.get('kind') != 'movies':return ''
        self.poster(row)
        identity = row.get('imdb_id', '')
        identity = identity if isinstance(identity, str) and re.fullmatch(r'tt[0-9]{5,12}', identity) else ''
        key = (series_title(row).casefold(), str(row.get('year') or ''), identity)
        with self.lock:
            summary = self.summaries.get(key, '')
            matched_id = self.matched_ids.get(key, '')
            # Fetch full metadata once only for an already uniquely matched movie.
            if summary or not re.fullmatch(r'tt[0-9]{5,12}', matched_id):return summary
            self.matched_ids[key] = ''
            try:
                payload = json.loads(self.fetch('https://v3-cinemeta.strem.io/meta/movie/'+matched_id+'.json', timeout=5, max_bytes=1024*1024, public_only=True))
                entry = payload.get('meta')
                if not isinstance(entry,dict) or entry.get('id') != matched_id or entry.get('type','movie') != 'movie':return ''
                from .overviews import clean_overview
                summary = clean_overview(entry.get('description'))
                self.summaries[key] = summary
            except Exception:pass
            return summary


class ArtworkSources:
    def __init__(self):
        self.series = TVMaze()
        self.movies = Cinemeta()

    def poster(self, row):
        if row.get('kind') == 'series':
            return self.series.poster(row)
        if row.get('kind') == 'movies':
            return self.movies.poster(row)
        return ''


    def overview(self, row):
        source = self.series if row.get('kind') == 'series' else self.movies if row.get('kind') == 'movies' else None
        return source.overview(row) if source else ''

    def programme_poster(self, row):
        title = str(row.get('title') or '').strip()
        if not title or len(title)<3 or re.search(r'\b(live|news|coverage|weather|tba|teleshopping)\b',title,re.I):
            return ''
        # Without an explicit guide type, accept a title only when exactly one
        # catalogue identifies it. A shared film/series name is ambiguous.
        series = self.series.poster({'kind':'series','name':title})
        movie = self.movies.poster({'kind':'movies','name':title})
        return (series or movie) if bool(series) != bool(movie) else ''
