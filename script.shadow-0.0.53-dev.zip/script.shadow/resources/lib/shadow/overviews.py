"""Bounded plain-text overviews and one replaceable background request."""
import re
from html.parser import HTMLParser
from queue import Queue, Empty
from threading import Thread, Lock


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.hidden = [], 0
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'):self.hidden += 1
        if tag in ('p','br','div'):self.parts.append(' ')
    def handle_endtag(self, tag):
        if tag in ('script','style'):self.hidden = max(0,self.hidden-1)
        if tag in ('p','div'):self.parts.append(' ')
    def handle_data(self, data):
        if not self.hidden:self.parts.append(data)


def clean_overview(value):
    if not isinstance(value,str):return ''
    parser = _Text()
    try:parser.feed(value[:20000]);parser.close()
    except Exception:return ''
    text = re.sub(r'\[[^\]\r\n]{0,100}\]', '', ''.join(parser.parts))
    text = ''.join(c for c in text if c.isprintable() or c.isspace())
    return ' '.join(text.split())[:6000]


class OverviewLoader:
    def __init__(self, source):
        self.source = source
        self.queue, self.lock = Queue(1), Lock()
        self.generation, self.result, self.closed = 0, None, False
        self.worker = Thread(target=self._run, name='ShadowOverviews', daemon=True)
        self.worker.start()
    def select(self, row):
        with self.lock:
            self.generation += 1
            token = self.generation
            self.result = None
            if self.closed:return token
            try:self.queue.get_nowait()
            except Empty:pass
            self.queue.put_nowait((token,dict(row)))
            return token
    def poll(self):
        with self.lock:
            result, self.result = self.result, None
            return result
    def close(self):
        with self.lock:
            self.closed = True
            self.generation += 1
            self.result = None
            try:self.queue.get_nowait()
            except Empty:pass
            self.queue.put_nowait(None)
    def _run(self):
        while True:
            request = self.queue.get()
            if request is None:return
            token,row = request
            try:text = clean_overview(row.get('plot')) or clean_overview(self.source.overview(row))
            except Exception:text = ''
            with self.lock:
                if not self.closed and token == self.generation:self.result = (token,text)
