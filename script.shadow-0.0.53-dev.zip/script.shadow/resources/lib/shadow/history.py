"""Account-scoped, URL-free resume history. One coalescing disk worker."""
import json
import math
import queue
import threading
import time
from functools import wraps
from .preferences import atomic_bytes
from .local_files import read_regular_bytes
from .xtream import display_text

MAX_ROWS = 1000
MAX_BYTES = 1024 * 1024


def clean_record(value):
    if not isinstance(value, dict) or value.get('kind') not in ('movies', 'series'):
        raise ValueError()
    row = {'kind': value['kind']}
    for key in ('id', 'series_id'):
        identity = value.get(key, '')
        if key == 'series_id' and row['kind'] == 'movies':
            continue
        if not isinstance(identity, str) or not identity.isascii() or not identity.isdigit() or not 1 <= len(identity) <= 64:
            raise ValueError()
        row[key] = identity
    for key in ('name', 'series_name'):
        text = display_text(value.get(key, ''), 180)
        row[key] = 'Title' if '://' in text or 'token=' in text.lower() or 'password=' in text.lower() else text
    for key in ('season', 'episode'):
        number = value.get(key, 0)
        if type(number) is not int or not 0 <= number <= 999999:
            raise ValueError()
        row[key] = number
    for key in ('position', 'duration', 'updated'):
        number = value.get(key, 0)
        if type(number) not in (int, float) or not math.isfinite(number) or not 0 <= number <= 253402300799:
            raise ValueError()
        row[key] = float(number)
    if row['duration'] <= 0 or row['position'] > row['duration']:
        raise ValueError()
    row['completed'] = row['position'] >= row['duration'] * .95
    return row


def record_key(row):
    return row['kind'] + ':' + row.get('series_id', '') + ':' + row['id']


def _locked(method):
    @wraps(method)
    def invoke(self,*args,**kwargs):
        with self._state_lock:
            return method(self,*args,**kwargs)
    return invoke


class WatchHistory:
    def __init__(self, store):
        self._state_lock = threading.RLock()
        self.queued_generation = 0
        self.persisted_generation = 0
        self.scope = store.scope
        self.path = None if getattr(store, 'temporary', False) else store.path + '.history.json'
        self.rows = {}
        self.live = []
        self.error = None
        self.blocked = False
        self.closed = False
        self.dirty = False
        self.generation = 0
        self.queue = queue.Queue(1)
        self.wake = threading.Event()
        self.worker = None
        if self.path:
            try:
                raw = read_regular_bytes(self.path,MAX_BYTES)
                if len(raw) > MAX_BYTES:
                    raise ValueError()
                data = json.loads(raw)
                if data.get('version') != 1 or data.get('scope') != self.scope or not isinstance(data.get('rows'), list) or len(data['rows']) > MAX_ROWS:
                    raise ValueError()
                live = data.get('recent_channels', [])
                if not isinstance(live, list) or len(live) > 20 or any(not isinstance(i, str) or not i.isascii() or not i.isdigit() or len(i) > 64 for i in live):
                    raise ValueError()
                self.live = list(dict.fromkeys(live))
                for value in data['rows']:
                    row = clean_record(value)
                    self.rows[record_key(row)] = row
            except FileNotFoundError:
                pass
            except Exception:
                self.rows.clear()
                self.error, self.blocked = 'History could not be read; existing file preserved.', True
            self.worker = threading.Thread(target=self._write, daemon=True)
            self.worker.start()

    @_locked
    def remember_channel(self, identity):
        if self.closed or not isinstance(identity, str) or not identity.isascii() or not identity.isdigit() or not 1 <= len(identity) <= 64:
            return
        self.live = ([identity] + [i for i in self.live if i != identity])[:20]
        self.generation += 1
        self.dirty = True
        self.flush()

    def recent(self, kind):
        rows = sorted((dict(row) for row in self.rows.values() if row['kind'] == kind), key=lambda row: row['updated'], reverse=True)
        if kind == 'series':
            seen, unique = set(), []
            for row in rows:
                if row['series_id'] not in seen:
                    unique.append(row)
                    seen.add(row['series_id'])
            return unique
        return rows

    def find(self, media):
        return self.rows.get(record_key(media))

    @_locked
    def update(self, media, position, duration, persist=False):
        if self.closed:
            return
        try:
            row = clean_record(dict(media, position=position, duration=duration, updated=time.time()))
        except (ValueError, TypeError):
            return
        self.rows[record_key(row)] = row
        self.dirty = True
        self.generation += 1
        if len(self.rows) > MAX_ROWS:
            oldest = min(self.rows, key=lambda key: self.rows[key]['updated'])
            del self.rows[oldest]
        if persist:
            self.flush()

    @_locked
    def flush(self):
        if self.closed or not self.path or self.blocked or not self.dirty:
            return
        payload = json.dumps({'version': 1, 'scope': self.scope, 'rows': list(self.rows.values()), 'recent_channels': self.live}, ensure_ascii=True, separators=(',', ':')).encode('utf-8')
        if len(payload) > MAX_BYTES:
            self.error = 'History exceeded its storage budget; existing file preserved.'
            return
        try:
            self.queue.get_nowait()
            self.queue.task_done()
        except queue.Empty:
            pass
        self.queued_generation = self.generation
        self.queue.put_nowait((self.generation,payload))
        self.dirty = False
        self.wake.set()

    @_locked
    def replace_snapshot(self,records,live):
        # Explicit restore replaces only fully validated personal state.
        checked=[clean_record(row) for row in records]
        if self.closed or len(checked)>MAX_ROWS or not isinstance(live,list) or len(live)>20 or any(not isinstance(v,str) or not v.isascii() or not v.isdigit() or not 1<=len(v)<=64 for v in live):raise ValueError()
        if len(json.dumps({'version':1,'scope':self.scope,'rows':checked,'recent_channels':live},ensure_ascii=True,separators=(',',':')).encode())>MAX_BYTES:raise ValueError()
        self.rows={record_key(row):row for row in checked}
        self.live=list(live)[:20]
        self.blocked=False;self.error=None;self.generation+=1;self.dirty=True
        self.flush()

    def wait_saved(self,timeout=3):
        from .cancellation import checkpoint
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            checkpoint()
            if self.error:return False
            if not self.dirty and self.queue.unfinished_tasks==0:return True
            time.sleep(.02)
        return False

    @_locked
    def clear(self):
        # Explicit Clear is the only route that may replace a corrupt file.
        self.rows.clear()
        self.generation += 1
        self.blocked = False
        self.dirty = True
        self.flush()

    @_locked
    def remove(self, media):
        self.rows.pop(record_key(media), None)
        self.generation += 1
        self.dirty = True
        self.flush()

    def _write(self):
        while True:
            self.wake.wait(.2)
            self.wake.clear()
            try:
                generation,payload = self.queue.get_nowait()
            except queue.Empty:
                if self.closed:
                    return
                continue
            try:
                atomic_bytes(self.path, payload)
                with self._state_lock:
                    self.persisted_generation=max(self.persisted_generation,generation)
                    self.error=None
                    if generation==self.generation:self.dirty=False
            except Exception:
                with self._state_lock:
                    # An older failure must not mark a newer queued snapshot dirty.
                    if generation>=self.queued_generation:
                        self.error = 'History could not be saved; progress remains in this session.'
                        self.dirty = True
            finally:
                self.queue.task_done()
            if self.closed and self.queue.empty():
                return

    def close(self):
        with self._state_lock:
            if self.closed:
                return
            self.flush()
            self.closed = True
            self.wake.set()
        if self.worker:
            self.worker.join(2)
        with self._state_lock:
            self.rows.clear()
