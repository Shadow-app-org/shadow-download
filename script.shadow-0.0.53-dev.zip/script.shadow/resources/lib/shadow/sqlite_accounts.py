"""Transactional account identities/preferences for runtimes without file sync.

No login credentials or provider addresses are stored here. Legacy files remain
untouched. Database failures never fall back to an older JSON revision.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid

from . import preferences
from .local_files import read_regular_bytes
from .safe_errors import storage_failure_detail

DATABASE = 'accounts-v1.sqlite3'
MARKER = '.sqlite-accounts-v1'
MAX_DATABASE = 64 * 1024 * 1024
_SCHEMA = {
    'identity': 'CREATE TABLE identity (id INTEGER PRIMARY KEY CHECK(id=1), key BLOB NOT NULL)',
    'accounts': 'CREATE TABLE accounts (scope TEXT PRIMARY KEY, current BLOB, previous BLOB, damaged BLOB, legacy_hash TEXT NOT NULL)',
}


def selected(directory):
    # Once migrated, always use that database, even on a different platform.
    return (_exists(os.path.join(directory, DATABASE)) or
            _exists(os.path.join(directory, MARKER)) or
            (os.name == 'nt' and not callable(getattr(os, 'fsync', None))))


def _fail(code):
    raise preferences.PreferencesError('Account storage operation failed', code) from None


def _exists(path):
    # lexists suppresses permission/I/O errors as if the database were absent.
    # Only an actual missing path permits a new database or backend selection.
    try:
        os.lstat(path)
        return True
    except FileNotFoundError:
        return False
    except (OSError, AttributeError, NotImplementedError):
        _fail('S455')


def _regular(path, limit):
    info = os.lstat(path)
    if not stat.S_ISREG(info.st_mode):
        _fail('S456')
    if info.st_nlink != 1:
        _fail('S457')
    if info.st_size < 0 or info.st_size > limit:
        _fail('S458')


class SQLiteAccounts:
    def __init__(self, directory):
        self.directory = os.path.abspath(directory)
        self.path = os.path.join(self.directory, DATABASE)
        self.expected_key = None

    def _legacy_key(self, creating):
        path = os.path.join(self.directory, 'scope-key.bin')
        if os.path.lexists(path + '.lock'):
            _fail('S402')
        try:
            key = read_regular_bytes(path, 32)
        except FileNotFoundError:
            if creating and any(re.match(r'^[0-9a-f]{64}\.json(?:\.|$)', name)
                                for name in os.listdir(self.directory)):
                _fail('S404')
            return None
        if len(key) != 32:
            _fail('S405')
        return key

    def _configure(self, db):
        if db.execute('PRAGMA journal_mode=DELETE').fetchone() != ('delete',):
            _fail('S432')
        db.execute('PRAGMA synchronous=EXTRA')
        if db.execute('PRAGMA synchronous').fetchone() != (3,):
            _fail('S432')
        db.execute('PRAGMA temp_store=MEMORY')
        page_size = db.execute('PRAGMA page_size').fetchone()[0]
        if type(page_size) is not int or not 512 <= page_size <= 65536:
            _fail('S432')
        db.execute('PRAGMA max_page_count=' + str(MAX_DATABASE // page_size))

    def _verify(self, db):
        objects = db.execute("SELECT name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").fetchall()
        if dict(objects) != _SCHEMA or len(objects) != len(_SCHEMA):
            _fail('S437' if not objects else 'S461')
        if db.execute('PRAGMA user_version').fetchone() != (1,):
            _fail('S462')
        if db.execute('PRAGMA quick_check').fetchall() != [('ok',)]:
            _fail('S463')

    @contextmanager
    def _transaction(self):
        db = None
        stage = 'S430'
        try:
            try:
                import sqlite3
            except Exception:
                _fail('S436')
            stage = 'S450'
            os.makedirs(self.directory, mode=0o700, exist_ok=True)
            stage = 'S451'
            if not stat.S_ISDIR(os.lstat(self.directory).st_mode):
                _fail('S451')
            marker = os.path.join(self.directory, MARKER)
            new_marker = False
            # Do not mkdir an existing marker on every transaction. Embedded
            # runtimes need not report that collision as FileExistsError.
            # Only a successful mkdir grants ownership of initialization.
            stage = 'S453'
            if not _exists(marker):
                stage = 'S452'
                try:
                    os.mkdir(marker, 0o700)
                    new_marker = True
                except FileExistsError:
                    # A concurrent creator owns initialization, never us.
                    new_marker = False
            stage = 'S453'
            if not stat.S_ISDIR(os.lstat(marker).st_mode):
                _fail('S453')
            # A missing migrated database must not silently resurrect old JSON.
            if not new_marker and not _exists(self.path):
                _fail('S437')
            # Kodi's emulated os.open may truncate despite O_EXCL. Never use it
            # to reserve or reopen the DB. Only the owner of a new marker may
            # create, and native SQLite mode=rw cannot recreate an existing DB.
            created = not _exists(self.path)
            stage = 'S455'
            if not created:
                _regular(self.path, MAX_DATABASE)
            for suffix in ('-journal', '-wal', '-shm'):
                if _exists(self.path + suffix):
                    _regular(self.path + suffix, MAX_DATABASE)
            stage = 'S459'
            uri = Path(self.path).as_uri() + ('?mode=rwc' if created else '?mode=rw')
            stage = 'S460'
            db = sqlite3.connect(uri, uri=True, timeout=1, isolation_level=None)
            if created:
                stage = 'S455'
                _regular(self.path, MAX_DATABASE)
                stage = 'S464'
                os.chmod(self.path, 0o600)
                # Check it is still empty before creating our schema. This also
                # refuses a nonempty database that appeared during creation.
                if db.execute("SELECT count(*) FROM sqlite_master").fetchone() != (0,):
                    _fail('S461')
            if not created:
                stage = 'S461'
                self._verify(db)
            stage = 'S432'
            self._configure(db)
            stage = 'S431'
            db.execute('BEGIN IMMEDIATE')
            if created:
                for sql in _SCHEMA.values():
                    db.execute(sql)
                key = self._legacy_key(creating=True)
                key = key if key is not None else os.urandom(32)
                db.execute('INSERT INTO identity VALUES (1, ?)', (key,))
                db.execute('PRAGMA user_version=1')
            keys = db.execute('SELECT key FROM identity WHERE id=1').fetchall()
            if len(keys) != 1 or type(keys[0][0]) is not bytes or len(keys[0][0]) != 32:
                _fail('S405')
            key = keys[0][0]
            legacy = self._legacy_key(creating=False)
            if (legacy is not None and legacy != key) or (self.expected_key is not None and self.expected_key != key):
                _fail('S404')
            yield db, key
            db.execute('COMMIT')
        except BaseException as error:
            if db is not None and db.in_transaction:
                try:
                    db.execute('ROLLBACK')
                except Exception:
                    _fail('S433')
            if isinstance(error, preferences.PreferencesError) or not isinstance(error, Exception):
                raise
            failure = preferences.PreferencesError('Account database operation failed', stage)
            failure.storage_detail = storage_failure_detail(error)
            raise failure from None
        finally:
            if db is not None:
                try:
                    db.close()
                except Exception:
                    _fail('S433')

    def key(self):
        with self._transaction() as (_db, key):
            result = key
        self.expected_key = result
        return result

    def _legacy(self, path):
        if os.path.lexists(path + '.lock'):
            _fail('S402')
        bodies = []
        digest = hashlib.sha256()
        for suffix in ('', '.bak'):
            try:
                body = read_regular_bytes(path + suffix, preferences.MAX_SETTINGS_BYTES)
            except FileNotFoundError:
                body = None
            except (OSError, AttributeError, NotImplementedError):
                _fail('S412')
            if body is not None and len(body) > preferences.MAX_SETTINGS_BYTES:
                _fail('S412')
            digest.update(b'absent' if body is None else b'present' + hashlib.sha256(body).digest())
            bodies.append(body)
        return bodies, digest.hexdigest()

    def _decode(self, body, scope):
        if type(body) is not bytes or len(body) > preferences.MAX_SETTINGS_BYTES:
            _fail('S412')
        try:
            data = preferences._validate(json.loads(body.decode('utf-8')))
        except (preferences.PreferencesError, ValueError, UnicodeError, RecursionError):
            _fail('S412')
        if data['provider_scope'] != scope:
            _fail('S412')
        return data

    def _encode(self, data, scope):
        checked = preferences._validate(data)
        if checked['provider_scope'] != scope:
            _fail('S412')
        body = json.dumps(checked, ensure_ascii=True, separators=(',', ':')).encode('utf-8')
        if len(body) > preferences.MAX_SETTINGS_BYTES:
            _fail('S412')
        return body

    def _row(self, db, scope, path, recovering=False):
        if not isinstance(scope, str) or not re.fullmatch('[0-9a-f]{64}', scope):
            _fail('S412')
        if path != os.path.join(self.directory, scope + '.json'):
            _fail('S430')
        bodies, fingerprint = self._legacy(path)
        sizes = db.execute('SELECT length(current), length(previous), length(damaged) FROM accounts WHERE scope=?', (scope,)).fetchone()
        if sizes is not None and any(n is not None and n > preferences.MAX_SETTINGS_BYTES for n in sizes):
            _fail('S412')
        row = db.execute('SELECT current, previous, legacy_hash FROM accounts WHERE scope=?', (scope,)).fetchone()
        if row is not None:
            if row[2] != fingerprint:
                _fail('S434')
            return row[0], row[1]
        current, previous = bodies
        if current is not None and not recovering:
            self._decode(current, scope)
        if current is None and previous is None:
            current = self._encode(dict(preferences._defaults(), provider_scope=scope), scope)
        if db.execute('SELECT count(*) FROM accounts').fetchone()[0] >= 1000:
            _fail('S438')
        db.execute('INSERT INTO accounts VALUES (?, ?, ?, NULL, ?)', (scope, current, previous, fingerprint))
        return current, previous

    def load(self, scope, path):
        with self._transaction() as (db, _key):
            current, _previous = self._row(db, scope, path)
            result = self._decode(current, scope)
        return result

    def save(self, scope, path, data, expected_revision):
        validated = preferences._validate(data)
        if validated['provider_scope'] != scope:
            _fail('S412')
        with self._transaction() as (db, _key):
            current, _previous = self._row(db, scope, path)
            old = self._decode(current, scope)
            if old['revision'] != expected_revision:
                raise preferences.PreferencesConflict('Settings changed; reload before saving')
            validated['revision'] = uuid.uuid4().hex
            body = self._encode(validated, scope)
            db.execute('UPDATE accounts SET current=?, previous=? WHERE scope=?',
                       (body, current, scope))
        return deepcopy(validated)

    def recover(self, scope, path, confirmed=False):
        if confirmed is not True:
            raise preferences.PreferencesError('Recovery requires explicit confirmation of settings rollback')
        with self._transaction() as (db, _key):
            current, previous = self._row(db, scope, path, recovering=True)
            data = self._decode(previous, scope)
            data['revision'] = uuid.uuid4().hex
            db.execute('UPDATE accounts SET current=?, damaged=? WHERE scope=?',
                       (self._encode(data, scope), current, scope))
        return data

    def backup(self, scope, path):
        """Readback for the isolated production storage check only."""
        with self._transaction() as (db, _key):
            _current, previous = self._row(db, scope, path)
            result = self._decode(previous, scope)
        return result
