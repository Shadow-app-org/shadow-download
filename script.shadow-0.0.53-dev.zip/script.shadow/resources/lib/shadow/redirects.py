"""Validate provider-supplied stream locations without adding account data."""
from urllib.parse import urljoin, urlsplit


class RedirectError(Exception):
    def __init__(self, code='P460'):
        self.code = code if code in ('P460', 'P461', 'P462') else 'P460'
        super().__init__(self.code)


def stream_redirect(current, locations, allow_http=False, allow_http_redirects=False):
    if len(locations) != 1:
        raise RedirectError()
    location = locations[0]
    if (not isinstance(location, str) or not location or len(location) > 16384 or
            any(ord(c) < 33 or ord(c) == 127 for c in location) or '\\' in location or '#' in location):
        raise RedirectError()
    try:
        target = urljoin(current, location)
        parts = urlsplit(target)
        if (len(target) > 16384 or parts.scheme not in ('http', 'https') or not parts.hostname or
                parts.username is not None or parts.password is not None or parts.fragment):
            raise ValueError()
        if parts.port is not None and not 1 <= parts.port <= 65535:
            raise ValueError()
        parts.hostname.rstrip('.').encode('idna')
    except (ValueError, UnicodeError):
        raise RedirectError() from None
    if urlsplit(current).scheme == 'https' and parts.scheme == 'http' and allow_http_redirects is not True:
        raise RedirectError('P461')
    if parts.scheme == 'http' and allow_http is not True and allow_http_redirects is not True:
        raise RedirectError('P461')
    return target
