"""Opt-in, local plaintext Xtream login. Never stores playback permissions.

This is convenience storage, not an encrypted vault. It deliberately does not
reuse the settings backup mechanism: no extra password-bearing backup files.
"""
import json
import os
import stat
import tempfile
from .file_sync import sync_file
from . import sqlite_local_state as local_state
from urllib.parse import urlsplit


class LoginStorageError(Exception):
    def __init__(self, code='L500'):
        self.code = code if isinstance(code, str) and code in local_state.CODES else 'L500'
        super().__init__('Saved login could not be read, written or removed. (' + self.code + ')')


def error_code(error):
    code = getattr(error, 'code', None)
    return code if type(code) is str and code in local_state.CODES else 'L500'


def validate(values):
    if not isinstance(values, (list, tuple)) or len(values) != 3:
        raise LoginStorageError()
    if any(not isinstance(v, str) or not v or len(v) > 2048 for v in values):
        raise LoginStorageError()
    base, username, password = values
    try:
        parsed = urlsplit(base)
        if (parsed.scheme not in ('http', 'https') or not parsed.hostname or
                parsed.username or parsed.password or parsed.query or parsed.fragment or
                '\\' in base or any(ord(c) < 33 or ord(c) == 127 for c in base) or
                (parsed.port is not None and not 1 <= parsed.port <= 65535)):
            raise ValueError()
    except Exception:
        raise LoginStorageError() from None
    return base, username, password


class SavedLogin:
    def __init__(self, profile):
        self.path = os.path.join(profile, 'remembered-xtream.json')

    def __repr__(self):
        return 'SavedLogin(<redacted>)'

    def _sqlite(self):
        return local_state.selected(os.path.dirname(self.path), 'login')

    def _document(self):
        return local_state.LocalDocument(os.path.dirname(self.path), 'login')

    def _encode(self, values):
        if values is None:
            return None
        raw = json.dumps({'version': 1, 'login': validate(values)}, ensure_ascii=False).encode('utf-8')
        if len(raw) > 16384:
            raise LoginStorageError()
        return raw

    def _decode(self, raw):
        if raw is None:
            return None
        if type(raw) is not bytes or len(raw) > 16384:
            raise LoginStorageError()
        data = json.loads(raw.decode('utf-8'))
        if type(data) is not dict or set(data) != {'version', 'login'} or type(data['version']) is not int or data['version'] != 1:
            raise LoginStorageError()
        return validate(data['login'])

    def exists(self):
        # An unreadable store must still offer the explicit saved-login error
        # path, never crash startup or quietly pretend credentials are absent.
        try:
            return self.load() is not None if self._sqlite() else os.path.lexists(self.path)
        except (LoginStorageError, local_state.LocalStateError):
            return True

    def load(self):
        try:
            if not self._sqlite():
                return self._legacy_load()
            def checked(raw):
                self._decode(raw)
                return raw
            raw = self._document().mutate(lambda: self._encode(self._legacy_load()), checked)
            local_state.remove_legacy(self.path, '.shadow-login-')
            return self._decode(raw)
        except Exception as error:
            raise LoginStorageError(getattr(error, 'code', 'L500')) from None

    def _legacy_load(self):

        try:
            if not local_state._exists(self.path):
                return None
            # Refuse links and non-regular files, including a replacement between
            # lstat/open on platforms that provide O_NOFOLLOW.
            if not stat.S_ISREG(os.lstat(self.path).st_mode):
                raise LoginStorageError()
            fd = os.open(self.path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) |
                         getattr(os, 'O_NONBLOCK', 0))
            with os.fdopen(fd, 'rb') as handle:
                if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                    raise LoginStorageError()
                raw = handle.read(16385)
            if len(raw) > 16384:
                raise LoginStorageError()
            data = json.loads(raw.decode('utf-8'))
            if not isinstance(data, dict) or set(data) != {'version', 'login'} or data['version'] != 1:
                raise LoginStorageError()
            return validate(data['login'])
        except Exception:
            raise LoginStorageError() from None

    def save(self, values):
        try:
            if self._sqlite():
                body = self._encode(validate(values))
                self._document().mutate(lambda: None, lambda _old: body)
                local_state.remove_legacy(self.path, '.shadow-login-')
                return
        except Exception as error:
            raise LoginStorageError(getattr(error, 'code', 'L500')) from None
        temp = None
        try:
            values = validate(values)
            raw = json.dumps({'version': 1, 'login': values}, ensure_ascii=False).encode('utf-8')
            if len(raw) > 16384:
                raise LoginStorageError()
            directory = os.path.dirname(self.path)
            os.makedirs(directory, exist_ok=True)
            fd, temp = tempfile.mkstemp(prefix='.shadow-login-', suffix='.tmp', dir=directory)
            with os.fdopen(fd, 'wb') as handle:
                # mkstemp requests 0600; enforce it where the platform supports it.
                if hasattr(os, 'fchmod'):
                    os.fchmod(handle.fileno(), 0o600)
                handle.write(raw)
                handle.flush()
                sync_file(handle,temp)
            os.replace(temp, self.path)
            temp = None
        except Exception:
            raise LoginStorageError() from None
        finally:
            if temp is not None:
                try:
                    os.unlink(temp)
                except OSError:
                    pass

    def forget(self):
        try:
            if self._sqlite():
                self._document().mutate(lambda: None, lambda _old: None)
                local_state.remove_legacy(self.path, '.shadow-login-')
                return
        except Exception as error:
            raise LoginStorageError(getattr(error, 'code', 'L500')) from None
        failed = False
        try:
            os.unlink(self.path)
        except FileNotFoundError:
            pass
        except Exception:
            failed = True
        # Abrupt process termination during an atomic write can leave its private
        # temporary file. Forget removes these too; never follow their contents.
        try:
            with os.scandir(os.path.dirname(self.path)) as entries:
                for entry in entries:
                    if entry.name.startswith('.shadow-login-'):
                        try:
                            os.unlink(entry.path)
                        except FileNotFoundError:
                            pass
                        except OSError:
                            failed = True
        except FileNotFoundError:
            pass
        except OSError:
            failed = True
        if failed:
            raise LoginStorageError() from None
