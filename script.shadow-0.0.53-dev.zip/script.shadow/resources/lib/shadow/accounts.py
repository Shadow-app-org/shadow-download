"""Isolate channel approvals by canonical provider endpoint and exact username.

A local random HMAC key prevents writing usernames or raw endpoint URLs to disk.
This key is an identifier salt, not a credential vault or encryption mechanism.
"""
import hashlib
import hmac
import os
import re
from urllib.parse import urlsplit, urlunsplit
from . import preferences
from .local_files import read_regular_bytes


def canonical_endpoint(endpoint):
    parsed = urlsplit(endpoint)
    host = parsed.hostname.lower()
    if ':' in host:
        host = '[' + host + ']'
    port = parsed.port
    if port is not None and port != (443 if parsed.scheme == 'https' else 80):
        host += ':' + str(port)
    return urlunsplit((parsed.scheme.lower(), host, parsed.path, '', ''))


def _scope_key(directory):
    from .sqlite_accounts import selected, SQLiteAccounts
    if selected(directory):
        return SQLiteAccounts(directory).key()
    try:
        os.makedirs(directory, mode=0o700, exist_ok=True)
    except (OSError, AttributeError, NotImplementedError):
        raise preferences.PreferencesError('Could not create account directory', 'S401') from None
    path = os.path.join(directory, 'scope-key.bin')
    with preferences._lock(path):
        try:
            key = read_regular_bytes(path,32)
        except FileNotFoundError:
            # Replacing a lost identity key would silently orphan valid approvals.
            try:
                existing = os.listdir(directory)
            except (OSError, AttributeError, NotImplementedError):
                raise preferences.PreferencesError('Could not inspect account identity', 'S404') from None
            if any(re.fullmatch(r'[0-9a-f]{64}\.json(?:\.bak|\.damaged|\.lock)?', name) for name in existing):
                raise preferences.PreferencesError('Account identity is missing; existing selections were preserved', 'S404')
            key = os.urandom(32)
            preferences.atomic_bytes(path, key)
        except (OSError, AttributeError, NotImplementedError):
            raise preferences.PreferencesError('Could not read account identity', 'S404') from None
        if len(key) != 32:
            raise preferences.PreferencesError('Account identity data is damaged; existing selections were preserved', 'S405')
        return key


class AccountStore:
    def __init__(self, directory, endpoint, username):
        directory = os.path.abspath(directory)
        from .sqlite_accounts import selected, SQLiteAccounts
        self.sqlite = SQLiteAccounts(directory) if selected(directory) else None
        key = self.sqlite.key() if self.sqlite is not None else _scope_key(directory)
        identity = (canonical_endpoint(endpoint) + '\0' + username).encode('utf-8')
        self.scope = hmac.new(key, identity, hashlib.sha256).hexdigest()
        self.path = os.path.join(directory, self.scope + '.json')

    def load(self):
        if self.sqlite is not None:
            return self.sqlite.load(self.scope, self.path)
        data = preferences.load(self.path)
        if data['provider_scope'] and data['provider_scope'] != self.scope:
            raise preferences.PreferencesError('Settings belong to a different provider account')
        if not data['provider_scope'] and os.path.exists(self.path):
            raise preferences.PreferencesError('Unbound settings cannot be adopted automatically')
        data['provider_scope'] = self.scope
        return data

    def save(self, data, expected_revision):
        if self.sqlite is not None:
            return self.sqlite.save(self.scope, self.path, data, expected_revision)
        if data.get('provider_scope') != self.scope:
            raise preferences.PreferencesError('Settings belong to a different provider account')
        return preferences.save(self.path, data, expected_revision=expected_revision)

    def recover(self, confirmed=False):
        if self.sqlite is not None:
            return self.sqlite.recover(self.scope, self.path, confirmed)
        return preferences.recover(self.path, confirmed=confirmed, expected_scope=self.scope)

    def backup(self):
        if self.sqlite is not None:
            return self.sqlite.backup(self.scope, self.path)
        return preferences.load(self.path + '.bak')
