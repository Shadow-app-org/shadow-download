"""Single in-flight job, explicit result ownership and cancellation cleanup."""
from threading import Event, Lock, Thread
from .safe_errors import SafeError
from .safe_errors import provider_code, provider_stage, clean_http_status
from .preferences import PreferencesError
from .provider import ProviderError
from .streaming import PlaybackError
from .safe_errors import playback_code, playback_stage
from .cancellation import Cancellation, bind


class JobError(Exception):
    pass


class Job:
    def __init__(self, operation, dispose=lambda value: None):
        self.done = Event()
        self._lock = Lock()
        self._cancelled = False
        self._result = None
        self._failed = False
        self._error_code = None
        self._error_stage = None
        self._http_status = None
        self._error_details = {}
        self._dispose = dispose
        self._cancellation = Cancellation()
        self.thread = Thread(target=self._run, args=(operation,), name='ShadowRequest', daemon=True)
        self.thread.start()

    def _run(self, operation):
        result = None
        bind(self._cancellation)
        try:
            result = operation()
        except BaseException as error:
            # Do not retain exception objects, traceback frames, or request URLs.
            with self._lock:
                self._failed = True
                if type(error) is SafeError:
                    self._error_code = error.code
                elif isinstance(error, PreferencesError):
                    self._error_code = provider_code(error.code)
                    self._error_stage = 'settings'
                elif type(error) is ProviderError:
                    self._error_code = provider_code(error.code)
                    self._error_stage = provider_stage(error.stage)
                    self._http_status = clean_http_status(self._error_code, error.http_status)
                elif type(error) is PlaybackError:
                    self._error_code = playback_code(error.code)
                    self._error_stage = playback_stage(error.stage)
                    self._http_status = clean_http_status(self._error_code, error.http_status)
                    if self._error_code == 'P454':
                        from .range_diagnostics import clean_range
                        self._error_details = clean_range(getattr(error, 'details', None))
        else:
            with self._lock:
                cancelled = self._cancelled
                if not cancelled:
                    self._result = result
            if cancelled:
                self._dispose_safely(result)
        finally:
            self._cancellation.detach()
            bind(None)
            self.done.set()

    def _dispose_safely(self, result):
        try:
            self._dispose(result)
        except Exception:
            # Cleanup must never print credential-bearing objects or tracebacks.
            self._failed = True

    def cancel(self):
        with self._lock:
            self._cancelled = True
            result, self._result = self._result, None
        self._cancellation.cancel()
        if result is not None:
            self._dispose_safely(result)

    def take(self):
        if not self.done.is_set():
            raise JobError('Request is still running')
        with self._lock:
            if self._cancelled:
                return None
            if self._failed:
                error = JobError('Request could not be completed')
                error.code = self._error_code
                error.stage = self._error_stage
                error.http_status = self._http_status
                error.details = dict(self._error_details)
                raise error
            result, self._result = self._result, None
            return result


class JobRunner:
    def __init__(self):
        self.active = None

    def submit(self, operation, dispose=lambda value: None):
        if self.active is not None and not self.active.done.is_set():
            error = JobError('A previous request is still finishing')
            error.code = 'X415'
            raise error
        if self.active is not None:
            self.active.cancel()
        self.active = Job(operation, dispose)
        return self.active

    def close(self):
        if self.active is not None:
            self.active.cancel()
