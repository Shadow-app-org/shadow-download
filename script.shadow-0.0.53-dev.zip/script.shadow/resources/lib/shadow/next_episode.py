"""Player callbacks record events only; UI ticks decide whether to offer next."""
from threading import Event

def make_player(player_type):
    if not isinstance(player_type,type):return player_type()
    class ObservedPlayer(player_type):
        def __init__(self):
            super().__init__()
            self.shadow_events={'ended':Event(),'stopped':Event()}
        def onPlayBackStarted(self):
            for event in self.shadow_events.values():event.clear()
        def onPlayBackEnded(self):self.shadow_events['ended'].set()
        def onPlayBackStopped(self):self.shadow_events['stopped'].set()
        def onPlayBackError(self):self.shadow_events['stopped'].set()
    return ObservedPlayer()

def natural_end(events):
    return isinstance(events,dict) and set(events)=={'ended','stopped'} and events['ended'].is_set() and not events['stopped'].is_set()

def next_in_sequence(episodes,current):
    # episodes_from_payload already sorts across season boundaries.
    index=next((i for i,row in enumerate(episodes) if row['id']==current['id']),None)
    return episodes[index+1] if index is not None and index+1<len(episodes) else None
