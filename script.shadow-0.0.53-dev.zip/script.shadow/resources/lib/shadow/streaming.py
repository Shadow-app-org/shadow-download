"""Private, incremental HTTP(S) MPEG-TS input with explicit HTTP consent. Never return upstream URLs to Kodi."""
import socket
import os
import time
import http.client
from urllib.parse import urlsplit
from .transport import Deadline, _DNS, _Connection, checked_addresses, TransportError
from .safe_errors import playback_code, playback_stage, safe_message, clean_http_status
from .redirects import stream_redirect, RedirectError


class PlaybackError(Exception):
    """Only fixed, non-sensitive messages cross the playback boundary."""
    def __init__(self, message=None, code='P499', stage='preparation', http_status=None):
        self.code = playback_code(code)
        self.stage = playback_stage(stage)
        self.http_status = clean_http_status(self.code, http_status)
        super().__init__(self.code + ': ' + safe_message(self.code, self.http_status))


def stream_id(value):
    if not isinstance(value, str) or not value.isascii() or not value.isdigit() or not 1 <= len(value) <= 64:
        raise PlaybackError(code='P400', stage='approval')
    return value


class TSInput:
    """Up to three opted-in redirects, 12s total handshake, 10s per-read deadline.

    Each read gets a fresh absolute budget: slow trickles cannot keep one read
    alive forever, while a live programme has no artificial total time limit.
    """
    def __init__(self, url, timeout=12, idle_timeout=10, tls_context=None,
                 resolver=socket.getaddrinfo, allow_query=False, public_only=False, allow_http=False,
                 allow_redirects=False, allow_http_redirects=False):
        self.conn = self.response = self.socket = None
        self.closed = False
        self.pending = b''
        self.count = 0
        self.expected = None
        self.idle_timeout = idle_timeout
        failure = 'N400'
        try:
            Deadline(idle_timeout)
            self.budget = Deadline(timeout)
            seen = set()
            for hop in range(4):
                if url in seen:
                    raise PlaybackError(code='P462', stage='stream')
                seen.add(url)
                if not isinstance(url, str) or len(url) > 16384 or any(ord(c) < 33 or ord(c) == 127 for c in url) or '\\' in url:
                    raise ValueError()
                parts = urlsplit(url)
                # This exception permits provider-directed playback hops only;
                # it never changes the initial endpoint's transport permission.
                http_allowed = allow_http is True or (hop > 0 and allow_redirects is True and allow_http_redirects is True)
                if (parts.scheme != 'https' and not (parts.scheme == 'http' and http_allowed)) or not parts.hostname or parts.username is not None or parts.password is not None or (parts.query and allow_query is not True and hop == 0) or parts.fragment:
                    raise ValueError()
                host = parts.hostname.rstrip('.').encode('idna').decode('ascii')
                port = parts.port or (443 if parts.scheme == 'https' else 80)
                failure = 'N410'
                addresses = checked_addresses(_DNS.resolve(host, port, self.budget, resolver), public_only=public_only or hop > 0)
                failure = 'N430'
                self.conn = _Connection(host, port, addresses[0], parts.scheme == 'https', self.budget, tls_context)
                target = (parts.path or '/') + ('?' + parts.query if parts.query else '')
                self.conn.request('GET', target, headers={
                    'Accept': 'video/mp2t', 'Accept-Encoding': 'identity',
                    'User-Agent': 'Shadow/0.0.9', 'Connection': 'close'})
                # Retain the raw socket even when http.client detaches it for HTTP/1.0.
                self.socket = self.conn.sock.raw
                failure = 'N431'
                self.response = self.conn.getresponse()
                response = self.response
                self.budget.remaining()
                if response.status in (301,302,303,307,308) and allow_redirects is True:
                    if hop == 3:
                        raise PlaybackError(code='P462', stage='stream')
                    target = stream_redirect(url, response.headers.get_all('Location', []), allow_http,
                                             allow_http_redirects=allow_http_redirects)
                    # Close the old response/socket without reading its body or
                    # forwarding its headers. All hops share the same deadline.
                    self._release()
                    url = target
                    continue
                break
            if response.status != 200:
                status = response.status
                code = ('N440' if status in (301,302,303,307,308) else 'N441' if status in (401,403) else
                        'N442' if status == 429 else 'N443' if 500 <= status < 600 else
                        'N445' if status == 404 else 'N444')
                raise PlaybackError(code=code, stage='stream', http_status=status)
            if response.getheader('Content-Encoding', 'identity').strip().lower() != 'identity':
                raise PlaybackError(code='N450', stage='stream')
            mime = response.getheader('Content-Type', '').split(';')[0].strip().lower()
            if mime not in ('video/mp2t', 'application/octet-stream'):
                raise PlaybackError(code='P450', stage='stream')
            lengths = response.headers.get_all('Content-Length', [])
            transfers = response.headers.get_all('Transfer-Encoding', [])
            if len(lengths) > 1 or len(transfers) > 1 or (transfers and (lengths or transfers[0].strip().lower() != 'chunked')):
                raise PlaybackError(code='N451', stage='stream')
            if lengths:
                value = lengths[0].strip()
                if not value.isascii() or not value.isdigit() or len(value) > 20:
                    raise PlaybackError(code='N451', stage='stream')
                self.expected = int(value)
                if self.expected < 564 or self.expected % 188:
                    raise PlaybackError(code='P452', stage='stream')
            # Verify three complete transport packets before a local URL exists.
            failure = 'N455'
            prefix = response.read(564)
            self.budget.remaining()
            if len(prefix) != 564 or any(prefix[i] != 0x47 for i in (0, 188, 376)):
                raise PlaybackError(code='P451', stage='stream')
            self.pending = prefix
            self.count = len(prefix)
            self.length = self.expected
        except BaseException as error:
            if type(error) is RedirectError:
                code = error.code
            elif type(error) is PlaybackError:
                code = playback_code(error.code)
            elif type(error) is TransportError and error.code != 'N409':
                code = error.code
            elif isinstance(error, (socket.timeout, TimeoutError)) or (type(error) is TransportError and error.code == 'N409'):
                code = {'N410':'N411','N431':'N432','N455':'N454'}.get(failure, 'N409')
            elif isinstance(error, http.client.IncompleteRead):
                code = 'N453'
            elif isinstance(error, http.client.LineTooLong):
                code = 'N433'
            else:
                code = failure
            try:
                self.close()
            except Exception:
                pass
            if not isinstance(error, Exception):
                raise
            raise PlaybackError(code=code, stage='stream', http_status=getattr(error, 'http_status', None)) from None

    def read(self):
        if self.closed:
            return b''
        try:
            self.budget.end = time.monotonic() + self.idle_timeout
            while True:
                size = len(self.pending) // 188 * 188
                if size:
                    block, self.pending = self.pending[:size], self.pending[size:]
                    if any(block[i] != 0x47 for i in range(0, len(block), 188)):
                        raise ValueError()
                    return block
                block = self.response.read1(16384)
                self.budget.remaining()
                if not block:
                    if self.pending or (self.expected is not None and self.count != self.expected):
                        raise ValueError()
                    return b''
                self.count += len(block)
                self.pending += block
        except Exception as error:
            code = 'P453'
            if isinstance(error, (socket.timeout, TimeoutError)) or (type(error) is TransportError and error.code == 'N409'):
                code = 'N454'
            elif type(error) is TransportError:
                code = error.code
            try:
                self.close()
            except Exception:
                pass
            raise PlaybackError(code=code, stage='read') from None

    def cancel(self):
        self.closed = True
        if self.socket is not None:
            try:
                self.socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def close(self):
        try:
            self.cancel()
        finally:
            self.pending = b''
            self._release()

    def _release(self):
        response, conn, sock = self.response, self.conn, self.socket
        self.response = self.conn = self.socket = None
        failed = False
        for resource in (response, conn, sock):
            if resource is not None:
                try:
                    resource.close()
                except Exception:
                    failed = True
        if failed:
            raise PlaybackError(code='N457', stage='stream') from None


class LocalSample:
    """Packaged synthetic media only; never an arbitrary local-request path."""
    def __init__(self, path):
        self.file = open(path, 'rb')
        self.length = os.fstat(self.file.fileno()).st_size
        self.closed = False

    def read(self):
        return b'' if self.closed else self.file.read(188 * 64)

    def cancel(self):
        self.closed = True

    def close(self):
        self.cancel()
        self.file.close()
