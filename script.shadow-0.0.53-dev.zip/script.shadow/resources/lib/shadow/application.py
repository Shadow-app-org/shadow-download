"""Provider/account application layer, independent of Kodi and controller dialogs."""
from copy import deepcopy
from dataclasses import dataclass
import os
import time
from .accounts import AccountStore
from .memory_store import MemoryStore
from .provider import XtreamClient, ProviderError
from .xtream import channels_from_payload, programmes_from_short_epg, media_from_payload
from .selection import organize_groups
from . import preferences
from .safe_errors import provider_code, STORAGE_CODES, SafeError
from .cancellation import checkpoint


@dataclass(repr=False)
class Connection:
    client: object
    store: object
    prefs: dict
    categories: list
    channels: list

    def close(self):
        try:
            self.client.close()
        finally:
            if isinstance(self.store, MemoryStore):
                self.store.close()
                self.prefs.clear()


def prepare_connection(directory, base_url, username, password, allow_http=False, client_factory=XtreamClient, allow_http_playback=False, temporary=False):
    """Prepare off-thread; caller must adopt or close returned connection."""
    client = None
    store = None
    stage = 'setup'
    try:
        options = {'allow_insecure_http': allow_http}
        if allow_http_playback is True:
            options['allow_http_playback'] = True
        client = client_factory(base_url, username, password, **options)
        stage = 'login'
        client.authenticate()
        stage = 'settings'
        store = MemoryStore() if temporary is True else AccountStore(os.path.join(directory, 'accounts'), client.endpoint, username)
        prefs = store.load()
        stage = 'categories'
        categories = client.live_categories()
        stage = 'channels'
        payload = client.live_streams()
        stage = 'catalogue'
        channels = channels_from_payload(payload)
        del payload
        # Preserve an explicit Other group for streams with absent category metadata.
        known = {str(c.get('category_id')) for c in categories if isinstance(c, dict)}
        for channel in channels:
            checkpoint()
            group = channel['category_id']
            if group not in known:
                categories.append({'category_id': group, 'category_name': 'Other'})
                known.add(group)
        return Connection(client, store, prefs, categories, channels)
    except BaseException as error:
        code = {'setup': 'X400', 'settings': 'X411', 'catalogue': 'X410'}.get(stage, 'X499')
        if stage == 'settings' and isinstance(error, OSError):
            code = 'S413'  # Preserve the supplied v0.0.45 filesystem classification.
        if type(error) is ProviderError:
            code = provider_code(error.code)
        elif isinstance(error, preferences.PreferencesError) or type(error) is SafeError:
            candidate = getattr(error, 'code', None)
            if isinstance(candidate, str) and candidate in STORAGE_CODES:
                code = candidate
        if client is not None:
            try:
                client.close()
            except Exception:
                pass  # Never replace the primary failure with raw cleanup details.
        if isinstance(store, MemoryStore):
            store.close()
        if not isinstance(error, Exception):
            raise
        raise ProviderError(code=code, stage=stage,
                            http_status=error.http_status if type(error) is ProviderError else None) from None


def recover_account(directory, base_url, username, password, confirmed=False, allow_http=False, client_factory=XtreamClient):
    """Authenticate before restoring this account; no credentials are persisted."""
    client = client_factory(base_url, username, password, allow_insecure_http=allow_http)
    try:
        client.authenticate()
        store = AccountStore(os.path.join(directory, 'accounts'), client.endpoint, username)
        store.recover(confirmed=confirmed)
        return True
    finally:
        client.close()


class Session:
    def __init__(self):
        self.connection = None
        self.history = None
        self.discovery = None
        self.epg = {}
        self.epg_updated = {}
        self.movies = []
        self.series = []
        self.media_loaded = {}
        self._visible_cache = {}

    @property
    def connected(self):
        return self.connection is not None

    @property
    def temporary(self):
        return bool(self.connection and isinstance(self.connection.store, MemoryStore))

    @property
    def prefs(self):
        return self.connection.prefs if self.connection else None

    @property
    def channels(self):
        return self.connection.channels if self.connection else []

    def adopt(self, connection):
        self.close()
        self.connection = connection
        from .history import WatchHistory
        self.history = WatchHistory(connection.store)
        from .discovery import Discovery
        self.discovery = Discovery(connection.store)

    def close(self):
        if self.history is not None:
            self.history.close()
            self.history = None
        connection, self.connection = self.connection, None
        try:
            if connection is not None:
                connection.close()
        finally:
            self.epg.clear()
            self.epg_updated.clear()
            self.movies = []
            self.series = []
        self.media_loaded = {}
        self._visible_cache = {}

    def ensure_current(self):
        if self.connection and self.connection.store.load()['revision'] != self.prefs['revision']:
            raise preferences.PreferencesConflict('Settings changed; reload before continuing')

    def save(self, changes):
        if not self.connection:
            raise ProviderError('Connect a provider first')
        updated = deepcopy(self.prefs)
        updated.update(changes)
        known = {c['stream_id'] for c in self.channels}
        additions = set(updated['approved_channel_ids']) - set(self.prefs['approved_channel_ids'])
        if not additions <= known:
            raise preferences.PreferencesError('Unknown channels cannot be approved')
        updated['approved_channel_ids'] = [i for i in updated['approved_channel_ids'] if i in known]
        approved = set(updated['approved_channel_ids'])
        updated['favourites'] = [i for i in updated['favourites'] if i in approved]
        updated['channel_order'] = [i for i in updated['channel_order'] if i in approved]
        for name, ids in updated['custom_categories'].items():
            updated['custom_categories'][name] = [i for i in ids if i in approved]
        self.connection.prefs = self.connection.store.save(updated, self.prefs['revision'])
        self.epg = {i: entries for i, entries in self.epg.items() if i in approved}
        self.epg_updated = {i: stamp for i, stamp in self.epg_updated.items() if i in approved}
        return self.prefs

    def reload(self):
        if self.connection:
            self.connection.prefs = self.connection.store.load()
            self.epg.clear()
            self.epg_updated.clear()

    def visible(self, favourites=False, query='', category=None):
        if not self.connection:
            return []
        cache_key = (id(self.connection), self.prefs['revision'], id(self.channels), favourites, query, category)
        if cache_key in self._visible_cache:
            return self._visible_cache[cache_key]
        allowed = set(self.prefs['approved_channel_ids'])
        if favourites:
            allowed &= set(self.prefs['favourites'])
        if category is not None:
            allowed &= set(self.prefs['custom_categories'].get(category, []))
        from .search import score, ranked
        rows = [c for c in self.channels if c['stream_id'] in allowed and score(c['name'], query) is not None]
        languages=self.prefs.get('browse_languages')
        if languages:
            from .selection import canonical_language,language_for_channel
            names={str(c.get('category_id')):c.get('category_name','') for c in self.connection.categories}
            rows=[c for c in rows if canonical_language(language_for_channel(c['name'],names.get(c.get('category_id'),''))) in languages]
        order = {value: position for position, value in enumerate(self.prefs['channel_order'])}
        result = sorted(rows, key=lambda c: order.get(c['stream_id'], len(order)))
        if query:result = ranked(result,query)
        if len(self._visible_cache) >= 4:
            self._visible_cache.clear()
        self._visible_cache[cache_key] = result
        return result

    def epg_fresh(self, stream_id):
        updated = self.epg_updated.get(stream_id)
        lifetime = 1800 if self.epg.get(stream_id) else 300
        return updated is not None and time.monotonic() - updated < lifetime

    def epg_request(self, stream_id, force=False):
        self.ensure_current()
        if not self.connection or stream_id not in {c['stream_id'] for c in self.visible()}:
            raise ProviderError('Channel is not approved')
        connection = self.connection
        cached = self.epg.get(stream_id) if not force and self.epg_fresh(stream_id) else None
        def fetch():
            if cached is not None:
                return connection, stream_id, cached
            entries = programmes_from_short_epg(connection.client.short_epg(stream_id), now=int(time.time()))
            return connection, stream_id, entries
        return fetch

    def accept_epg(self, result):
        connection, stream_id, entries = result
        if connection is not self.connection or stream_id not in {c['stream_id'] for c in self.visible()}:
            return False
        try:
            self.ensure_current()
        except preferences.PreferencesConflict:
            return False
        if self.epg.get(stream_id) is not entries:
            self.epg_updated[stream_id] = time.monotonic()
        self.epg[stream_id] = entries
        return True

    def media_request(self, kind):
        if not self.connection or kind not in ('movies', 'series'):
            raise ProviderError('Connect a provider first')
        connection = self.connection
        from .collection_progress import CollectionStatus
        status = CollectionStatus()
        def fetch():
            with status.active():
                status.check()
                payload = connection.client.movies() if kind == 'movies' else connection.client.series()
                status.check()
                if not isinstance(payload, list):
                    raise ProviderError(code='X412', stage='catalogue')
                status.update('processing', total=len(payload))
                try:
                    items = media_from_payload(payload, kind)
                except SafeError:
                    raise
                except Exception:
                    checkpoint()  # Preserve cancellation instead of diagnosing a failure.
                    raise ProviderError(code='X414', stage='catalogue') from None
                status.check()
                status.update('ready')
                return connection, kind, items
        fetch.collection_status = status
        return fetch

    def accept_media(self, result):
        connection, kind, items = result
        if connection is not self.connection:
            return False
        setattr(self, kind, items)
        self.media_loaded[kind] = time.monotonic()
        if self.discovery:self.discovery.update(kind,items)
        return True

    def languages(self):
        return organize_groups(self.connection.categories, self.connection.channels) if self.connection else {}


def update_filtered_selection(current, candidates, selected):
    """Changing a filtered page never silently revokes approvals outside that page."""
    candidate_ids = {c['stream_id'] for c in candidates}
    selected = set(selected)
    if not selected <= candidate_ids:
        raise preferences.PreferencesError('Unknown channel selection')
    return sorted((set(current) - candidate_ids) | selected)
