"""Revocable one-item loopback capability; three bounded workers, no URL logs."""
import hmac
import queue
import secrets
import socket
import threading
import time
from .cancellation import Cancellation, bind
from .vod import byte_range


def _close(sock):
    if sock is not None:
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        sock.close()


class VODRelay:
    """Reusable GET/HEAD only until Stop, revocation, ownership loss or expiry.

    A valid new GET cancels the previous request. One serial streaming worker
    owns all upstream reads; one queued replacement at most. HEAD is metadata
    only, and never interrupts an active read.
    """
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.lock = threading.RLock()
        self.queue = queue.Queue(1)
        self.closed = threading.Event()
        self.prepared = None
        self.token = None
        self.active = None
        self.handshake = None
        self.expires = 0
        self.status = 'idle'
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.bind(('127.0.0.1', 0))
        self.listener.listen(2)
        self.listener.settimeout(.2)
        self.port = self.listener.getsockname()[1]
        self.host = '127.0.0.1:%d' % self.port
        self.workers = [threading.Thread(target=fn, daemon=True) for fn in (self._accept, self._stream, self._guard)]
        for worker in self.workers:
            worker.start()

    def start(self, prepared):
        self.stop()
        try:
            allowed = prepared.permitted()
        except Exception:
            allowed = False
        if self.closed.is_set() or not allowed:
            prepared.close()
            raise ValueError('Playback unavailable')
        with self.lock:
            self.prepared = prepared
            self.token = '/' + secrets.token_urlsafe(32) + '.' + prepared.source.extension
            self.expires = self.clock() + 30
            self.status = 'ready'
            return 'http://' + self.host + self.token

    def touch_owned(self):
        with self.lock:
            if self.prepared is not None:
                self.expires = self.clock() + 60

    def _valid(self, prepared):
        try:
            return prepared is not None and self.prepared is prepared and self.clock() < self.expires and prepared.permitted()
        except Exception:
            return False

    def _error(self, client, status):
        try:
            client.sendall(('HTTP/1.1 %s\r\nContent-Length: 0\r\nConnection: close\r\n\r\n' % status).encode('ascii'))
        except OSError:
            pass

    def _request(self, client):
        deadline = self.clock() + 2
        data = b''
        while b'\r\n\r\n' not in data:
            remaining = deadline - self.clock()
            if remaining <= 0 or len(data) >= 8192:
                raise ValueError()
            client.settimeout(remaining)
            part = client.recv(min(1024, 8192-len(data)))
            if not part:
                raise ValueError()
            data += part
        head, tail = data.split(b'\r\n\r\n', 1)
        if tail:
            raise ValueError()
        lines = head.decode('ascii').split('\r\n')
        method, path, version = lines[0].split(' ')
        if method not in ('GET', 'HEAD') or version not in ('HTTP/1.0', 'HTTP/1.1') or len(lines) > 33:
            raise ValueError()
        headers = {}
        for line in lines[1:]:
            name, value = line.split(':', 1)
            if not name or name.strip() != name or any(ord(c) < 33 or ord(c) > 126 for c in name):
                raise ValueError()
            name, value = name.lower(), value.strip()
            if name in headers or any(ord(c) < 32 or ord(c) > 126 for c in value):
                raise ValueError()
            headers[name] = value
        if headers.get('host') != self.host or any(name in headers for name in ('origin', 'referer', 'authorization', 'proxy-authorization', 'cookie', 'transfer-encoding', 'if-range')) or headers.get('content-length', '0') != '0':
            raise ValueError()
        return method, path, headers.get('range')

    def _headers(self, prepared, start, end, partial):
        source = prepared.source
        lines = ['HTTP/1.1 206 Partial Content' if partial else 'HTTP/1.1 200 OK',
                 'Content-Type: ' + source.mime, 'Content-Length: ' + str(end-start+1),
                 'Accept-Ranges: ' + ('bytes' if getattr(source, 'seekable', True) else 'none'), 'Cache-Control: no-store', 'Connection: close']
        if partial:
            lines.append('Content-Range: bytes %d-%d/%d' % (start, end, source.length))
        return ('\r\n'.join(lines) + '\r\n\r\n').encode('ascii')

    def _accept(self):
        while not self.closed.is_set():
            try:
                client, peer = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            transferred = False
            with self.lock:
                self.handshake = client
            try:
                if peer[0] != '127.0.0.1':
                    raise ValueError()
                method, path, requested = self._request(client)
                with self.lock:
                    prepared = self.prepared
                    if not self._valid(prepared) or not hmac.compare_digest(path, self.token or ''):
                        self._error(client, '403 Forbidden')
                        continue
                    try:
                        start, end = byte_range(requested, prepared.source.length)
                        if not getattr(prepared.source, 'seekable', True) and start != 0:
                            raise ValueError()
                    except ValueError:
                        self._error(client, '416 Range Not Satisfiable')
                        continue
                    client.settimeout(10)
                    if method == 'HEAD':
                        client.sendall(self._headers(prepared, start, end, requested is not None))
                        continue
                    cancellation = Cancellation()
                    entry = (client, prepared, start, end, requested is not None, cancellation)
                    self._cancel_active()
                    self._drain()
                    self.active = entry
                    self.queue.put_nowait(entry)
                    transferred = True
            except Exception:
                self._error(client, '400 Bad Request')
            finally:
                with self.lock:
                    if self.handshake is client:
                        self.handshake = None
                if not transferred:
                    _close(client)

    def _stream(self):
        while not self.closed.is_set():
            try:
                entry = self.queue.get(timeout=.2)
            except queue.Empty:
                continue
            client, prepared, start, end, partial, cancellation = entry
            reader = None
            headers_sent = False
            bind(cancellation)
            try:
                cancellation.check()
                if not self._valid(prepared):
                    raise ValueError()
                reader = prepared.source.open(start, end)
                cancellation.check()
                client.sendall(self._headers(prepared, start, end, partial))
                headers_sent = True
                while True:
                    cancellation.check()
                    if not self._valid(prepared):
                        raise ValueError()
                    block = reader.read()
                    if not block:
                        break
                    try:
                        client.sendall(block)
                    except OSError:
                        # Kodi closing/reopening a range is normal during seek.
                        break
            except Exception:
                if not cancellation.event.is_set() and self._valid(prepared):
                    # An upstream failure is terminal; local seek cancellation
                    # has already marked its token and cannot poison a new item.
                    with self.lock:
                        if self.active is entry:
                            if not headers_sent:
                                self._error(client, '502 Bad Gateway')
                            self.stop()
                            self.status = 'stream-failed'
            finally:
                if reader is not None:
                    try:
                        reader.close()
                    except Exception:
                        pass
                cancellation.detach()
                bind(None)
                _close(client)
                with self.lock:
                    if self.active is entry:
                        self.active = None
                self.queue.task_done()

    def _cancel_active(self):
        if self.active:
            self.active[-1].cancel()
            _close(self.active[0])
            self.active = None

    def _drain(self):
        try:
            entry = self.queue.get_nowait()
        except queue.Empty:
            return
        entry[-1].cancel()
        _close(entry[0])
        self.queue.task_done()

    def stop(self):
        with self.lock:
            prepared, self.prepared = self.prepared, None
            self.token = None
            _close(self.handshake)
            self.handshake = None
            self._cancel_active()
            self._drain()
            if prepared is not None:
                prepared.close()
            self.status = 'stopped'

    def _guard(self):
        while not self.closed.wait(.2):
            with self.lock:
                if self.prepared is not None and not self._valid(self.prepared):
                    self.stop()
                    self.status = 'authorization-ended'

    def close(self):
        self.stop()
        self.closed.set()
        _close(self.listener)
        for worker in self.workers:
            worker.join(.6)
