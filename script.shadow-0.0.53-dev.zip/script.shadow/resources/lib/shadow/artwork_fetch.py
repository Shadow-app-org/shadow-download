"""Opt-in HTTPS artwork fetcher. No redirects, proxies, or secondary DNS lookup.

Bounded PNG and JPEG files are supported; native Kodi performs final decoding.
Unsupported WebP/GIF falls back; never pass remote URLs straight to Kodi.
"""
import hashlib
import ipaddress
import os
import socket
import struct
import tempfile
from threading import RLock
from .file_sync import sync_file
import time
import zlib
from .artwork import safe_remote_image

MAX_BYTES = 2 * 1024 * 1024
MAX_PIXELS = 1920 * 1080
MAX_CACHE_BYTES = 20 * 1024 * 1024


class ArtworkError(Exception):
    pass


def public_addresses(host, resolver=socket.getaddrinfo):
    try:
        answers = resolver(host, 443, type=socket.SOCK_STREAM)
        addresses = list(dict.fromkeys(answer[4][0] for answer in answers))
        if not addresses or len(addresses) > 16:
            raise ValueError()
        for address in addresses:
            ip = ipaddress.ip_address(address)
            if (not ip.is_global or ip.is_multicast or getattr(ip, 'ipv4_mapped', None) is not None
                    or (ip.version == 6 and (ip not in ipaddress.ip_network('2000::/3')
                                            or ip.sixtofour is not None or ip.teredo is not None))):
                raise ValueError()
        return addresses
    except Exception:
        raise ArtworkError('Artwork destination is not permitted') from None


def validate_png(body):
    """Validate chunks, CRC, dimensions and exact bounded scanline decompression.

    Supports RGB/RGBA and bounded indexed PNG logos; rejects animation and interlacing.
    Kodi still performs final pixel rendering; device decoder testing is required.
    """
    try:
        if len(body) > MAX_BYTES or not body.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError()
        pos, width, height, channels = 8, 0, 0, 0
        compressed = bytearray()
        palette = 0
        row_bytes = 0
        ended = False
        idat_seen = False
        chunks = 0
        while pos < len(body):
            chunks += 1
            if chunks > 4096 or pos + 12 > len(body):
                raise ValueError()
            length = struct.unpack('!I', body[pos:pos+4])[0]
            kind = body[pos+4:pos+8]
            stop = pos + 12 + length
            if stop > len(body):
                raise ValueError()
            data = body[pos+8:pos+8+length]
            crc = struct.unpack('!I', body[pos+8+length:stop])[0]
            if zlib.crc32(kind + data) & 0xffffffff != crc:
                raise ValueError()
            if kind == b'IHDR' and pos == 8 and length == 13:
                width, height, depth, colour, comp, filt, interlace = struct.unpack('!IIBBBBB', data)
                if not (0 < width <= 4096 and 0 < height <= 4096 and width * height <= MAX_PIXELS):
                    raise ValueError()
                if (comp, filt, interlace) != (0, 0, 0):
                    raise ValueError()
                if colour == 3 and depth in (1, 2, 4, 8):
                    channels = 1
                    row_bytes = (width * depth + 7) // 8
                elif colour in (2, 6) and depth == 8:
                    channels = 3 if colour == 2 else 4
                    row_bytes = width * channels
                else:
                    raise ValueError()
            elif kind == b'PLTE' and channels and not idat_seen:
                if palette or not length or length % 3 or length > 768 or (colour == 3 and length//3 > 2**depth):
                    raise ValueError()
                palette = length//3
            elif kind == b'tRNS' and colour == 3:
                if not palette or idat_seen or not 0 < length <= palette:
                    raise ValueError()
            elif kind == b'IDAT' and channels:
                if colour == 3 and not palette:
                    raise ValueError()
                compressed.extend(data)
                idat_seen = True
            elif kind == b'IEND' and not length and idat_seen:
                ended = True
                pos = stop
                break
            elif kind[:1].islower() and channels and kind not in (b'acTL', b'fcTL', b'fdAT'):
                pass  # Ignore CRC-checked ancillary metadata, never interpret it.
            else:
                raise ValueError()
            pos = stop
        if not ended or pos != len(body):
            raise ValueError()
        expected = height * (1 + row_bytes)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(bytes(compressed), expected + 1)
        if len(raw) != expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
            raise ValueError()
        if any(raw[i] > 4 for i in range(0, expected, 1 + row_bytes)):
            raise ValueError()
        return width, height
    except Exception:
        raise ArtworkError('Unsupported or invalid artwork image') from None


def validate_jpeg(body):
    """Bound markers, frame dimensions and scan data before native Kodi decoding.

    This structural check is not a full entropy decoder. Only 8-bit baseline,
    extended sequential and progressive DCT frames are accepted.
    """
    try:
        if len(body) > MAX_BYTES or not body.startswith(b'\xff\xd8'):
            raise ValueError()
        pos, dimensions, scans, markers = 2, None, 0, 0
        while pos < len(body):
            markers += 1
            if markers > 4096 or body[pos] != 255:
                raise ValueError()
            while pos < len(body) and body[pos] == 255:
                pos += 1
            marker = body[pos]; pos += 1
            if marker == 0xd9:
                if dimensions and scans and pos == len(body):
                    return dimensions
                raise ValueError()
            if marker in (0, 0xd8) or 0xd0 <= marker <= 0xd7:
                raise ValueError()
            length = int.from_bytes(body[pos:pos+2], 'big')
            end = pos + length
            if length < 2 or end > len(body):
                raise ValueError()
            data = body[pos+2:end]
            if marker in (0xc0, 0xc1, 0xc2):
                if dimensions or len(data) < 6 or data[0] != 8:
                    raise ValueError()
                height, width = struct.unpack('!HH', data[1:5])
                if not (0 < width <= 4096 and 0 < height <= 4096 and width*height <= MAX_PIXELS):
                    raise ValueError()
                if data[5] not in (1, 3) or len(data) != 6+3*data[5]:
                    raise ValueError()
                dimensions = (width, height)
            elif marker in (0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf):
                raise ValueError()
            pos = end
            if marker == 0xda:
                if not dimensions or not data or len(data) != 4+2*data[0]:
                    raise ValueError()
                scans += 1
                while pos < len(body):
                    if body[pos] != 255:
                        pos += 1; continue
                    if pos+1 < len(body) and (body[pos+1] == 0 or 0xd0 <= body[pos+1] <= 0xd7):
                        pos += 2; continue
                    break
        raise ValueError()
    except Exception:
        raise ArtworkError('Unsupported or invalid artwork image') from None


def validate_image(body):
    if body.startswith(b'\xff\xd8'):
        validate_jpeg(body)
        return '.jpg'
    validate_png(body)
    return '.png'


def download(url, timeout=8, resolver=socket.getaddrinfo):
    from .transport import request_bytes
    if not safe_remote_image(url):
        raise ArtworkError('Artwork URL is not permitted')
    try:
        body = request_bytes(url, timeout=timeout, max_bytes=MAX_BYTES, accept='image/png,image/jpeg', public_only=True, resolver=resolver)
        validate_image(body)
        return body
    except Exception:
        raise ArtworkError('Artwork download failed') from None


def _cache_locked(method):
    from functools import wraps
    @wraps(method)
    def invoke(self,*args,**kwargs):
        with self._file_lock:
            return method(self,*args,**kwargs)
    return invoke


class ArtworkCache:
    """Shared bounded image cache. Network fetches run outside its file lock.

    No URL manifests are persisted (provider image queries may contain secrets).
    """
    def __init__(self, directory, fetch=download, ttl=86400, max_cache_bytes=MAX_CACHE_BYTES):
        self._file_lock = RLock()
        self.max_cache_bytes = max_cache_bytes
        self.directory, self.fetch, self.ttl = os.path.abspath(directory), fetch, ttl
        os.makedirs(self.directory, exist_ok=True)

    def get(self, url):
        if not safe_remote_image(url):
            raise ArtworkError('Artwork URL is not permitted')
        # No network work under the file lock: other workers can reuse cached art.
        with self._file_lock:
            cached = self.peek(url)
            if cached:
                return cached
        body = self.fetch(url)
        extension = validate_image(body)
        if len(body) > self.max_cache_bytes:
            raise ArtworkError('Artwork exceeds cache budget')
        path = os.path.join(self.directory, hashlib.sha256(url.encode()).hexdigest() + extension)
        temporary = None
        with self._file_lock:
            try:
                with tempfile.NamedTemporaryFile(dir=self.directory, prefix='.shadow-art-', suffix='.tmp', delete=False) as target:
                    temporary = target.name
                    target.write(body)
                    target.flush()
                    sync_file(target, temporary)
                os.replace(temporary, path)
                temporary = None
                files = []
                for name in os.listdir(self.directory):
                    if name.endswith(('.png', '.jpg')):
                        candidate = os.path.join(self.directory, name)
                        try:
                            info = os.stat(candidate)
                            files.append((info.st_mtime, candidate, info.st_size))
                        except OSError:
                            continue
                total = sum(size for modified, candidate, size in files)
                for modified, candidate, size in sorted(files):
                    if total <= self.max_cache_bytes:
                        break
                    if candidate == path:
                        continue
                    try:
                        os.unlink(candidate)
                        total -= size
                    except FileNotFoundError:
                        total -= size
                return path
            except OSError:
                raise ArtworkError('Artwork cache unavailable') from None
            finally:
                if temporary is not None:
                    try:
                        os.unlink(temporary)
                    except OSError:
                        pass

    @_cache_locked
    def media_get(self, key):
        """Worker-only local association; hashes and validated basenames, no URLs."""
        try:
            marker=os.path.join(self.directory,'.media-'+hashlib.sha256(key.encode()).hexdigest()+'.txt')
            if time.time()-os.path.getmtime(marker)>self.ttl:return ''
            with open(marker,'r',encoding='ascii') as f:name=f.read(100)
            import re
            if not re.fullmatch(r'[0-9a-f]{64}\.(?:png|jpg)',name):return ''
            path=os.path.join(self.directory,name)
            with open(path,'rb') as f:validate_image(f.read(MAX_BYTES+1))
            os.utime(path,None)
            return path
        except Exception:return ''

    @_cache_locked
    def media_remember(self,key,path):
        temporary=None
        try:
            name=os.path.basename(path)
            if os.path.dirname(os.path.abspath(path))!=self.directory:return
            marker=os.path.join(self.directory,'.media-'+hashlib.sha256(key.encode()).hexdigest()+'.txt')
            with tempfile.NamedTemporaryFile(dir=self.directory,prefix='.link-',delete=False) as f:
                temporary=f.name;f.write(name.encode('ascii'))
            os.replace(temporary,marker);temporary=None
            markers=[os.path.join(self.directory,n) for n in os.listdir(self.directory) if n.startswith('.media-') and n.endswith('.txt')]
            for old in sorted(markers,key=os.path.getmtime)[:-256]:
                try:os.unlink(old)
                except OSError:pass
        except Exception:pass
        finally:
            if temporary:
                try:os.unlink(temporary)
                except OSError:pass

    @_cache_locked
    def peek(self,url):
        """Return a validated cached image without attempting any network request."""
        if not safe_remote_image(url):return ''
        stem=os.path.join(self.directory,hashlib.sha256(url.encode()).hexdigest())
        for extension in ('.png','.jpg'):
            path=stem+extension
            try:
                if time.time()-os.path.getmtime(path)>self.ttl:continue
                with open(path,'rb') as source:validate_image(source.read(MAX_BYTES+1))
                os.utime(path,None)
                return path
            except (OSError,ArtworkError):pass
        return ''
