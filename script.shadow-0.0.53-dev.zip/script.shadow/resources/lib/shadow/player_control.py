"""Poll Kodi state on the GUI tick; no worker ever invokes a Kodi API."""
import time
from .playback import PlaybackRelay
from .streaming import PlaybackError


class PlaybackController:
    def __init__(self, player, item_factory, relay_factory=PlaybackRelay, clock=time.monotonic,
                 stop_player=None, windowed=False):
        self.player, self.item_factory = player, item_factory
        self.relay = relay_factory()
        self.clock = clock
        # The Kodi adapter queues its stop command without waiting for native
        # teardown. The relay is always revoked first, on this same caller.
        self.stop_player = stop_player if stop_player is not None else player.stop
        self.windowed = windowed
        self.last_stop = None
        self.url = None
        self.started = False
        self.fullscreen_seen = False
        self.deadline = 0
        self.permitted = None
        self.stopping_url = None
        self.last_failure = None

    def _playing_file(self):
        try:
            return self.player.getPlayingFile() if self.player.isPlaying() else None
        except Exception:
            return None

    def start(self, prepared):
        self.last_failure = None
        self.stop()
        self.stopping_url = None
        try:
            self.url = self.relay.start(prepared)
            self.permitted = prepared.permitted
            item = self.item_factory(self.url)
            self.deadline = self.clock() + 30
            self.started = self.fullscreen_seen = False
            if self.windowed:
                self.player.play(self.url, item, windowed=True)
            else:
                self.player.play(self.url, item)
        except Exception:
            self.stop()
            prepared.close()
            raise PlaybackError('Kodi could not start local playback') from None

    def stop(self):
        active = self.url is not None
        begun = time.monotonic()
        owned = self.url is not None and self._playing_file() == self.url
        checked = time.monotonic()
        self.relay.stop()
        revoked = time.monotonic()
        started, fullscreen_seen = self.started, self.fullscreen_seen
        stopping_url = self.url
        self.url = None
        self.permitted = None
        self.started = self.fullscreen_seen = False
        requested = False
        if owned:
            self.stopping_url = stopping_url
            try:
                self.stop_player()
                requested = True
            except Exception:
                pass
        if active:
            ended = time.monotonic()
            self.last_stop = {
                'ownership_ms': round((checked-begun)*1000),
                'relay_ms': round((revoked-checked)*1000),
                'request_ms': round((ended-revoked)*1000),
                'total_ms': round((ended-begun)*1000),
                'owned': owned, 'requested': requested,
                'started': started, 'fullscreen_seen': fullscreen_seen,
            }

    def return_ready(self):
        """Poll completion on the existing caller; never wait or stop other media.

        A queued Stop is not completion. Keep the modal window closed until Kodi
        no longer reports our old loopback URL. Query errors are not completion.
        """
        if self.stopping_url is None:
            return True
        try:
            if self.player.isPlaying() and self.player.getPlayingFile() == self.stopping_url:
                return False
        except Exception:
            return False
        self.stopping_url = None
        return True

    def tick(self, fullscreen):
        if self.url is None:
            return None
        try:
            allowed = self.permitted is not None and self.permitted()
        except Exception:
            allowed = False
        if not allowed or self.relay.status == 'authorization-ended':
            self.last_failure = ('P401', 'approval', None)
            self.stop()
            return 'failed'
        if self.relay.status == 'stream-failed':
            self.last_failure = getattr(self.relay, 'failure', None) or ('P481', 'read', None)
            self.stop()
            return 'failed'
        if self.relay.status == 'client-ended':
            # Kodi closed its local reader (e.g. its native Stop button). This
            # is not evidence of an upstream error or a changed approval.
            self.stop()
            return 'finished'
        playing = self._playing_file()
        if playing == self.url:
            self.started = True
            if hasattr(self.relay, 'touch_owned'):
                self.relay.touch_owned()
            if fullscreen:
                self.fullscreen_seen = True
            elif self.fullscreen_seen:
                self.stop()
                return 'back'
        elif self.started:
            # Revoke without stopping unrelated media selected elsewhere in Kodi.
            self.stop()
            return 'replaced' if playing else 'finished'
        elif self.clock() >= self.deadline:
            self.last_failure = ('P480', 'preparation', None)
            self.stop()
            return 'timeout'
        return None

    def close(self):
        self.stop()
        self.relay.close()
