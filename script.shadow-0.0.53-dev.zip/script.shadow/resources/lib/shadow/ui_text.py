"""Read-only font coverage for readable metadata; original text stays unchanged.

Kodi renders script XML using the skin's fonts. For Estuary, inspect the selected
font13 face instead of treating all non-Latin text as corrupt or deleting scripts.
No fonts, skin XML or global settings are changed.
"""
import bisect
import json
import os
import struct
import unicodedata
import xml.etree.ElementTree as ET


class FontCoverage:
    def __init__(self, data):
        self.tables=[]
        count=struct.unpack_from('!H',data,4)[0]
        if count>256:raise ValueError()
        for i in range(count):
            pos=12+16*i
            if data[pos:pos+4]==b'cmap':
                offset,length=struct.unpack_from('!II',data,pos+8)
                table=data[offset:offset+length]
                if len(table)!=length:raise ValueError()
                n=struct.unpack_from('!H',table,2)[0]
                if n>256:raise ValueError()
                for j in range(n):
                    platform,encoding,start=struct.unpack_from('!HHI',table,4+8*j)
                    if platform!=0 and not (platform==3 and encoding in (1,10)):continue
                    fmt=struct.unpack_from('!H',table,start)[0]
                    if fmt==12:
                        size=struct.unpack_from('!I',table,start+4)[0]
                        groups=struct.unpack_from('!I',table,start+12)[0]
                        if groups>100000:raise ValueError()
                        raw=table[start:start+size]
                        ranges=[struct.unpack_from('!III',raw,16+12*k) for k in range(groups)]
                        self.tables.append((12,ranges,[a for a,b,g in ranges]))
                    elif fmt==4:
                        size=struct.unpack_from('!H',table,start+2)[0]
                        raw=table[start:start+size];segments=struct.unpack_from('!H',raw,6)[0]//2
                        if segments>8192:raise ValueError()
                        ends=list(struct.unpack_from('!%dH'%segments,raw,14))
                        starts=list(struct.unpack_from('!%dH'%segments,raw,16+2*segments))
                        deltas=list(struct.unpack_from('!%dh'%segments,raw,16+4*segments))
                        positions=16+6*segments
                        offsets=list(struct.unpack_from('!%dH'%segments,raw,positions))
                        self.tables.append((4,(raw,ends,starts,deltas,positions,offsets),None))
                break
        if not self.tables:raise ValueError()

    def supports(self, char):
        if char in '\r\n\t':return True
        code=ord(char)
        for fmt,table,starts in self.tables:
            if fmt==12:
                i=bisect.bisect_right(starts,code)-1
                if i>=0:
                    first,last,glyph=table[i]
                    if first<=code<=last and glyph+code-first:return True
            elif code<=65535:
                raw,ends,begins,deltas,position,offsets=table
                i=bisect.bisect_left(ends,code)
                if i<len(ends) and begins[i]<=code:
                    if not offsets[i]:glyph=(code+deltas[i])&65535
                    else:
                        pos=position+2*i+offsets[i]+2*(code-begins[i])
                        glyph=struct.unpack_from('!H',raw,pos)[0]
                        if glyph:glyph=(glyph+deltas[i])&65535
                    if glyph:return True
        return False


def readable(text, coverage=None, fallback='Text unavailable in this font.'):
    value=unicodedata.normalize('NFKC',str(text or ''))
    if coverage and any(not coverage.supports(char) for char in value):
        return fallback
    return value


def load_estuary_coverage(xbmc, xbmcvfs):
    try:
        if xbmc.getSkinDir()!='skin.estuary':return None
        reply=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Settings.GetSettingValue','params':{'setting':'lookandfeel.font'}})))
        selected=reply['result']['value']
        root=ET.parse(xbmcvfs.translatePath('special://skin/xml/Font.xml')).getroot()
        fontset=next((f for f in root.findall('fontset') if f.get('id')==selected),None)
        if fontset is None:return None
        face=next((f.findtext('filename') for f in fontset.findall('font') if f.findtext('name')=='font13'),None)
        if not face or os.path.basename(face)!=face:return None
        for prefix in ('special://skin/fonts/','special://xbmc/media/Fonts/'):
            path=xbmcvfs.translatePath(prefix+face)
            if os.path.isfile(path):
                with open(path,'rb') as source:data=source.read(20*1024*1024+1)
                if len(data)>20*1024*1024:return None
                return FontCoverage(data)
    except Exception:
        return None
    return None
