"""Fail-closed file sync; native Windows fallback for incompatible CRT descriptors.

Only the already-written private temporary file may be reopened, never a provider
URL. Native APIs are loaded from System32 and never downloaded. No sync failure
is silently converted to success.
"""
import errno
import ntpath
import os
from .safe_errors import SafeError

_COMPAT_ERRORS = frozenset(getattr(errno, name) for name in
                           ('ENOSYS', 'ENOTSUP', 'EINVAL', 'EBADF') if hasattr(errno, name))


def _windows():
    return os.name == 'nt'


def _api():
    try:
        import ctypes
    except Exception:
        raise SafeError('S420') from None
    try:
        # Restrict DLL search to Windows system components, never add-on folders.
        api = ctypes.WinDLL('kernel32.dll', use_last_error=True, winmode=0x00000800)
    except Exception:
        raise SafeError('S421') from None
    stage = 'S422'
    try:
        for name, args, result, stage in (
            ('CreateFile2', [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p], ctypes.c_void_p, 'S422'),
            ('GetFileType', [ctypes.c_void_p], ctypes.c_uint32, 'S423'),
            ('FlushFileBuffers', [ctypes.c_void_p], ctypes.c_int, 'S424'),
            ('CloseHandle', [ctypes.c_void_p], ctypes.c_int, 'S425')):
            function = getattr(api, name)
            function.argtypes, function.restype = args, result
        return api, ctypes.c_void_p(-1).value
    except Exception:
        raise SafeError(stage) from None


def _native_flush(path):
    if not _windows():
        raise SafeError('S416')
    # An internal writer-created disk path only; reject URLs, UNC/devices and ADS.
    if not isinstance(path, str) or '\x00' in path:
        raise SafeError('S417')
    normal = ntpath.normpath(path)
    drive, tail = ntpath.splitdrive(normal)
    name = ntpath.basename(normal)
    if (len(drive) != 2 or not drive[0].isascii() or not drive[0].isalpha() or drive[1] != ':'
            or not tail.startswith('\\') or ':' in tail or '..' in path.replace('/', '\\').split('\\')
            or not name.startswith('.shadow-') or not name.endswith('.tmp')):
        raise SafeError('S417')
    api, invalid = _api()
    handle = None
    try:
        # GENERIC_WRITE; exclusive access; OPEN_EXISTING (never truncate/create).
        handle = api.CreateFile2(normal, 0x40000000, 0, 3, None)
        if handle is None or handle == invalid or handle == 0:
            handle = None
            raise SafeError('S417')
        if api.GetFileType(handle) != 1:  # FILE_TYPE_DISK, excludes pipes/devices
            raise SafeError('S417')
        if not api.FlushFileBuffers(handle):
            raise SafeError('S418')
    except SafeError:
        raise
    except Exception:
        raise SafeError('S418') from None
    finally:
        if handle is not None:
            try:
                closed = api.CloseHandle(handle)
            except Exception:
                closed = False
            if not closed:
                raise SafeError('S419') from None


def sync_file(file, path):
    """Caller flushes Python buffers first; success is required before replacement."""
    try:
        os.fsync(file.fileno())
        return
    except (AttributeError, NotImplementedError):
        if not _windows():
            raise
    except OSError as error:
        # Do not mask full disks, permissions, I/O failure or unknown errors.
        if not _windows() or error.errno not in _COMPAT_ERRORS:
            raise
    # Kodi's virtual descriptor may not be a Windows CRT descriptor. Reopen only
    # this same temp file with native APIs after closing the Python handle.
    file.close()
    _native_flush(path)
