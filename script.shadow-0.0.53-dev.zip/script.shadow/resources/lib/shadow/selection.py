"""First-run channel selection; no channels are approved implicitly."""
import re
from .xtream import display_text

LANGUAGES = {'EN':'English','US':'US English','UK':'UK English','ES':'Spanish','FR':'French','DE':'German','IT':'Italian','PT':'Portuguese','NL':'Dutch','PL':'Polish','AR':'Arabic','TR':'Turkish','UA':'Ukrainian'}
_PREFIX = re.compile(r'^([A-Za-z]{2})(?:\s*[:|\-]\s*|\s+)')
_REGION_PREFIX = re.compile(r'^\s*(?:[\[(]\s*)?(US|UK)(?=$|[\s:|\-_/\])\u2013\u2014])', re.IGNORECASE)

def regional_english(name):
    match = _REGION_PREFIX.match(name) if isinstance(name, str) else None
    return LANGUAGES[match.group(1).upper()] if match else None

def language_for_group(name):
    region = regional_english(name)
    if region:
        return region
    match = _PREFIX.match(name.strip()) if isinstance(name, str) else None
    return LANGUAGES.get(match.group(1).upper(), 'Other') if match else 'Other'

def language_for_channel(name, group_name):
    return regional_english(name) or language_for_group(group_name)

def organize_groups(payload, channels=None):
    result = {}
    if not isinstance(payload, list):
        return result
    groups = []
    for item in payload:
        if not isinstance(item, dict) or item.get('category_id') is None:
            continue
        category_id = str(item['category_id'])
        name = display_text(item.get('category_name'), 180) or 'Unnamed group'
        groups.append({'category_id': category_id, 'name': name})
    if channels is None:
        for group in groups:
            result.setdefault(language_for_group(group['name']), []).append(group)
        return result
    names = {group['category_id']: group['name'] for group in groups}
    languages = {}
    for channel in channels:
        category_id = channel['category_id']
        language = language_for_channel(channel['name'], names.get(category_id, 'Other'))
        languages.setdefault(category_id, set()).add(language)
    for group in groups:
        for language in sorted(languages.get(group['category_id'], {language_for_group(group['name'])})):
            result.setdefault(language, []).append(dict(group, language=language))
    return result

def channels_for_groups(channels, groups):
    """Filter mixed provider groups by language without changing provider IDs."""
    selected = {(group['category_id'], group['language']) for group in groups}
    names = {group['category_id']: group['name'] for group in groups}
    return [channel for channel in channels
            if (channel['category_id'], language_for_channel(channel['name'], names.get(channel['category_id'], 'Other'))) in selected]

def update_approvals(current_ids, add=(), remove=(), valid_ids=()):
    """Only explicit add requests can approve; unknown provider IDs are ignored."""
    valid = {str(x) for x in valid_ids}
    removed = {str(x) for x in remove}
    result = list(dict.fromkeys(str(x) for x in current_ids if str(x) not in removed))
    for item in add:
        key = str(item)
        if key in valid and key not in result:
            result.append(key)
    return result


def canonical_language(value):
    return 'English' if value in ('US English','UK English','English') else value
