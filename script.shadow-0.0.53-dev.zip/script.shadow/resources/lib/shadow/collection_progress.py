"""Worker-local, numeric catalogue progress; no provider strings or GUI calls."""
from contextlib import contextmanager
from threading import Lock, local
import time
from .safe_errors import SafeError

LIMIT_SECONDS = 300
IDLE_SECONDS = 30
_worker = local()
_PHASES = ('connecting', 'download', 'processing', 'ready')


class CollectionStatus:
    def __init__(self):
        self.started = time.monotonic()
        self.lock = Lock()
        self.phase = 'connecting'
        self.received = self.records = self.processed = self.total = 0
        self.expected_bytes = None

    def check(self):
        if time.monotonic() - self.started >= LIMIT_SECONDS:
            raise SafeError('X413')

    def update(self, phase=None, **counts):
        with self.lock:
            if phase in _PHASES:
                self.phase = phase
            for key in ('received', 'records', 'processed', 'total', 'expected_bytes'):
                value = counts.get(key)
                if type(value) is int and 0 <= value <= 2**63 - 1:
                    setattr(self, key, value)

    def view(self):
        with self.lock:
            percent = None
            if self.phase == 'connecting':
                text = 'Waiting for provider response'
            elif self.phase == 'download':
                if self.expected_bytes:
                    percent = min(100, self.received * 100 / self.expected_bytes)
                    text = 'Downloading: %.1f / %.1f MiB (%s%%); %s records read' % (self.received / 1048576, self.expected_bytes / 1048576, int(percent), self.records)
                else:
                    text = 'Downloading: %.1f MiB; %s records read (total size unknown)' % (self.received / 1048576, self.records)
            elif self.phase == 'processing':
                percent = min(100, self.processed * 100 / self.total) if self.total else 0
                text = 'Preparing titles: %s / %s records (%s%%)' % (self.processed, self.total, int(percent))
            else:
                text = 'Collection ready'
                percent = 100
        return '%s - %ss' % (text, max(0, int(time.monotonic() - self.started))), percent

    def message(self):
        return self.view()[0]

    @contextmanager
    def active(self):
        previous = getattr(_worker, 'status', None)
        _worker.status = self
        try:
            yield
        finally:
            _worker.status = previous


def report(phase=None, **counts):
    status = getattr(_worker, 'status', None)
    if status is not None:
        status.update(phase, **counts)


def check_deadline():
    status = getattr(_worker, 'status', None)
    if status is not None:
        status.check()


def overall_deadline():
    """Share the GUI's absolute limit, including time already spent preparing."""
    status = getattr(_worker, 'status', None)
    return (status.started if status is not None else time.monotonic()) + LIMIT_SECONDS
