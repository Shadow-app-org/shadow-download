"""Bounded direct HTTP(S) transport with an absolute deadline and pinned DNS.

No redirects or environment proxies. HTTP parsing stays in Python's http.client.
One daemon DNS worker bounds caller wait and prevents unlimited resolver threads;
a stuck OS resolver cannot be killed and temporarily makes resolution unavailable.
"""
import http.client
import errno
import io
import ipaddress
import math
import socket
import ssl
import time
from concurrent.futures import Future, TimeoutError
from queue import Queue, Full
from threading import Thread
from urllib.parse import urlsplit
from .safe_errors import NETWORK_CODES, safe_message, clean_http_status, SafeError
from .json_array import JSONArray, ArrayError, channel_fields
from .cancellation import checkpoint, current, watch_socket, Cancelled
from .collection_progress import report, overall_deadline, IDLE_SECONDS


class TransportError(Exception):
    def __init__(self, message=None, code='N499', http_status=None):
        # Legacy callers may supply a message; never carry raw exceptions/URLs.
        self.code = code if isinstance(code, str) and code in NETWORK_CODES else 'N499'
        self.http_status = clean_http_status(self.code, http_status)
        super().__init__(self.code + ': ' + safe_message(self.code, self.http_status))


class Deadline:
    def __init__(self, timeout):
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 60:
            raise TransportError(code='N400')
        self.end = time.monotonic() + timeout

    def remaining(self):
        checkpoint()
        remaining = self.end - time.monotonic()
        if remaining <= 0:
            raise TransportError(code='N409')
        return remaining


class CatalogueDeadline(Deadline):
    """Existing opening budget; then byte inactivity plus a fixed overall cap.

    Only Movies/Series opt in. Raw receive progress renews the idle allowance,
    even when http.client is filling a larger application read. It never renews
    the overall allowance, and no policy for login/live/artwork is changed.
    """
    def __init__(self, timeout):
        super().__init__(timeout)
        self.total_end = overall_deadline()
        self.body = False
        self.idle_end = 0

    def remaining(self):
        checkpoint()
        now = time.monotonic()
        if now >= self.total_end:
            raise SafeError('X413')
        if not self.body:
            return min(super().remaining(), self.total_end-now)
        if now >= self.idle_end:
            raise SafeError('X416')
        return min(self.idle_end, self.total_end)-now

    def start_body(self):
        self.remaining()
        self.body = True
        self.idle_end = time.monotonic()+IDLE_SECONDS

    def progress(self, count):
        if self.body and count > 0:
            self.remaining()
            self.idle_end = time.monotonic()+IDLE_SECONDS


def dns_error_code(error):
    """Classify lookup failures without retaining or displaying exception text."""
    numbers = {n for n in (getattr(error, 'errno', None), getattr(error, 'winerror', None))
               if type(n) is int}
    if isinstance(error, PermissionError) or numbers.intersection((errno.EACCES, errno.EPERM, 10013)):
        return 'N416'
    if isinstance(error, (AttributeError, NotImplementedError, ImportError)):
        return 'N417'
    if isinstance(error, (TypeError, ValueError, UnicodeError)):
        return 'N418'
    if isinstance(error, (socket.timeout, TimeoutError)):
        return 'N411'
    if isinstance(error, socket.gaierror):
        missing = {getattr(socket, name, None) for name in ('EAI_NONAME', 'EAI_NODATA')}
        temporary = {getattr(socket, 'EAI_AGAIN', None)}
        if numbers.intersection(missing | {11001, 11004}):
            return 'N414'
        if numbers.intersection(temporary | {11002}):
            return 'N415'
        return 'N410'
    return 'N419'


class BoundedResolver:
    def __init__(self):
        self.jobs = Queue(maxsize=1)
        self.thread = Thread(target=self._run, name='ShadowDNS', daemon=True)
        self.thread.start()

    def resolve(self, host, port, budget, resolver=socket.getaddrinfo):
        future = Future()
        try:
            self.jobs.put_nowait((future, resolver, host, port))
        except Full:
            raise TransportError(code='N412') from None
        try:
            while True:
                remaining = budget.remaining()
                try:
                    return future.result(timeout=min(.05, remaining))
                except TimeoutError:
                    budget.remaining()
        except TimeoutError:
            future.cancel()
            raise TransportError(code='N411') from None
        except (SafeError, Cancelled):
            future.cancel()
            raise
        except TransportError as error:
            future.cancel()
            raise TransportError(code='N411' if error.code == 'N409' else error.code) from None
        except Exception as error:
            future.cancel()
            raise TransportError(code=dns_error_code(error)) from None

    def _run(self):
        while True:
            future, resolver, host, port = self.jobs.get()
            if not future.set_running_or_notify_cancel():
                continue
            try:
                result = resolver(host, port, type=socket.SOCK_STREAM)
            except Exception as error:
                future.set_exception(TransportError(code=dns_error_code(error)))
            else:
                future.set_result(result)


_DNS = BoundedResolver()


def checked_addresses(answers, public_only=False):
    try:
        addresses = list(dict.fromkeys(answer[4][0] for answer in answers))
        if not addresses or len(addresses) > 16:
            raise ValueError()
        for value in addresses:
            ip = ipaddress.ip_address(value)
            if '%' in value:
                raise ValueError()
            if public_only and (
                not ip.is_global or ip.is_multicast or ip.is_unspecified
                or getattr(ip, 'ipv4_mapped', None) is not None
                or (ip.version == 6 and (ip not in ipaddress.ip_network('2000::/3') or ip.sixtofour is not None or ip.teredo is not None))
            ):
                raise ValueError()
        return addresses
    except Exception:
        raise TransportError(code='N413') from None


class _DeadlineReader(io.RawIOBase):
    def __init__(self, sock, budget):
        super().__init__()
        self.owner, self.budget = sock, budget

    def readable(self):
        return True

    def readinto(self, buffer):
        self.owner.raw.settimeout(self.budget.remaining())
        count = self.owner.raw.recv_into(buffer)
        if isinstance(self.budget, CatalogueDeadline):
            self.budget.progress(count)
        return count

    def close(self):
        if not self.closed:
            self.owner.release_file()
        super().close()


class _DeadlineSocket:
    def __init__(self, sock, budget, on_close=lambda: None):
        self.raw, self.budget = sock, budget
        self.on_close = on_close
        self.files = 0
        self.closing = False

    def sendall(self, data):
        self.raw.settimeout(self.budget.remaining())
        return self.raw.sendall(data)

    def makefile(self, mode, *args, **kwargs):
        if mode != 'rb':
            raise TransportError('Unsupported socket mode')
        self.files += 1
        return io.BufferedReader(_DeadlineReader(self, self.budget), buffer_size=8192)

    def release_file(self):
        self.files -= 1
        if self.closing and not self.files:
            self._close_raw()

    def _close_raw(self):
        try:
            self.raw.close()
        finally:
            self.on_close()

    def close(self):
        self.closing = True
        if not self.files:
            self._close_raw()

    def __getattr__(self, name):
        return getattr(self.raw, name)


class _HeaderBudget:
    def __init__(self, stream):
        self.stream = stream
        self.count = 0
        self.headers = True

    def readline(self, limit=-1):
        if self.headers:
            limit = min(limit if limit >= 0 else 65537, 65537 - self.count)
            if limit <= 0:
                raise TransportError(code='N433')
        line = self.stream.readline(limit)
        if self.headers:
            self.count += len(line)
            if self.count > 65536:
                raise TransportError(code='N433')
        return line

    def __getattr__(self, name):
        return getattr(self.stream, name)


class _Response(http.client.HTTPResponse):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fp = _HeaderBudget(self.fp)

    def begin(self):
        super().begin()
        if self.fp is not None:
            self.fp.headers = False


class _Connection(http.client.HTTPConnection):
    response_class = _Response

    def __init__(self, host, port, address, secure, budget, context=None):
        super().__init__(host, port, timeout=budget.remaining())
        self.address, self.secure, self.budget, self.context = address, secure, budget, context
        self._cancel_token = current()
        self._unwatch = lambda: None

    def connect(self):
        raw = None
        stage = 'N420'
        try:
            raw = socket.socket(socket.AF_INET6 if ':' in self.address else socket.AF_INET, socket.SOCK_STREAM)
            self._unwatch = watch_socket(self._cancel_token, raw)
            raw.settimeout(self.budget.remaining())
            raw.connect((self.address, self.port))
            if self.secure:
                stage = 'N423'
                context = self.context if self.context is not None else ssl.create_default_context()
                if not context.check_hostname or context.verify_mode != ssl.CERT_REQUIRED:
                    raise TransportError(code='N424')
                if context.minimum_version < ssl.TLSVersion.TLSv1_2:
                    context.minimum_version = ssl.TLSVersion.TLSv1_2
                raw.settimeout(self.budget.remaining())
                raw = context.wrap_socket(raw, server_hostname=self.host)
                self._unwatch()
                self._unwatch = watch_socket(self._cancel_token, raw)
                self.budget.remaining()
            self.sock = _DeadlineSocket(raw, self.budget, self._unwatch)
        except BaseException as error:
            self._unwatch()
            if raw is not None:
                try:
                    raw.close()
                except Exception:
                    pass
            if not isinstance(error, Exception):
                raise
            if type(error) in (SafeError, Cancelled):
                raise
            if type(error) is TransportError and error.code != 'N409':
                raise
            if isinstance(error, ssl.SSLCertVerificationError):
                code = 'N422'
            elif isinstance(error, (socket.timeout, TimeoutError)) or (type(error) is TransportError and error.code == 'N409'):
                code = 'N426' if stage == 'N423' else 'N421'
            elif isinstance(error, (AttributeError, NotImplementedError, ImportError)):
                code = 'N428'
            elif isinstance(error, OSError) and (error.errno in (errno.EACCES, errno.EPERM) or getattr(error, 'winerror', None) == 10013):
                code = 'N427'
            else:
                code = stage
            raise TransportError(code=code) from None


def request_bytes(url, timeout=12, max_bytes=8*1024*1024, accept='application/json',
                  allow_http=False, public_only=False, dns=None, resolver=socket.getaddrinfo,
                  tls_context=None):
    return _request(url, timeout, max_bytes, accept, allow_http, public_only,
                    dns, resolver, tls_context)


def request_live_channels(url, timeout=12, allow_http=False):
    """No total byte/channel cap; parse each row and discard unused fields."""
    parser = JSONArray(channel_fields)
    _request(url, timeout=timeout, max_bytes=None, allow_http=allow_http,
             consumer=parser.feed)
    return parser.finish()


def request_media_catalogue(url, timeout=60, allow_http=False):
    from .json_array import SKIP
    fields = ('stream_id', 'series_id', 'name', 'plot', 'container_extension', 'language', 'genre', 'releaseDate', 'release_date', 'year')
    image_fields = ('cover', 'stream_icon', 'movie_image', 'poster', 'cover_big', 'backdrop_path', 'imdb_id', 'imdb')
    def artwork_fields(row):
        return {key: (value[:2048] if isinstance(value, str) else
                      [v[:2048] for v in value[:8] if isinstance(v, str)])
                for key in image_fields if key in row
                for value in [row[key]] if isinstance(value, (str, list))}
    def project(row):
        if not isinstance(row, dict):
            return SKIP
        result = {key: row[key] for key in fields if key in row}
        result.update(artwork_fields(row))
        if isinstance(row.get('info'), dict):
            result['info'] = artwork_fields(row['info'])
        return result
    parser = JSONArray(project)
    def consume(block):
        parser.feed(block)
        report(records=len(parser.rows))
    _request(url, timeout=timeout, max_bytes=None, allow_http=allow_http,
             consumer=consume, catalogue=True)
    return parser.finish()


def _request(url, timeout=12, max_bytes=8*1024*1024, accept='application/json',
             allow_http=False, public_only=False, dns=None, resolver=socket.getaddrinfo,
             tls_context=None, consumer=None, catalogue=False):
    """One GET; no redirects, retry, decompression or unbounded header/body reads."""
    conn = response = None
    budget = None
    consuming = False
    stage = 'N400'
    try:
        budget = CatalogueDeadline(timeout) if catalogue else Deadline(timeout)
        if not isinstance(url, str) or len(url) > 16384 or any(ord(c) < 33 or ord(c) == 127 for c in url) or '\\' in url:
            raise ValueError()
        parts = urlsplit(url)
        if parts.scheme not in ('http', 'https') or not parts.hostname or parts.username is not None or parts.password is not None or parts.fragment:
            raise ValueError()
        if parts.scheme == 'http' and allow_http is not True:
            raise ValueError()
        if not (max_bytes is None and callable(consumer)) and (type(max_bytes) is not int or not 0 < max_bytes <= 8*1024*1024):
            raise ValueError()
        host = parts.hostname.rstrip('.').encode('idna').decode('ascii')
        port = parts.port or (443 if parts.scheme == 'https' else 80)
        stage = 'N410'
        answers = (dns or _DNS).resolve(host, port, budget, resolver)
        addresses = checked_addresses(answers, public_only)
        stage = 'N420'
        conn = _Connection(host, port, addresses[0], parts.scheme == 'https', budget, tls_context)
        target = parts.path or '/'
        if parts.query:
            target += '?' + parts.query
        stage = 'N430'
        conn.request('GET', target, headers={'Accept': accept, 'Accept-Encoding': 'identity', 'User-Agent': 'Shadow/0.0.7', 'Connection': 'close'})
        stage = 'N431'
        response = conn.getresponse()
        budget.remaining()
        if response.status != 200:
            status = response.status
            code = ('N440' if status in (301, 302, 303, 307, 308) else 'N441' if status in (401, 403) else
                    'N442' if status == 429 else ('N' + str(status) if status in (500,501,502,503,504,505,506,507,508,510,511) else 'N443') if 500 <= status < 600 else
                    'N445' if status == 404 else 'N444')
            raise TransportError(code=code, http_status=status)
        encoding = response.getheader('Content-Encoding', 'identity').strip().lower()
        if encoding != 'identity':
            raise TransportError(code='N450')
        length_headers = response.headers.get_all('Content-Length', [])
        transfer_headers = response.headers.get_all('Transfer-Encoding', [])
        transfer = response.getheader('Transfer-Encoding', '').strip().lower()
        if len(length_headers) > 1 or len(transfer_headers) > 1 or (transfer_headers and (transfer != 'chunked' or length_headers)):
            raise TransportError(code='N451')
        length = length_headers[0].strip() if length_headers else None
        declared_length = None
        if length is not None:
            if not length.isascii() or not length.isdigit():
                raise TransportError(code='N451')
            # Compare canonical decimal strings; never parse huge header integers.
            significant = length.lstrip('0') or '0'
            if max_bytes is not None and (len(significant) > len(str(max_bytes)) or int(significant) > max_bytes):
                raise TransportError(code='N452')
            declared_length = significant
        report('download')
        if declared_length is not None and len(declared_length) <= 18:
            report(expected_bytes=int(declared_length))
        if accept == 'image/png' and response.getheader('Content-Type', '').split(';')[0].strip().lower() != 'image/png':
            raise TransportError(code='N456')
        result = bytearray()
        received = 0
        if catalogue:
            budget.start_body()
        stage = 'N455'
        while max_bytes is None or received <= max_bytes:
            budget.remaining()
            block = response.read(65536 if max_bytes is None else min(65536, max_bytes + 1 - received))
            if not block:
                break
            if catalogue:
                budget.progress(len(block))
            received += len(block)
            report('download', received=received)
            if consumer is None:
                result.extend(block)
            else:
                consuming = True
                consumer(block)
                consuming = False
        budget.remaining()
        if max_bytes is not None and received > max_bytes:
            raise TransportError(code='N452')
        if declared_length is not None and str(received) != declared_length:
            if catalogue:
                raise SafeError('X418')
            raise TransportError(code='N453')
        return bytes(result)
    except Exception as error:
        if type(error) in (ArrayError, SafeError, Cancelled):
            raise
        if type(error) is TransportError and error.code != 'N409':
            raise
        if catalogue and stage == 'N455':
            # A runtime can wrap a timed-out read in OSError. Check our clocks
            # first, rather than losing the expired deadline as generic N455.
            budget.remaining()
            if isinstance(error, (socket.timeout, TimeoutError)) or (
                    isinstance(error, OSError) and
                    (error.errno in (errno.ETIMEDOUT, 10060) or getattr(error, 'winerror', None) == 10060)):
                raise SafeError('X416') from None
            if isinstance(error, http.client.IncompleteRead):
                raise SafeError('X418') from None
            if isinstance(error, (AttributeError, NotImplementedError, ImportError)):
                raise TransportError(code='N428') from None
            if not consuming and isinstance(error, (OSError, http.client.HTTPException)):
                raise SafeError('X417') from None
            raise SafeError('X414') from None
        if isinstance(error, (socket.timeout, TimeoutError)) or (type(error) is TransportError and error.code == 'N409'):
            code = {'N410': 'N411', 'N420': 'N421', 'N431': 'N432', 'N455': 'N454'}.get(stage, 'N409')
        elif isinstance(error, http.client.IncompleteRead):
            code = 'N453'
        elif isinstance(error, http.client.LineTooLong):
            code = 'N433'
        elif isinstance(error, (AttributeError, NotImplementedError, ImportError)):
            code = 'N428'
        else:
            code = stage
        raise TransportError(code=code) from None
    finally:
        cleanup_failed = False
        if response is not None:
            try:
                response.close()
            except Exception:
                cleanup_failed = True
        if conn is not None:
            try:
                conn.close()
            except Exception:
                cleanup_failed = True
        if cleanup_failed:
            raise TransportError(code='N457') from None
