"""Artwork candidate selection; validated fetching is owned by artwork_fetch."""
from dataclasses import dataclass
import ipaddress
import re
from urllib.parse import urlsplit

@dataclass(frozen=True)
class Artwork:
    kind: str
    value: str = ''

def safe_remote_image(value):
    if not isinstance(value, str) or len(value) > 2048:
        return ''
    if value != value.strip() or '\\' in value:
        return ''
    try:
        parts = urlsplit(value)
        if parts.scheme.lower() != 'https' or not parts.hostname or parts.username or parts.password or parts.fragment:
            return ''
        if parts.port not in (None, 443) or any(ord(c) < 33 or ord(c) == 127 for c in value):
            return ''
        host = parts.hostname.rstrip('.').lower()
        if host == 'localhost' or host.endswith(('.localhost', '.local', '.internal')) or '.' not in host:
            return ''
        if len(host) > 253 or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label) for label in host.split('.')):
            return ''
        try:
            ipaddress.ip_address(host.strip('[]'))
            return ''  # No literal IPs, including public IPs, in untrusted artwork URLs.
        except ValueError:
            pass
        return value
    except (ValueError, TypeError):
        return ''

def resolve_artwork(programme, channel):
    for key in ('image', 'icon', 'artwork'):
        image = safe_remote_image((programme or {}).get(key))
        if image:
            return Artwork('programme', image)
    logo = safe_remote_image((channel or {}).get('stream_icon'))
    if logo:
        return Artwork('channel', logo)
    return Artwork('placeholder')

def visible_channels(channels, approved_ids):
    allowed = {str(x) for x in approved_ids}
    return [c for c in channels if str(c.get('stream_id', '')) in allowed]


def image_candidates(item):
    """Bounded provider alternatives, preferring posters over backgrounds."""
    result = []
    for source in (item, item.get('info', {}), item.get('movie_data', {})):
        if not isinstance(source, dict):
            continue
        for key in ('artwork', 'artwork_candidates', 'cover', 'stream_icon', 'movie_image', 'poster', 'cover_big', 'backdrop_path'):
            values = source.get(key, '')
            values = values[:8] if isinstance(values, (list, tuple)) else [values]
            for value in values:
                value = safe_remote_image(value)
                if value and value not in result:
                    result.append(value)
    return result[:8]
