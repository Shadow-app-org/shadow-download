"""Explicit, account-bound settings transfers. No login or history is exported."""
import json
import os
import uuid
from .local_files import read_regular_bytes,write_new_bytes
from .preferences import DEFAULTS, _validate, MAX_SETTINGS_BYTES, PreferencesError

FIELDS = set(DEFAULTS) - {'revision', 'provider_scope', 'schema_version'}
DEFAULTED = {'auto_reconnect_live','autoplay_next','hide_watched','watched_movies','watched_series','watch_later_movies','watch_later_series'}


def export_settings(directory, prefs):
    data = {'version': 1, 'scope': prefs['provider_scope'],
            'settings': {key: prefs[key] for key in FIELDS}}
    path = os.path.join(directory, 'shadow-settings-' + uuid.uuid4().hex[:12] + '.json')
    write_new_bytes(path,json.dumps(data,ensure_ascii=True).encode('utf-8'))
    return path


def import_settings(path, scope):
    body = read_regular_bytes(path,MAX_SETTINGS_BYTES)
    if len(body) > MAX_SETTINGS_BYTES:
        raise PreferencesError('Backup exceeds size limit')
    try:
        data = json.loads(body)
        if set(data) != {'version', 'scope', 'settings'} or data['version'] != 1 or data['scope'] != scope:
            raise ValueError()
        settings = data['settings']
        if not isinstance(settings, dict) or not (FIELDS-DEFAULTED <= set(settings) <= FIELDS):
            raise ValueError()
        valid = _validate(settings)
        return {key: valid[key] for key in FIELDS}
    except (ValueError, TypeError, KeyError, RecursionError):
        raise PreferencesError('Backup is invalid or belongs to another account') from None
