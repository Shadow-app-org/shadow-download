"""Portable personal lists/progress only; no login, URLs, grants or approvals."""
import hashlib,json,os,re,uuid
from .accounts import canonical_endpoint
from .preferences import _validate,PreferencesError
from .history import clean_record,MAX_ROWS,MAX_BYTES as HISTORY_BYTES
from .local_files import read_regular_bytes, write_new_bytes
FIELDS={'watch_later_movies','watch_later_series','favourites','watched_movies','watched_series','hide_watched','autoplay_next'}
MAX_BYTES=8*1024*1024

def binding(session):
    client=session.connection.client
    endpoint=getattr(client,'endpoint',None);credentials=getattr(client,'_credentials',None)
    username=getattr(credentials,'username',None)
    if isinstance(endpoint,str) and isinstance(username,str) and username:
        value='xtream\0'+canonical_endpoint(endpoint)+'\0'+username
        return hashlib.sha256(value.encode()).hexdigest()
    return session.prefs['provider_scope']

def _validate_payload(data,account):
    try:
        if not isinstance(data,dict) or set(data)!={'version','binding','settings','history','recent_channels'} or data['version']!=1 or data['binding']!=account:raise ValueError()
        settings=data['settings']
        if not isinstance(settings,dict) or set(settings)!=FIELDS:raise ValueError()
        checked=_validate(settings)
        for key in FIELDS-{'hide_watched','autoplay_next'}:
            if any(not re.fullmatch(r'[0-9]{1,64}',value) for value in checked[key]):raise ValueError()
        history=data['history'];live=data['recent_channels']
        if not isinstance(history,list) or len(history)>MAX_ROWS or not isinstance(live,list) or len(live)>20 or any(not isinstance(v,str) or not re.fullmatch(r'[0-9]{1,64}',v) for v in live):raise ValueError()
        records=[clean_record(row) for row in history]
        if len(json.dumps({'version':1,'scope':account,'rows':records,'recent_channels':live},ensure_ascii=True,separators=(',',':')).encode())>HISTORY_BYTES:raise ValueError()
        return {'binding':account,'settings':{key:checked[key] for key in FIELDS},'history':records,'recent_channels':list(dict.fromkeys(live))}
    except (ValueError,TypeError,KeyError):raise PreferencesError('Backup is invalid or belongs to another provider account') from None

def export_personal(directory,session):
    if session.temporary:raise PreferencesError('Use a saved provider account for backups')
    data={'version':1,'binding':binding(session),'settings':{key:session.prefs[key] for key in FIELDS},'history':list(session.history.rows.values()) if session.history else [],'recent_channels':list(session.history.live) if session.history else []}
    _validate_payload(data,binding(session))
    body=json.dumps(data,ensure_ascii=True).encode()
    if len(body)>MAX_BYTES:raise PreferencesError('Personal backup exceeds size limit')
    path=os.path.join(directory,'shadow-personal-'+uuid.uuid4().hex[:12]+'.json')
    try:write_new_bytes(path,body)
    except Exception:raise PreferencesError('Personal backup could not be saved') from None
    return path

def read_personal(path,session):
    if session.temporary:raise PreferencesError('Use a saved provider account for restore')
    try:
        body=read_regular_bytes(path,MAX_BYTES)
        if len(body)>MAX_BYTES:raise ValueError()
        data=json.loads(body)
    except (ValueError,UnicodeError,RecursionError):raise PreferencesError('Personal backup could not be read') from None
    return _validate_payload(data,binding(session))

def restore_personal(session,data):
    # Caller validates the whole file and asks before changing either collection.
    data=_validate_payload(dict(data,version=1),binding(session))
    changes=dict(data['settings']);approved=set(session.prefs['approved_channel_ids'])
    changes['favourites']=[value for value in changes['favourites'] if value in approved]
    session.save(changes)
    if session.history:session.history.replace_snapshot(data['history'],[value for value in data['recent_channels'] if value in approved])
