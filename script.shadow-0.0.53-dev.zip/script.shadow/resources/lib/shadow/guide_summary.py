"""Pure, bounded Now/Next selection for cached selected-channel EPG."""
import math


def now_next(entries, now):
    if type(now) not in (int,float) or not math.isfinite(now):
        return None,None,0
    valid=[]
    for programme in entries if isinstance(entries,(list,tuple)) else ():
        if not isinstance(programme,dict) or not isinstance(programme.get('title'),str):
            continue
        start,end=programme.get('start'),programme.get('end')
        if (type(start) not in (int,float) or type(end) not in (int,float)
                or not math.isfinite(start) or not math.isfinite(end)
                or not 0<=start<end<=253402300799 or end-start>3*86400):
            continue
        valid.append(programme)
    valid.sort(key=lambda programme:programme['start'])
    current=next((p for p in valid if p['start']<=now<p['end']),None)
    following=next((p for p in valid if p['start']>now and (not current or p['start']>=current['end'])),None)
    percent=max(0,min(100,int(100*(now-current['start'])/(current['end']-current['start'])))) if current else 0
    return current,following,percent
