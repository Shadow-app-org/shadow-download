"""Temporary noninteractive controls on Estuary playback clock overlay.

No skin files or global regional preferences are edited. Controls are removed
when Shadow releases playback. Native input handling is left to Kodi.
"""
import os
from datetime import datetime, timedelta


class PlaybackClock:
    def __init__(self, gui, addon_path):
        self.window = gui.Window(11109)
        width, height = self.window.getWidth(), self.window.getHeight()
        x, y, w, h = int(width*.65), 0, int(width*.35), int(height*.19)
        self.controls = [
            gui.ControlImage(x, y, w, h, os.path.join(addon_path, 'resources', 'skins', 'Default', 'media', 'shadow-black.png')),
            gui.ControlLabel(x+12, int(height*.015), w-40, int(height*.06), '', font='font30_title', textColor='FFFFFFFF', alignment=1),
            gui.ControlLabel(x+12, int(height*.075), w-40, int(height*.045), '', font='font13', textColor='FFE0E0E0', alignment=1),
            gui.ControlLabel(x+12, int(height*.12), w-40, int(height*.045), '', font='font13', textColor='FFE0E0E0', alignment=1)]
        for control in self.controls:
            control.setVisibleCondition('Window.IsActive(fullscreenvideo)')
        self.window.addControls(self.controls)

    def update(self, player, now=None):
        now = now or datetime.now()
        self.controls[1].setLabel(now.strftime('%H:%M'))
        self.controls[2].setLabel(now.strftime('%a %d %b').replace(' 0', ' '))
        ends = ''
        try:
            remaining = player.getTotalTime() - player.getTime()
            if 0 < remaining < 7*86400:
                ends = 'Ends at: ' + (now + timedelta(seconds=remaining)).strftime('%H:%M')
        except Exception:
            pass
        self.controls[3].setLabel(ends)

    def close(self):
        try:
            self.window.removeControls(self.controls)
        except Exception:
            pass
        self.controls = []
