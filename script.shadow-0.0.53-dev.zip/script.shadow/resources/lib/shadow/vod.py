"""Private byte-range media input. Provider URLs never leave this module boundary."""
import re
import socket
import time
from urllib.parse import urlsplit
from .transport import Deadline, _DNS, _Connection, checked_addresses, TransportError
from .streaming import PlaybackError, TSInput
from .redirects import stream_redirect, RedirectError
from .cancellation import checkpoint

MIMES = {'mp4': 'video/mp4', 'm4v': 'video/mp4', 'mov': 'video/quicktime',
         'mkv': 'video/x-matroska', 'webm': 'video/webm', 'avi': 'video/x-msvideo',
         'ts': 'video/mp2t', 'mpg': 'video/mpeg', 'mpeg': 'video/mpeg'}
_RANGE = re.compile(r'bytes ([0-9]{1,20})-([0-9]{1,20})/([0-9]{1,20})\Z')
_REQUEST = re.compile(r'bytes=([0-9]{0,20})-([0-9]{0,20})\Z')
MAX_OFFSET = 2**63 - 1


def byte_range(value, total):
    """One HTTP byte range; suffix/open-ended supported, multipart rejected."""
    if value is None:
        return 0, total - 1
    match = _REQUEST.fullmatch(value)
    if not match or not any(match.groups()):
        raise ValueError('Invalid range')
    left, right = match.groups()
    if not left:
        suffix = int(right)
        if not 0 < suffix <= MAX_OFFSET:
            raise ValueError('Invalid range')
        return max(0, total - suffix), total - 1
    start = int(left)
    end = min(int(right), total - 1) if right else total - 1
    if not 0 <= start <= end < total or start > MAX_OFFSET:
        raise ValueError('Invalid range')
    return start, end


class RangeInput:
    """A finite, pinned GET. Shared 12s redirect handshake; 10s/read budget."""
    _release = TSInput._release
    cancel = TSInput.cancel
    close = TSInput.close

    def __init__(self, url, start, end, *, timeout=12, idle_timeout=10,
                 resolver=socket.getaddrinfo, tls_context=None, allow_http=False,
                 allow_redirects=False, allow_http_redirects=False,
                 identity=None, public_only=False, _budget=None, _no_range=False):
        self.conn = self.response = self.socket = None
        self.closed = False
        self.pending = b''
        self.idle_timeout = idle_timeout
        self.remaining = 0
        failure = 'N400'
        original_url = url
        details = {}
        try:
            if not 0 <= start <= end <= MAX_OFFSET:
                raise ValueError()
            Deadline(idle_timeout)
            self.budget = _budget or Deadline(timeout)
            seen = set()
            for hop in range(4):
                checkpoint()
                if url in seen:
                    raise PlaybackError(code='P462', stage='stream')
                seen.add(url)
                if not isinstance(url, str) or len(url) > 16384 or any(ord(c) < 33 or ord(c) == 127 for c in url) or '\\' in url:
                    raise ValueError()
                parts = urlsplit(url)
                http_ok = allow_http is True or (hop > 0 and allow_redirects is True and allow_http_redirects is True)
                if (parts.scheme != 'https' and not (parts.scheme == 'http' and http_ok)) or not parts.hostname or parts.username is not None or parts.password is not None or parts.fragment or (hop == 0 and parts.query):
                    raise ValueError()
                host = parts.hostname.rstrip('.').encode('idna').decode('ascii')
                port = parts.port or (443 if parts.scheme == 'https' else 80)
                failure = 'N410'
                addresses = checked_addresses(_DNS.resolve(host, port, self.budget, resolver), public_only=public_only or hop > 0)
                failure = 'N430'
                self.conn = _Connection(host, port, addresses[0], parts.scheme == 'https', self.budget, tls_context)
                headers = {'Accept': 'video/*, application/octet-stream',
                           'Accept-Encoding': 'identity', 'User-Agent': 'Shadow/0.0.43',
                           'Connection': 'close', 'Range': 'bytes=%d-%d' % (start, end)}
                if _no_range:
                    headers.pop('Range', None)
                # No Authorization, Cookie, or previous-hop headers are forwarded.
                target = (parts.path or '/') + ('?' + parts.query if parts.query else '')
                self.conn.request('GET', target, headers=headers)
                self.socket = self.conn.sock.raw
                failure = 'N431'
                response = self.response = self.conn.getresponse()
                self.budget.remaining()
                if response.status in (301, 302, 303, 307, 308):
                    if allow_redirects is not True:
                        raise PlaybackError(code='N440', stage='stream')
                    if hop == 3:
                        raise PlaybackError(code='P462', stage='stream')
                    target = stream_redirect(url, response.headers.get_all('Location', []), allow_http,
                                             allow_http_redirects=allow_http_redirects)
                    self._release()
                    url = target
                    continue
                break
            if response.status == 400 and start == 0 and identity is None and not _no_range:
                self._release()
                self.__init__(original_url, start, end, timeout=timeout, idle_timeout=idle_timeout,
                    resolver=resolver, tls_context=tls_context, allow_http=allow_http,
                    allow_redirects=allow_redirects, allow_http_redirects=allow_http_redirects,
                    public_only=public_only, _budget=self.budget, _no_range=True)
                self.no_range = True
                return
            self.no_range = _no_range
            details = {'http_status': response.status, 'request_mode': 'full-file' if _no_range else 'byte-range'}
            if not _no_range:
                details.update(requested_start=start, requested_end=end)
            self.seekable = response.status == 206
            if _no_range and response.status == 206:
                raise PlaybackError(code='P454', stage='stream')
            if response.status not in (200, 206):
                details['reason'] = 'http-status'
                code = 'N441' if response.status in (401, 403) else 'N445' if response.status == 404 else 'P454'
                raise PlaybackError(code=code, stage='stream')
            ranges = response.headers.get_all('Content-Range', [])
            lengths = response.headers.get_all('Content-Length', [])
            encodings = response.headers.get_all('Content-Encoding', [])
            types = response.headers.get_all('Content-Type', [])
            if ((self.seekable and len(ranges) != 1) or (not self.seekable and ranges) or len(lengths) != 1 or response.headers.get_all('Transfer-Encoding', []) or
                    len(encodings) > 1 or (encodings and encodings[0].strip().lower() != 'identity') or len(types) > 1):
                raise PlaybackError(code='N451', stage='stream')
            match = _RANGE.fullmatch(ranges[0].strip()) if self.seekable else None
            length = lengths[0].strip()
            if (self.seekable and not match) or not length.isascii() or not length.isdigit() or len(length) > 20:
                raise PlaybackError(code='N451', stage='stream')
            if self.seekable:
                first, last, total = map(int, match.groups())
            else:
                # An honest full response supports start-from-beginning only.
                # Never relabel bytes at offset zero as a later range.
                if start != 0:
                    details['reason'] = 'range-ignored'
                    raise PlaybackError(code='P454', stage='stream')
                total = int(length)
                first, last = 0, total - 1
            details.update(first=first, last=last, total=total, length=int(length))
            reason = ('range-bounds' if not 0 <= first <= last < total <= MAX_OFFSET else
                      'offset-mismatch' if first != start else
                      'range-overrun' if self.seekable and last > min(end, total-1) else
                      'length-mismatch' if int(length) != last-first+1 else '')
            if reason:
                details['reason'] = reason
                raise PlaybackError(code='P454', stage='stream')
            self.mime = types[0].split(';', 1)[0].strip().lower() if types else 'application/octet-stream'
            if self.mime not in tuple(MIMES.values()) + ('application/octet-stream', 'application/mp4', 'video/avi', 'video/x-m4v'):
                raise PlaybackError(code='P450', stage='stream')
            etags = response.headers.get_all('ETag', [])
            dates = response.headers.get_all('Last-Modified', [])
            if len(etags) > 1 or len(dates) > 1:
                raise PlaybackError(code='N451', stage='stream')
            # Identity values stay private. A strong ETag is preferred. Without
            # one, total/Last-Modified and a stable prefix are checked per open.
            self.identity = (total, etags[0] if etags and not etags[0].startswith('W/') else '', dates[0] if dates else '')
            if identity is not None and self.identity != identity:
                raise PlaybackError(code='P455', stage='stream')
            self.total, self.start, self.end = total, first, last
            self.remaining = min(last, end) - first + 1
            self.end = min(last, end)
        except BaseException as error:
            code = error.code if type(error) in (PlaybackError, TransportError, RedirectError) else failure
            try:
                self.close()
            except Exception:
                pass
            if not isinstance(error, Exception):
                raise
            from .range_diagnostics import clean_range
            safe = PlaybackError(code=code, stage='stream')
            safe.details = clean_range(details or getattr(error, 'details', {})) if code == 'P454' else {}
            raise safe from None

    def read(self, size=65536):
        if self.closed or self.remaining == 0:
            return b''
        try:
            checkpoint()
            self.budget.end = time.monotonic() + self.idle_timeout
            block = self.response.read1(min(size, 65536, self.remaining))
            self.budget.remaining()
            if not block:
                raise PlaybackError(code='N453', stage='read')
            self.remaining -= len(block)
            return block
        except Exception:
            self.close()
            raise PlaybackError(code='P453', stage='read') from None


def prefix_bytes(source, amount):
    result = b''
    while len(result) < amount:
        block = source.read(amount - len(result))
        if not block:
            break
        result += block
    return result


class VODResource:
    """One private item, immutable options, incremental range requests only."""
    def __init__(self, url, extension, **options):
        if extension not in MIMES:
            raise PlaybackError(code='P456', stage='preparation')
        self._url, self._options = url, options
        self.closed = False
        self.extension, self.mime = extension, MIMES[extension]
        source = RangeInput(url, 0, 1023, **options)
        try:
            self.identity, self.length = source.identity, source.total
            self.seekable = source.seekable
            self._options = dict(options, _no_range=source.no_range)
            self.prefix = prefix_bytes(source, min(1024, self.length, source.end + 1))
            valid = valid_signature(extension, self.prefix)
            if not valid:
                raise PlaybackError(code='P450', stage='stream')
        finally:
            source.close()

    def open(self, start, end):
        if self.closed:
            raise PlaybackError(code='P401', stage='approval')
        # No stable server validator: recheck the prefix on every request. This
        # catches replacement headers/containers but is not a cryptographic
        # whole-file identity guarantee; documented as a compatibility limit.
        options = dict(self._options, _budget=Deadline(self._options.get('timeout', 12)))
        if not self.identity[1]:
            probe = RangeInput(self._url, 0, len(self.prefix)-1, identity=self.identity, **options)
            try:
                if prefix_bytes(probe, len(self.prefix)) != self.prefix:
                    raise PlaybackError(code='P455', stage='stream')
            finally:
                probe.close()
        if self.closed:
            raise PlaybackError(code='P401', stage='approval')
        if not self.seekable and start != 0:
            raise PlaybackError(code='P454', stage='stream')
        return RangeChain(self._url, start, end, self.identity, options)

    def cancel(self):
        self.closed = True

    def close(self):
        self.closed = True
        self._url = ''
        self._options.clear()
        self.prefix = b''


def valid_signature(extension, prefix):
    if extension in ('mp4', 'm4v', 'mov'):
        return len(prefix) >= 12 and prefix[4:8] in (b'ftyp', b'moov', b'mdat', b'wide')
    if extension in ('mkv', 'webm'):
        return prefix.startswith(b'\x1aE\xdf\xa3')
    if extension == 'avi':
        return prefix.startswith(b'RIFF') and prefix[8:12] == b'AVI '
    if extension in ('mpg', 'mpeg'):
        return prefix.startswith(b'\x00\x00\x01\xba')
    if extension == 'ts':
        return len(prefix) > 376 and all(prefix[i] == 0x47 for i in (0, 188, 376))
    return False


class RangeChain:
    """Continue exact adjacent ranges when a server caps each 206 response."""
    def __init__(self, url, start, end, identity, options):
        self.url, self.next, self.end = url, start, end
        self.identity, self.options = identity, options
        self.reader = None
        self.closed = False

    def read(self, size=65536):
        if self.closed or self.next > self.end:
            return b''
        if self.reader is None:
            options = dict(self.options)
            options['_budget'] = Deadline(options.get('timeout', 12))
            self.reader = RangeInput(self.url, self.next, self.end, identity=self.identity, **options)
        block = self.reader.read(size)
        self.next += len(block)
        if self.reader.remaining == 0:
            self.reader.close()
            self.reader = None
        return block

    def close(self):
        self.closed = True
        if self.reader is not None:
            self.reader.close()
        self.url = ''
        self.options.clear()

    cancel = close
