"""Account-local discovery dates; initial refresh is a baseline, never all-new."""
import json,time
from .preferences import atomic_bytes
from .local_files import read_regular_bytes
class Discovery:
    def __init__(self,store,clock=time.time):
        self.path=None if getattr(store,'temporary',False) else store.path+'.discovery.json'
        self.scope,self.clock=store.scope,clock
        self.rows={'movies':None,'series':None};self.blocked=False
        if self.path:
            try:
                raw=read_regular_bytes(self.path,8*1024*1024)
                if len(raw)>8*1024*1024:raise ValueError()
                data=json.loads(raw)
                if data.get('scope')!=self.scope or data.get('version')!=1:raise ValueError()
                for kind in self.rows:
                    rows=data['rows'][kind]
                    if rows is not None and (not isinstance(rows,dict) or len(rows)>100000 or any(not isinstance(k,str) or not 1<=len(k)<=128 or type(v) not in (int,float) or not 0<=v<=253402300799 for k,v in rows.items())):raise ValueError()
                    self.rows[kind]=rows
            except FileNotFoundError:pass
            except Exception:self.rows={'movies':None,'series':None};self.blocked=True
    def update(self,kind,items):
        if self.blocked:return
        previous=self.rows[kind];now=self.clock();ids=[str(row['id']) for row in items][:100000]
        existing=previous or {};updated={value:existing.get(value,now if previous is not None else 0) for value in ids}
        if previous==updated:return
        self.rows[kind]=updated
        if self.path:
            try:atomic_bytes(self.path,json.dumps({'version':1,'scope':self.scope,'rows':self.rows},separators=(',',':')).encode())
            except Exception:self.rows[kind]=previous;self.blocked=True
    def recent_ids(self,kind):
        now=self.clock()
        return [key for key,value in sorted((self.rows[kind] or {}).items(),key=lambda item:item[1],reverse=True) if value>0 and now-30*86400<=value<=now]

def is_watched(row,prefs,history):
    kind=row.get('kind');value=(row.get('series_id') or row.get('id')) if kind=='series' else row.get('id')
    if str(value) in prefs.get('watched_'+str(kind),[]):return True
    # An entire series is only completed by an explicit series-level mark.
    if kind=='series' and not row.get('series_id'):return False
    previous=history.find(row) if history else None
    return bool(previous and previous.get('completed'))


class WatchedIndex:
    """One revision-scoped lookup instead of scanning saved IDs for every title."""
    def __init__(self,prefs,history):
        self.movies=set(prefs.get('watched_movies',()))
        self.series=set(prefs.get('watched_series',()))
        self.episodes=set()
        records=getattr(history,'rows',{}) if history else {}
        for row in records.values():
            if not row.get('completed'):
                continue
            if row.get('kind')=='movies':
                self.movies.add(row['id'])
            elif row.get('kind')=='series':
                self.episodes.add((row.get('series_id'),row['id']))

    def contains(self,row):
        if row.get('kind')=='movies':
            return str(row.get('id')) in self.movies
        if row.get('kind')=='series':
            parent=str(row.get('series_id') or row.get('id'))
            return parent in self.series or bool(row.get('series_id') and (parent,str(row.get('id'))) in self.episodes)
        return False
