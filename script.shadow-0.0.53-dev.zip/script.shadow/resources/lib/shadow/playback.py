"""Account-scoped playback preparation and one bounded, loopback-only relay."""
import secrets
import socket
import threading
import time
from .streaming import PlaybackError, TSInput, stream_id
from .safe_errors import SafeError
from .live_reconnect import diagnostic
from .provider import ProviderError
from .memory_store import MemoryStore


class PreparedPlayback:
    def __init__(self, source, permitted):
        self.source, self.permitted = source, permitted

    def close(self):
        self.source.close()


def prepare_playback(session, channel_id, opener=TSInput, expected_connection=None):
    """Run in the existing single job worker; callers adopt or close the result."""
    stream_id(channel_id)
    connection = session.connection
    if connection is None or (expected_connection is not None and connection is not expected_connection):
        raise PlaybackError(code='P401', stage='approval')
    revision = connection.prefs['revision']
    channels = connection.channels
    known_ids = {row['stream_id'] for row in channels}
    approved = set(connection.prefs['approved_channel_ids'])
    storage_lock = threading.Lock()
    storage_check = [0.0, False]

    def stored_current():
        if isinstance(connection.store, MemoryStore):
            return connection.store.matches_revision(revision)
        with storage_lock:
            if time.monotonic() >= storage_check[0]:
                storage_check[1] = connection.store.load()['revision'] == revision
                storage_check[0] = time.monotonic() + .2
            return storage_check[1]

    def permitted():
        try:
            if session.connection is not connection:
                return False
            if not connection.client.playback_session_valid():
                return False
            channel_check = getattr(connection.client, 'playback_channel_valid', None)
            if channel_check is not None and not channel_check(channel_id):
                return False
            prefs = connection.prefs
            if prefs['revision'] != revision or 'live' not in prefs['content_types'] or channel_id not in approved:
                return False
            if connection.channels is not channels or channel_id not in known_ids:
                return False
            current = stored_current()
            return current and session.connection is connection
        except Exception:
            return False

    source = None
    stage = 'approval'
    try:
        if not permitted():
            raise PlaybackError(code='P401', stage=stage)
        # Enforce the session transport policy before authentication for Watch.
        stage = 'address'
        url = connection.client.live_playback_url(channel_id)
        stage = 'login'
        connection.client.authenticate()
        if getattr(connection.client, 'is_m3u', False):
            connection.client.live_playback_url(channel_id)
        if not permitted():
            raise PlaybackError(code='P401', stage='approval')
        stage = 'stream'
        open_stream = getattr(connection.client, 'open_playback_stream', None)
        source = open_stream(channel_id, opener) if callable(open_stream) else opener(url)
        url = None
        if not permitted():
            raise PlaybackError(code='P401', stage='approval')
        return PreparedPlayback(source, permitted)
    except SafeError:
        if source is not None:
            try:
                source.close()
            except Exception:
                pass
        raise
    except Exception as error:
        if source is not None:
            try:
                source.close()
            except Exception:
                pass
        code = 'P402' if stage == 'address' else 'P499'
        if type(error) is PlaybackError:
            code, stage = error.code, error.stage
        elif type(error) is ProviderError and stage != 'address':
            code = error.code
        raise PlaybackError(code=code, stage=stage, http_status=getattr(error, 'http_status', None)) from None


class _Lease:
    def __init__(self, prepared, ttl):
        self.prepared = prepared
        self.path = '/play/' + secrets.token_urlsafe(32) + '.ts'
        self.expires = time.monotonic() + ttl
        self.claimed = False
        self.revoked = False

    def valid(self):
        try:
            return not self.revoked and (self.claimed or time.monotonic() < self.expires) and self.prepared.permitted()
        except Exception:
            return False


class _ClientEnded(Exception):
    """The local player closed its reader; carries no URL or exception text."""


class PlaybackRelay:
    """Two fixed workers, one stream, backlog 2, 8KiB/2s request limit.

    Local HTTP is intentional: only 127.0.0.1, no reusable credentials. Provider
    input uses verified HTTPS or explicitly consented HTTP. No TLS key, proxy, CORS, redirects or remote binding.
    """
    def __init__(self, ticket_ttl=20):
        if not isinstance(ticket_ttl, (int, float)) or isinstance(ticket_ttl, bool) or not 0 < ticket_ttl <= 30:
            raise PlaybackError('Invalid ticket lifetime')
        self.ttl = ticket_ttl
        self.lock = threading.RLock()
        self.closed = threading.Event()
        self.lease = None
        self.client = None
        self.status = 'idle'
        self.failure = None
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.listener.bind(('127.0.0.1', 0))
            self.listener.listen(2)
            self.listener.settimeout(.2)
            self.host = '127.0.0.1:%s' % self.listener.getsockname()[1]
            self.worker = threading.Thread(target=self._serve, name='ShadowRelay', daemon=True)
            self.guard = threading.Thread(target=self._watch, name='ShadowPlaybackGuard', daemon=True)
            self.worker.start()
            self.guard.start()
        except Exception:
            self.closed.set()
            self.listener.close()
            raise PlaybackError('Local playback listener is unavailable') from None

    def start(self, prepared):
        self.stop()
        with self.lock:
            if self.closed.is_set() or not prepared.permitted():
                prepared.close()
                raise PlaybackError('Playback authorization changed')
            self.lease = _Lease(prepared, self.ttl)
            self.failure = None
            self.status = 'waiting'
            return 'http://' + self.host + self.lease.path

    @staticmethod
    def _disconnect(sock):
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def stop(self, status='stopped'):
        with self.lock:
            lease, self.lease = self.lease, None
            self.status = status
            if lease:
                lease.revoked = True
                lease.prepared.source.cancel()
                if not lease.claimed:
                    lease.prepared.close()
            self._disconnect(self.client)

    def _watch(self):
        while not self.closed.wait(.2):
            with self.lock:
                lease = self.lease
                if lease is not None and not lease.valid():
                    self.stop('authorization-ended')

    def _request(self, sock):
        end, data = time.monotonic() + 2, bytearray()
        while b'\r\n\r\n' not in data:
            remaining = end - time.monotonic()
            if remaining <= 0 or len(data) >= 8192:
                raise ValueError()
            sock.settimeout(remaining)
            block = sock.recv(min(2048, 8192-len(data)))
            if not block:
                raise ValueError()
            data.extend(block)
        raw, extra = bytes(data).split(b'\r\n\r\n', 1)
        if extra or any(c < 32 and c not in (10, 13) or c > 126 for c in raw):
            raise ValueError()
        lines = raw.decode('ascii').split('\r\n')
        method, path, version = lines[0].split(' ')
        if method != 'GET' or version not in ('HTTP/1.0', 'HTTP/1.1') or len(lines) > 33:
            raise ValueError()
        headers = {}
        for line in lines[1:]:
            name, value = line.split(':', 1)
            if not name or name != name.strip() or name.lower() in headers:
                raise ValueError()
            headers[name.lower()] = value.strip()
        if headers.get('host') != self.host:
            raise ValueError()
        if any(name in headers for name in ('origin', 'referer', 'authorization', 'proxy-authorization', 'cookie', 'transfer-encoding')):
            raise ValueError()
        if headers.get('content-length', '0') != '0' or headers.get('range', 'bytes=0-') != 'bytes=0-':
            raise ValueError()
        return path

    @staticmethod
    def _send(sock, data):
        try:
            sock.sendall(data)
        except (BrokenPipeError, ConnectionResetError):
            raise _ClientEnded() from None

    def record_failure(self, lease, error):
        # No exception, URL or traceback survives the relay boundary. A late
        # worker cannot overwrite the status of a newer playback lease.
        with self.lock:
            if self.lease is lease:
                self.failure = (diagnostic(error) if type(error) is PlaybackError
                                else ('P481', 'read', None))
                self.status = 'stream-failed'

    def _serve(self):
        while not self.closed.is_set():
            try:
                sock, peer = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            lease = None
            started = False
            with self.lock:
                if self.closed.is_set():
                    sock.close()
                    break
                self.client = sock
            try:
                if peer[0] != '127.0.0.1':
                    raise ValueError()
                path = self._request(sock)
                with self.lock:
                    lease = self.lease
                    if lease is None or lease.claimed or not secrets.compare_digest(path, lease.path) or not lease.valid():
                        lease = None
                        raise ValueError()
                    lease.claimed = True
                    self.status = 'streaming'
                sock.settimeout(2)
                length = getattr(lease.prepared.source, 'length', None)
                chunked = length is None
                framing = b'Transfer-Encoding: chunked\r\n' if chunked else ('Content-Length: %s\r\n' % length).encode('ascii')
                self._send(sock, b'HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\nCache-Control: no-store\r\nAccept-Ranges: none\r\nConnection: close\r\n' + framing + b'\r\n')
                started = True
                while lease.valid() and not self.closed.is_set():
                    block = lease.prepared.source.read()
                    if not block:
                        if chunked and lease.valid():
                            self._send(sock, b'0\r\n\r\n')
                        break
                    if len(block) > 16572 or not lease.valid():
                        raise ValueError()
                    self._send(sock, ('%x\r\n' % len(block)).encode('ascii') + block + b'\r\n' if chunked else block)
                with self.lock:
                    if self.lease is lease:
                        self.status = 'ended' if lease.valid() else 'authorization-ended'
            except _ClientEnded:
                with self.lock:
                    if lease is not None and self.lease is lease:
                        self.status = 'client-ended'
            except Exception as error:
                if lease is not None:
                    self.record_failure(lease, error)
                if not started:
                    try:
                        sock.settimeout(.2)
                        sock.sendall(b'HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
                    except OSError:
                        pass
            finally:
                if lease is not None:
                    lease.revoked = True
                    try:
                        lease.prepared.close()
                    except Exception:
                        # Cleanup failures must not print upstream state or kill
                        # the listener and silently disable future playback.
                        self.record_failure(lease, PlaybackError(code='N457', stage='read'))
                    with self.lock:
                        if self.lease is lease:
                            self.lease = None
                sock.close()
                with self.lock:
                    if self.client is sock:
                        self.client = None

    def close(self):
        self.closed.set()
        self.stop()
        self.listener.close()
        self.worker.join(.5)
        self.guard.join(.5)
