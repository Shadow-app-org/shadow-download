"""Xtream JSON client; standard library only. Credentials never logged or persisted here."""
import json
import math
import time
from .credentials import SessionCredentials
from urllib.parse import quote, urlencode, urlsplit, urlunsplit
from .safe_errors import provider_code, provider_stage, safe_message, clean_http_status, SafeError
from .cancellation import Cancelled
from .transport import TransportError
from .json_array import ArrayError

class ProviderError(Exception):
    def __init__(self, message=None, code='X499', stage='connection', http_status=None):
        # Legacy message arguments are deliberately never copied into diagnostics.
        self.code = provider_code(code)
        self.stage = provider_stage(stage)
        self.http_status = clean_http_status(self.code, http_status)
        super().__init__(self.code + ': ' + safe_message(self.code, self.http_status))

class XtreamClient:
    def __init__(self, base_url, username, password, transport=None, timeout=12, allow_insecure_http=False, allow_http_playback=False):
        if not isinstance(base_url, str) or not base_url or len(base_url) > 2048 or any(ord(c) < 33 or ord(c) == 127 for c in base_url) or '\\' in base_url:
            raise ValueError('Invalid provider URL')
        parsed = urlsplit(base_url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Invalid provider URL')
        if parsed.port is not None and not (1 <= parsed.port <= 65535):
            raise ValueError('Invalid provider port')
        if parsed.scheme == 'http' and allow_insecure_http is not True:
            raise ValueError('HTTP exposes provider credentials; explicit consent is required')
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 60:
            raise ValueError('Invalid provider timeout')
        credentials = SessionCredentials(username, password)
        path = parsed.path.rstrip('/')
        if not path.endswith('/player_api.php'):
            path += '/player_api.php'
        self.endpoint = urlunsplit((parsed.scheme, parsed.netloc, path, '', ''))
        self._credentials = credentials
        self._transport = transport
        self.timeout = timeout
        self._allow_http_playback = allow_insecure_http is True and allow_http_playback is True
        self._authenticated = False
        self._authenticated_until = None
        self._allow_stream_redirects = False
        self._allow_http_redirects = False

    def _download(self, url, timeout):
        from .transport import request_bytes
        return request_bytes(url, timeout=timeout, allow_http=self.endpoint.startswith('http://'))

    def request(self, action=None, **params):
        if not self._credentials.username or not self._credentials.password:
            raise ProviderError(code='X409')
        query = {'username': self._credentials.username, 'password': self._credentials.password}
        if action:
            query['action'] = action
        query.update({k: v for k, v in params.items() if k not in ('username', 'password')})
        url = self.endpoint + '?' + urlencode(query)
        try:
            if action == 'get_live_streams' and self._transport is None:
                from .transport import request_live_channels
                return request_live_channels(url, timeout=60,
                                             allow_http=self.endpoint.startswith('http://'))
            if action in ('get_vod_streams', 'get_series') and self._transport is None:
                from .transport import request_media_catalogue
                return request_media_catalogue(url, timeout=60, allow_http=self.endpoint.startswith('http://'))
            payload = (self._transport or self._download)(url, self.timeout)
        except ArrayError as error:
            code = ('X412' if error.code == 'X408' else 'X419') if action in ('get_vod_streams', 'get_series') else error.code
            raise ProviderError(code=code) from None
        except Cancelled:
            raise
        except SafeError as error:
            raise ProviderError(code=error.code, stage='catalogue') from None
        except TransportError as error:
            code = error.code if type(error) is TransportError else 'X490'
            raise ProviderError(code=code, http_status=error.http_status if type(error) is TransportError else None) from None
        except Exception:
            raise ProviderError(code='X490') from None
        if not isinstance(payload, bytes):
            raise ProviderError(code='X403')
        if action not in ('get_live_streams', 'get_vod_streams', 'get_series') and len(payload) > 8 * 1024 * 1024:
            raise ProviderError(code='X404')
        try:
            return json.loads(payload.decode('utf-8'))
        except Exception:
            raise ProviderError(code='X403') from None

    def authenticate(self):
        self._authenticated = False
        self._authenticated_until = None
        result = self.request()
        user_info = result.get('user_info') if isinstance(result, dict) else None
        if not isinstance(user_info, dict):
            raise ProviderError(code='X405')
        if str(user_info.get('auth', '0')) != '1':
            raise ProviderError(code='X401')
        status = user_info.get('status')
        if status is not None and (not isinstance(status, str) or status.casefold() != 'active'):
            raise ProviderError(code='X402')
        expiry = user_info.get('exp_date')
        if expiry not in (None, '', '0', 0):
            if isinstance(expiry, bool) or not str(expiry).isascii() or not str(expiry).isdigit() or len(str(expiry)) > 20 or int(expiry) <= time.time():
                raise ProviderError(code='X406')
            self._authenticated_until = int(expiry)
        self._authenticated = True
        return True

    def playback_session_valid(self):
        return bool(self._authenticated and self._credentials.username and self._credentials.password and
                    (self._authenticated_until is None or time.time() < self._authenticated_until))

    def live_playback_url(self, channel_id):
        """Private relay input only. Never pass this return value to Kodi."""
        from .streaming import stream_id
        stream_id(channel_id)
        parts = urlsplit(self.endpoint)
        if (parts.scheme != 'https' and not (parts.scheme == 'http' and self._allow_http_playback)) or not self._credentials.username or not self._credentials.password:
            raise ProviderError('Live playback requires provider credentials and transport consent')
        def segment(value):
            return quote(value, safe='').replace('.', '%2E') if value in ('.', '..') else quote(value, safe='')
        prefix = parts.path.rsplit('/', 1)[0]
        path = prefix + '/live/' + segment(self._credentials.username) + '/' + segment(self._credentials.password) + '/' + channel_id + '.ts'
        return urlunsplit((parts.scheme, parts.netloc, path, '', ''))

    def open_playback_stream(self, channel_id, opener):
        url = self.live_playback_url(channel_id)
        options = {'allow_redirects': True} if self._allow_stream_redirects is True else {}
        if self._allow_stream_redirects is True and self._allow_http_redirects is True and self.playback_session_valid():
            options['allow_http_redirects'] = True
        if urlsplit(url).scheme == 'http':
            options['allow_http'] = self._allow_http_playback
        return opener(url, **options)

    def media_playback_url(self, kind, identity, extension):
        """Private relay input only; never accepts direct_source or full URLs."""
        from .streaming import stream_id
        from .vod import MIMES
        stream_id(identity)
        if kind not in ('movies', 'series') or extension not in MIMES:
            raise ProviderError(code='X400')
        # Reuse the exact established credential/path/HTTP policy.
        live = self.live_playback_url(identity)
        parts = urlsplit(live)
        prefix, tail = parts.path.rsplit('/live/', 1)
        path = prefix + ('/movie/' if kind == 'movies' else '/series/') + tail[:-3] + '.' + extension
        return urlunsplit((parts.scheme, parts.netloc, path, '', ''))

    def open_media_stream(self, kind, identity, extension, opener):
        url = self.media_playback_url(kind, identity, extension)
        options = {'allow_redirects': self._allow_stream_redirects is True,
                   'allow_http_redirects': self._allow_stream_redirects is True and self._allow_http_redirects is True and self.playback_session_valid(),
                   'allow_http': urlsplit(url).scheme == 'http' and self._allow_http_playback}
        return opener(url, extension, **options)

    def set_stream_redirects(self, allowed):
        self._allow_stream_redirects = allowed is True
        if not self._allow_stream_redirects:
            self._allow_http_redirects = False

    def set_http_stream_redirects(self, allowed):
        """Explicit, memory-only playback exception; never changes API transport."""
        self._allow_http_redirects = (allowed is True and self._allow_stream_redirects is True
                                      and self.playback_session_valid())

    def live_categories(self):
        result = self.request('get_live_categories')
        if not isinstance(result, list):
            raise ProviderError(code='X407')
        return result

    def live_streams(self):
        result = self.request('get_live_streams')
        if not isinstance(result, list):
            raise ProviderError(code='X408')
        return result

    def short_epg(self, stream_id, limit=12):
        if not str(stream_id).isascii() or not str(stream_id).isdigit() or len(str(stream_id)) > 64:
            raise ValueError('Invalid stream ID')
        return self.request('get_short_epg', stream_id=str(stream_id), limit=str(min(max(int(limit), 1), 100)))

    def close(self):
        self._allow_stream_redirects = False
        self._allow_http_redirects = False
        self._allow_http_playback = False
        self._authenticated = False
        self._authenticated_until = None
        self._credentials.clear()

    def movie_info(self, identity):
        from .streaming import stream_id
        stream_id(identity)
        return self.request('get_vod_info', vod_id=identity)

    def movie_categories(self):
        return self._listing('get_vod_categories')

    def movies(self):
        return self._listing('get_vod_streams')

    def series(self):
        return self._listing('get_series')

    def series_info(self, series_id):
        if not str(series_id).isascii() or not str(series_id).isdigit() or len(str(series_id)) > 64:
            raise ValueError('Invalid series ID')
        result = self.request('get_series_info', series_id=str(series_id))
        if not isinstance(result, dict):
            raise ProviderError('Provider returned invalid series data')
        return result

    def _listing(self, action):
        result = self.request(action)
        if not isinstance(result, list):
            raise ProviderError(code='X412', stage='catalogue')
        return result
