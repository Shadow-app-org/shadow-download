"""Explicit temporary preferences, isolated per connection; never reads/writes files."""
from copy import deepcopy
import json
import secrets
import threading
import uuid
from . import preferences


class MemoryStore:
    temporary = True

    def __init__(self):
        self.scope = secrets.token_hex(32)
        self._lock = threading.RLock()
        self._data = preferences._defaults()
        self._data.update(provider_scope=self.scope, programme_artwork=False)

    def _check_open(self):
        if self._data is None:
            raise preferences.PreferencesError('Temporary session has ended')

    def load(self):
        with self._lock:
            self._check_open()
            return deepcopy(self._data)

    def matches_revision(self, revision):
        """Playback guard without copying the complete approval list per packet."""
        with self._lock:
            self._check_open()
            return self._data['revision'] == revision

    def save(self, data, expected_revision):
        with self._lock:
            self._check_open()
            validated = preferences._validate(data)
            if validated['provider_scope'] != self.scope:
                raise preferences.PreferencesError('Settings belong to another session')
            if expected_revision != self._data['revision']:
                raise preferences.PreferencesConflict('Temporary settings changed; reload before saving')
            validated['revision'] = uuid.uuid4().hex
            # Temporary tests never initiate artwork disk-cache writes.
            validated['programme_artwork'] = False
            if len(json.dumps(validated).encode('utf-8')) > preferences.MAX_SETTINGS_BYTES:
                raise preferences.PreferencesError('Preferences exceed size limit')
            self._data = validated
            return deepcopy(validated)

    def clone(self):
        """Owned snapshot for same-playlist refresh; never shares mutable approvals."""
        with self._lock:
            self._check_open()
            result = MemoryStore()
            result.scope = self.scope
            result._data = deepcopy(self._data)
            return result

    def close(self):
        with self._lock:
            self._data = None

    def recover(self, confirmed=False):
        raise preferences.PreferencesError('Temporary sessions have no saved backup')
