"""Bounded M3U-link import. Sensitive URLs live only inside the playlist client.

No Kodi directives are executed. No logos, external EPG, manifests or nested
playlists are fetched. Only explicitly approved public HTTP(S) TS inputs can play; HTTP requires consent.
"""
from collections import Counter
import hashlib
import hmac
import ipaddress
import os
import re
from urllib.parse import urljoin, urlsplit, urlunsplit, unquote
from .accounts import AccountStore, _scope_key
from .application import Connection
from .safe_errors import SafeError
from .preferences import PreferencesError
from .memory_store import MemoryStore
from .selection import LANGUAGES
from .streaming import TSInput, stream_id
from .transport import request_bytes, TransportError
from .xtream import display_text

MAX_BYTES = 8 * 1024 * 1024
MAX_LINES = 200000
MAX_ENTRIES = 50000
MAX_LINE = 16384
_ATTR = re.compile(r'''\s+([A-Za-z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s]+))''')
_DURATION = re.compile(r'^(-?\d+(?:\.\d+)?)')
_ALIASES = {'eng':'EN', 'en':'EN', 'english':'EN', 'spa':'ES', 'spanish':'ES',
            'fra':'FR', 'fre':'FR', 'french':'FR', 'deu':'DE', 'ger':'DE', 'german':'DE',
            'ita':'IT', 'italian':'IT', 'por':'PT', 'portuguese':'PT', 'nld':'NL', 'dutch':'NL',
            'pol':'PL', 'polish':'PL', 'ara':'AR', 'arabic':'AR', 'tur':'TR', 'turkish':'TR',
            'ukr':'UA', 'uk':'UA', 'ukrainian':'UA'}


def validated_url(value, allow_http=False):
    """Reject unsafe forms before DNS; DNS is independently pinned/public-checked."""
    try:
        if not isinstance(value, str) or not value or len(value) > MAX_LINE:
            raise ValueError()
        if not value.isascii() or any(ord(c) < 33 or ord(c) == 127 for c in value) or any(c in value for c in ('\\', '|')):
            raise ValueError()
        if re.search(r'%(?![0-9A-Fa-f]{2})', value):
            raise ValueError()
        parsed = urlsplit(value)
        if (parsed.scheme != 'https' and not (parsed.scheme == 'http' and allow_http is True)) or not parsed.hostname or parsed.username is not None or parsed.password is not None or parsed.fragment:
            raise ValueError()
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            raise ValueError()
        host = parsed.hostname.rstrip('.').lower()
        if '%' in host or host == 'localhost' or host.endswith(('.localhost', '.local')):
            raise ValueError()
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            ip = None
        if ip is not None and (not ip.is_global or ip.is_multicast or getattr(ip, 'ipv4_mapped', None)):
            raise ValueError()
        netloc = '[' + host + ']' if ':' in host else host
        if parsed.port is not None and parsed.port != (443 if parsed.scheme == 'https' else 80):
            netloc += ':' + str(parsed.port)
        return urlunsplit((parsed.scheme, netloc, parsed.path or '/', parsed.query, ''))
    except Exception:
        raise SafeError('M300') from None


def https_url(value):
    return validated_url(value)


def _text(value, fallback):
    value = display_text(value, 180)
    # Never use a URL as the fallback label for a missing channel/group name.
    if '://' in value or re.search(r'(?:username|password|token)\s*=', value, re.I):
        return fallback
    return value or fallback


def _extinf(line):
    content = line[len('#EXTINF:'):]
    quote = None
    for index, char in enumerate(content):
        if quote:
            if char == quote:
                quote = None
        elif char in ('"', "'"):
            quote = char
        elif char == ',':
            head, name = content[:index], content[index+1:]
            break
    else:
        raise ValueError()
    duration = _DURATION.match(head)
    if duration is None or len(duration[1]) > 12:
        raise ValueError()
    attributes, pos = {}, duration.end()
    while head[pos:].strip():
        match = _ATTR.match(head, pos)
        if match is None or match[1].lower() in attributes:
            raise ValueError()
        attributes[match[1].lower()] = next(v for v in match.groups()[1:] if v is not None)
        pos = match.end()
    return attributes, name, float(duration[1])


def parse_playlist(payload, source_url, allow_http=False):
    """Return transient entries and numeric skip counts; never print this result."""
    if not isinstance(payload, bytes):
        raise SafeError('M302')
    if len(payload) > MAX_BYTES:
        raise SafeError('M304')
    try:
        text = payload.decode('utf-8-sig')
    except UnicodeError:
        raise SafeError('M302') from None
    if any(ord(c) < 32 and c not in '\r\n\t' for c in text) or '\x7f' in text:
        raise SafeError('M302')
    lines = text.splitlines()
    if len(lines) > MAX_LINES or any(len(line) > MAX_LINE for line in lines):
        raise SafeError('M304')
    lines = [line.strip() for line in lines if line.strip()]
    if not lines or not re.match(r'^#EXTM3U(?:\s|$)', lines[0]):
        raise SafeError('M302')
    if any(line.startswith('#EXT-X-') for line in lines):
        raise SafeError('M303')
    entries, seen, counts = [], set(), Counter()
    pending, blocked, group = None, False, ''
    total = 0
    for line in lines[1:]:
        if line.startswith('#EXTINF:'):
            if pending is not None:
                counts['malformed'] += 1
            try:
                pending = _extinf(line)
                blocked = False
            except ValueError:
                pending, blocked = ({}, '', -1), True
                counts['malformed'] += 1
            total += 1
            if total > MAX_ENTRIES:
                raise SafeError('M304')
            continue
        if line.startswith('#EXTGRP:'):
            group = line[len('#EXTGRP:'):]
            continue
        if line.startswith(('#KODIPROP:', '#EXTVLCOPT:', '#EXTHTTP:')):
            if pending is None:
                # Global player options cannot safely be applied to later entries.
                raise SafeError('M302')
            blocked = True
            counts['player_options'] += 1
            continue
        if line.startswith('#'):
            continue
        if pending is None:
            counts['malformed'] += 1
            continue
        attrs, name, duration = pending
        pending = None
        if blocked:
            continue
        if duration > 0 or attrs.get('radio', '').lower() in ('true', '1'):
            counts['other_format'] += 1
            continue
        try:
            raw = urljoin(source_url, line)
            if urlsplit(raw).scheme == 'http' and allow_http is not True:
                counts['http'] += 1
                continue
            url = validated_url(raw, allow_http)
        except (SafeError, ValueError):
            counts['unsafe'] += 1
            continue
        extension = os.path.splitext(unquote(urlsplit(url).path).lower())[1]
        if extension in ('.m3u', '.m3u8', '.mpd'):
            counts['hls_or_manifest'] += 1
            continue
        if extension in ('.mp4', '.mkv', '.avi', '.mp3', '.aac', '.flv', '.mov', '.webm'):
            counts['other_format'] += 1
            continue
        if url in seen:
            counts['duplicate'] += 1
            continue
        seen.add(url)
        category = _text(attrs.get('group-title') or group, 'Other')
        language = attrs.get('tvg-language', '').strip().lower()
        code = _ALIASES.get(language, language.upper() if language.upper() in LANGUAGES else None)
        if code:
            category = code + ' | ' + category
        entries.append({'url': url, 'name': _text(name or attrs.get('tvg-name'), 'Unnamed channel'),
                        'group': category})
    if pending is not None:
        counts['malformed'] += 1
    return entries, dict(counts)


class PlaylistClient:
    """Implements the existing session/playback interface without exposing URLs."""
    is_m3u = True

    def __init__(self, source_url, key, scope, downloader=None, allow_http=False):
        self._allow_http = allow_http is True
        self._source = validated_url(source_url, self._allow_http)
        self._key, self._scope = key, scope
        self._downloader = downloader
        self._urls, self._available = {}, set()
        self._active = False
        self.counts = {}
        self._temporary_store = None

    @staticmethod
    def _download(url, allow_http=False):
        options = {'allow_http': True} if allow_http is True else {}
        return request_bytes(url, timeout=12, max_bytes=MAX_BYTES, accept='application/x-mpegURL, text/plain', public_only=True, **options)

    def _entries(self):
        if not self._source:
            raise SafeError('M308')
        try:
            body = self._downloader(self._source) if self._downloader else self._download(self._source, self._allow_http)
        except TransportError as error:
            # Only a fixed transport code crosses the worker/UI boundary.
            raise SafeError(error.code if type(error) is TransportError else 'M301') from None
        except Exception:
            raise SafeError('M301') from None
        return parse_playlist(body, self._source, self._allow_http)

    def _identity(self, url):
        value = ('m3u-channel-v1\0' + self._scope + '\0' + url).encode('utf-8')
        return str(int.from_bytes(hmac.new(self._key, value, hashlib.sha256).digest()[:24], 'big'))

    def load(self):
        entries, self.counts = self._entries()
        if not entries:
            raise SafeError('M305')
        groups, channels = {}, []
        for entry in entries:
            identity = self._identity(entry['url'])
            category = groups.setdefault(entry['group'], str(len(groups)+1))
            self._urls[identity] = entry['url']
            channels.append({'stream_id': identity, 'name': entry['name'], 'category_id': category,
                             'stream_icon': '', 'epg_channel_id': ''})
        self._available = set(self._urls)
        self._active = True
        return [{'category_id': value, 'category_name': key} for key, value in groups.items()], channels

    def authenticate(self):
        # Re-read before every Watch. New or changed URLs cannot inherit approval.
        self._active = False
        entries, _ = self._entries()
        self._available = {self._identity(entry['url']) for entry in entries} & set(self._urls)
        self._active = True
        return True

    def playback_session_valid(self):
        return self._active and bool(self._source)

    def playback_channel_valid(self, channel_id):
        return channel_id in self._available and channel_id in self._urls

    def live_playback_url(self, channel_id):
        stream_id(channel_id)
        if not self.playback_session_valid():
            raise SafeError('M308')
        if not self.playback_channel_valid(channel_id):
            raise SafeError('M307')
        return self._urls[channel_id]

    def open_playback_stream(self, channel_id, opener=TSInput):
        try:
            options = {'allow_http': True} if self._allow_http else {}
            return opener(self.live_playback_url(channel_id), allow_query=True, public_only=True, **options)
        except SafeError:
            raise
        except Exception:
            raise SafeError('M309') from None

    def short_epg(self, *args, **kwargs):
        return {'epg_listings': []}

    def reconnect(self, directory):
        if not self._source:
            raise SafeError('M308')
        if self._temporary_store is not None:
            # Same playlist and key: unchanged URLs retain their explicit approval.
            # New/changed URLs get new IDs; cancellation closes only the snapshot.
            return _temporary_playlist(self._source, self._downloader, self._allow_http,
                                       self._key, self._temporary_store.clone())
        return prepare_playlist(directory, self._source, self._downloader, allow_http=self._allow_http)

    def close(self):
        self._active = False
        self._allow_http = False
        self._source = ''
        self._urls.clear()
        self._available.clear()
        self._key = b''
        self._downloader = None
        self._temporary_store = None


def prepare_playlist(directory, source_url, downloader=None, recover=False, allow_http=False, temporary=False):
    """Single-job worker operation; result must be adopted or explicitly closed."""
    url = validated_url(source_url, allow_http)
    if temporary is True:
        if recover:
            raise SafeError('M312')
        return _temporary_playlist(url, downloader, allow_http)
    client = None
    stage = 'M310'
    try:
        account_dir = os.path.join(directory, 'playlist-accounts')
        key = _scope_key(account_dir)
        # A fixed namespace plus the complete URL separates different tokens/users.
        # AccountStore persists only an HMAC identifier, never its input strings.
        store = AccountStore(account_dir, 'https://shadow.invalid/m3u', url)
        client = PlaylistClient(url, key, store.scope, downloader, allow_http)
        stage = 'M311'
        categories, channels = client.load()
        if recover:
            stage = 'M312'
            store.recover(confirmed=True)
        stage = 'M313'
        prefs = store.load()
        return Connection(client, store, prefs, categories, channels)
    except PreferencesError as error:
        if client is not None:
            client.close()
        raise SafeError(error.code) from None
    except SafeError:
        if client is not None:
            client.close()
        raise
    except Exception:
        if client is not None:
            client.close()
        raise SafeError(stage) from None


def _temporary_playlist(url, downloader, allow_http, key=None, store=None):
    """Separate explicit path: no account files, scope keys, backups or recovery."""
    store = store if store is not None else MemoryStore()
    client = None
    try:
        client = PlaylistClient(url, key if key is not None else os.urandom(32),
                                store.scope, downloader, allow_http)
        client._temporary_store = store
        categories, channels = client.load()
        connection = Connection(client, store, store.load(), categories, channels)
        # Reuse normal selection validation to prune disappeared channel approvals.
        # Do not adopt/close via Session: the caller owns the prepared result.
        from .application import Session
        session = Session()
        session.connection = connection
        session.save({})
        return connection
    except Exception as error:
        if client is not None:
            client.close()
        store.close()
        if type(error) is SafeError:
            raise
        raise SafeError('M311') from None
