"""Credential-free capability evidence, never a substitute for production sync.

Only disposable files below a newly created private profile subdirectory are
used. No account data is read, no provider is contacted, and no save policy is
changed. A successful SQLite probe is not proof of crash/power-loss durability.
"""
import errno
import importlib
import os
import stat
import sys
import tempfile

from .safe_errors import SafeError, STORAGE_CODES, format_storage_failure
from .storage_check import check_storage


def _error(error):
    # Never show exception text, arbitrary class names, paths or module names.
    names = (ModuleNotFoundError, ImportError, PermissionError, FileNotFoundError,
             NotImplementedError, AttributeError, OSError, ValueError, TypeError)
    label = next((kind.__name__ for kind in names if isinstance(error, kind)), 'Error')
    number = getattr(error, 'errno', None)
    if type(number) is int and 0 <= number <= 65535:
        label += '(' + errno.errorcode.get(number, str(number)) + ')'
    number = getattr(error, 'sqlite_errorcode', None)
    if type(number) is int and 0 <= number <= 65535:
        label += '(sqlite=' + str(number) + ')'
    return label


def _fsync(directory):
    stage = 'create'
    try:
        with tempfile.NamedTemporaryFile(prefix='.shadow-', suffix='.tmp',
                                         dir=directory, delete=False) as file:
            stage = 'write'
            file.write(b'Shadow diagnostic only\n')
            file.flush()
            stage = 'fsync'
            os.fsync(file.fileno())
            stage = 'close'
        return 'PASS'
    except Exception as error:
        return stage + '/' + _error(error)


def _ctypes():
    try:
        importlib.import_module('ctypes')
        return 'import PASS'
    except Exception as error:
        return _import_error(error)


def _import_error(error):
    label = _error(error)
    name = getattr(error, 'name', None)
    if isinstance(error, ImportError) and name in ('ctypes', '_ctypes', 'sqlite3', '_sqlite3'):
        label += '(' + name + ')'
    return label


def _sqlite(directory):
    connection = None
    stage = 'import'
    outcome = 'not run'
    try:
        sqlite = importlib.import_module('sqlite3')
        path = os.path.join(directory, 'capability.sqlite')

        def open_database():
            db = sqlite.connect(path, timeout=1, isolation_level=None)
            try:
                if db.execute('PRAGMA journal_mode=DELETE').fetchone() != ('delete',):
                    raise ValueError()
                db.execute('PRAGMA synchronous=EXTRA')
                if db.execute('PRAGMA synchronous').fetchone() != (3,):
                    raise ValueError()
                return db
            except Exception:
                db.close()
                raise

        stage = 'open/config'
        connection = open_database()
        stage = 'commit'
        connection.execute('BEGIN IMMEDIATE')
        connection.execute('CREATE TABLE probe (value INTEGER NOT NULL)')
        connection.execute('INSERT INTO probe VALUES (1)')
        connection.execute('COMMIT')
        connection.close()
        connection = None
        stage = 'reopen'
        connection = open_database()
        if connection.execute('SELECT value FROM probe').fetchall() != [(1,)]:
            raise ValueError()
        stage = 'rollback'
        connection.execute('BEGIN IMMEDIATE')
        connection.execute('UPDATE probe SET value=2')
        connection.execute('ROLLBACK')
        if connection.execute('SELECT value FROM probe').fetchall() != [(1,)]:
            raise ValueError()
        # Normal close with an uncommitted transaction, not a simulated crash.
        stage = 'uncommitted close'
        connection.execute('BEGIN IMMEDIATE')
        connection.execute('UPDATE probe SET value=3')
        connection.close()
        connection = None
        stage = 'verify'
        connection = open_database()
        if (connection.execute('SELECT value FROM probe').fetchall() != [(1,)] or
                connection.execute('PRAGMA integrity_check').fetchall() != [('ok',)]):
            raise ValueError()
        outcome = 'PASS (EXTRA)'
    except Exception as error:
        outcome = stage + '/' + (_import_error(error) if stage == 'import' else _error(error))
    finally:
        if connection is not None:
            try:
                connection.close()
            except Exception as error:
                outcome = 'close/' + _error(error)
    return outcome


def _metadata(directory):
    """Report only fixed file kinds and a bounded count for the disposable DB."""
    try:
        folder = os.lstat(directory)
        info = os.lstat(os.path.join(directory, 'capability.sqlite'))
        kind = ('regular' if stat.S_ISREG(info.st_mode) else
                'symlink' if stat.S_ISLNK(info.st_mode) else 'other')
        links = info.st_nlink
        count = str(links) if type(links) is int and 0 <= links <= 65535 else 'unknown'
        return ('dir=OK' if stat.S_ISDIR(folder.st_mode) else 'dir=other') + '; ' + kind + '; links=' + count
    except Exception as error:
        return _error(error)


def _remembered(directory):
    """Exercise login/consent persistence and forgetting using synthetic data only."""
    from .saved_login import SavedLogin, LoginStorageError, error_code
    from .connection_permissions import ConnectionPermissions, identity
    rows = []
    details = ('https://storage-check.invalid', 'local-test', 'diagnostic-only')
    options = dict(remember=True, redirects=False, http_redirects=False, http_login=False)
    key = identity(details)
    login = SavedLogin(directory)
    try:
        login.save(details)
        if SavedLogin(directory).load() != details:
            raise LoginStorageError()
        rows.append(('Saved login', 'PASS'))
    except LoginStorageError as error:
        rows.append(('Saved login', error_code(error)))
    try:
        permissions = ConnectionPermissions(directory)
        permissions.remember(key, options)
        if ConnectionPermissions(directory).lookup(key) != options:
            raise LoginStorageError()
        permissions.set_enabled(False)
        if ConnectionPermissions(directory).lookup(key) is not None:
            raise LoginStorageError()
        permissions.set_enabled(True)
        if ConnectionPermissions(directory).lookup(key) is not None:
            raise LoginStorageError()
        rows.append(('Permissions', 'PASS'))
    except LoginStorageError as error:
        rows.append(('Permissions', error_code(error)))
    try:
        login.forget()
        if SavedLogin(directory).load() is not None:
            raise LoginStorageError()
        rows.append(('Forget login', 'PASS'))
    except LoginStorageError as error:
        rows.append(('Forget login', error_code(error)))
    return rows


def diagnose_storage(profile):
    """Return fixed labels and sanitized evidence for a screenshot, never secrets."""
    rows = [('Python', '.'.join(str(n) for n in sys.version_info[:3]))]
    detail = ''
    step = ''
    try:
        result = check_storage(profile)
        production = 'PASS' if result is True else 'S413'
    except SafeError as error:
        production = error.code if error.code in STORAGE_CODES else 'S413'
        detail = format_storage_failure(getattr(error, 'storage_detail', None))
        candidate = getattr(error, 'storage_step', None)
        if type(candidate) is str and candidate in (
                'temporary folder', 'identity creation', 'identity reopen',
                'account open', 'preferences read', 'first save', 'second save',
                'backup read', 'saved readback'):
            step = candidate
    except Exception:
        production = 'S413'
    rows.append(('Current saver', production))
    if step:
        rows.append(('Saver step', step))
    if detail:
        rows.append(('Saver detail', detail))
    rows.append(('ctypes', _ctypes()))
    temporary = None
    try:
        temporary = tempfile.TemporaryDirectory(prefix='.shadow-capability-', dir=profile)
    except Exception as error:
        rows.append(('Probe folder', _error(error)))
        return rows
    try:
        rows.append(('File sync', _fsync(temporary.name)))
        rows.append(('SQLite', _sqlite(temporary.name)))
        rows.append(('DB metadata', _metadata(temporary.name)))
        rows.extend(_remembered(temporary.name))
    finally:
        try:
            temporary.cleanup()
            cleanup = 'PASS'
        except Exception as error:
            cleanup = _error(error)
        rows.append(('Cleanup', cleanup))
    return rows
