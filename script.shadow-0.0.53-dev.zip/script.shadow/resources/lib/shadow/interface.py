"""Controller focus contract and preview-only inventory. No provider impersonation."""
MENU = ('Home', 'Live TV', 'TV Guide', 'Movies', 'TV Series', 'Watch Later', 'Continue Watching', 'Search', 'Settings')
SHORTCUTS = ('Live TV', 'TV Guide', 'Movies', 'TV Series')
PALETTE = {'background': 'FF090909', 'panel': 'FF191919', 'card': 'FF222222', 'channel': 'FF505050', 'focus': 'FFE0E0E0'}
DEMO_CATEGORIES = [{'category_id': 'demo-en', 'category_name': 'EN | Preview'}, {'category_id': 'demo-fr', 'category_name': 'FR | Preview'}]
DEMO_CHANNELS = [{'stream_id': 'demo-1', 'category_id': 'demo-en', 'name': 'Demo channel 1'}, {'stream_id': 'demo-2', 'category_id': 'demo-fr', 'name': 'Demo channel 2'}]


def focus_target(control, direction, page='Home', has_rows=True, has_programmes=True):
    if direction not in ('up', 'down', 'left', 'right'):
        raise ValueError('Unknown focus direction')
    if 100 <= control <= 108:
        right = 200 if page == 'Home' else 420 if page=='Watch Later' and has_rows else 300 if has_rows else control
        return {'up':100+(control-101)%9,'down':100+(control-99)%9,'left':control,'right':right}[direction]
    if 200 <= control <= 203:
        return {'up':100,'down':620+control-200,'left':control-1 if control>200 else 100,'right':min(control+1,203)}[direction]
    if 620 <= control <= 623:
        i = control-620
        return {'up':200+i,'down':600+i%2,'left':control-1 if i else 100,'right':control+1 if i<3 else 100}[direction]
    if control in (210,211,212,213):
        return {'up':100,'down':200+control-210,'left':100 if control==210 else control-1,'right':control+1 if control<213 else 100}[direction]
    if 600 <= control <= 603 or 610 <= control <= 613:
        base = 600 if control < 610 else 610
        index = control-base
        up = control-2 if index>=2 else (620+index if base==600 else 602+index)
        down = control+2 if index<2 else (610+index-2 if base==600 else 100)
        return {'up':up, 'down':down, 'left':control-1 if index%2 else 100, 'right':control+1 if index%2==0 else 100}[direction]
    if control in (420,421):
        return {'up':control,'down':control,'left':105 if control==420 else 420,'right':421 if control==420 else 425}[direction]
    if control in (424,425):
        return {'up':control,'down':control,'left':420 if control==424 else 421,'right':421 if control==424 else 105}[direction]
    if control==422:
        return {'up':101,'down':300,'left':101,'right':300}[direction]
    if control in (300,301):
        return {'up':control,'down':control,'left':100 if control==300 else 300,'right':301 if control==300 and has_programmes and page not in ('Movies','TV Series') else 100}[direction]
    raise ValueError('Unknown control')
