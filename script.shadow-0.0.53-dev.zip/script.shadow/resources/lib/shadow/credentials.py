"""Session-only credentials. No portable Kodi secure vault has been verified.

Never serialize this object or place secrets in Kodi settings. Python strings
cannot be reliably wiped from memory; clear() releases references only.
"""
from dataclasses import dataclass, field


@dataclass(repr=False)
class SessionCredentials:
    username: str = field(repr=False)
    password: str = field(repr=False)

    def __post_init__(self):
        for value in (self.username, self.password):
            if not isinstance(value, str) or not 1 <= len(value) <= 1024 or any(ord(c) < 32 or ord(c) == 127 for c in value):
                raise ValueError('Invalid provider credentials')

    def __repr__(self):
        return 'SessionCredentials(<redacted>)'

    def clear(self):
        self.username = self.password = ''

    def persist(self, *args, **kwargs):
        raise RuntimeError('Persistent credentials require a verified platform secure vault')
