"""Atomic, validated local preferences. Credentials must never be stored here."""
import json
from copy import deepcopy
import os
import tempfile
import uuid
import re
from contextlib import contextmanager
from .safe_errors import STORAGE_CODES, SafeError
from .file_sync import sync_file
from .local_files import read_regular_bytes

DEFAULTS = {'approved_channel_ids': [], 'theme': 'obsidian', 'favourites': [], 'watch_later_movies': [], 'watch_later_series': [], 'content_types': [], 'setup_completed': False, 'schema_version': 1, 'channel_order': [], 'custom_categories': {}, 'programme_artwork': True, 'browse_languages': None, 'auto_reconnect_live': False, 'autoplay_next': False, 'hide_watched': False, 'watched_movies': [], 'watched_series': [], 'subtitles_default': False, 'audio_language': '', 'rotate_featured': True, 'revision': '', 'provider_scope': ''}
_ALLOWED_CONTENT = {'live', 'movies', 'series'}

class PreferencesError(Exception):
    def __init__(self, message, code='S413'):
        super().__init__(message)
        self.code = code if isinstance(code, str) and code in STORAGE_CODES else 'S413'

class PreferencesConflict(PreferencesError):
    pass

def _defaults():
    return deepcopy(DEFAULTS)

def _validate(data):
    if not isinstance(data, dict):
        raise PreferencesError('Invalid preferences structure')
    if type(data.get('schema_version', 1)) is not int or data.get('schema_version', 1) != 1:
        raise PreferencesError('Unsupported preferences version')
    for key, length in (('revision', 32), ('provider_scope', 64)):
        value = data.get(key, '')
        if not isinstance(value, str) or (value and not re.fullmatch('[0-9a-f]{%s}' % length, value)):
            raise PreferencesError('Invalid settings identity')
    result = _defaults()
    for key in DEFAULTS:
        if key in data:
            result[key] = deepcopy(data[key])
    for key in ('approved_channel_ids', 'favourites', 'channel_order', 'watched_movies', 'watched_series'):
        values = result[key]
        if not isinstance(values, list) or len(values) > 100000 or any(not isinstance(x, str) or len(x) > 128 for x in values):
            raise PreferencesError('Invalid preferences field: ' + key)
        result[key] = list(dict.fromkeys(values))
    for key in ('watch_later_movies', 'watch_later_series'):
        values = result[key]
        if not isinstance(values,list) or len(values)>1000 or any(not isinstance(v,str) or not 1<=len(v)<=128 for v in values):
            raise PreferencesError('Invalid watch later selection')
        result[key] = list(dict.fromkeys(values))
    content = result['content_types']
    if not isinstance(content, list) or any(not isinstance(x, str) or x not in _ALLOWED_CONTENT for x in content):
        raise PreferencesError('Invalid content selection')
    result['content_types'] = list(dict.fromkeys(content))
    if not isinstance(result['setup_completed'], bool):
        raise PreferencesError('Invalid setup status')
    if not isinstance(result['theme'], str) or not 1 <= len(result['theme']) <= 64:
        raise PreferencesError('Invalid theme')
    if not isinstance(result['programme_artwork'], bool):
        raise PreferencesError('Invalid artwork preference')
    if type(result['subtitles_default']) is not bool or type(result['rotate_featured']) is not bool:
        raise PreferencesError('Invalid playback preference')
    if type(result['auto_reconnect_live']) is not bool or type(result['autoplay_next']) is not bool or type(result['hide_watched']) is not bool:
        raise PreferencesError('Invalid personal playback preference')
    if result['audio_language'] not in ('', 'English', 'French', 'German', 'Spanish', 'Italian', 'Portuguese'):
        raise PreferencesError('Invalid audio preference')
    languages=result['browse_languages']
    if languages is not None and (not isinstance(languages,list) or len(languages)>64 or any(not isinstance(v,str) or not 1<=len(v)<=64 for v in languages)):
        raise PreferencesError('Invalid browsing languages')
    categories = result['custom_categories']
    if not isinstance(categories, dict) or len(categories) > 100:
        raise PreferencesError('Invalid custom categories')
    for name, ids in categories.items():
        if not isinstance(name, str) or not 1 <= len(name) <= 64 or not isinstance(ids, list) or len(ids) > 100000 or any(not isinstance(i, str) or len(i) > 128 for i in ids):
            raise PreferencesError('Invalid custom category')
    return result

MAX_SETTINGS_BYTES = 4 * 1024 * 1024

def _read(path):
    try:
        body = read_regular_bytes(path,MAX_SETTINGS_BYTES)
        if len(body)>MAX_SETTINGS_BYTES:
            raise PreferencesError('Preferences exceed size limit')
        data = json.loads(body.decode('utf-8'))
    except FileNotFoundError:
        raise
    except (OSError, ValueError, UnicodeError, RecursionError, AttributeError, NotImplementedError):
        raise PreferencesError('Preferences could not be read; existing selections were preserved', 'S412') from None
    try:
        return _validate(data)
    except PreferencesError:
        raise PreferencesError('Preferences validation failed', 'S412') from None

def load(path):
    try:
        return _read(path)
    except FileNotFoundError:
        # Missing primary with a backup may be an interrupted operation.
        if os.path.exists(str(path) + '.bak'):
            raise PreferencesError('Primary settings missing; explicit recovery is required')
        return _defaults()

@contextmanager
def _lock(path):
    lock = str(path) + '.lock'
    try:
        os.mkdir(lock, 0o700)
    except FileExistsError:
        raise PreferencesError('Settings are busy; retry later', 'S402') from None
    except (OSError, AttributeError, NotImplementedError):
        raise PreferencesError('Could not lock settings', 'S403') from None
    try:
        yield
    finally:
        try:
            os.rmdir(lock)
        except (OSError, AttributeError, NotImplementedError):
            raise PreferencesError('Could not release settings lock', 'S411') from None


def _atomic(path, validated):
    directory = os.path.dirname(os.path.abspath(path))
    temp_path = None
    stage = 'S406'
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=directory, prefix='.shadow-', suffix='.tmp', delete=False) as fh:
            temp_path = fh.name
            stage = 'S407'
            os.chmod(temp_path, 0o600)
            body = json.dumps(validated, indent=2)
            if len(body.encode('utf-8')) > MAX_SETTINGS_BYTES:
                raise PreferencesError('Preferences exceed size limit')
            stage = 'S408'
            fh.write(body)
            fh.flush()
            stage = 'S409'
            sync_file(fh, temp_path)
        stage = 'S410'
        os.replace(temp_path, path)
        temp_path = None
    except SafeError as error:
        raise PreferencesError('Could not sync local settings', error.code) from None
    except (OSError, AttributeError, NotImplementedError):
        raise PreferencesError('Could not save preferences', stage) from None
    finally:
        if temp_path is not None:
            try:
                os.unlink(temp_path)
            except OSError:
                pass


def save(path, data, *, expected_revision=None):
    """Serialize cooperating writers; keep last valid revision, never overwrite corrupt primary.

    A crash can leave .lock behind. Fail closed; removal requires checking that
    no writer is running. No automatic stale-lock deletion or backup rollback.
    """
    validated = _validate(data)
    directory = os.path.dirname(os.path.abspath(path))
    try:
        os.makedirs(directory, exist_ok=True)
        with _lock(path):
            try:
                previous = _read(path)
            except FileNotFoundError:
                if os.path.exists(str(path) + '.bak'):
                    raise PreferencesError('Explicit settings recovery is required')
                previous = None
            actual_revision = previous['revision'] if previous is not None else ''
            if expected_revision is not None and actual_revision != expected_revision:
                raise PreferencesConflict('Settings changed in another window; reload before saving')
            validated['revision'] = uuid.uuid4().hex
            if previous is not None:
                _atomic(str(path) + '.bak', previous)
            _atomic(path, validated)
            return deepcopy(validated)
    except (OSError, AttributeError, NotImplementedError):
        raise PreferencesError('Could not create settings directory', 'S401') from None


def recover(path, *, confirmed=False, expected_scope=None):
    try:
        return _recover(path, confirmed=confirmed, expected_scope=expected_scope)
    except (OSError, AttributeError, NotImplementedError):
        raise PreferencesError('Could not read settings for recovery', 'S412') from None


def _recover(path, *, confirmed=False, expected_scope=None):
    """Explicitly restore last known valid revision. Older approvals may reappear.

    UI must explain rollback and request confirmation; corrupt primary is retained
    separately for diagnosis. Recovery never stores credentials.
    """
    if not confirmed:
        raise PreferencesError('Recovery requires explicit confirmation of settings rollback')
    with _lock(path):
        try:
            backup = _read(str(path) + '.bak')
        except FileNotFoundError:
            raise PreferencesError('No settings backup is available') from None
        if expected_scope is not None and backup['provider_scope'] != expected_scope:
            raise PreferencesError('Backup belongs to a different provider account')
        backup['revision'] = uuid.uuid4().hex
        if os.path.exists(path):
            # Do not parse or blindly duplicate untrusted large files.
            if os.path.getsize(path) > MAX_SETTINGS_BYTES:
                raise PreferencesError('Corrupt settings exceed recovery limit')
            try:
                damaged = read_regular_bytes(path, MAX_SETTINGS_BYTES)
            except (OSError, AttributeError, NotImplementedError):
                raise PreferencesError('Could not preserve damaged settings', 'S412') from None
            if len(damaged) > MAX_SETTINGS_BYTES:
                raise PreferencesError('Corrupt settings exceed recovery limit')
            atomic_bytes(str(path) + '.damaged', damaged)
        _atomic(path, backup)
        return backup


def atomic_bytes(path, body):
    """Local bounded byte write used for recovery evidence and scope keys."""
    temporary = None
    stage = 'S406'
    try:
        directory = os.path.dirname(os.path.abspath(path))
        with tempfile.NamedTemporaryFile(dir=directory, prefix='.shadow-', suffix='.tmp', delete=False) as target:
            temporary = target.name
            stage = 'S407'
            os.chmod(temporary, 0o600)
            stage = 'S408'
            target.write(body)
            target.flush()
            stage = 'S409'
            sync_file(target, temporary)
        stage = 'S410'
        os.replace(temporary, path)
        temporary = None
    except SafeError as error:
        raise PreferencesError('Could not sync local data', error.code) from None
    except (OSError, AttributeError, NotImplementedError):
        raise PreferencesError('Could not save local data', stage) from None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass
