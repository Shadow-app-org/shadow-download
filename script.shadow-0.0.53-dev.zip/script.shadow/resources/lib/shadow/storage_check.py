"""Isolated, credential-free storage probe using the production account/write path."""
import tempfile
import os
from .accounts import AccountStore, _scope_key
from . import preferences
from .safe_errors import SafeError


def check_storage(profile):
    temporary = None
    step = 'temporary folder'
    try:
        try:
            temporary = tempfile.TemporaryDirectory(prefix='.shadow-storage-check-', dir=profile)
        except (OSError, AttributeError, NotImplementedError):
            raise SafeError('S401') from None
        directory = temporary.name
        from .sqlite_accounts import selected, SQLiteAccounts
        step = 'identity creation'
        key = (SQLiteAccounts(directory).key() if selected(os.path.join(profile, 'accounts'))
               else _scope_key(directory))
        step = 'identity reopen'
        if key != _scope_key(directory):
            raise SafeError('S414')
        step = 'account open'
        store = AccountStore(directory, 'https://storage-check.invalid/player_api.php', 'local-test')
        step = 'preferences read'
        original = store.load()
        step = 'first save'
        first = store.save(original, original['revision'])
        changed = dict(first)
        changed['theme'] = 'charcoal'
        step = 'second save'
        second = store.save(changed, first['revision'])
        step = 'backup read'
        backup = store.backup()
        step = 'saved readback'
        if store.load() != second or backup != first:
            raise SafeError('S414')
        return True
    except preferences.PreferencesError as error:
        failure = SafeError(error.code)
        failure.storage_detail = getattr(error, 'storage_detail', None)
        failure.storage_step = step
        raise failure from None
    except SafeError:
        raise
    except Exception:
        raise SafeError('S413') from None
    finally:
        if temporary is not None:
            try:
                temporary.cleanup()
            except Exception:
                raise SafeError('S415') from None
