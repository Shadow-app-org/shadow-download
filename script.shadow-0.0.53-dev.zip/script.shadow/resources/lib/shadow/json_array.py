"""Incremental UTF-8 JSON array reader without a total byte or item-count cap.

Only the current JSON item is buffered as text. Completed rows can be projected
before retention. The resulting catalogue still needs memory proportional to
its retained metadata; a single exceptionally large item also needs memory.
"""
import codecs
import json
from .cancellation import checkpoint

SKIP = object()


class ArrayError(Exception):
    def __init__(self, code='X403'):
        self.code = 'X408' if code == 'X408' else 'X403'
        super().__init__(self.code)


class JSONArray:
    def __init__(self, project=lambda value: value):
        self._utf8 = codecs.getincrementaldecoder('utf-8')('strict')
        self._project = project
        self.rows = []
        self._state = 'start'
        self._parts = []
        self._depth = 0
        self._string = False
        self._escape = False
        self._has_item = False
        self._after_comma = False

    def feed(self, data):
        checkpoint()
        try:
            self._text(self._utf8.decode(data))
        except (UnicodeError, TypeError):
            raise ArrayError() from None

    def _item(self):
        checkpoint()
        try:
            value = json.loads(''.join(self._parts))
        except (ValueError, RecursionError):
            raise ArrayError() from None
        self._parts.clear()
        self._has_item = False
        value = self._project(value)
        if value is not SKIP:
            self.rows.append(value)

    def _text(self, text):
        begin = 0
        for pos, char in enumerate(text):
            if self._state == 'start':
                begin = pos + 1
                if char in ' \t\r\n':
                    continue
                if char != '[':
                    raise ArrayError('X408')
                self._state = 'items'
                continue
            if self._state == 'done':
                begin = pos + 1
                if char not in ' \t\r\n':
                    raise ArrayError()
                continue
            if self._string:
                if self._escape:
                    self._escape = False
                elif char == '\\':
                    self._escape = True
                elif char == '"':
                    self._string = False
                continue
            if self._depth == 0 and char in ',]':
                self._parts.append(text[begin:pos])
                begin = pos + 1
                if self._has_item:
                    self._item()
                elif char == ',' or self._after_comma:
                    raise ArrayError()
                else:
                    self._parts.clear()
                if char == ']':
                    self._state = 'done'
                else:
                    self._after_comma = True
                continue
            if char not in ' \t\r\n':
                self._has_item = True
                self._after_comma = False
            if char == '"':
                self._string = True
            elif char in '[{':
                self._depth += 1
            elif char in ']}':
                self._depth -= 1
                if self._depth < 0:
                    raise ArrayError()
        if self._state == 'items':
            # Drop whitespace between records instead of accumulating it.
            tail = text[begin:]
            if self._has_item:
                self._parts.append(tail)

    def finish(self):
        checkpoint()
        try:
            self._text(self._utf8.decode(b'', final=True))
        except UnicodeError:
            raise ArrayError() from None
        if self._state != 'done':
            raise ArrayError()
        return self.rows


def channel_fields(value):
    """Keep only fields used by existing live-channel normalization."""
    if not isinstance(value, dict):
        return SKIP
    return {key: value[key] for key in
            ('stream_id', 'name', 'category_id', 'stream_icon', 'epg_channel_id')
            if key in value}
