"""Model an existing-marker error variant against unchanged .48 source.
This is a compatibility hypothesis, not a reproduction on the physical Xbox.
"""
import errno
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
root = Path(__file__).resolve().parent.parent
source = Path(sys.argv[1]) if len(sys.argv)>1 else root/'work48/script.shadow'
sys.path.insert(0, str(source/'resources/lib'))
from shadow import sqlite_accounts as backend, build_info, preferences
assert build_info.VERSION == '0.0.48'
original = os.mkdir
calls = []
def mkdir(path, *args, **kwargs):
    if os.path.basename(os.fspath(path)) == backend.MARKER:
        calls.append(True)
        if os.path.lexists(path):
            raise PermissionError(errno.EACCES, 'synthetic marker collision')
    return original(path, *args, **kwargs)
with tempfile.TemporaryDirectory(prefix='shadow48-reproduction-') as directory:
    store = backend.SQLiteAccounts(directory)
    with patch.object(os, 'mkdir', side_effect=mkdir):
        key = store.key()
        try:
            store.key()
        except preferences.PreferencesError as error:
            code = error.code
        else:
            raise AssertionError('Expected .48 to fail this modeled collision')
    assert store.key() == key
assert code == 'S452' and len(calls) == 2
print(json.dumps({'version':'0.0.48','result':'MODELED FAILURE REPRODUCED',
    'code':code, 'marker_create_attempts':len(calls), 'identity_preserved':True,
    'assumption':'Existing-marker mkdir raises PermissionError instead of FileExistsError',
    'limitation':'Xbox exception type is unknown; this is a simulated compatibility scenario.'},indent=2))
