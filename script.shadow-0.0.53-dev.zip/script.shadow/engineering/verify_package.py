"""Build and verify the single installable .53 catalogue deadline handover ZIP."""
import ast
import hashlib
import json
import os
from pathlib import Path
import py_compile
import re
import tempfile
import xml.etree.ElementTree as ET
import zipfile

engineering = Path(__file__).resolve().parent
root = engineering.parent
source = root if (root/'addon.xml').is_file() else root/'work53/script.shadow'
output = root/'deliverables/script.shadow-0.0.53-dev.zip'
output.parent.mkdir(exist_ok=True)
reports = engineering/'reports'
reports.mkdir(exist_ok=True)
files = {p.relative_to(source).as_posix(): p.read_bytes()
         for p in source.rglob('*') if p.is_file() and '__pycache__' not in p.parts
         and p.suffix != '.pyc' and 'engineering' not in p.relative_to(source).parts
         and 'deliverables' not in p.relative_to(source).parts}
runtime_names = set(files)
for relative in ['run_tests.py', 'verify_package.py', 'verify_compatibility.py', 'reproduce_47.py', 'reproduce_48.py', 'reproduce_50.py', 'reproduce_53.py', 'HANDOVER.txt',
                 'reports/test-summary.json', 'reports/test-output.txt',
                 'reports/python312-test-output.txt', 'reports/initial-test-output.txt',
                 'reports/second-test-output.txt', 'reports/52-before.json', 'reports/53-after.json',
                 'reports/python38-test-summary.json', 'reports/python38-test-output.txt',
                 'reports/python312-test-summary.json', 'reports/compatibility-38.json',
                 'reports/compatibility-312.json', 'reports/github-status.json',
                 'reports/50-before.json', 'reports/51-after.json', 'reports/47-reproduction.json', 'reports/48-reproduction.json', 'reports/source-investigation.json']:
    files['engineering/'+relative] = (engineering/relative).read_bytes()
for p in sorted((engineering/'tests').glob('*.py')):
    files['engineering/tests/'+p.name] = p.read_bytes()
test_summary = json.loads(files['engineering/reports/test-summary.json'])
assert test_summary['successful'] and test_summary['tests'] == 432
assert all(test_summary[k] == 0 for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
for name in ('python38-test-summary.json','python312-test-summary.json'):
    recorded = json.loads(files['engineering/reports/'+name])
    assert recorded['tests'] == 432 and recorded['successful']
    assert all(recorded[k] == 0 for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
addon = ET.fromstring(files['addon.xml'])
tree = ast.parse(files['resources/lib/shadow/build_info.py'])
version = ast.literal_eval(tree.body[1].value)
assert addon.attrib['id'] == 'script.shadow'
assert addon.attrib['version'] == version == '0.0.53'
entry = addon.find("extension[@point='xbmc.python.script']").attrib['library']
assert entry in files and addon.find("requires/import[@addon='xbmc.python']") is not None
assert 'resources/skins/Default/1080i/Shadow.xml' in files
assert all(not n.startswith('/') and '..' not in Path(n).parts for n in files)
assert not any(n.endswith(('.pyc','.bak','.tmp','.lock','.sqlite','.sqlite3','scope-key.bin',
                          'remembered-xtream.json','connection-permissions.json')) for n in files)

collection = ET.fromstring(files['resources/skins/Default/1080i/ShadowCollection.xml'])
assert collection.find(".//control[@id='920']").attrib['type'] == 'progress'
assert collection.find(".//control[@id='910']").attrib['type'] == 'button'
# Brand-only pulse must not animate progress, status, or controller controls.
for name in ('ShadowCollection.xml','ShadowLoading.xml','Shadow.xml'):
    window = ET.fromstring(files['resources/skins/Default/1080i/'+name])
    glow = window.find(".//control[@description='shadow-loading-glow']")
    brand = window.find(".//control[@description='shadow-loading-brand-wordmark']")
    assert glow is not None and brand is not None
    assert len(glow.findall('control')) == 8
    for control in (glow, brand):
        pulse = control.find('animation')
        assert pulse.attrib['pulse'] == 'true' and pulse.attrib['time'] == '1100'
    scope = window.find(".//control[@description='playback-loading-cover']") if name == 'Shadow.xml' else window
    assert not any(c.findall('.//animation') for c in scope.findall('.//control')
                   if c.attrib.get('type') in ('progress','label','button'))
assert 'resources/skins/Default/media/shadow-white.png' in files

comparison = 'NOT REPEATED: .52 working source is not available here'
baseline = root/'work52/script.shadow'
if baseline.is_dir():
    old = {p.relative_to(baseline).as_posix(): p.read_bytes()
           for p in baseline.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    added = runtime_names - set(old)
    removed = set(old) - runtime_names
    changed = {n for n in old if files.get(n) != old[n]}
    assert not added
    assert not removed
    assert changed == {'addon.xml','resources/lib/shadow/build_info.py',
                       'resources/lib/shadow/collection_progress.py',
                       'resources/lib/shadow/transport.py','resources/lib/shadow/provider.py',
                       'resources/lib/shadow/safe_errors.py',
                       'resources/skins/Default/1080i/Shadow.xml',
                       'resources/skins/Default/1080i/ShadowLoading.xml',
                       'resources/skins/Default/1080i/ShadowCollection.xml'}
    comparison = {'result':'PASS', 'added':sorted(added), 'changed':sorted(changed),
                  'unchanged_runtime_files':len(old)-len(changed), 'removed':[]}

patterns = {
    'private_key': r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'github_token': r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b',
    'openai_key': r'\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b',
    'aws_access_key': r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'embedded_url_credentials': r'https?://[^\s\"\x27<>]+:[^\s\"\x27<>]+@',
    'literal_url_password': r'https?://[^\s\"\x27<>]*[?&](?:password|token|api_key)=[A-Za-z0-9_%.-]{4,}'
}
findings = []
allowed = []
compiled = []
xmls = []
text_files = 0
with tempfile.TemporaryDirectory(prefix='shadow-compile-') as temporary:
    for name, data in sorted(files.items()):
        suffix = Path(name).suffix
        if suffix == '.xml':
            ET.fromstring(data)
            xmls.append(name)
        if suffix not in ('.py','.xml','.txt','.md','.json'):
            continue
        text = data.decode('utf-8')
        text_files += 1
        for rule, pattern in patterns.items():
            for match in re.finditer(pattern, text):
                finding = {'file':name,'line':text.count('\n',0,match.start())+1,'rule':rule}
                if (name == 'engineering/tests/test_remembered_state.py' and
                        rule == 'literal_url_password' and
                        hashlib.sha256(match.group().encode()).hexdigest() == '2b70caf03e8bc5e3bfe17671845ef24f809e24c61eabb8c6b38a9cf624b6c16d'):
                    allowed.append(dict(finding, reason='Exact synthetic .invalid rejected-input fixture'))
                else:
                    findings.append(finding)
        if suffix == '.py':
            temp_source = Path(temporary)/str(len(compiled))
            temp_source.write_bytes(data)
            py_compile.compile(str(temp_source), cfile=str(temp_source)+'.pyc', doraise=True)
            compiled.append(name)
            for node in ast.walk(ast.parse(data)):
                if not isinstance(node, (ast.Assign, ast.AnnAssign)):
                    continue
                value = node.value
                if not isinstance(value, ast.Constant) or not isinstance(value.value, str) or not value.value:
                    continue
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for target in targets:
                    key = target.id if isinstance(target, ast.Name) else target.attr if isinstance(target, ast.Attribute) else ''
                    if key.lower() not in ('password','api_key','access_token','secret_key','username'):
                        continue
                    finding = {'file':name,'line':node.lineno,'rule':'literal_sensitive_assignment'}
                    if name == 'engineering/tests/test_regressions.py' and key == 'PASSWORD' and value.value == 'fixture-password':
                        allowed.append(dict(finding, reason='Explicit synthetic .invalid test credential'))
                    else:
                        findings.append(finding)
assert not findings, findings

summary = {
    'build':'0.0.53 bounded catalogue downloads and diagnostics development candidate', 'tests':test_summary,
    'runtime_files':len(runtime_names), 'compiled_python_files':len(compiled),
    'xml_files_parsed':len(xmls), 'zip_integrity':'PASS',
    'source_package_byte_comparison':'PASS', 'kodi_structure':'PASS (static only)',
    'comparison_to_52':comparison,
    'secret_scan':{'text_files':text_files,'unresolved_findings':findings,
                   'synthetic_fixture_allowlist':allowed,'scope':'All runtime and engineering text before generated manifests',
                   'limitation':'Heuristic scanning is not proof that all possible secrets are absent.'},
    'catalogue_stall_root_cause_on_xbox':'UNCONFIRMED', 'progress_ui_on_xbox':'NOT YET TESTED', 'remembered_login_fix_on_xbox':'NOT YET CONFIRMED', 'live_reconnect_on_xbox':'NOT YET TESTED', 'account_backend_changed':False, 'remembered_login_consent_backend_changed':False,
    'file_sync_tls_credentials_redirect_controls':'TLS/auth/redirect controls and opt-in unencrypted credential policy unchanged from .52',
    'github_commit':'NOT COMPLETED: Shadow repository unavailable'
}
verification = (json.dumps(summary,indent=2)+'\n').encode()
files['engineering/reports/package-verification.json'] = verification
manifest = {n:hashlib.sha256(data).hexdigest() for n,data in sorted(files.items())}
manifest_data = (json.dumps(manifest,indent=2)+'\n').encode()
files['engineering/reports/source-manifest.json'] = manifest_data
(reports/'package-verification.json').write_bytes(verification)
(reports/'source-manifest.json').write_bytes(manifest_data)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo('script.shadow/'+name,date_time=(2026,10,20,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        archive.writestr(info,data)
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    for name,data in files.items():
        assert archive.read('script.shadow/'+name) == data
delivery = dict(summary,package_files=len(files),bytes=output.stat().st_size,
                sha256=hashlib.sha256(output.read_bytes()).hexdigest(),path=str(output))
print(json.dumps(delivery,indent=2))
