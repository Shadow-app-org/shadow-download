"""Run SHD-053 account storage tests with an enforced outbound-network prohibition."""
import json
import os
from pathlib import Path
import socket
import sys
import unittest
from unittest.mock import patch

root=Path(__file__).resolve().parent.parent
engineering=Path(__file__).resolve().parent
os.chdir(root)
os.environ.setdefault('SHADOW_SOURCE', str(root if (root/'addon.xml').exists() else root/'work53/script.shadow'))
sys.path.insert(0,str(engineering/'tests'))
# Fixtures replace network edges explicitly. Any accidental real network use fails.
with patch.object(socket.socket,'connect',side_effect=AssertionError('Live networking prohibited by test runner')),patch.object(socket,'getaddrinfo',side_effect=AssertionError('Live DNS prohibited by test runner')):
    suite=unittest.defaultTestLoader.discover(str(engineering/'tests'))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
summary={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses),'successful':result.wasSuccessful(),'python':sys.version,'source':os.environ.get('SHADOW_SOURCE','work53/script.shadow'),'network':'Socket connect and live getaddrinfo blocked; all network fixtures mocked','failed_tests':[str(t) for t,_ in result.failures+result.errors]}
(engineering/'reports').mkdir(exist_ok=True)
(engineering/'reports/test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)
