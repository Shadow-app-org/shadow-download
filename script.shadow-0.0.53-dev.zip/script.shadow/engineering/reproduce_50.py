"""Deterministic pre/post checks. Models UI waiting; does not reproduce Xbox OS."""
import json
import os
from pathlib import Path
import sys
import types
from unittest.mock import Mock, patch
engineering=Path(__file__).resolve().parent
sys.path.insert(0,str(engineering/'tests'))
import test_wizard
from shadow import kodi_ui, jobs

w=types.SimpleNamespace(session=Mock(),dialog=Mock())
w.session.media_loaded={};w.session.media_request.return_value=lambda:None
error=jobs.JobError('Synthetic failure');error.code='N503';error.http_status=503
w.run_job=Mock(side_effect=error)
kodi_ui.ShadowWindow.ensure_catalogue(w,'movies')
message=' '.join(w.dialog.ok.call_args.args)

clock=[0]
job=Mock();job.done.is_set.side_effect=[False,False,True];job.take.return_value='late-result'
owner=types.SimpleNamespace(jobs=Mock(),addon_path='fixture');owner.jobs.submit.return_value=job
progress=Mock();progress.iscanceled.return_value=False
monitor=Mock()
def wait(_):clock[0]+=61;return False
monitor.waitForAbort.side_effect=wait
code=None;value=None
with patch.object(kodi_ui,'CollectionProgress',return_value=progress),patch.object(kodi_ui.xbmc,'Monitor',return_value=monitor,create=True),patch.object(kodi_ui.time,'monotonic',side_effect=lambda:clock[0]):
    try:value=kodi_ui.ShadowWindow.run_job(owner,'Loading collection...',lambda:None)
    except jobs.JobError as failure:code=getattr(failure,'code',None)
events=[]
switch=kodi_ui.ShadowWindow.__new__(kodi_ui.ShadowWindow)
switch.running=True;switch.switch_state=None;switch.playing_channel='1'
switch.session=Mock();switch.session.visible.return_value=[{'stream_id':'1'},{'stream_id':'2'}]
switch.playback=Mock();switch.playback.url='local-test-stream'
switch.playback.stop.side_effect=lambda:events.append('stop')
switch.close_overlay=lambda:events.append('overlay-close')
switch.clear_playback_clock=Mock();switch.setProperty=Mock()
switch.show=lambda:events.append('window-show')
switch.show_loading_cover=lambda:events.append('cover-show')
switch.request_switch('2')
print(json.dumps({'switch_request_order':events, 'source':os.environ['SHADOW_SOURCE'],'http_503_visible':'HTTP 503' in message,
                  'mocked_elapsed_seconds':clock[0],'timeout_code':code,'late_result_adopted':value=='late-result',
                  'limitation':'Mocked UI/clock/provider; not a reproduction of the unknown Xbox catalogue stall.'},indent=2))
