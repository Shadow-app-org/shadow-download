"""Reproduce the old catalogue budget against an explicitly supplied source."""
import io
import json
from pathlib import Path
import socket
import sys
from email.message import Message
from unittest.mock import Mock, patch

sys.path.insert(0,str(Path(sys.argv[1]).resolve()/'resources/lib'))
# Bind safe defaults before importing transport.
with patch.object(socket.socket,'connect',side_effect=AssertionError('Live networking prohibited')),patch.object(socket,'getaddrinfo',side_effect=AssertionError('Live DNS prohibited')):
    from shadow import transport
    results={}
    for case in ('progress_140_seconds','wrapped_idle_30_seconds'):
        clock=[0];reply=Mock(status=200);reply.headers=Message()
        reply.getheader.side_effect=lambda key,default=None:reply.headers.get(key,default)
        chunks=[b'[',b'{"stream_id":1}',b',',b'{"stream_id":2}',b']',b' ',b' ']
        def read(_):
            if case=='wrapped_idle_30_seconds':clock[0]=30;raise OSError('synthetic wrapped read failure')
            if not chunks:return b''
            clock[0]+=20;return chunks.pop(0)
        reply.read.side_effect=read
        conn=Mock();conn.getresponse.return_value=reply
        answers=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('203.0.113.1',443))]
        with patch.object(transport.time,'monotonic',side_effect=lambda:clock[0]),patch.object(transport,'_Connection',return_value=conn),patch.object(transport._DNS,'resolve',return_value=answers):
            try:
                rows=transport.request_media_catalogue('https://fixture.invalid')
                result={'result':'completed','records':len(rows)}
            except Exception as error:result={'result':'rejected','code':getattr(error,'code','unclassified')}
        result.update(elapsed=clock[0],response_closed=reply.close.call_count==1,connection_closed=conn.close.call_count==1)
        results[case]=result
print(json.dumps({'source':str(Path(sys.argv[1]).resolve()),'network':'mocked only','cases':results,'limitation':'Synthetic reproduction; console exception and provider behavior remain unconfirmed.'},indent=2))
