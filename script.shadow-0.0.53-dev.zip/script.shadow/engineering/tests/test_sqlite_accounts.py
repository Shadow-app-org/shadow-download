"""SQLite migration/recovery, real transactions and process-interruption coverage."""
import builtins
import errno
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch

from test_regressions import DiskCase, accounts, preferences, URL, USER, PASSWORD, RAW
from shadow import sqlite_accounts as backend
from shadow.storage_check import check_storage
from test_wizard import WizardTests as _WizardTests


class SQLiteTests(DiskCase):
    def store(self):
        with patch.object(backend, 'selected', return_value=True):
            return super().store()

    def saved(self):
        store = self.store()
        data = store.load()
        data.update(theme='charcoal', favourites=['1'], approved_channel_ids=['1'])
        return store, store.save(data, data['revision'])

    def database(self, store):
        return Path(store.sqlite.path)

    def mutate(self, store, sql, values=()):
        db = sqlite3.connect(store.sqlite.path)
        try:
            db.execute(sql, values)
            db.commit()
        finally:
            db.close()

    def test_fresh_store_saves_and_reopens_without_python_fsync(self):
        with patch.object(os, 'fsync', side_effect=AttributeError(RAW)) as sync:
            store, saved = self.saved()
            self.assertEqual(self.store().load(), saved)
        sync.assert_not_called()
        self.assertFalse(Path(store.path).exists())
        self.assertEqual(saved['theme'], 'charcoal')

    def test_runtime_selection_is_narrow_and_database_selection_is_sticky(self):
        path = str(self.root)
        with patch.object(backend, 'os', SimpleNamespace(name='nt', path=os.path, lstat=os.lstat)):
            self.assertTrue(backend.selected(path))
        with patch.object(backend, 'os', SimpleNamespace(name='posix', path=os.path, lstat=os.lstat)):
            self.assertFalse(backend.selected(path))
        store = self.store()
        self.assertTrue(backend.selected(str(Path(store.path).parent)))

    def test_account_key_and_scope_are_stable(self):
        first = self.store()
        second = self.store()
        self.assertEqual(first.scope, second.scope)
        self.assertEqual(first.sqlite.key(), second.sqlite.key())

    def test_accounts_are_isolated_and_credentials_absent_from_database(self):
        first, saved = self.saved()
        second = accounts.AccountStore(str(Path(first.path).parent), URL, 'different-user')
        self.assertNotEqual(first.scope, second.scope)
        self.assertEqual(second.load()['favourites'], [])
        self.assertEqual(first.load(), saved)
        body = self.database(first).read_bytes()
        for value in (URL, USER, PASSWORD):
            self.assertNotIn(value.encode(), body)

    def test_transactions_keep_previous_revision(self):
        store, saved = self.saved()
        changed = store.save(dict(saved, theme='obsidian'), saved['revision'])
        self.assertEqual(store.backup(), saved)
        self.assertEqual(store.load(), changed)

    def test_stale_revision_cannot_overwrite_primary_or_backup(self):
        store, saved = self.saved()
        changed = store.save(dict(saved, theme='obsidian'), saved['revision'])
        with self.assertRaises(preferences.PreferencesConflict):
            store.save(saved, saved['revision'])
        self.assertEqual(store.load(), changed)
        self.assertEqual(store.backup(), saved)

    def test_different_scope_save_is_rejected(self):
        store, saved = self.saved()
        with self.assertRaises(preferences.PreferencesError):
            store.save(dict(saved, provider_scope='a'*64), saved['revision'])
        self.assertEqual(store.load(), saved)

    def test_json_migration_preserves_key_scope_preferences_backup_and_original_bytes(self):
        legacy = super().store()
        first = legacy.save(dict(legacy.load(), theme='charcoal'), '')
        latest = legacy.save(dict(first, favourites=['1']), first['revision'])
        parent = Path(legacy.path).parent
        original = {p.name:p.read_bytes() for p in parent.iterdir() if p.is_file()}
        migrated = self.store()
        self.assertEqual(migrated.scope, legacy.scope)
        self.assertEqual(migrated.load(), latest)
        self.assertEqual(migrated.backup(), first)
        migrated.save(dict(latest, theme='obsidian'), latest['revision'])
        self.assertEqual({name:(parent/name).read_bytes() for name in original}, original)

    def test_legacy_change_after_migration_fails_closed(self):
        legacy = super().store()
        previous = legacy.save(legacy.load(), '')
        migrated = self.store()
        self.assertEqual(migrated.load(), previous)
        legacy.save(dict(previous, theme='charcoal'), previous['revision'])
        with self.assertRaises(preferences.PreferencesError) as error:
            migrated.load()
        self.assertEqual(error.exception.code, 'S434')

    def test_missing_legacy_identity_is_not_replaced(self):
        legacy = super().store()
        legacy.save(legacy.load(), '')
        (Path(legacy.path).parent/'scope-key.bin').unlink()
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S404')

    def test_changed_legacy_identity_is_rejected(self):
        legacy = super().store()
        migrated = self.store()
        (Path(legacy.path).parent/'scope-key.bin').write_bytes(b'x'*32)
        with self.assertRaises(preferences.PreferencesError) as error:
            migrated.load()
        self.assertEqual(error.exception.code, 'S404')

    def test_legacy_account_lock_is_not_removed(self):
        legacy = super().store()
        Path(legacy.path+'.lock').mkdir()
        migrated = self.store()
        with self.assertRaises(preferences.PreferencesError) as error:
            migrated.load()
        self.assertEqual(error.exception.code, 'S402')
        self.assertTrue(Path(legacy.path+'.lock').is_dir())

    def test_corrupt_legacy_primary_blocks_load_and_explicit_recovery_retains_evidence(self):
        legacy = super().store()
        first = legacy.save(dict(legacy.load(), theme='charcoal'), '')
        legacy.save(dict(first, theme='obsidian'), first['revision'])
        Path(legacy.path).write_bytes(b'corrupt original')
        migrated = self.store()
        with self.assertRaises(preferences.PreferencesError):
            migrated.load()
        with self.assertRaises(preferences.PreferencesError):
            migrated.recover()
        restored = migrated.recover(confirmed=True)
        self.assertEqual(restored['theme'], 'charcoal')
        self.assertNotEqual(restored['revision'], first['revision'])
        self.assertEqual(Path(legacy.path).read_bytes(), b'corrupt original')
        self.assertEqual(migrated.load(), restored)

    def test_missing_legacy_primary_with_backup_requires_explicit_recovery(self):
        legacy = super().store()
        first = legacy.save(dict(legacy.load(), theme='charcoal'), '')
        legacy.save(first, first['revision'])
        Path(legacy.path).unlink()
        migrated = self.store()
        with self.assertRaises(preferences.PreferencesError):
            migrated.load()
        self.assertEqual(migrated.recover(confirmed=True)['theme'], 'charcoal')

    def test_corrupt_database_primary_recovery_preserves_raw_evidence(self):
        store, first = self.saved()
        store.save(dict(first, theme='obsidian'), first['revision'])
        self.mutate(store, 'UPDATE accounts SET current=? WHERE scope=?', (b'damaged row', store.scope))
        with self.assertRaises(preferences.PreferencesError):
            store.load()
        restored = store.recover(confirmed=True)
        self.assertEqual(restored['theme'], 'charcoal')
        db = sqlite3.connect(store.sqlite.path)
        try:
            self.assertEqual(db.execute('SELECT damaged FROM accounts').fetchone(), (b'damaged row',))
        finally:
            db.close()

    def test_corrupt_or_wrong_scope_backup_cannot_be_recovered(self):
        store, saved = self.saved()
        for body in (b'bad json', json.dumps(dict(saved, provider_scope='a'*64)).encode()):
            self.mutate(store, 'UPDATE accounts SET previous=? WHERE scope=?', (body, store.scope))
            with self.assertRaises(preferences.PreferencesError):
                store.recover(confirmed=True)
            self.assertEqual(store.load(), saved)

    def test_database_corruption_never_falls_back_to_legacy(self):
        legacy = super().store()
        original = legacy.save(legacy.load(), '')
        migrated = self.store()
        migrated.load()
        self.database(migrated).write_bytes(b'corrupt database')
        with self.assertRaises(preferences.PreferencesError) as error:
            accounts.AccountStore(str(Path(legacy.path).parent), URL, USER)
        self.assertEqual(error.exception.code, 'S461')
        self.assertEqual(legacy.load(), original)

    def test_preexisting_empty_database_is_not_reinitialized(self):
        directory = self.root/'accounts'
        directory.mkdir()
        (directory/backend.DATABASE).write_bytes(b'')
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S437')
        self.assertEqual((directory/backend.DATABASE).read_bytes(), b'')

    def test_missing_migrated_database_cannot_resurrect_stale_json(self):
        legacy = super().store()
        old = legacy.save(legacy.load(), '')
        store = self.store()
        store.save(dict(store.load(), theme='charcoal'), old['revision'])
        self.database(store).unlink()
        self.assertTrue(backend.selected(str(Path(store.path).parent)))
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S437')
        self.assertFalse(self.database(store).exists())

    def test_legacy_preferences_without_revision_remain_recoverable(self):
        legacy = super().store()
        Path(legacy.path).write_text(json.dumps(dict(legacy.load(), theme='charcoal')))
        store = self.store()
        data = store.load()
        store.save(dict(data, theme='obsidian'), '')
        self.assertEqual(store.backup()['theme'], 'charcoal')

    def test_unexpected_schema_objects_rejected(self):
        store = self.store()
        self.mutate(store, 'CREATE TABLE unexpected(value TEXT)')
        with self.assertRaises(preferences.PreferencesError) as error:
            store.load()
        self.assertEqual(error.exception.code, 'S461')

    def test_database_symlink_rejected_without_touching_target(self):
        target = self.root/'target'
        target.write_bytes(b'keep')
        directory = self.root/'accounts'
        directory.mkdir()
        (directory/backend.DATABASE).symlink_to(target)
        with self.assertRaises(preferences.PreferencesError):
            self.store()
        self.assertEqual(target.read_bytes(), b'keep')

    def test_journal_symlink_rejected_without_touching_target(self):
        store = self.store()
        target = self.root/'target'
        target.write_bytes(b'keep')
        Path(store.sqlite.path+'-journal').symlink_to(target)
        with self.assertRaises(preferences.PreferencesError):
            store.load()
        self.assertEqual(target.read_bytes(), b'keep')

    def test_database_permissions_are_private_on_posix(self):
        store = self.store()
        self.assertEqual(self.database(store).stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.database(store).parent.stat().st_mode & 0o777, 0o700)

    def test_oversize_settings_rejected_without_changes(self):
        store, saved = self.saved()
        large = dict(saved, custom_categories={'x':['a'*128]*40000})
        with self.assertRaises(preferences.PreferencesError):
            store.save(large, saved['revision'])
        self.assertEqual(store.load(), saved)

    def test_database_busy_is_actionable_and_original_survives(self):
        store, saved = self.saved()
        db = sqlite3.connect(store.sqlite.path, isolation_level=None)
        try:
            db.execute('BEGIN IMMEDIATE')
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(saved, saved['revision'])
            self.assertEqual(error.exception.code, 'S431')
        finally:
            db.close()
        self.assertEqual(store.load(), saved)

    def test_commit_failure_rolls_back_primary_and_backup(self):
        store, first = self.saved()
        second = store.save(dict(first, theme='obsidian'), first['revision'])
        original = sqlite3.connect
        class FailingCommit:
            def __init__(self, *args, **kwargs): self.db = original(*args, **kwargs)
            @property
            def in_transaction(self): return self.db.in_transaction
            def execute(self, sql, *args):
                if sql == 'COMMIT': raise sqlite3.OperationalError(RAW)
                return self.db.execute(sql, *args)
            def close(self): self.db.close()
        with patch.object(sqlite3, 'connect', FailingCommit):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(first, second['revision'])
        self.assertEqual(error.exception.code, 'S431')
        self.assertNotIn(RAW, str(error.exception))
        self.assertEqual(store.load(), second)
        self.assertEqual(store.backup(), first)

    def test_sync_configuration_failure_blocks_mutation(self):
        store, saved = self.saved()
        with patch.object(store.sqlite, '_configure', side_effect=preferences.PreferencesError('blocked', 'S432')):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(saved, saved['revision'])
        self.assertEqual(error.exception.code, 'S432')
        self.assertEqual(store.load(), saved)

    def test_database_refusing_extra_sync_is_rejected(self):
        store, saved = self.saved()
        original = sqlite3.connect
        class WeakenedSync:
            def __init__(self, *args, **kwargs): self.db = original(*args, **kwargs)
            @property
            def in_transaction(self): return self.db.in_transaction
            def execute(self, sql, *args):
                if sql == 'PRAGMA synchronous':
                    return Mock(fetchone=Mock(return_value=(1,)))
                return self.db.execute(sql, *args)
            def close(self): self.db.close()
        with patch.object(sqlite3, 'connect', WeakenedSync):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(saved, saved['revision'])
        self.assertEqual(error.exception.code, 'S432')
        self.assertEqual(store.load(), saved)

    def test_two_writers_cannot_both_commit_the_same_expected_revision(self):
        store, saved = self.saved()
        other = self.store()
        barrier = threading.Barrier(2)
        results = []
        def write(candidate):
            barrier.wait(3)
            try:
                results.append(candidate.save(saved, saved['revision']))
            except preferences.PreferencesConflict:
                results.append('conflict')
        threads = [threading.Thread(target=write, args=(candidate,)) for candidate in (store, other)]
        for thread in threads: thread.start()
        for thread in threads: thread.join(5)
        self.assertFalse(any(thread.is_alive() for thread in threads))
        self.assertEqual(results.count('conflict'), 1)
        committed = next(row for row in results if isinstance(row, dict))
        self.assertEqual(store.load(), committed)
        self.assertEqual(store.backup(), saved)

    def test_m3u_prepare_and_reopen_keep_approved_channel_identity(self):
        from shadow.m3u import prepare_playlist
        body = b'#EXTM3U\n#EXTINF:-1 group-title="Test",Test Channel\nhttps://fixture.invalid/live/1.ts\n'
        source = URL + '/playlist.m3u'
        with patch.object(backend, 'selected', return_value=True), \
                patch.object(os, 'fsync', side_effect=AttributeError(RAW)):
            first = prepare_playlist(str(self.root), source, downloader=lambda url: body)
            try:
                identity = first.channels[0]['stream_id']
                first.store.save(dict(first.prefs, approved_channel_ids=[identity]), first.prefs['revision'])
                second = prepare_playlist(str(self.root), source, downloader=lambda url: body)
                try:
                    self.assertEqual(second.channels[0]['stream_id'], identity)
                    self.assertEqual(second.prefs['approved_channel_ids'], [identity])
                finally:
                    second.close()
            finally:
                first.close()

    def test_open_error_is_sanitized(self):
        store, saved = self.saved()
        with patch.object(sqlite3, 'connect', side_effect=OSError(errno.EACCES, RAW)):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.load()
        self.assertEqual(error.exception.code, 'S460')
        self.assertNotIn(RAW, str(error.exception))

    def test_close_failure_reports_uncertain_result_without_rolling_back_committed_data(self):
        store, saved = self.saved()
        original = sqlite3.connect
        class FailedClose:
            def __init__(self, *args, **kwargs): self.db = original(*args, **kwargs)
            @property
            def in_transaction(self): return self.db.in_transaction
            def execute(self, sql, *args): return self.db.execute(sql, *args)
            def close(self):
                self.db.close()
                raise OSError(errno.EIO, RAW)
        with patch.object(sqlite3, 'connect', FailedClose):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(dict(saved, theme='obsidian'), saved['revision'])
        self.assertEqual(error.exception.code, 'S433')
        self.assertEqual(store.load()['theme'], 'obsidian')
        with self.assertRaises(preferences.PreferencesConflict):
            store.save(saved, saved['revision'])

    def test_disk_full_at_commit_keeps_previous_revision(self):
        store, saved = self.saved()
        original = sqlite3.connect
        class FullDisk:
            def __init__(self, *args, **kwargs): self.db = original(*args, **kwargs)
            @property
            def in_transaction(self): return self.db.in_transaction
            def execute(self, sql, *args):
                if sql == 'COMMIT': raise sqlite3.OperationalError('database or disk is full')
                return self.db.execute(sql, *args)
            def close(self): self.db.close()
        with patch.object(sqlite3, 'connect', FullDisk):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(dict(saved, theme='obsidian'), saved['revision'])
        self.assertEqual(error.exception.code, 'S431')
        self.assertEqual(store.load(), saved)

    def test_missing_sqlite_is_sanitized(self):
        store = self.store()
        original = builtins.__import__
        def load(name, *args, **kwargs):
            if name == 'sqlite3': raise ImportError(RAW)
            return original(name, *args, **kwargs)
        with patch.object(builtins, '__import__', side_effect=load):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.load()
        self.assertEqual(error.exception.code, 'S436')

    def test_process_exit_during_write_recovers_previous_committed_revision(self):
        store, saved = self.saved()
        code = ('import os,sqlite3,sys; db=sqlite3.connect(sys.argv[1],isolation_level=None); '
                'db.execute("PRAGMA synchronous=EXTRA"); db.execute("BEGIN IMMEDIATE"); '
                'db.execute("UPDATE accounts SET current=? WHERE scope=?",(b"interrupted",sys.argv[2])); '
                'os._exit(0)')
        result = subprocess.run([sys.executable,'-c',code,store.sqlite.path,store.scope], timeout=10)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(self.store().load(), saved)

    def test_process_exit_during_initialization_does_not_regenerate_identity(self):
        from test_regressions import SOURCE
        directory = self.root/'accounts'
        code = ('import os,sys; sys.path.insert(0,sys.argv[1]); '
                'from shadow.sqlite_accounts import SQLiteAccounts; '
                'transaction=SQLiteAccounts(sys.argv[2])._transaction(); '
                'transaction.__enter__(); os._exit(0)')
        result = subprocess.run([sys.executable,'-c',code,str(SOURCE/'resources/lib'),str(directory)], timeout=10)
        self.assertEqual(result.returncode, 0)
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S437')
        self.assertTrue((directory/backend.DATABASE).exists())
        self.assertTrue((directory/backend.MARKER).is_dir())

    def test_isolated_production_check_exercises_sqlite_and_cleans_up(self):
        with patch.object(backend, 'selected', return_value=True), \
                patch.object(os, 'fsync', side_effect=AttributeError(RAW)) as sync:
            self.assertTrue(check_storage(str(self.root)))
        sync.assert_not_called()
        self.assertEqual(list(self.root.iterdir()), [])

    def test_m3u_key_route_uses_same_database_identity(self):
        store = self.store()
        self.assertEqual(accounts._scope_key(str(Path(store.path).parent)), store.sqlite.key())


class SQLiteWizardTests(_WizardTests):
    """Run every existing real wizard-adapter test with SQLite accounts."""
    def setUp(self):
        super().setUp()
        self.selection = patch.object(backend, 'selected', return_value=True)
        self.selection.start()
        self.addCleanup(self.selection.stop)

    def test_corruption_explicit_recovery_then_relaunch_wizard(self):
        from test_regressions import application, client_factory
        w = self.window()
        w.session.save({'theme':'charcoal'})
        w.session.save({'theme':'obsidian'})
        store = w.session.connection.store
        w.session.close()
        db = sqlite3.connect(store.sqlite.path)
        try:
            db.execute('UPDATE accounts SET current=? WHERE scope=?', (b'{broken', store.scope))
            db.commit()
        finally:
            db.close()
        self.assertTrue(application.recover_account(str(self.root), URL, USER, PASSWORD,
                                                   confirmed=True, client_factory=client_factory))
        w.session.adopt(self.prepare())
        self.assertEqual(w.session.prefs['theme'], 'charcoal')
        self.assertFalse(w.session.prefs['setup_completed'])
        self.assertTrue(w.setup())

    def test_optional_login_and_permission_failure_keeps_connection_and_wizard(self):
        from shadow.saved_login import LoginStorageError
        w = self.window(False)
        w.connection_options.return_value['remember'] = True
        w.run_job = Mock(return_value=self.prepare())
        w.saved_login.save.side_effect = LoginStorageError()
        w.connection_permissions.remember.side_effect = LoginStorageError()
        w.connect_provider()
        self.assertTrue(w.session.connected)
        self.assertTrue(w.session.prefs['setup_completed'])
        titles = [call.args[0] for call in w.dialog.ok.call_args_list]
        self.assertIn('Connection permissions', titles)
        self.assertIn('Login storage unavailable', titles)


# Avoid unittest discovering the imported base class twice in this module.
del _WizardTests
