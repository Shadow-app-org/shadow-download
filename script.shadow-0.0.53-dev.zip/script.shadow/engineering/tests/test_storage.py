import errno
import json
import os
from pathlib import Path
import stat
import unittest
from unittest.mock import patch
from test_regressions import DiskCase, URL, USER, PASSWORD, RAW, accounts, application, preferences, provider, file_sync
from shadow.safe_errors import SafeError
from shadow.storage_check import check_storage

class StorageTests(DiskCase):
    def seeded(self):
        store = self.store()
        data = store.load()
        data.update(theme='charcoal', approved_channel_ids=['1'], favourites=['1'], content_types=['live'])
        return store, store.save(data, '')

    def test_fresh_account_defaults_are_isolated_and_unapproved(self):
        store = self.store()
        data = store.load()
        self.assertFalse(data['setup_completed'])
        self.assertEqual(data['approved_channel_ids'], [])
        self.assertEqual(data['provider_scope'], store.scope)
        self.assertFalse(Path(store.path).exists())
        self.assertEqual(len((self.root/'accounts/scope-key.bin').read_bytes()),32)

    def test_directory_and_key_private_permissions(self):
        self.store()
        self.assertEqual(stat.S_IMODE((self.root/'accounts').stat().st_mode),0o700)
        self.assertEqual(stat.S_IMODE((self.root/'accounts/scope-key.bin').stat().st_mode),0o600)

    def test_saved_preferences_round_trip_and_permission(self):
        store, first = self.seeded()
        self.assertEqual(self.store().load(),first)
        self.assertEqual(stat.S_IMODE(Path(store.path).stat().st_mode),0o600)

    def test_same_account_canonical_host_reopens_same_scope(self):
        store, first = self.seeded()
        reopened = accounts.AccountStore(str(self.root/'accounts'),'https://FIXTURE.invalid:443/player_api.php',USER)
        self.assertEqual(reopened.load(),first)

    def test_username_case_is_account_specific(self):
        store = self.store()
        other = accounts.AccountStore(str(self.root/'accounts'),URL+'/player_api.php',USER.upper())
        self.assertNotEqual(store.scope, other.scope)

    def test_no_username_endpoint_password_in_saved_preferences(self):
        store, first = self.seeded()
        text = Path(store.path).read_text()
        for value in (USER,PASSWORD,URL):self.assertNotIn(value,text)

    def test_backup_is_previous_valid_revision(self):
        store, first = self.seeded()
        changed = dict(first,theme='obsidian')
        second = store.save(changed, first['revision'])
        self.assertEqual(preferences.load(store.path+'.bak'),first)
        self.assertEqual(store.load(),second)
        self.assertNotEqual(first['revision'],second['revision'])

    def test_atomic_replacement_never_exposes_partial_json(self):
        store, first = self.seeded()
        replace = os.replace
        observed = []
        def inspect(source, destination):
            if str(destination) == store.path:
                self.assertEqual(store.load(),first)
                self.assertEqual(json.loads(Path(source).read_text())['theme'],'obsidian')
                observed.append(True)
            return replace(source,destination)
        with patch.object(preferences.os,'replace',side_effect=inspect):
            store.save(dict(first,theme='obsidian'),first['revision'])
        self.assertEqual(observed,[True])

    def test_conflicting_revision_cannot_overwrite(self):
        store, first = self.seeded()
        second=store.save(dict(first,theme='obsidian'),first['revision'])
        with self.assertRaises(preferences.PreferencesConflict):store.save(first,first['revision'])
        self.assertEqual(store.load(),second)

    def test_corrupt_primary_never_silently_resets(self):
        store, first = self.seeded()
        Path(store.path).write_text('{broken')
        with self.assertRaises(preferences.PreferencesError):store.load()
        with self.assertRaises(preferences.PreferencesError):store.save(first,first['revision'])
        self.assertEqual(Path(store.path).read_text(),'{broken')

    def test_missing_primary_with_backup_requires_explicit_recovery(self):
        store, first = self.seeded()
        store.save(dict(first,theme='obsidian'),first['revision'])
        Path(store.path).unlink()
        with self.assertRaises(preferences.PreferencesError):store.load()
        with self.assertRaises(preferences.PreferencesError):store.save(first,'')
        recovered=store.recover(confirmed=True)
        self.assertEqual(recovered['theme'],first['theme'])

    def test_recovery_confirmation_required_and_no_mutation(self):
        store, first = self.seeded()
        before=Path(store.path).read_bytes()
        with self.assertRaises(preferences.PreferencesError):store.recover()
        self.assertEqual(Path(store.path).read_bytes(),before)

    def test_recovery_retains_damaged_primary_and_valid_preferences(self):
        store, first = self.seeded()
        store.save(dict(first,theme='obsidian'),first['revision'])
        Path(store.path).write_bytes(b'{corrupt')
        recovered=store.recover(confirmed=True)
        self.assertEqual(recovered['favourites'],['1'])
        self.assertEqual(recovered['theme'],'charcoal')
        self.assertEqual(Path(store.path+'.damaged').read_bytes(),b'{corrupt')
        self.assertEqual(store.load(),recovered)

    def test_recovery_without_backup_preserves_original(self):
        store, first = self.seeded()
        before=Path(store.path).read_bytes()
        with self.assertRaises(preferences.PreferencesError):store.recover(confirmed=True)
        self.assertEqual(Path(store.path).read_bytes(),before)

    def test_recovery_rejects_foreign_scope(self):
        store, first = self.seeded()
        foreign=dict(first,provider_scope='a'*64)
        preferences._atomic(store.path+'.bak',foreign)
        with self.assertRaises(preferences.PreferencesError):store.recover(confirmed=True)
        self.assertEqual(store.load(),first)

    def test_scope_mismatch_does_not_adopt_preferences(self):
        store, first = self.seeded()
        preferences._atomic(store.path,dict(first,provider_scope='a'*64))
        with self.assertRaises(preferences.PreferencesError):store.load()
        with self.assertRaises(preferences.PreferencesError):store.save(dict(first,provider_scope='a'*64),first['revision'])

    def test_unbound_existing_preferences_not_adopted(self):
        store=self.store()
        preferences._atomic(store.path,preferences._defaults())
        with self.assertRaises(preferences.PreferencesError):store.load()

    def test_partial_account_reopens_without_losing_preferences(self):
        store, first=self.seeded()
        self.assertFalse(first['setup_completed'])
        c=self.prepare()
        self.addCleanup(c.close)
        self.assertEqual(c.prefs,first)

    def test_interrupted_key_creation_retry_after_atomic_failure(self):
        with patch.object(preferences.os,'replace',side_effect=OSError(errno.EIO,RAW)):
            with self.assertRaises(provider.ProviderError) as caught:self.prepare()
        self.assertEqual(caught.exception.code,'S410')
        self.assertFalse((self.root/'accounts/scope-key.bin').exists())
        self.assertFalse(list((self.root/'accounts').glob('.shadow-*')))
        c=self.prepare();self.addCleanup(c.close)
        self.assertFalse(c.prefs['setup_completed'])

    def test_stale_key_lock_fails_closed_and_is_preserved(self):
        folder=self.root/'accounts';folder.mkdir()
        (folder/'scope-key.bin.lock').mkdir()
        with self.assertRaises(provider.ProviderError) as caught:self.prepare()
        self.assertEqual(caught.exception.code,'S402')
        self.assertTrue((folder/'scope-key.bin.lock').is_dir())

    def test_stale_settings_lock_preserves_valid_preferences(self):
        store,first=self.seeded()
        Path(store.path+'.lock').mkdir()
        with self.assertRaises(preferences.PreferencesError) as caught:store.save(first,first['revision'])
        self.assertEqual(caught.exception.code,'S402')
        self.assertEqual(store.load(),first)

    def test_missing_scope_key_never_orphans_existing_settings(self):
        store,first=self.seeded()
        (self.root/'accounts/scope-key.bin').unlink()
        with self.assertRaises(preferences.PreferencesError) as caught:self.store()
        self.assertEqual(caught.exception.code,'S404')
        self.assertFalse((self.root/'accounts/scope-key.bin').exists())
        self.assertEqual(preferences.load(store.path),first)

    def test_corrupt_scope_key_is_preserved(self):
        self.store()
        path=self.root/'accounts/scope-key.bin';path.write_bytes(b'broken')
        with self.assertRaises(preferences.PreferencesError) as caught:self.store()
        self.assertEqual(caught.exception.code,'S405')
        self.assertEqual(path.read_bytes(),b'broken')

    def test_symlink_preferences_are_rejected(self):
        store=self.store()
        target=self.root/'unrelated';target.write_text('{}')
        Path(store.path).symlink_to(target)
        with self.assertRaises(preferences.PreferencesError):store.load()
        self.assertEqual(target.read_text(),'{}')

    def test_symlink_damaged_primary_not_copied_during_recovery(self):
        store,first=self.seeded()
        store.save(dict(first,theme='obsidian'),first['revision'])
        Path(store.path).unlink()
        target=self.root/'unrelated';target.write_text('private fixture')
        Path(store.path).symlink_to(target)
        with self.assertRaises(preferences.PreferencesError):store.recover(confirmed=True)
        self.assertFalse(Path(store.path+'.damaged').exists())
        self.assertEqual(target.read_text(),'private fixture')

    def test_isolated_storage_probe_preserves_real_account(self):
        store,first=self.seeded()
        self.assertTrue(check_storage(str(self.root)))
        self.assertEqual(store.load(),first)
        self.assertFalse(list(self.root.glob('.shadow-storage-check-*')))

    def test_account_directory_failure(self):
        with patch.object(accounts.os,'makedirs',side_effect=PermissionError(RAW)):
            with self.assertRaises(provider.ProviderError) as caught:self.prepare()
        self.assertEqual(caught.exception.code,'S401')
        self.assertNotIn(PASSWORD,str(caught.exception))

    def test_key_read_failure(self):
        self.store()
        with patch.object(accounts,'read_regular_bytes',side_effect=PermissionError(RAW)):
            with self.assertRaises(preferences.PreferencesError) as caught:self.store()
        self.assertEqual(caught.exception.code,'S404')

    def test_settings_read_permission_failure(self):
        store,first=self.seeded()
        with patch.object(preferences,'read_regular_bytes',side_effect=PermissionError(RAW)):
            with self.assertRaises(preferences.PreferencesError) as caught:store.load()
        self.assertEqual(caught.exception.code,'S412')
        self.assertEqual(store.load(),first)

    def test_invalid_preferences_do_not_mutate_disk(self):
        store,first=self.seeded()
        with self.assertRaises(preferences.PreferencesError):store.save(dict(first,setup_completed='yes'),first['revision'])
        self.assertEqual(store.load(),first)

# Separate test IDs for every storage stage and both production write paths.
def write_failure(target, code, byte_writer):
    def test(self):
        store,first=self.seeded()
        before=Path(store.path).read_bytes()
        with patch(target,side_effect=OSError(errno.EIO,RAW)):
            with self.assertRaises(preferences.PreferencesError) as caught:
                if byte_writer:preferences.atomic_bytes(store.path,b'new fixture bytes')
                else:store.save(dict(first,theme='obsidian'),first['revision'])
        self.assertEqual(caught.exception.code,code)
        self.assertNotIn(PASSWORD,str(caught.exception))
        self.assertEqual(Path(store.path).read_bytes(),before)
        self.assertFalse(Path(store.path+'.lock').exists())
        self.assertFalse(list((self.root/'accounts').glob('.shadow-*')))
    return test
for name,target,code in [('tempfile','shadow.preferences.tempfile.NamedTemporaryFile','S406'),('chmod','shadow.preferences.os.chmod','S407'),('sync','shadow.preferences.sync_file','S409'),('replace','shadow.preferences.os.replace','S410')]:
    for writer in ('json','bytes'):
        setattr(StorageTests,'test_'+writer+'_failure_'+name,write_failure(target,code,writer=='bytes'))

def native_code(code):
    def test(self):
        with patch.object(preferences,'sync_file',side_effect=SafeError(code)):
            with self.assertRaises(provider.ProviderError) as caught:self.prepare()
        self.assertEqual(caught.exception.code,code)
        self.assertEqual(caught.exception.stage,'settings')
    return test
for code in range(416,426):setattr(StorageTests,'test_native_sync_diagnostic_S'+str(code),native_code('S'+str(code)))
