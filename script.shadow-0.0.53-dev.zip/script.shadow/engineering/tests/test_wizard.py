"""Execute the real Kodi adapter methods with GUI-only dependencies replaced."""
import sys
import types
from unittest.mock import Mock, patch
from test_regressions import DiskCase, URL, USER, PASSWORD, RAW, application, preferences, provider, jobs
from shadow.safe_errors import safe_message
from shadow.test_login import TestLogin

class NativeWindow:
    def setProperty(self,key,value):self.properties[key]=value
    def getControl(self,identity):return self.control

sys.modules.setdefault('xbmc',types.ModuleType('xbmc'))
sys.modules.setdefault('xbmcvfs',types.ModuleType('xbmcvfs'))
gui=types.ModuleType('xbmcgui')
gui.WindowXML=gui.WindowXMLDialog=NativeWindow
sys.modules.setdefault('xbmcgui',gui)
from shadow.kodi_ui import ShadowWindow

class WizardTests(DiskCase):
    def window(self, connected=True):
        w=ShadowWindow.__new__(ShadowWindow)
        w.properties={};w.control=Mock();w.dialog=Mock();w.running=True
        w.profile=str(self.root);w.session=application.Session()
        self.addCleanup(w.session.close)
        if connected:w.session.adopt(self.prepare())
        w.test_login=TestLogin();w.saved_login=Mock();w.connection_permissions=Mock()
        w.connection_permissions.lookup.return_value=None
        w.connection_options=Mock(return_value={'redirects':False,'http_redirects':False,'remember':False,'http_login':False})
        w.credentials=Mock(return_value=(URL,USER,PASSWORD,False))
        w.clear_guide=Mock();w.stop_playback=Mock();w.open_page=Mock();w.update_header=Mock();w.apply_theme=Mock()
        w.chosen_browse_languages=['English'];w.multiselect=Mock(return_value=[0]);w.choose_channels=Mock(return_value=['1'])
        w.dialog.select.return_value=1
        w.dialog.yesno.return_value=True
        return w

    def test_successful_setup_persists_explicit_selection(self):
        w=self.window()
        self.assertTrue(w.setup())
        data=w.session.connection.store.load()
        self.assertTrue(data['setup_completed']);self.assertEqual(data['approved_channel_ids'],['1'])
        self.assertEqual(data['theme'],'charcoal');self.assertEqual(data['browse_languages'],['English'])
        self.assertEqual(w.properties['shadow.status'],'Setup complete')

    def test_failed_save_can_retry_same_draft(self):
        w=self.window();save=w.session.save;attempts=[]
        def fail_once(changes):
            attempts.append(dict(changes))
            if len(attempts)==1:raise preferences.PreferencesError('write failed','S410')
            return save(changes)
        with patch.object(w.session,'save',side_effect=fail_once):self.assertTrue(w.setup())
        self.assertEqual(attempts[0],attempts[1]);self.assertTrue(w.session.prefs['setup_completed'])
        self.assertTrue(any('S410' in call.args[0] for call in w.dialog.ok.call_args_list))

    def test_declined_save_retry_preserves_saved_preferences(self):
        w=self.window();w.session.save({'theme':'charcoal','favourites':['1'],'approved_channel_ids':['1']})
        before=w.session.connection.store.load()
        w.dialog.yesno.side_effect=[True,True,False]
        with patch.object(w.session,'save',side_effect=preferences.PreferencesError('failed','S410')):
            self.assertFalse(w.setup())
        self.assertEqual(w.session.connection.store.load(),before)
        self.assertEqual(w.properties['shadow.status'],'Setup incomplete - save failed')

    def test_revision_conflict_does_not_retry_over_newer_preferences(self):
        w=self.window()
        original=w.session.prefs.copy()
        saved=w.session.connection.store.save(dict(original,theme='charcoal'),original['revision'])
        self.assertFalse(w.setup());self.assertEqual(w.session.connection.store.load(),saved)
        self.assertIn('reload settings',w.properties['shadow.status'])

    def test_relaunch_interrupted_setup_resumes_without_implicit_approval(self):
        w=self.window();w.session.save({'theme':'charcoal','content_types':['live']})
        w.session.close();w.session.adopt(self.prepare())
        self.assertFalse(w.session.prefs['setup_completed']);self.assertEqual(w.session.prefs['approved_channel_ids'],[])
        self.assertTrue(w.setup());self.assertTrue(w.session.prefs['setup_completed'])

    def test_after_connect_reopens_incomplete_wizard(self):
        w=self.window();w.setup=Mock(return_value=False)
        w.after_connect();w.setup.assert_called_once()

    def test_after_connect_completed_account_skips_wizard(self):
        w=self.window();w.session.save({'setup_completed':True,'content_types':['live']});w.setup=Mock()
        w.after_connect();w.setup.assert_not_called()

    def test_after_connect_inference_storage_failure_does_not_abort_wizard(self):
        w=self.window();w.session.save({'approved_channel_ids':['1']});w.setup=Mock()
        with patch.object(w.session,'save',side_effect=preferences.PreferencesError('failed','S409')):w.after_connect()
        w.setup.assert_called_once()
        self.assertTrue(any('S409' in call.args[0] for call in w.dialog.ok.call_args_list))

    def test_failed_account_preparation_retries_without_reentering_credentials(self):
        w=self.window(connected=False)
        error=jobs.JobError();error.code='S410';error.stage='settings'
        w.run_job=Mock(side_effect=[error,self.prepare()]);w.after_connect=Mock()
        w.connect_provider()
        self.assertEqual(w.run_job.call_count,2);w.credentials.assert_called_once()
        self.assertTrue(w.session.connected);w.after_connect.assert_called_once()

    def test_failed_account_preparation_declined_retry_explains_home_return(self):
        w=self.window(connected=False)
        error=jobs.JobError(RAW);error.code='X411';error.stage='settings'
        w.run_job=Mock(side_effect=error);w.dialog.yesno.return_value=False
        w.connect_provider()
        self.assertFalse(w.session.connected)
        self.assertEqual(w.properties['shadow.status'],'Connection incomplete - see diagnostic')
        w.dialog.ok.assert_called_once();self.assertNotIn(PASSWORD,str(w.dialog.ok.call_args))
        self.assertIn('Check local storage',w.dialog.ok.call_args.args[1])

    def test_cancelled_connection_job_has_explicit_feedback(self):
        w=self.window(connected=False);w.run_job=Mock(return_value=None)
        w.connect_provider()
        self.assertFalse(w.session.connected);self.assertIn('cancelled',w.properties['shadow.status'])
        w.dialog.ok.assert_called_once()

    def test_credentials_cancel_does_not_start_connection(self):
        w=self.window(connected=False);w.credentials.return_value=None;w.run_job=Mock()
        w.connect_provider();w.run_job.assert_not_called()

    def test_replacement_connection_failure_preserves_existing_session(self):
        w=self.window();old=w.session.connection
        error=jobs.JobError();error.code='N443';error.stage='login';error.http_status=502
        w.run_job=Mock(side_effect=error);w.dialog.yesno.return_value=False
        w.connect_provider();self.assertIs(w.session.connection,old)
        self.assertIn('502',w.dialog.ok.call_args.args[1])

    def test_http_status_rendered_without_provider_details(self):
        w=self.window(False)
        error=jobs.JobError(RAW);error.code='N443';error.stage='login';error.http_status=504
        w.provider_error(error)
        self.assertIn('HTTP 504',w.dialog.ok.call_args.args[1])
        self.assertNotIn(PASSWORD,str(w.dialog.ok.call_args));self.assertNotIn(URL,str(w.dialog.ok.call_args))

    def test_corruption_explicit_recovery_then_relaunch_wizard(self):
        from pathlib import Path
        from test_regressions import client_factory
        w=self.window();w.session.save({'theme':'charcoal'})
        w.session.save({'theme':'obsidian'})
        path=w.session.connection.store.path
        w.session.close();Path(path).write_text('{broken')
        self.assertTrue(application.recover_account(str(self.root),URL,USER,PASSWORD,confirmed=True,client_factory=client_factory))
        w.session.adopt(self.prepare())
        self.assertEqual(w.session.prefs['theme'],'charcoal');self.assertFalse(w.session.prefs['setup_completed'])
        self.assertTrue(w.setup())

# Each cancellation point runs the actual adapter and verifies no writes.
def cancel_test(point):
    def test(self):
        w=self.window();before=w.session.connection.store.load()
        if point=='content':w.multiselect.return_value=None
        elif point=='empty_content':w.multiselect.return_value=[]
        elif point=='channels':w.choose_channels.return_value=None
        elif point=='appearance':w.dialog.select.return_value=-1
        else:w.dialog.yesno.side_effect=[True,False]
        self.assertFalse(w.setup())
        self.assertEqual(w.session.connection.store.load(),before)
        self.assertIn('cancelled',w.properties['shadow.status'])
        self.assertTrue(any('Resume with Settings' in call.args[1] for call in w.dialog.ok.call_args_list))
    return test
for point in ('content','empty_content','channels','appearance','review'):setattr(WizardTests,'test_cancel_at_'+point,cancel_test(point))

class StartupFailureTests(WizardTests):
    # Do not duplicate inherited test methods in collection: this class is removed
    # below and the method is attached to the existing fixture class.
    def test_profile_creation_failure_explained_before_exit(self):
        w=self.window(False);w.initialized=False;w.shutdown=Mock()
        with patch('shadow.kodi_ui.xbmcgui.Dialog',create=True,return_value=w.dialog),patch('shadow.ui_text.load_estuary_coverage',return_value=None),patch('shadow.kodi_ui.os.makedirs',side_effect=PermissionError(RAW)):
            w.onInit()
        w.shutdown.assert_called_once()
        self.assertIn('S401',w.dialog.ok.call_args.args[0])
        self.assertNotIn(PASSWORD,str(w.dialog.ok.call_args))
WizardTests.test_profile_creation_failure_explained_before_exit=StartupFailureTests.test_profile_creation_failure_explained_before_exit
del StartupFailureTests
