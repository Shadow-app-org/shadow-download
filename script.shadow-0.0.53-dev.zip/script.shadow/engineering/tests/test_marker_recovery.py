"""Marker ownership, embedded mkdir error variants, and sanitized failure details."""
import errno
import os
from pathlib import Path
from unittest.mock import patch
from test_regressions import DiskCase, preferences, RAW
from shadow import sqlite_accounts as backend, storage_diagnostic as diagnostic
from shadow.safe_errors import SafeError, storage_failure_detail, format_storage_failure


class MarkerTests(DiskCase):
    def setUp(self):
        super().setUp()
        selection = patch.object(backend, 'selected', return_value=True)
        selection.start()
        self.addCleanup(selection.stop)

    def test_nonstandard_existing_marker_error_does_not_block_reopen_or_saves(self):
        original = os.mkdir
        calls = []
        def mkdir(path, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.MARKER:
                calls.append(path)
                if os.path.lexists(path):
                    raise PermissionError(errno.EACCES, RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'mkdir', side_effect=mkdir):
            first = self.store()
            data = first.load()
            saved = first.save(dict(data, theme='charcoal', favourites=['1']), data['revision'])
            other = self.store()
            self.assertEqual(first.scope, other.scope)
            self.assertEqual(other.load(), saved)
            other.save(dict(saved, theme='obsidian'), saved['revision'])
            self.assertEqual(first.backup(), saved)
        self.assertEqual(len(calls), 1)

    def test_missing_database_with_marker_never_gets_recreated(self):
        directory = self.root/'accounts'
        directory.mkdir()
        (directory/backend.MARKER).mkdir()
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S437')
        self.assertFalse((directory/backend.DATABASE).exists())

    def test_real_marker_creation_denial_blocks_and_reports_numeric_detail(self):
        original = os.mkdir
        def mkdir(path, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.MARKER:
                raise PermissionError(errno.EACCES, RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'mkdir', side_effect=mkdir):
            rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertEqual(rows['Current saver'], 'S452')
        self.assertEqual(rows['Saver step'], 'identity creation')
        self.assertEqual(rows['Saver detail'], 'PermissionError (errno=13)')
        self.assertEqual(rows['SQLite'], 'PASS (EXTRA)')
        self.assertEqual(rows['Cleanup'], 'PASS')
        self.assertNotIn(RAW, str(rows))
        self.assertEqual(list(self.root.iterdir()), [])

    def test_creation_errors_are_not_treated_as_marker_ownership(self):
        original = os.mkdir
        for problem in (OSError(errno.ENOSPC, RAW), OSError(0, RAW), AttributeError(RAW)):
            with self.subTest(problem=type(problem).__name__):
                def mkdir(path, *args, **kwargs):
                    if os.path.basename(os.fspath(path)) == backend.MARKER:
                        raise problem
                    return original(path, *args, **kwargs)
                with patch.object(os, 'mkdir', side_effect=mkdir):
                    with self.assertRaises(preferences.PreferencesError) as error:
                        self.store()
                self.assertEqual(error.exception.code, 'S452')
                self.assertFalse((self.root/'accounts'/backend.DATABASE).exists())
                self.assertNotIn(RAW, str(error.exception.storage_detail))

    def test_preexisting_marker_file_is_rejected_unchanged(self):
        directory = self.root/'accounts'
        directory.mkdir()
        marker = directory/backend.MARKER
        marker.write_bytes(b'keep')
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S453')
        self.assertEqual(marker.read_bytes(), b'keep')
        self.assertFalse((directory/backend.DATABASE).exists())

    def test_marker_symlink_is_rejected_without_touching_target(self):
        directory = self.root/'accounts'
        directory.mkdir()
        target = self.root/'target'
        target.mkdir()
        (directory/backend.MARKER).symlink_to(target, target_is_directory=True)
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S453')
        self.assertEqual(list(target.iterdir()), [])

    def test_racing_creator_keeps_initialization_ownership(self):
        original = os.mkdir
        def mkdir(path, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.MARKER:
                original(path, *args, **kwargs)
                raise FileExistsError(errno.EEXIST, RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'mkdir', side_effect=mkdir):
            with self.assertRaises(preferences.PreferencesError) as error:
                self.store()
        self.assertEqual(error.exception.code, 'S437')
        self.assertFalse((self.root/'accounts'/backend.DATABASE).exists())

    def test_wrong_error_after_racing_creation_still_blocks_initialization(self):
        original = os.mkdir
        def mkdir(path, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.MARKER:
                original(path, *args, **kwargs)
                raise OSError(0, RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'mkdir', side_effect=mkdir):
            with self.assertRaises(preferences.PreferencesError) as error:
                self.store()
        self.assertEqual(error.exception.code, 'S452')
        self.assertFalse((self.root/'accounts'/backend.DATABASE).exists())

    def test_new_marker_is_verified_even_when_mkdir_claims_success(self):
        original = os.mkdir
        def mkdir(path, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.MARKER:
                Path(path).write_bytes(b'wrong kind')
                return None
            return original(path, *args, **kwargs)
        with patch.object(os, 'mkdir', side_effect=mkdir):
            with self.assertRaises(preferences.PreferencesError) as error:
                self.store()
        self.assertEqual(error.exception.code, 'S453')
        self.assertFalse((self.root/'accounts'/backend.DATABASE).exists())

    def test_existing_marker_metadata_error_blocks_without_changing_database(self):
        store = self.store()
        data = store.load()
        before = Path(store.sqlite.path).read_bytes()
        original = os.lstat
        def metadata(path, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.MARKER:
                raise OSError(errno.EIO, RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'lstat', side_effect=metadata):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.save(dict(data, theme='charcoal'), data['revision'])
        self.assertEqual(error.exception.code, 'S455')
        self.assertEqual(Path(store.sqlite.path).read_bytes(), before)

    def test_safe_details_reject_arbitrary_labels_and_codes(self):
        for detail in [(RAW, None, None, None), ('OSError', RAW, None, None),
                       ('OSError', True, None, None), ('OSError', -1, None, None),
                       ('OSError', 65536, None, None), RAW, ['OSError', 1, 2, 3]]:
            self.assertEqual(format_storage_failure(detail), '')
        error = type('private_provider_name', (Exception,), {})(RAW)
        error.errno = RAW
        error.winerror = RAW
        error.sqlite_errorcode = RAW
        self.assertEqual(format_storage_failure(storage_failure_detail(error)), 'Error')

    def test_bounded_windows_and_sqlite_error_numbers_are_retained(self):
        error = OSError(errno.EACCES, RAW)
        error.winerror = 5
        error.sqlite_errorcode = 14
        self.assertEqual(format_storage_failure(storage_failure_detail(error)),
                         'PermissionError (errno=13) (winerror=5) (sqlite=14)')

    def test_forged_diagnostic_detail_or_step_cannot_expose_text(self):
        error = SafeError('S452')
        error.storage_detail = (RAW, None, None, None)
        error.storage_step = RAW
        with patch.object(diagnostic, 'check_storage', side_effect=error):
            rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertNotIn('Saver detail', rows)
        self.assertNotIn('Saver step', rows)
        self.assertNotIn(RAW, str(rows))
