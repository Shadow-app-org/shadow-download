"""Remembered-login/consent transactions with synthetic data and no networking."""
import errno
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch
from test_regressions import DiskCase, URL, USER, PASSWORD, RAW
from test_wizard import WizardTests as _WindowHelpers
from shadow import saved_login as login, connection_permissions as consent
from shadow import sqlite_local_state as state, sqlite_accounts, storage_diagnostic

DETAILS = (URL, USER, PASSWORD)
OPTIONS = dict(remember=True, redirects=False, http_redirects=False, http_login=False)


class RememberedStateTests(DiskCase):
    window = _WindowHelpers.window

    def setUp(self):
        super().setUp()
        selection = patch.object(state, 'selected', return_value=True)
        selection.start()
        self.addCleanup(selection.stop)
        self.login = login.SavedLogin(str(self.root))
        self.consent = consent.ConnectionPermissions(str(self.root))
        self.key = consent.identity(DETAILS)

    def dbpath(self, kind='login'):
        return Path(state.paths(str(self.root), kind)[1])

    def test_login_survives_new_objects_without_fsync_or_ctypes(self):
        with patch.object(os, 'fsync', side_effect=AttributeError(RAW)), patch.object(login, 'sync_file', side_effect=AssertionError('Old saver called')):
            self.login.save(DETAILS)
            reopened = login.SavedLogin(str(self.root))
            self.assertTrue(reopened.exists())
            self.assertEqual(reopened.load(), DETAILS)

    def test_login_survives_fresh_python_process(self):
        from test_regressions import SOURCE
        self.login.save(DETAILS)
        script = ('import sys;sys.path.insert(0,sys.argv[1]);from shadow.saved_login import SavedLogin;'
                  's=SavedLogin(sys.argv[2]);v=s.load();assert len(v)==3 and s.exists();print("PASS")')
        result = subprocess.run([sys.executable, '-c', script, str(SOURCE/'resources/lib'), str(self.root)], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), 'PASS')
        self.assertEqual(result.stderr, '')

    def test_new_profile_does_not_implicitly_store_login(self):
        self.assertIsNone(self.login.load())
        self.assertFalse(self.login.exists())
        self.assertNotIn(PASSWORD.encode(), self.dbpath().read_bytes())

    def test_permissions_reopen_and_bind_exact_login(self):
        self.consent.remember(self.key, OPTIONS)
        reopened = consent.ConnectionPermissions(str(self.root))
        self.assertEqual(reopened.lookup(self.key), OPTIONS)
        changed = consent.identity((URL, USER, 'different-fixture'))
        self.assertIsNone(reopened.lookup(changed))
        body = self.dbpath('permissions').read_bytes()
        for item in DETAILS:
            self.assertNotIn(item.encode(), body)

    def test_disabled_permissions_do_not_reappear_on_enable(self):
        self.consent.remember(self.key, OPTIONS)
        self.consent.set_enabled(False)
        self.consent.remember(self.key, OPTIONS)
        self.assertFalse(consent.ConnectionPermissions(str(self.root)).enabled())
        self.assertIsNone(self.consent.lookup(self.key))
        self.consent.set_enabled(True)
        self.assertIsNone(self.consent.lookup(self.key))

    def test_clear_permissions_keeps_enabled_choice(self):
        self.consent.set_enabled(False)
        self.consent.clear()
        self.assertFalse(self.consent.enabled())

    def test_unsafe_redirect_grants_rejected(self):
        with self.assertRaises(login.LoginStorageError):
            self.consent.remember(self.key, dict(OPTIONS, http_redirects=True))
        self.assertIsNone(self.consent.lookup(self.key))

    def test_untyped_options_or_invalid_identity_rejected(self):
        for key, options in [('bad', OPTIONS), (self.key, dict(OPTIONS, redirects='yes'))]:
            with self.assertRaises(login.LoginStorageError):
                self.consent.remember(key, options)
        self.assertIsNone(self.consent.lookup(self.key))

    def test_concurrent_permission_updates_are_not_lost(self):
        self.consent.enabled()
        barrier = threading.Barrier(2)
        errors = []
        def remember(key):
            try:
                barrier.wait(3)
                consent.ConnectionPermissions(str(self.root)).remember(key, OPTIONS)
            except Exception as error:
                errors.append(type(error).__name__)
        threads = [threading.Thread(target=remember, args=(key,)) for key in ('a'*64,'b'*64)]
        for thread in threads:thread.start()
        for thread in threads:thread.join(5)
        self.assertFalse(any(t.is_alive() for t in threads))
        self.assertEqual(errors, [])
        self.assertEqual(self.consent.lookup('a'*64), OPTIONS)
        self.assertEqual(self.consent.lookup('b'*64), OPTIONS)

    def test_permission_entries_remain_bounded(self):
        for number in range(33):
            self.consent.remember('%064x' % number, OPTIONS)
        self.assertIsNone(self.consent.lookup('%064x' % 0))
        self.assertEqual(self.consent.lookup('%064x' % 32), OPTIONS)
        self.assertEqual(len(self.consent._read()['entries']), 32)

    def test_valid_legacy_login_migrates_and_original_is_removed(self):
        raw = self.login._encode(DETAILS)
        Path(self.login.path).write_bytes(raw)
        self.assertEqual(self.login.load(), DETAILS)
        self.assertFalse(Path(self.login.path).exists())
        self.assertEqual(login.SavedLogin(str(self.root)).load(), DETAILS)

    def test_valid_legacy_permissions_preserved(self):
        data = dict(version=1, enabled=True, entries={self.key:OPTIONS})
        Path(self.consent.path).write_text(json.dumps(data))
        self.assertEqual(self.consent.lookup(self.key), OPTIONS)
        self.assertFalse(Path(self.consent.path).exists())

    def test_invalid_legacy_login_preserved_without_claiming_destination(self):
        Path(self.login.path).write_bytes(b'invalid')
        with self.assertRaises(login.LoginStorageError):self.login.load()
        self.assertEqual(Path(self.login.path).read_bytes(), b'invalid')
        self.assertFalse(self.dbpath().exists())
        self.login.save(DETAILS)
        self.assertEqual(self.login.load(), DETAILS)

    def test_invalid_legacy_permissions_can_be_explicitly_disabled(self):
        Path(self.consent.path).write_bytes(b'invalid')
        with self.assertRaises(login.LoginStorageError):self.consent.lookup(self.key)
        self.assertEqual(Path(self.consent.path).read_bytes(), b'invalid')
        self.consent.set_enabled(False)
        self.assertFalse(self.consent.enabled())
        self.assertFalse(Path(self.consent.path).exists())

    def test_forget_removes_value_and_legacy_temps_without_resurrection(self):
        self.login.save(DETAILS)
        Path(self.login.path).write_bytes(self.login._encode(DETAILS))
        temp = self.root/'.shadow-login-interrupted.tmp'
        temp.write_bytes(PASSWORD.encode())
        unrelated = self.root/'unrelated'
        unrelated.write_bytes(b'keep')
        self.login.forget()
        self.assertIsNone(login.SavedLogin(str(self.root)).load())
        self.assertFalse(temp.exists())
        self.assertFalse(Path(self.login.path).exists())
        self.assertEqual(unrelated.read_bytes(), b'keep')
        self.assertNotIn(PASSWORD.encode(), self.dbpath().read_bytes())
        self.assertEqual(list(self.dbpath().parent.glob('*-journal')), [])
        self.assertEqual(list(self.dbpath().parent.glob('*-wal')), [])

    def test_replacing_login_does_not_keep_old_password_in_live_database(self):
        old = 'synthetic-old-value-'*30
        self.login.save((URL, USER, old))
        self.login.save(DETAILS)
        self.assertNotIn(old.encode(), self.dbpath().read_bytes())
        self.assertEqual(self.login.load(), DETAILS)

    def test_forget_leaves_account_selections_and_permissions_separate(self):
        store = self.store()
        prefs = store.save(dict(store.load(), approved_channel_ids=['1']), '')
        self.consent.remember(self.key, OPTIONS)
        self.login.save(DETAILS)
        self.login.forget()
        self.assertEqual(store.load(), prefs)
        self.assertEqual(self.consent.lookup(self.key), OPTIONS)

    def failing_connection(self, statement):
        original = sqlite3.connect
        class Broken:
            def __init__(self,*a,**k):self.db=original(*a,**k)
            @property
            def in_transaction(self):return self.db.in_transaction
            def execute(self,sql,*args):
                if sql==statement:raise sqlite3.OperationalError(RAW)
                return self.db.execute(sql,*args)
            def close(self):self.db.close()
        return Broken

    def test_failed_save_commit_preserves_old_login(self):
        self.login.save(DETAILS)
        with patch.object(sqlite3,'connect',self.failing_connection('COMMIT')):
            with self.assertRaises(login.LoginStorageError) as error:
                self.login.save((URL,USER,'synthetic-new-value'))
        self.assertEqual(error.exception.code,'L507')
        self.assertNotIn(RAW,str(error.exception))
        self.assertEqual(self.login.load(),DETAILS)

    def test_failed_forget_commit_does_not_claim_success(self):
        self.login.save(DETAILS)
        with patch.object(sqlite3,'connect',self.failing_connection('COMMIT')):
            with self.assertRaises(login.LoginStorageError):self.login.forget()
        self.assertEqual(self.login.load(),DETAILS)

    def test_failed_permission_commit_preserves_old_grants(self):
        self.consent.remember(self.key,OPTIONS)
        with patch.object(sqlite3,'connect',self.failing_connection('COMMIT')):
            with self.assertRaises(login.LoginStorageError):
                self.consent.remember(self.key,dict(OPTIONS,redirects=True))
        self.assertEqual(self.consent.lookup(self.key),OPTIONS)

    def test_legacy_removal_failure_is_reported_after_commit(self):
        Path(self.login.path).write_bytes(self.login._encode(DETAILS))
        original=os.unlink
        def unlink(path,*a,**k):
            if os.fspath(path)==self.login.path:raise PermissionError(errno.EACCES,RAW)
            return original(path,*a,**k)
        with patch.object(os,'unlink',side_effect=unlink):
            with self.assertRaises(login.LoginStorageError) as error:self.login.load()
        self.assertEqual(error.exception.code,'L509')
        self.assertTrue(Path(self.login.path).exists())
        self.assertEqual(self.login.load(),DETAILS)
        self.assertFalse(Path(self.login.path).exists())

    def test_missing_migrated_database_does_not_reimport_old_login(self):
        self.login.save(DETAILS)
        self.dbpath().unlink()
        Path(self.login.path).write_bytes(self.login._encode(DETAILS))
        with self.assertRaises(login.LoginStorageError) as error:self.login.load()
        self.assertEqual(error.exception.code,'L502')
        self.assertFalse(self.dbpath().exists())

    def test_corrupt_database_does_not_fall_back_to_legacy(self):
        self.login.save(DETAILS)
        self.dbpath().write_bytes(b'corrupt')
        Path(self.login.path).write_bytes(self.login._encode(DETAILS))
        with self.assertRaises(login.LoginStorageError):self.login.load()
        self.assertTrue(self.login.exists())
        self.assertTrue(Path(self.login.path).exists())

    def test_symlink_database_does_not_touch_target(self):
        self.login.save(DETAILS)
        self.dbpath().unlink()
        target=self.root/'target';target.write_bytes(b'keep')
        self.dbpath().symlink_to(target)
        with self.assertRaises(login.LoginStorageError):self.login.save(DETAILS)
        self.assertEqual(target.read_bytes(),b'keep')

    def test_hardlinked_database_is_rejected(self):
        self.login.save(DETAILS)
        os.link(str(self.dbpath()),str(self.root/'link'))
        with self.assertRaises(login.LoginStorageError):self.login.load()

    def test_private_database_permissions_and_no_backup_files(self):
        self.login.save(DETAILS)
        self.assertEqual(self.dbpath().stat().st_mode & 0o777,0o600)
        self.assertEqual(self.dbpath().parent.stat().st_mode & 0o777,0o700)
        self.assertEqual(sorted(p.name for p in self.dbpath().parent.iterdir()),['.initialized','state.sqlite3'])

    def test_secure_delete_and_extra_sync_are_required(self):
        self.login.save(DETAILS)
        original=sqlite3.connect
        for pragma in ('secure_delete','synchronous'):
            class Weak:
                def __init__(self,*a,**k):self.db=original(*a,**k)
                @property
                def in_transaction(self):return self.db.in_transaction
                def execute(self,sql,*args):
                    if sql=='PRAGMA '+pragma:return Mock(fetchone=Mock(return_value=(0,)))
                    return self.db.execute(sql,*args)
                def close(self):self.db.close()
            with self.subTest(pragma=pragma),patch.object(sqlite3,'connect',Weak):
                with self.assertRaises(login.LoginStorageError) as error:self.login.forget()
            self.assertEqual(error.exception.code,'L504')
        self.assertEqual(self.login.load(),DETAILS)

    def test_interrupted_update_restores_last_committed_login(self):
        self.login.save(DETAILS)
        script=('import sqlite3,sys,os;d=sqlite3.connect(sys.argv[1],isolation_level=None);'
                'd.execute("PRAGMA synchronous=EXTRA");d.execute("BEGIN IMMEDIATE");'
                'd.execute("UPDATE document SET body=?",(b"interrupted",));os._exit(0)')
        result=subprocess.run([sys.executable,'-c',script,str(self.dbpath())],timeout=10)
        self.assertEqual(result.returncode,0)
        self.assertEqual(self.login.load(),DETAILS)

    def test_oversized_login_and_invalid_url_do_not_overwrite(self):
        self.login.save(DETAILS)
        for values in ((URL,USER,'x'*2049),('https://fixture.invalid/?token=fixture',USER,PASSWORD)):
            with self.assertRaises(login.LoginStorageError):self.login.save(values)
        self.assertEqual(self.login.load(),DETAILS)

    def test_production_diagnostic_checks_new_stores_and_forget(self):
        sentinel=self.root/'existing';sentinel.write_bytes(b'keep')
        rows=dict(storage_diagnostic.diagnose_storage(str(self.root)))
        for label in ('Saved login','Permissions','Forget login','Cleanup'):
            self.assertEqual(rows[label],'PASS')
        self.assertEqual(list(self.root.iterdir()),[sentinel])

    def test_forget_cleanup_failure_cannot_resurrect_legacy_password(self):
        self.login.save(DETAILS)
        Path(self.login.path).write_bytes(self.login._encode(DETAILS))
        with patch.object(state, 'remove_legacy', side_effect=state.LocalStateError('L509')):
            with self.assertRaises(login.LoginStorageError):self.login.forget()
        self.assertTrue(Path(self.login.path).exists())
        self.assertIsNone(login.SavedLogin(str(self.root)).load())
        self.assertFalse(Path(self.login.path).exists())

    def test_interruption_during_initial_creation_is_not_silently_reset(self):
        from test_regressions import SOURCE
        script=('import sys,os;sys.path.insert(0,sys.argv[1]);'
                'from shadow.sqlite_local_state import LocalDocument;'
                'LocalDocument(sys.argv[2],"login").mutate(lambda:None,lambda old:os._exit(0))')
        result=subprocess.run([sys.executable,'-c',script,str(SOURCE/'resources/lib'),str(self.root)],timeout=10)
        self.assertEqual(result.returncode,0)
        before=self.dbpath().read_bytes()
        with self.assertRaises(login.LoginStorageError):self.login.save(DETAILS)
        self.assertEqual(self.dbpath().read_bytes(),before)

    def test_permission_disabling_failure_preserves_prior_state_and_reports_error(self):
        self.consent.remember(self.key,OPTIONS)
        with patch.object(sqlite3,'connect',self.failing_connection('COMMIT')):
            with self.assertRaises(login.LoginStorageError):self.consent.set_enabled(False)
        self.assertTrue(self.consent.enabled())
        self.assertEqual(self.consent.lookup(self.key),OPTIONS)

    def test_readonly_connect_cannot_recreate_a_disappeared_database(self):
        self.login.save(DETAILS)
        original=sqlite3.connect
        def connect(*args,**kwargs):
            self.dbpath().unlink()
            return original(*args,**kwargs)
        with patch.object(sqlite3,'connect',side_effect=connect):
            with self.assertRaises(login.LoginStorageError) as error:self.login.load()
        self.assertEqual(error.exception.code,'L503')
        self.assertFalse(self.dbpath().exists())

    def test_ui_saved_connection_skips_keyboard_and_permission_reprompt(self):
        self.login.save(DETAILS)
        self.consent.remember(self.key,OPTIONS)
        w=self.window(False);w.saved_login=self.login;w.connection_permissions=self.consent
        w.run_job=Mock(return_value=self.prepare());w.after_connect=Mock()
        w.connect_saved_provider()
        w.credentials.assert_not_called();w.connection_options.assert_not_called()
        w.after_connect.assert_called_once();self.assertTrue(w.session.connected)
        w.dialog.ok.assert_not_called()

    def test_ui_forget_disconnects_and_revokes_permissions(self):
        self.login.save(DETAILS);self.consent.remember(self.key,OPTIONS)
        w=self.window();w.saved_login=self.login;w.connection_permissions=self.consent;w.jobs=Mock()
        w.forget_saved_login()
        self.assertFalse(w.session.connected)
        self.assertIsNone(self.login.load());self.assertIsNone(self.consent.lookup(self.key))
        self.assertEqual(w.dialog.ok.call_args.args[0],'Saved login forgotten')

    def test_ui_failed_login_read_does_not_attempt_network(self):
        self.login.save(DETAILS);self.dbpath().write_bytes(b'broken')
        w=self.window(False);w.saved_login=self.login;w.run_job=Mock()
        w.connect_saved_provider();w.run_job.assert_not_called()
        self.assertIn('L505',w.dialog.ok.call_args.args[1])
        self.assertNotIn(PASSWORD,str(w.dialog.ok.call_args))


class SelectionTests(DiskCase):
    def test_narrow_selection_sticky_migration_and_io_fail_closed(self):
        profile=str(self.root)
        with patch.object(state,'os',SimpleNamespace(name='nt',path=os.path)):
            self.assertTrue(state.selected(profile,'login'))
        self.assertFalse(state.selected(profile,'login'))
        directory,db,marker=state.paths(profile,'login')
        Path(directory).mkdir();Path(marker).mkdir()
        self.assertTrue(state.selected(profile,'login'))
        with patch.object(state,'_exists',side_effect=PermissionError(RAW)):
            with self.assertRaises(state.LocalStateError):state.selected(profile,'login')


del _WindowHelpers
