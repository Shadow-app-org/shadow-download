""".53 measured-progress budgets and classified failures, using fake time/I/O."""
import errno
import http.client
import io
import socket
import types
import unittest
from unittest.mock import Mock, patch
from test_regressions import URL, USER, PASSWORD, RAW, provider, transport
from test_collections import response
from shadow import collection_progress as cp
from shadow.safe_errors import SafeError, safe_message
from shadow.cancellation import Cancellation, Cancelled, bind

ANSWERS = [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('203.0.113.1',443))]

class CatalogueBudgetTests(unittest.TestCase):
    def setUp(self):
        self.clock = 0.0
        self.time_patch = patch.object(transport.time, 'monotonic', side_effect=lambda:self.clock)
        self.time_patch.start();self.addCleanup(self.time_patch.stop)

    def budget(self):
        budget=transport.CatalogueDeadline(60);budget.start_body();return budget

    def test_progress_continues_past_both_old_limits(self):
        budget=self.budget()
        for self.clock in range(20,281,20):
            budget.progress(8192)
            self.assertGreater(budget.remaining(),0)

    def test_idle_expires_exactly_at_30_seconds(self):
        budget=self.budget();self.clock=29.9;budget.remaining();self.clock=30
        with self.assertRaises(SafeError) as caught:budget.remaining()
        self.assertEqual(caught.exception.code,'X416')

    def test_eof_does_not_renew_inactivity(self):
        budget=self.budget();self.clock=20;budget.progress(0);self.clock=30
        with self.assertRaises(SafeError) as caught:budget.remaining()
        self.assertEqual(caught.exception.code,'X416')

    def test_trickle_cannot_extend_five_minute_cap(self):
        budget=self.budget()
        for self.clock in range(20,300,20):budget.progress(1)
        self.clock=300
        with self.assertRaises(SafeError) as caught:budget.progress(1)
        self.assertEqual(caught.exception.code,'X413')

    def test_preparation_time_is_included_in_total(self):
        state=cp.CollectionStatus();self.clock=275
        with state.active():budget=self.budget()
        self.assertEqual(budget.remaining(),25)
        self.clock=300
        with self.assertRaises(SafeError) as caught:budget.remaining()
        self.assertEqual(caught.exception.code,'X413')

    def test_opening_headers_keep_60_second_absolute_limit(self):
        budget=transport.CatalogueDeadline(60);self.clock=59;budget.progress(1)
        self.clock=60
        with self.assertRaises(transport.TransportError) as caught:budget.start_body()
        self.assertEqual(caught.exception.code,'N409')

    def test_regular_request_deadline_is_not_extended(self):
        budget=transport.Deadline(12);self.clock=12
        with self.assertRaises(transport.TransportError):budget.remaining()

    def test_raw_socket_receives_renew_inside_buffered_read(self):
        budget=self.budget();raw=Mock()
        def receive(buffer):
            self.clock+=10
            size=min(len(buffer),8192);buffer[:size]=b'x'*size;return size
        raw.recv_into.side_effect=receive
        wrapper=transport._DeadlineSocket(raw,budget)
        with wrapper.makefile('rb') as stream:
            self.assertEqual(len(stream.read(65536)),65536)
        self.assertEqual(self.clock,80)
        self.assertEqual(budget.remaining(),30)
        self.assertTrue(all(call.args[0]<=30 for call in raw.settimeout.call_args_list))

    def test_cancel_interrupts_budget_without_diagnostic_remapping(self):
        budget=self.budget();token=Cancellation();bind(token);self.addCleanup(bind,None)
        token.cancel()
        with self.assertRaises(Cancelled):budget.remaining()


class CatalogueReadTests(unittest.TestCase):
    def invoke(self, reply, action='get_vod_streams', clock=None):
        conn=Mock();conn.getresponse.return_value=reply
        client=provider.XtreamClient(URL,USER,PASSWORD)
        with patch.object(transport,'_Connection',return_value=conn),patch.object(transport._DNS,'resolve',return_value=ANSWERS):
            try:return client.request(action)
            finally:
                reply.close.assert_called_once();conn.close.assert_called_once()

    def assert_code(self, reply, code):
        with self.assertRaises(provider.ProviderError) as caught:self.invoke(reply)
        self.assertEqual(caught.exception.code,code)
        self.assertNotIn(PASSWORD,str(caught.exception));self.assertNotIn(USER,str(caught.exception))
        self.assertNotIn('playlist',str(caught.exception))

    def test_movies_download_progresses_for_140_seconds(self):
        self.long_download('get_vod_streams')

    def test_series_download_progresses_for_140_seconds(self):
        self.long_download('get_series')

    def long_download(self, action):
        clock=[0];chunks=[b'[',b'{"stream_id":1,"series_id":1}',b',',b'{"stream_id":2,"series_id":2}',b']',b' ',b' ']
        reply=response(b'',False)
        def read(_):
            if not chunks:return b''
            clock[0]+=20;return chunks.pop(0)
        reply.read.side_effect=read
        with patch.object(transport.time,'monotonic',side_effect=lambda:clock[0]):
            self.assertEqual(len(self.invoke(reply,action)),2)
        self.assertEqual(clock[0],140)

    def test_large_streamed_catalogue_exceeds_reported_record_count(self):
        # ~44 MiB and 114,000 records: no full download byte buffer is built.
        row=b'{"stream_id":1,"name":"'+b'A'*385+b'"}'
        remaining=[114000];reply=response(b'',False);first=[True];finished=[False]
        def read(limit):
            if remaining[0]:
                count=min(100,remaining[0]);remaining[0]-=count
                block=(b'[' if first[0] else b',')+b','.join([row]*count)
                first[0]=False;self.assertLessEqual(len(block),limit);return block
            if not finished[0]:finished[0]=True;return b']'
            return b''
        reply.read.side_effect=read
        with patch.object(transport.time,'monotonic',return_value=0):
            state=cp.CollectionStatus()
            with state.active():rows=self.invoke(reply)
        self.assertEqual(len(rows),114000);self.assertEqual(state.records,114000)
        self.assertGreater(state.received,43.8*1048576)

    def test_socket_timeout_is_classified(self):
        reply=response(b'');reply.read.side_effect=socket.timeout(RAW);self.assert_code(reply,'X416')

    def test_os_timeout_is_classified(self):
        reply=response(b'');reply.read.side_effect=OSError(errno.ETIMEDOUT,RAW);self.assert_code(reply,'X416')

    def test_windows_timeout_is_classified(self):
        error=OSError(RAW);error.winerror=10060
        reply=response(b'');reply.read.side_effect=error;self.assert_code(reply,'X416')

    def test_reset_is_distinguished_from_timeout(self):
        reply=response(b'');reply.read.side_effect=ConnectionResetError(RAW);self.assert_code(reply,'X417')

    def test_http_read_error_is_distinguished(self):
        reply=response(b'');reply.read.side_effect=http.client.HTTPException(RAW);self.assert_code(reply,'X417')

    def test_wrapped_idle_expiry_preserves_deadline_reason(self):
        clock=[0];reply=response(b'')
        def read(_):clock[0]=30;raise OSError(RAW)
        reply.read.side_effect=read
        with patch.object(transport.time,'monotonic',side_effect=lambda:clock[0]):self.assert_code(reply,'X416')

    def test_wrapped_overall_expiry_preserves_deadline_reason(self):
        clock=[0];reply=response(b'')
        def read(_):clock[0]=300;raise OSError(RAW)
        reply.read.side_effect=read
        with patch.object(transport.time,'monotonic',side_effect=lambda:clock[0]):self.assert_code(reply,'X413')

    def test_content_length_mismatch_rejects_complete_json(self):
        reply=response(b'[]');reply.headers.replace_header('Content-Length','20');self.assert_code(reply,'X418')

    def test_truncated_http_chunk_rejects_partial_json(self):
        reply=response(b'');reply.read.side_effect=http.client.IncompleteRead(b'[',100);self.assert_code(reply,'X418')

    def test_malformed_json_reports_catalogue(self):self.assert_code(response(b'[{"stream_id":1},'),'X419')

    def test_invalid_utf8_reports_catalogue(self):self.assert_code(response(b'["\xff"]'),'X419')

    def test_runtime_capability_failure_is_distinguished(self):
        reply=response(b'');reply.read.side_effect=AttributeError(RAW);self.assert_code(reply,'N428')

    def test_unexpected_parser_failure_is_sanitized(self):
        with patch.object(transport.JSONArray,'feed',side_effect=RuntimeError(RAW)):
            self.assert_code(response(b'[]'),'X414')

    def test_cancellation_remains_cancellation_through_provider(self):
        reply=response(b'');reply.read.side_effect=Cancelled()
        with self.assertRaises(Cancelled):self.invoke(reply)

    def test_redirect_protection_is_unchanged(self):self.assert_code(response(b'',status=302),'N440')

    def test_exact_http_status_is_preserved(self):
        for status in (500,502,503,504,599):
            with self.subTest(status=status):
                with self.assertRaises(provider.ProviderError) as caught:self.invoke(response(b'',status=status))
                self.assertEqual(caught.exception.http_status,status)
                self.assertIn('HTTP '+str(status),str(caught.exception))
