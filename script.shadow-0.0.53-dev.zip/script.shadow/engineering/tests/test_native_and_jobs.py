import errno
from pathlib import Path
from threading import Event
from unittest import TestCase
from unittest.mock import Mock,patch
from test_regressions import DiskCase, RAW, file_sync, preferences, jobs, application, provider, URL, USER, PASSWORD
from shadow.safe_errors import SafeError

class FileSyncTests(TestCase):
    def test_fsync_success_never_uses_native_fallback(self):
        file=Mock()
        with patch.object(file_sync.os,'fsync') as sync,patch.object(file_sync,'_native_flush') as native:
            file_sync.sync_file(file,'fixture')
        sync.assert_called_once();native.assert_not_called();file.close.assert_not_called()

    def test_compatible_windows_error_closes_python_handle_before_native_flush(self):
        file=Mock();order=[];file.close.side_effect=lambda:order.append('close')
        with patch.object(file_sync.os,'fsync',side_effect=OSError(errno.EBADF,RAW)),patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_native_flush',side_effect=lambda path:order.append(path)):
            file_sync.sync_file(file,'C:\\profile\\.shadow-test.tmp')
        self.assertEqual(order,['close','C:\\profile\\.shadow-test.tmp'])

    def test_unavailable_fsync_windows_uses_native_path(self):
        file=Mock()
        with patch.object(file_sync.os,'fsync',side_effect=NotImplementedError()),patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_native_flush') as native:
            file_sync.sync_file(file,'C:\\profile\\.shadow-test.tmp')
        native.assert_called_once();file.close.assert_called_once()

    def test_nonwindows_sync_error_does_not_bypass(self):
        with patch.object(file_sync.os,'fsync',side_effect=OSError(errno.EINVAL,RAW)),patch.object(file_sync,'_windows',return_value=False),patch.object(file_sync,'_native_flush') as native:
            with self.assertRaises(OSError):file_sync.sync_file(Mock(),'fixture')
        native.assert_not_called()

    def test_disk_full_windows_does_not_fallback(self):
        with patch.object(file_sync.os,'fsync',side_effect=OSError(errno.ENOSPC,RAW)),patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_native_flush') as native:
            with self.assertRaises(OSError):file_sync.sync_file(Mock(),'fixture')
        native.assert_not_called()

    def test_native_file_existing_exclusive_and_disk_only(self):
        api=Mock();api.CreateFile2.return_value=123;api.GetFileType.return_value=1
        api.FlushFileBuffers.return_value=1;api.CloseHandle.return_value=1
        with patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_api',return_value=(api,-1)):
            file_sync._native_flush('C:\\profile\\.shadow-test.tmp')
        api.CreateFile2.assert_called_once_with('C:\\profile\\.shadow-test.tmp',0x40000000,0,3,None)
        api.FlushFileBuffers.assert_called_once_with(123);api.CloseHandle.assert_called_once_with(123)

    def test_native_flush_failure_reported_and_handle_closed(self):
        api=Mock();api.CreateFile2.return_value=123;api.GetFileType.return_value=1
        api.FlushFileBuffers.return_value=0;api.CloseHandle.return_value=1
        with patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_api',return_value=(api,-1)):
            with self.assertRaises(SafeError) as caught:file_sync._native_flush('C:\\profile\\.shadow-test.tmp')
        self.assertEqual(caught.exception.code,'S418');api.CloseHandle.assert_called_once()

    def test_native_pipe_rejected_and_handle_closed(self):
        api=Mock();api.CreateFile2.return_value=123;api.GetFileType.return_value=3;api.CloseHandle.return_value=1
        with patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_api',return_value=(api,-1)):
            with self.assertRaises(SafeError) as caught:file_sync._native_flush('C:\\profile\\.shadow-test.tmp')
        self.assertEqual(caught.exception.code,'S417');api.FlushFileBuffers.assert_not_called();api.CloseHandle.assert_called_once()

    def test_native_close_failure_blocks_success(self):
        api=Mock();api.CreateFile2.return_value=123;api.GetFileType.return_value=1;api.FlushFileBuffers.return_value=1;api.CloseHandle.return_value=0
        with patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_api',return_value=(api,-1)):
            with self.assertRaises(SafeError) as caught:file_sync._native_flush('C:\\profile\\.shadow-test.tmp')
        self.assertEqual(caught.exception.code,'S419')

    def test_native_unsafe_paths_blocked_before_api_lookup(self):
        for path in (RAW,'relative.tmp','\\\\server\\share\\.shadow-test.tmp','C:\\profile\\..\\.shadow-test.tmp','C:\\profile\\.shadow-test.tmp:ads','C:\\profile\\not-shadow.tmp'):
            with self.subTest(path=path),patch.object(file_sync,'_windows',return_value=True),patch.object(file_sync,'_api') as api:
                with self.assertRaises(SafeError) as caught:file_sync._native_flush(path)
                self.assertEqual(caught.exception.code,'S417');api.assert_not_called()

class JobsTests(TestCase):
    def test_cancelled_success_is_disposed_not_adopted(self):
        entered=Event();release=Event();disposed=Mock();result=object()
        def operation():entered.set();release.wait(2);return result
        job=jobs.Job(operation,disposed)
        self.assertTrue(entered.wait(2));job.cancel();release.set()
        self.assertTrue(job.done.wait(2));self.assertIsNone(job.take());disposed.assert_called_once_with(result)

    def test_cancel_completed_job_disposes_owned_result(self):
        result=object();dispose=Mock();job=jobs.Job(lambda:result,dispose)
        self.assertTrue(job.done.wait(2));job.cancel();self.assertIsNone(job.take());dispose.assert_called_once_with(result)

    def test_worker_result_has_single_owner(self):
        result=object();job=jobs.Job(lambda:result)
        self.assertTrue(job.done.wait(2));self.assertIs(job.take(),result);self.assertIsNone(job.take())

class AdditionalStorageTests(DiskCase):
    def test_write_failure_S408_preserves_previous_file(self):
        store=self.store();data=store.save(store.load(),'');before=Path(store.path).read_bytes()
        actual=preferences.tempfile.NamedTemporaryFile
        def factory(*a,**k):
            file=actual(*a,**k)
            original=file.write
            def fail(body):
                original(body[:3]);raise OSError(errno.ENOSPC,RAW)
            file.write=fail
            return file
        with patch.object(preferences.tempfile,'NamedTemporaryFile',side_effect=factory):
            with self.assertRaises(preferences.PreferencesError) as caught:store.save(dict(data,theme='charcoal'),data['revision'])
        self.assertEqual(caught.exception.code,'S408');self.assertEqual(Path(store.path).read_bytes(),before)
        self.assertFalse(list((self.root/'accounts').glob('.shadow-*')))

    def test_unexpected_filesystem_error_retains_original45_classification(self):
        with patch.object(application,'AccountStore',side_effect=OSError(RAW)):
            with self.assertRaises(provider.ProviderError) as caught:self.prepare()
        self.assertEqual(caught.exception.code,'S413');self.assertNotIn(RAW,str(caught.exception))

    def test_lock_creation_unsupported_has_storage_code(self):
        self.store()
        with patch.object(preferences.os,'mkdir',side_effect=NotImplementedError(RAW)):
            with self.assertRaises(preferences.PreferencesError) as caught:
                with preferences._lock(self.root/'settings'):pass
        self.assertEqual(caught.exception.code,'S403')

    def test_lock_release_failure_is_reported(self):
        with patch.object(preferences.os,'rmdir',side_effect=OSError(RAW)):
            with self.assertRaises(preferences.PreferencesError) as caught:
                with preferences._lock(self.root/'settings'):pass
        self.assertEqual(caught.exception.code,'S411')
