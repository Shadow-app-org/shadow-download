"""Emulate Kodi's non-exclusive create behaviour; retain all file guards."""
import errno
import os
from pathlib import Path
import sqlite3
from types import SimpleNamespace
from unittest.mock import Mock, patch
from test_regressions import DiskCase, accounts, preferences, RAW
from shadow import sqlite_accounts as backend, storage_diagnostic as diagnostic


class KodiSQLiteTests(DiskCase):
    def setUp(self):
        super().setUp()
        select = patch.object(backend, 'selected', return_value=True)
        select.start()
        self.addCleanup(select.stop)

    def test_kodi_ignoring_exclusive_flag_cannot_truncate_database(self):
        native_open = os.open
        attempts = []
        def emulated_open(path, flags, *args, **kwargs):
            if os.path.basename(os.fspath(path)) == backend.DATABASE:
                attempts.append(flags)
                if flags & os.O_CREAT:
                    flags = (flags & ~os.O_EXCL) | os.O_TRUNC
            return native_open(path, flags, *args, **kwargs)
        with patch.object(os, 'open', side_effect=emulated_open):
            first = self.store()
            data = first.load()
            saved = first.save(dict(data, theme='charcoal'), data['revision'])
            second = self.store()
            self.assertEqual(first.scope, second.scope)
            self.assertEqual(second.load(), saved)
            second.save(dict(saved, theme='obsidian'), saved['revision'])
            self.assertEqual(first.backup(), saved)
        self.assertEqual(attempts, [])

    def test_existing_database_uses_native_readwrite_without_create_mode(self):
        store = self.store()
        original = sqlite3.connect
        with patch.object(sqlite3, 'connect', side_effect=original) as connect:
            store.load()
        uri = connect.call_args.args[0]
        self.assertTrue(uri.startswith('file:'))
        self.assertTrue(uri.endswith('?mode=rw'))
        self.assertIs(connect.call_args.kwargs['uri'], True)

    def test_file_removed_just_before_connect_is_not_recreated(self):
        store = self.store()
        original = sqlite3.connect
        def remove_and_connect(*args, **kwargs):
            os.unlink(store.sqlite.path)
            return original(*args, **kwargs)
        with patch.object(sqlite3, 'connect', side_effect=remove_and_connect):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.load()
        self.assertEqual(error.exception.code, 'S460')
        self.assertFalse(os.path.exists(store.sqlite.path))

    def test_directory_metadata_failure_has_specific_code(self):
        original = os.lstat
        directory = str(self.root/'accounts')
        def metadata(path, *args, **kwargs):
            if os.fspath(path) == directory:
                raise AttributeError(RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'lstat', side_effect=metadata):
            with self.assertRaises(preferences.PreferencesError) as error:
                self.store()
        self.assertEqual(error.exception.code, 'S451')
        self.assertNotIn(RAW, str(error.exception))

    def test_zero_reported_link_count_still_blocks_saving_with_specific_code(self):
        store = self.store()
        original = os.lstat
        def metadata(path, *args, **kwargs):
            info = original(path, *args, **kwargs)
            if os.fspath(path) == store.sqlite.path:
                return SimpleNamespace(st_mode=info.st_mode, st_size=info.st_size, st_nlink=0)
            return info
        with patch.object(os, 'lstat', side_effect=metadata):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.load()
        self.assertEqual(error.exception.code, 'S457')

    def test_database_stat_error_has_specific_code(self):
        store = self.store()
        original = os.lstat
        def metadata(path, *args, **kwargs):
            if os.fspath(path) == store.sqlite.path:
                raise OSError(errno.EIO, RAW)
            return original(path, *args, **kwargs)
        with patch.object(os, 'lstat', side_effect=metadata):
            with self.assertRaises(preferences.PreferencesError) as error:
                store.load()
        self.assertEqual(error.exception.code, 'S455')

    def test_backend_selection_does_not_hide_io_error_as_absent_database(self):
        with patch.object(backend.os, 'lstat', side_effect=OSError(errno.EIO, RAW)):
            with self.assertRaises(preferences.PreferencesError) as error:
                backend._exists(str(self.root/backend.DATABASE))
        self.assertEqual(error.exception.code, 'S455')

    def test_hardlinked_database_is_still_rejected(self):
        store = self.store()
        os.link(store.sqlite.path, str(self.root/'second-link'))
        with self.assertRaises(preferences.PreferencesError) as error:
            store.load()
        self.assertEqual(error.exception.code, 'S457')

    def test_symlink_has_specific_code_and_target_is_preserved(self):
        directory = self.root/'accounts'
        directory.mkdir()
        target = self.root/'target'
        target.write_bytes(b'keep')
        (directory/backend.DATABASE).symlink_to(target)
        with self.assertRaises(preferences.PreferencesError) as error:
            self.store()
        self.assertEqual(error.exception.code, 'S456')
        self.assertEqual(target.read_bytes(), b'keep')

    def test_database_version_failure_has_specific_code(self):
        store = self.store()
        db = sqlite3.connect(store.sqlite.path)
        db.execute('PRAGMA user_version=2')
        db.close()
        with self.assertRaises(preferences.PreferencesError) as error:
            store.load()
        self.assertEqual(error.exception.code, 'S462')

    def test_failed_private_permissions_block_initialization(self):
        with patch.object(os, 'chmod', side_effect=OSError(errno.EACCES, RAW)):
            with self.assertRaises(preferences.PreferencesError) as error:
                self.store()
        self.assertEqual(error.exception.code, 'S464')

    def test_sqlite_uri_escapes_literal_query_characters_in_profile_path(self):
        directory = self.root/'name?mode=ro#fragment'
        backend_store = backend.SQLiteAccounts(str(directory))
        key = backend_store.key()
        self.assertEqual(backend_store.key(), key)
        self.assertTrue((directory/backend.DATABASE).exists())

    def test_metadata_report_is_bounded_and_credential_free(self):
        self.assertEqual(diagnostic._sqlite(str(self.root)), 'PASS (EXTRA)')
        self.assertEqual(diagnostic._metadata(str(self.root)), 'dir=OK; regular; links=1')
        with patch.object(diagnostic.os, 'lstat', side_effect=OSError(errno.EACCES, RAW)):
            result = diagnostic._metadata(str(self.root))
        self.assertEqual(result, 'PermissionError(EACCES)')
        self.assertNotIn(RAW, result)
