"""SHD-045B regression tests. All networking is mocked; .invalid fixtures only."""
import errno
import json
import os
from pathlib import Path
import socket
import ssl
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

SOURCE = Path(os.environ.get('SHADOW_SOURCE', 'work48/script.shadow')).resolve()
sys.path.insert(0, str(SOURCE / 'resources/lib'))
from shadow import accounts, application, preferences, provider, transport, jobs, file_sync
from shadow.safe_errors import SafeError

URL = 'https://fixture.invalid'
USER = 'fixture-user'
PASSWORD = 'fixture-password'
RAW = URL + '/player_api.php?username=' + USER + '&password=' + PASSWORD

def client_factory(*args, **kwargs):
    def fixture(url, timeout):
        if 'get_live_categories' in url:
            return b'[{"category_id":"1","category_name":"UK"}]'
        if 'get_live_streams' in url:
            return b'[{"stream_id":1,"category_id":"1","name":"UK Test"}]'
        return b'{"user_info":{"auth":1,"status":"Active"}}'
    return provider.XtreamClient(*args, transport=fixture, **kwargs)

class DiskCase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
    def store(self):
        return accounts.AccountStore(str(self.root/'accounts'), URL+'/player_api.php', USER)
    def prepare(self):
        return application.prepare_connection(str(self.root), URL, USER, PASSWORD, client_factory=client_factory)

class ConfirmedDefects(DiskCase):
    def test_native_sync_failure_retains_storage_code(self):
        with patch.object(preferences, 'sync_file', side_effect=SafeError('S421')):
            with self.assertRaises(provider.ProviderError) as caught:
                self.prepare()
        self.assertEqual(caught.exception.code, 'S421')
        self.assertEqual(caught.exception.stage, 'settings')

    def test_settings_read_runtime_failure_has_actionable_code(self):
        store = self.store()
        with patch.object(preferences, 'read_regular_bytes', side_effect=NotImplementedError(RAW)):
            with self.assertRaises(preferences.PreferencesError) as caught:
                store.load()
        self.assertEqual(caught.exception.code, 'S412')
        self.assertNotIn(PASSWORD, str(caught.exception))

    def test_worker_preserves_recovery_storage_errors(self):
        def fail():
            raise preferences.PreferencesError('fixture failure', 'S412')
        job = jobs.Job(fail)
        self.assertTrue(job.done.wait(2))
        with self.assertRaises(jobs.JobError) as caught:
            job.take()
        self.assertEqual(caught.exception.code, 'S412')

    def test_http_503_survives_transport_provider_application_worker(self):
        response = Mock(status=503)
        connection = Mock()
        connection.getresponse.return_value = response
        dns = Mock()
        dns.resolve.return_value = [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('203.0.113.1',443))]
        def factory(*args, **kwargs):
            return provider.XtreamClient(*args, transport=lambda url, timeout: transport.request_bytes(url, dns=dns), **kwargs)
        with patch.object(transport, '_Connection', return_value=connection):
            job = jobs.Job(lambda: application.prepare_connection(str(self.root), URL, USER, PASSWORD, client_factory=factory))
            self.assertTrue(job.done.wait(2))
        with self.assertRaises(jobs.JobError) as caught:
            job.take()
        self.assertEqual(caught.exception.code, 'N503')
        self.assertEqual(getattr(caught.exception, 'http_status', None), 503)
        response.read.assert_not_called()

if __name__ == '__main__':
    unittest.main()
