"""Isolated diagnostic checks; actual SQLite on Linux and mocked Xbox failures."""
import errno
import importlib
from pathlib import Path
import sqlite3
from unittest import TestCase
from unittest.mock import Mock, patch

from test_regressions import DiskCase, RAW, file_sync
from shadow import storage_diagnostic as diagnostic
from shadow.safe_errors import SafeError
from test_wizard import ShadowWindow


class DiagnosticTests(DiskCase):
    def test_success_and_cleanup_leave_existing_profile_bytes_unchanged(self):
        sentinel = self.root / 'valid-preferences.json'
        sentinel.write_bytes(b'existing user preferences')
        rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertEqual(rows['Current saver'], 'PASS')
        self.assertEqual(rows['File sync'], 'PASS')
        self.assertEqual(rows['SQLite'], 'PASS (EXTRA)')
        self.assertEqual(rows['Cleanup'], 'PASS')
        self.assertEqual(sentinel.read_bytes(), b'existing user preferences')
        self.assertEqual(list(self.root.iterdir()), [sentinel])

    def test_S420_and_EBADF_reported_without_blocking_other_probes(self):
        original = importlib.import_module
        def load(name):
            if name == 'ctypes':
                raise ModuleNotFoundError(RAW)
            return original(name)
        with patch.object(diagnostic, 'check_storage', side_effect=SafeError('S420')), \
                patch.object(diagnostic.os, 'fsync', side_effect=OSError(errno.EBADF, RAW)), \
                patch.object(diagnostic.importlib, 'import_module', side_effect=load):
            rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertEqual(rows['Current saver'], 'S420')
        self.assertEqual(rows['ctypes'], 'ModuleNotFoundError')
        self.assertEqual(rows['File sync'], 'fsync/OSError(EBADF)')
        self.assertEqual(rows['SQLite'], 'PASS (EXTRA)')
        self.assertNotIn(RAW, str(rows))
        self.assertEqual(list(self.root.iterdir()), [])

    def test_missing_fsync_is_distinguished_from_permission_failure(self):
        for error, expected in [(AttributeError(RAW), 'fsync/AttributeError'),
                                (NotImplementedError(RAW), 'fsync/NotImplementedError'),
                                (OSError(errno.EACCES, RAW), 'fsync/PermissionError(EACCES)'),
                                (OSError(errno.ENOSPC, RAW), 'fsync/OSError(ENOSPC)')]:
            with self.subTest(expected=expected), patch.object(diagnostic.os, 'fsync', side_effect=error):
                self.assertEqual(diagnostic._fsync(str(self.root)), expected)

    def test_file_creation_failure_is_not_mislabelled_as_sync_failure(self):
        with patch.object(diagnostic.tempfile, 'NamedTemporaryFile', side_effect=PermissionError(errno.EACCES, RAW)):
            self.assertEqual(diagnostic._fsync(str(self.root)), 'create/PermissionError(EACCES)')

    def test_import_dependency_failure_sanitized(self):
        with patch.object(diagnostic.importlib, 'import_module', side_effect=ImportError(RAW)):
            self.assertEqual(diagnostic._ctypes(), 'ImportError')
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'import/ImportError')

    def test_unavailable_sqlite_safely_reported(self):
        with patch.object(diagnostic.importlib, 'import_module', side_effect=ModuleNotFoundError(RAW)):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'import/ModuleNotFoundError')

    def test_missing_native_dependency_name_is_allowlisted(self):
        with patch.object(diagnostic.importlib, 'import_module',
                          side_effect=ModuleNotFoundError(RAW, name='_ctypes')):
            self.assertEqual(diagnostic._ctypes(), 'ModuleNotFoundError(_ctypes)')

    def test_unexpected_import_name_is_redacted(self):
        with patch.object(diagnostic.importlib, 'import_module',
                          side_effect=ModuleNotFoundError(RAW, name=RAW)):
            self.assertEqual(diagnostic._ctypes(), 'ModuleNotFoundError')

    def test_production_native_import_failure_is_S420(self):
        import builtins
        original = builtins.__import__
        def load(name, *args, **kwargs):
            if name == 'ctypes':
                raise ModuleNotFoundError(RAW, name='_ctypes')
            return original(name, *args, **kwargs)
        with patch.object(builtins, '__import__', side_effect=load), \
                patch.object(file_sync, '_windows', return_value=True):
            with self.assertRaises(SafeError) as caught:
                file_sync._native_flush('C:\\profile\\.shadow-test.tmp')
        self.assertEqual(caught.exception.code, 'S420')

    def test_sqlite_open_failure_reports_numeric_code_only(self):
        error = sqlite3.OperationalError(RAW)
        error.sqlite_errorcode = 14
        with patch.object(sqlite3, 'connect', side_effect=error):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'open/config/Error(sqlite=14)')

    def test_sqlite_rejects_missing_extra_sync(self):
        db = Mock()
        db.execute.return_value.fetchone.side_effect = [('delete',), (1,)]
        with patch.object(sqlite3, 'connect', return_value=db):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'open/config/ValueError')
        db.close.assert_called_once()
        self.assertFalse(any(c.args[0] == 'BEGIN IMMEDIATE' for c in db.execute.call_args_list))

    def test_sqlite_rejects_wrong_journal_mode(self):
        db = Mock()
        db.execute.return_value.fetchone.return_value = ('off',)
        with patch.object(sqlite3, 'connect', return_value=db):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'open/config/ValueError')
        db.close.assert_called_once()

    def test_sqlite_commit_failure_closes_connection(self):
        db = Mock()
        db.execute.return_value.fetchone.side_effect = [('delete',), (3,)]
        def execute(sql):
            if sql == 'COMMIT':
                raise sqlite3.OperationalError(RAW)
            return db.execute.return_value
        db.execute.side_effect = execute
        with patch.object(sqlite3, 'connect', return_value=db):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'commit/Error')
        db.close.assert_called_once()

    def test_sqlite_wrong_reopened_data_is_not_a_pass(self):
        db = Mock()
        db.execute.return_value.fetchone.side_effect = [('delete',), (3,), ('delete',), (3,)]
        db.execute.return_value.fetchall.return_value = [(2,)]
        with patch.object(sqlite3, 'connect', return_value=db):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'reopen/ValueError')
        self.assertEqual(db.close.call_count, 2)

    def test_sqlite_integrity_failure_is_not_a_pass(self):
        db = Mock()
        db.execute.return_value.fetchone.side_effect = [('delete',), (3,)] * 3
        db.execute.return_value.fetchall.side_effect = [[(1,)], [(1,)], [(1,)], [(RAW,)]]
        with patch.object(sqlite3, 'connect', return_value=db):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'verify/ValueError')

    def test_sqlite_final_close_failure_overrides_pass(self):
        db = Mock()
        db.execute.return_value.fetchone.side_effect = [('delete',), (3,)] * 3
        db.execute.return_value.fetchall.side_effect = [[(1,)], [(1,)], [(1,)], [('ok',)]]
        db.close.side_effect = [None, None, OSError(errno.EIO, RAW)]
        with patch.object(sqlite3, 'connect', return_value=db):
            self.assertEqual(diagnostic._sqlite(str(self.root)), 'close/OSError(EIO)')

    def test_profile_creation_failure_reports_no_false_probe_results(self):
        with patch.object(diagnostic, 'check_storage', side_effect=SafeError('S401')), \
                patch.object(diagnostic.tempfile, 'TemporaryDirectory', side_effect=PermissionError(errno.EACCES, RAW)):
            rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertEqual(rows['Current saver'], 'S401')
        self.assertEqual(rows['Probe folder'], 'PermissionError(EACCES)')
        self.assertNotIn('SQLite', rows)
        self.assertNotIn('File sync', rows)

    def test_cleanup_failure_retains_other_evidence(self):
        temp = Mock(name=str(self.root))
        temp.name = str(self.root)
        temp.cleanup.side_effect = PermissionError(errno.EACCES, RAW)
        with patch.object(diagnostic, 'check_storage', side_effect=SafeError('S420')), \
                patch.object(diagnostic.tempfile, 'TemporaryDirectory', return_value=temp):
            rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertEqual(rows['Current saver'], 'S420')
        self.assertEqual(rows['Cleanup'], 'PermissionError(EACCES)')
        self.assertEqual(rows['SQLite'], 'PASS (EXTRA)')

    def test_unexpected_production_exception_cannot_expose_credentials(self):
        with patch.object(diagnostic, 'check_storage', side_effect=RuntimeError(RAW)):
            rows = dict(diagnostic.diagnose_storage(str(self.root)))
        self.assertEqual(rows['Current saver'], 'S413')
        self.assertNotIn(RAW, str(rows))

    def test_probe_never_changes_production_sync_policy(self):
        diagnostic.diagnose_storage(str(self.root))
        with patch.object(file_sync.os, 'fsync', side_effect=OSError(errno.EBADF, RAW)), \
                patch.object(file_sync, '_windows', return_value=True), \
                patch.object(file_sync, '_native_flush', side_effect=SafeError('S420')):
            with self.assertRaises(SafeError) as caught:
                file_sync.sync_file(Mock(), 'C:\\profile\\.shadow-test.tmp')
        self.assertEqual(caught.exception.code, 'S420')

    def test_arbitrary_exception_class_name_is_not_displayed(self):
        error = type('secret_provider_password', (Exception,), {})(RAW)
        error.errno = RAW
        error.sqlite_errorcode = RAW
        self.assertEqual(diagnostic._error(error), 'Error')


class DiagnosticUITests(TestCase):
    def window(self):
        w = ShadowWindow.__new__(ShadowWindow)
        w.profile = 'unused'
        w.dialog = Mock()
        w.stop_playback = Mock()
        w.run_job = Mock()
        return w

    def test_diagnostic_action_displays_report_without_pass_title(self):
        w = self.window()
        w.run_job.side_effect = lambda _label, operation: operation()
        rows = [('Current saver', 'S420'), ('SQLite', 'PASS (EXTRA)')]
        with patch.object(diagnostic, 'diagnose_storage', return_value=rows) as probe:
            w.check_storage()
        probe.assert_called_once_with('unused')
        title, body = w.dialog.ok.call_args.args
        self.assertIn('0.0.53', title)
        self.assertNotIn('PASS', title)
        self.assertIn('Current saver: S420', body)
        self.assertIn('Account, login and permission checks only', body)

    def test_cancelled_diagnostic_has_explanation(self):
        w = self.window()
        w.run_job.return_value = None
        w.check_storage()
        self.assertIn('cancelled', w.dialog.ok.call_args.args[0])

    def test_job_failure_is_sanitized(self):
        from shadow.jobs import JobError
        w = self.window()
        error = JobError()
        error.code = RAW
        w.run_job.side_effect = error
        w.check_storage()
        self.assertIn('S413', w.dialog.ok.call_args.args[0])
        self.assertNotIn(RAW, str(w.dialog.ok.call_args))
