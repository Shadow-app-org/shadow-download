"""Kodi channel-switch sequencing with a controllable native player; no network."""
import types
import os
from pathlib import Path
import xml.etree.ElementTree as ET
from unittest.mock import Mock, patch
from test_regressions import DiskCase, jobs
import test_wizard
from shadow import kodi_ui, playback


class ChannelSwitchTests(DiskCase):
    def window(self):
        w=test_wizard.WizardTests.window(self)
        w.session.connection.channels.append(dict(w.session.connection.channels[0],stream_id='2',name='Second'))
        w.session.save({'approved_channel_ids':['1','2'],'content_types':['live']})
        w.demo=False;w.playing_media=None;w.reconnect_context=None
        w.switch_state=None;w.switch_jobs=Mock();w.switch_jobs.active=None
        w.playing_channel='1';w.playback=Mock();w.playback.url='http://127.0.0.1:1/play/fixture.ts'
        w.playback.player.isPlaying.return_value=True;w.playback.player.getPlayingFile.return_value=w.playback.url
        w.playback.return_ready.return_value=False
        w.close_overlay=Mock();w.clear_playback_clock=Mock();w.show=Mock();w.show_loading_cover=Mock()
        w.return_from_playback=Mock();w.begin_playback=Mock();w.loading_cover=None
        w.cancel_switch=types.MethodType(kodi_ui.ShadowWindow.cancel_switch,w)
        return w

    def stopping(self):
        w=self.window();w.request_switch('2');return w

    def test_switch_queues_stop_without_opening_any_window(self):
        w=self.stopping()
        w.playback.stop.assert_called_once();w.close_overlay.assert_called_once()
        w.show.assert_not_called();w.show_loading_cover.assert_not_called()
        self.assertEqual(w.switch_state['phase'],'stopping')

    def test_overlay_switch_event_yields_before_polling(self):
        w=self.window();w.overlay=types.SimpleNamespace(event=('switch','2',w.session.connection))
        self.assertTrue(w.poll_overlay_action());self.assertIsNone(w.overlay.event)
        w.show.assert_not_called();w.switch_jobs.submit.assert_not_called()

    def test_old_playing_stream_blocks_new_window_and_request(self):
        w=self.stopping();w.poll_switch()
        w.show.assert_not_called();w.show_loading_cover.assert_not_called();w.switch_jobs.submit.assert_not_called()
        self.assertEqual(w.switch_state['phase'],'stopping')

    def test_idle_opens_cover_then_yields_before_network_preparation(self):
        w=self.stopping();w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        w.poll_switch()
        w.show.assert_called_once();w.show_loading_cover.assert_called_once();w.switch_jobs.submit.assert_not_called()
        self.assertEqual(w.switch_state['phase'],'preparing')
        w.poll_switch();w.switch_jobs.submit.assert_called_once()

    def test_still_owned_url_does_not_open_window_even_if_stop_poll_races(self):
        w=self.stopping();w.playback.return_ready.return_value=True
        w.poll_switch();w.show.assert_not_called();w.switch_jobs.submit.assert_not_called()

    def test_successful_switch_hands_prepared_stream_to_controller(self):
        w=self.stopping();w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        w.poll_switch()
        prepared=Mock();prepared.permitted.return_value=True
        job=Mock();job.done.is_set.return_value=True;job.take.return_value=prepared
        w.switch_jobs.submit.return_value=job
        w.poll_switch();w.poll_switch()
        w.begin_playback.assert_called_once_with(prepared);self.assertEqual(w.playing_channel,'2')
        self.assertIsNone(w.switch_state);prepared.close.assert_not_called()

    def test_preparation_failure_closes_switch_and_schedules_error_return(self):
        w=self.stopping();w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        w.poll_switch()
        failure=jobs.JobError('Synthetic');failure.code='N454';failure.stage='stream'
        job=Mock();job.done.is_set.return_value=True;job.take.side_effect=failure
        w.switch_jobs.submit.return_value=job;w.poll_switch();w.poll_switch()
        self.assertIsNone(w.switch_state);job.cancel.assert_called_once();w.begin_playback.assert_not_called()
        w.return_from_playback.assert_called_once_with(failed=True,error=failure)

    def test_switch_timeout_does_not_wait_for_user_back(self):
        w=self.stopping();w.switch_state['deadline']=0
        w.poll_switch()
        self.assertIsNone(w.switch_state);w.return_from_playback.assert_called_once()
        self.assertTrue(w.return_from_playback.call_args.kwargs['failed'])
        self.assertEqual(w.return_from_playback.call_args.kwargs['error'].code,'N409')
        w.show.assert_not_called()

    def test_unrelated_player_is_not_replaced(self):
        w=self.stopping();w.playback.player.getPlayingFile.return_value='unrelated-item'
        w.poll_switch();self.assertIsNone(w.switch_state)
        w.playback.stop.assert_called_once();w.show.assert_not_called();w.begin_playback.assert_not_called()
        w.switch_jobs.submit.assert_not_called()

    def test_changed_account_invalidates_switch(self):
        w=self.stopping();w.session.adopt(self.prepare());w.poll_switch()
        self.assertIsNone(w.switch_state);w.show.assert_not_called();w.switch_jobs.submit.assert_not_called()

    def test_revoked_channel_approval_stops_switch(self):
        w=self.stopping();w.session.save({'approved_channel_ids':['1']});w.poll_switch()
        self.assertIsNone(w.switch_state);w.begin_playback.assert_not_called()
        self.assertEqual(w.return_from_playback.call_args.kwargs['error'].code,'P401')

    def test_selecting_current_channel_only_dismisses_overlay(self):
        w=self.window();w.request_switch('1');w.close_overlay.assert_called_once()
        w.playback.stop.assert_not_called();w.show.assert_not_called();self.assertIsNone(w.switch_state)

    def test_loading_cover_back_remains_available(self):
        cover=kodi_ui.LoadingCover();cover.onAction(types.SimpleNamespace(getId=lambda:92))
        self.assertTrue(cover.cancelled)

    def test_loading_cover_is_above_all_main_window_controls(self):
        path=Path(os.environ['SHADOW_SOURCE'])/'resources/skins/Default/1080i/Shadow.xml'
        root=ET.parse(path).getroot();controls=root.find('controls')
        self.assertEqual(controls[-1].attrib.get('description'),'playback-loading-cover')
        self.assertEqual(controls[-1].find('control/texture').text,'shadow-white.png')
        self.assertEqual(controls[-1].find('control/colordiffuse').text,'FF090909')

    def test_live_favourites_and_programme_progress_hide_while_loading(self):
        path=Path(os.environ['SHADOW_SOURCE'])/'resources/skins/Default/1080i/Shadow.xml'
        root=ET.parse(path).getroot()
        for identity in ('422','335'):
            visible=root.find(".//control[@id='%s']/visible" % identity).text
            self.assertIn('!String.IsEqual(Window.Property(shadow.loading),true)',visible)
