"""Catalogue transport, progress, cancellation and UI recovery; no live requests."""
import io
import json
import socket
import threading
import types
import unittest
from email.message import Message
from unittest.mock import Mock, patch
from test_regressions import DiskCase, URL, USER, PASSWORD, RAW, application, provider, transport, jobs
import test_wizard
from shadow import collection_progress as cp, kodi_ui, xtream
from shadow.cancellation import Cancellation, Cancelled, bind
from shadow.safe_errors import SafeError


def response(payload, length=True, status=200):
    result = Mock(status=status)
    result.headers = Message()
    if length:
        result.headers['Content-Length'] = str(len(payload))
    result.getheader.side_effect = lambda key, default=None: result.headers.get(key, default)
    result.read.side_effect = io.BytesIO(payload).read
    return result


class ProgressTests(unittest.TestCase):
    def test_unknown_size_has_counts_without_percentage(self):
        state = cp.CollectionStatus();state.update('download', received=1048576, records=200)
        text, percent = state.view()
        self.assertIsNone(percent);self.assertIn('1.0 MiB', text);self.assertIn('200 records', text)
        self.assertIn('total size unknown', text)

    def test_download_percentage_uses_received_bytes(self):
        state = cp.CollectionStatus();state.update('download', received=512, expected_bytes=2048)
        self.assertEqual(state.view()[1], 25)

    def test_processing_percentage_uses_record_count(self):
        state = cp.CollectionStatus();state.update('processing', processed=75, total=300)
        self.assertEqual(state.view()[1], 25);self.assertIn('75 / 300', state.message())

    def test_elapsed_time_never_advances_percentage(self):
        with patch.object(cp.time, 'monotonic', return_value=0):state = cp.CollectionStatus()
        state.update('processing', processed=10, total=100)
        with patch.object(cp.time, 'monotonic', return_value=90):
            self.assertEqual(state.view()[1], 10);self.assertIn('90s', state.message())

    def test_empty_preparation_is_not_ready_until_completed(self):
        state=cp.CollectionStatus();state.update('processing',total=0)
        self.assertEqual(state.view()[1],0)
        state.update('ready');self.assertEqual(state.view()[1],100)

    def test_invalid_progress_fields_cannot_leak_strings(self):
        state=cp.CollectionStatus();state.update(RAW,received=RAW,records=True,total=-1,expected_bytes=2**70)
        self.assertNotIn(USER,state.message());self.assertNotIn(PASSWORD,state.message())
        self.assertIsNone(state.view()[1]);self.assertEqual(state.records,0)

    def test_reporting_is_worker_local_and_restores_context(self):
        outer=cp.CollectionStatus();inner=cp.CollectionStatus()
        with outer.active():
            cp.report('download',records=1)
            with inner.active():cp.report('processing',total=10)
            thread=threading.Thread(target=lambda:cp.report(records=99));thread.start();thread.join(2)
            cp.report(records=2)
        cp.report(records=100)
        self.assertEqual(outer.records,2);self.assertEqual(inner.total,10)

    def test_absolute_deadline_expires_at_300_seconds(self):
        with patch.object(cp.time,'monotonic',return_value=0):state=cp.CollectionStatus()
        with patch.object(cp.time,'monotonic',return_value=299.9):state.check()
        with patch.object(cp.time,'monotonic',return_value=300):
            with self.assertRaises(SafeError) as caught:state.check()
        self.assertEqual(caught.exception.code,'X413')


class CatalogueTests(DiskCase):
    def make_session(self):
        session=application.Session();session.adopt(self.prepare());self.addCleanup(session.close)
        session.connection.client._transport=None
        return session

    def fetch(self, session, kind, payload, length=True, status=200):
        reply=response(payload,length,status);conn=Mock();conn.getresponse.return_value=reply
        answers=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('203.0.113.1',443))]
        operation=session.media_request(kind)
        with patch.object(transport,'_Connection',return_value=conn),patch.object(transport._DNS,'resolve',return_value=answers):
            job=jobs.Job(operation);self.assertTrue(job.done.wait(5))
            value=job.take()
        self.assertTrue(session.accept_media(value))
        return operation.collection_status,reply,conn

    def test_movie_download_normalizes_and_adopts_all_rows(self):
        session=self.make_session()
        payload=json.dumps([{'stream_id':i,'name':'Film '+str(i),'container_extension':'mp4'} for i in range(1200)]).encode()
        state,reply,conn=self.fetch(session,'movies',payload)
        self.assertEqual(len(session.movies),1200);self.assertEqual(state.received,len(payload))
        self.assertEqual(state.expected_bytes,len(payload));self.assertEqual(state.records,1200)
        self.assertEqual(state.processed,1200);self.assertEqual(state.view()[1],100)
        self.assertEqual(session.movies[-1]['extension'],'mp4');reply.close.assert_called_once();conn.close.assert_called_once()

    def test_series_download_without_content_length(self):
        session=self.make_session()
        state,_,_=self.fetch(session,'series',b'[{"series_id":7,"name":"Series"}]',False)
        self.assertEqual(session.series[0]['id'],'7');self.assertIsNone(state.expected_bytes)

    def test_empty_list_is_a_successful_catalogue(self):
        session=self.make_session();self.fetch(session,'movies',b'[]')
        self.assertEqual(session.movies,[]);self.assertIn('movies',session.media_loaded)

    def test_malformed_json_rejects_partial_catalogue(self):
        session=self.make_session()
        with self.assertRaises(jobs.JobError) as caught:self.fetch(session,'movies',b'[{"stream_id":1},')
        self.assertEqual(caught.exception.code,'X419');self.assertNotIn('movies',session.media_loaded)

    def test_error_object_is_not_treated_as_empty_catalogue(self):
        session=self.make_session()
        with self.assertRaises(jobs.JobError) as caught:self.fetch(session,'series',b'{"error":"fixture"}')
        self.assertEqual(caught.exception.code,'X412');self.assertEqual(session.series,[])

    def test_http_503_survives_streamed_catalogue_worker(self):
        session=self.make_session()
        with self.assertRaises(jobs.JobError) as caught:self.fetch(session,'movies',RAW.encode(),status=503)
        self.assertEqual(caught.exception.code,'N503');self.assertEqual(caught.exception.http_status,503)
        self.assertNotIn(PASSWORD,str(caught.exception));self.assertEqual(session.movies,[])

    def test_http_599_retains_exact_status(self):
        session=self.make_session()
        with self.assertRaises(jobs.JobError) as caught:self.fetch(session,'series',b'',status=599)
        self.assertEqual(caught.exception.code,'N443');self.assertEqual(caught.exception.http_status,599)

    def test_processing_exception_has_sanitized_stage(self):
        session=self.make_session();session.connection.client.movies=Mock(return_value=[{}])
        with patch.object(application,'media_from_payload',side_effect=RuntimeError(RAW)):
            job=jobs.Job(session.media_request('movies'));self.assertTrue(job.done.wait(2))
            with self.assertRaises(jobs.JobError) as caught:job.take()
        self.assertEqual(caught.exception.code,'X414');self.assertEqual(caught.exception.stage,'catalogue')
        self.assertNotIn(PASSWORD,str(caught.exception));self.assertNotIn('movies',session.media_loaded)

    def test_processing_deadline_is_checked_without_gui(self):
        session=self.make_session();session.connection.client.movies=Mock(return_value=[{'stream_id':1}])
        operation=session.media_request('movies')
        with patch.object(cp.time,'monotonic',return_value=operation.collection_status.started+301):
            with self.assertRaises(SafeError) as caught:operation()
        self.assertEqual(caught.exception.code,'X413')

    def test_cancelled_processing_keeps_existing_collection(self):
        session=self.make_session();session.movies=[{'id':'old'}]
        token=Cancellation();token.cancel();bind(token)
        try:
            with self.assertRaises(Cancelled):xtream.media_from_payload([{'stream_id':1}],'movies')
        finally:bind(None)
        self.assertEqual(session.movies,[{'id':'old'}])

    def test_stale_connection_result_cannot_replace_catalogue(self):
        session=self.make_session();old=session.connection
        session.adopt(self.prepare())
        self.assertFalse(session.accept_media((old,'movies',[{'id':'old'}])))
        self.assertEqual(session.movies,[])

    def test_duplicate_and_invalid_entries_preserve_valid_titles(self):
        rows=xtream.media_from_payload([None,{'stream_id':True},{'stream_id':1,'name':'One'},{'stream_id':1},{'stream_id':2,'name':'Two'}],'movies')
        self.assertEqual([row['id'] for row in rows],['1','2'])

    def test_processing_deadline_interrupts_normalization(self):
        state=cp.CollectionStatus();state.started-=301
        with state.active():
            with self.assertRaises(SafeError) as caught:xtream.media_from_payload([{'stream_id':1}],'movies')
        self.assertEqual(caught.exception.code,'X413')

    def test_chunked_response_reports_bytes_without_invented_total(self):
        session=self.make_session();payload=b'[{"series_id":1}]'
        reply=response(payload,False);reply.headers['Transfer-Encoding']='chunked'
        conn=Mock();conn.getresponse.return_value=reply
        answers=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('203.0.113.1',443))]
        status=cp.CollectionStatus()
        with status.active(),patch.object(transport,'_Connection',return_value=conn),patch.object(transport._DNS,'resolve',return_value=answers):
            result=transport.request_media_catalogue(URL)
        self.assertEqual(len(result),1);self.assertEqual(status.received,len(payload));self.assertIsNone(status.view()[1])

    def test_catalogue_body_timeout_closes_transport(self):
        reply=response(b'');reply.read.side_effect=socket.timeout(RAW)
        conn=Mock();conn.getresponse.return_value=reply
        answers=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('203.0.113.1',443))]
        with patch.object(transport,'_Connection',return_value=conn),patch.object(transport._DNS,'resolve',return_value=answers):
            with self.assertRaises(SafeError) as caught:transport.request_media_catalogue(URL)
        self.assertEqual(caught.exception.code,'X416');self.assertNotIn(PASSWORD,str(caught.exception))
        reply.close.assert_called_once();conn.close.assert_called_once()


class CollectionUITests(DiskCase):
    def window(self):return test_wizard.WizardTests.window(self)

    def test_provider_status_is_visible_and_credentials_are_redacted(self):
        w=self.window();error=jobs.JobError(RAW);error.code='N503';error.http_status=503
        w.run_job=Mock(side_effect=error)
        self.assertFalse(w.ensure_catalogue('movies'))
        text=' '.join(w.dialog.ok.call_args.args)
        self.assertIn('N503',text);self.assertIn('HTTP 503',text);self.assertNotIn(PASSWORD,text)

    def test_failed_refresh_preserves_existing_collection_and_preferences(self):
        w=self.window();w.session.movies=[{'id':'old'}];w.session.media_loaded['movies']=0
        before=w.session.prefs.copy();w.run_job=Mock(side_effect=jobs.JobError(RAW))
        self.assertTrue(w.ensure_catalogue('movies',force=True))
        self.assertEqual(w.session.movies,[{'id':'old'}]);self.assertEqual(w.session.prefs,before)
        self.assertIn('previous catalogue',w.dialog.ok.call_args.args[1])

    def test_cancelled_initial_load_explains_return(self):
        w=self.window();w.run_job=Mock(return_value=None)
        self.assertFalse(w.ensure_catalogue('movies'))
        self.assertEqual(w.dialog.ok.call_args.args[0],'Collection cancelled')

    def test_cancelled_refresh_retains_previous_collection(self):
        w=self.window();w.session.series=[{'id':'old'}];w.session.media_loaded['series']=0;w.run_job=Mock(return_value=None)
        self.assertTrue(w.ensure_catalogue('series',force=True));self.assertEqual(w.session.series,[{'id':'old'}])

    def test_fresh_catalogue_does_not_redownload(self):
        w=self.window();w.session.media_loaded['movies']=kodi_ui.time.monotonic();w.run_job=Mock()
        self.assertTrue(w.ensure_catalogue('movies'));w.run_job.assert_not_called()

    def test_retry_after_error_adopts_successful_result(self):
        w=self.window();error=jobs.JobError();error.code='N454'
        w.run_job=Mock(side_effect=[error,(w.session.connection,'movies',[{'id':'1'}])])
        self.assertFalse(w.ensure_catalogue('movies'));self.assertTrue(w.ensure_catalogue('movies'))
        self.assertEqual(w.session.movies,[{'id':'1'}])

    def test_failed_navigation_keeps_previous_page(self):
        w=self.window();w.page='Home';w.cancel_watch_later_catalogues=Mock();w.remember_view=Mock()
        w.is_playlist=Mock(return_value=False);w.session.save({'content_types':['movies']})
        w.ensure_catalogue=Mock(return_value=False);w.apply_catalogue_filters=Mock()
        kodi_ui.ShadowWindow.open_page(w,'Movies')
        self.assertEqual(w.page,'Home');self.assertEqual(w.properties['shadow.heading'],'Home')
        w.apply_catalogue_filters.assert_not_called()

    def run_window(self):
        job=Mock();job.done.is_set.return_value=False
        w=types.SimpleNamespace(jobs=Mock(),addon_path='fixture');w.jobs.submit.return_value=job
        progress=Mock();progress.iscanceled.return_value=False
        monitor=Mock();monitor.waitForAbort.return_value=False
        return w,job,progress,monitor

    def test_ui_deadline_cancels_worker_and_closes_dialog(self):
        w,job,progress,monitor=self.run_window();clock=[0]
        def wait(_):clock[0]=301;return False
        monitor.waitForAbort.side_effect=wait
        with patch.object(kodi_ui,'CollectionProgress',return_value=progress),patch.object(kodi_ui.xbmc,'Monitor',return_value=monitor,create=True),patch.object(cp.time,'monotonic',side_effect=lambda:clock[0]):
            with self.assertRaises(jobs.JobError) as caught:kodi_ui.ShadowWindow.run_job(w,'Loading collection...',lambda:None)
        self.assertEqual(caught.exception.code,'X413');job.cancel.assert_called();job.take.assert_not_called();progress.close.assert_called_once()

    def test_cancel_button_returns_without_adopting_worker_result(self):
        w,job,progress,monitor=self.run_window();progress.iscanceled.return_value=True
        with patch.object(kodi_ui,'CollectionProgress',return_value=progress),patch.object(kodi_ui.xbmc,'Monitor',return_value=monitor,create=True):
            self.assertIsNone(kodi_ui.ShadowWindow.run_job(w,'Loading collection...',lambda:None))
        job.cancel.assert_called_once();job.take.assert_not_called();progress.close.assert_called_once()

    def test_kodi_abort_cancels_worker_and_closes_dialog(self):
        w,job,progress,monitor=self.run_window();monitor.waitForAbort.return_value=True
        with patch.object(kodi_ui,'CollectionProgress',return_value=progress),patch.object(kodi_ui.xbmc,'Monitor',return_value=monitor,create=True):
            self.assertIsNone(kodi_ui.ShadowWindow.run_job(w,'Loading collection...',lambda:None))
        job.cancel.assert_called_once();progress.close.assert_called_once()

    def test_worker_completion_closes_progress_and_transfers_result(self):
        w,job,progress,monitor=self.run_window();job.done.is_set.side_effect=[False,True];job.take.return_value=('fixture',)
        with patch.object(kodi_ui,'CollectionProgress',return_value=progress),patch.object(kodi_ui.xbmc,'Monitor',return_value=monitor,create=True):
            self.assertEqual(kodi_ui.ShadowWindow.run_job(w,'Loading collection...',lambda:None),('fixture',))
        progress.update_status.assert_called_once();progress.close.assert_called_once();job.cancel.assert_not_called()

    def test_real_progress_control_receives_measured_percentage(self):
        dialog=kodi_ui.CollectionProgress.__new__(kodi_ui.CollectionProgress);dialog.properties={};dialog.control=Mock()
        dialog.update_status('Preparing titles: 1 / 4 (25%)',25)
        dialog.control.setPercent.assert_called_once_with(25);dialog.control.setVisible.assert_called_with(True)
        dialog.control.reset_mock();dialog.update_status('Size unknown',None)
        dialog.control.setVisible.assert_called_once_with(False);dialog.control.setPercent.assert_not_called()

    def test_controller_back_and_cancel_button_set_cancellation(self):
        for action in (9,10,92,216,247,257):
            dialog=kodi_ui.CollectionProgress();dialog.onAction(types.SimpleNamespace(getId=lambda:action));self.assertTrue(dialog.iscanceled())
        dialog=kodi_ui.CollectionProgress();dialog.onClick(910);self.assertTrue(dialog.iscanceled())

    def test_busy_runner_has_actionable_code_without_new_worker(self):
        runner=jobs.JobRunner();runner.active=Mock();runner.active.done.is_set.return_value=False
        with patch.object(jobs,'Job') as factory:
            with self.assertRaises(jobs.JobError) as caught:runner.submit(lambda:None)
        self.assertEqual(caught.exception.code,'X415');factory.assert_not_called()
