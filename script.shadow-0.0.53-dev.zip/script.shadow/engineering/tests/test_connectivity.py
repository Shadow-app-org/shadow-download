import errno
import json
import socket
import ssl
from email.message import Message
from unittest import TestCase
from unittest.mock import Mock, patch
from test_regressions import DiskCase, URL, USER, PASSWORD, RAW, application, provider, transport, jobs
from shadow.safe_errors import safe_message, clean_http_status

class Response:
    def __init__(self,status=200,body=b'{}',headers=None):
        self.status=status;self.body=body;self.closed=False
        self.headers=Message()
        for k,v in (headers or {}).items():self.headers[k]=v
    def getheader(self,key,default=None):return self.headers.get(key,default)
    def read(self,size):
        result,self.body=self.body[:size],self.body[size:]
        return result
    def close(self):self.closed=True

class ConnectivityTests(DiskCase):
    def request_fixture(self,response,**kwargs):
        conn=Mock();conn.getresponse.return_value=response
        dns=Mock();dns.resolve.return_value=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('203.0.113.1',443))]
        with patch.object(transport,'_Connection',return_value=conn):
            result=transport.request_bytes(RAW,dns=dns,**kwargs)
        self.assertTrue(response.closed)
        conn.close.assert_called_once()
        return result

    def test_authentication_success(self):
        c=self.prepare();self.addCleanup(c.close)
        self.assertTrue(c.client.playback_session_valid())
        self.assertEqual(len(c.channels),1)

    def test_successful_http_body(self):
        self.assertEqual(self.request_fixture(Response(body=b'{"ok":true}')) ,b'{"ok":true}')

    def test_credentials_cleared_on_preparation_failure(self):
        client=Mock(endpoint=URL+'/player_api.php')
        client.authenticate.side_effect=provider.ProviderError(code='X401')
        with self.assertRaises(provider.ProviderError):application.prepare_connection(str(self.root),URL,USER,PASSWORD,client_factory=lambda *a,**k:client)
        client.close.assert_called_once()

    def test_failure_does_not_create_account_before_authentication(self):
        def factory(*a,**k):return provider.XtreamClient(*a,transport=lambda *a:b'{"user_info":{"auth":0}}',**k)
        with self.assertRaises(provider.ProviderError) as caught:application.prepare_connection(str(self.root),URL,USER,PASSWORD,client_factory=factory)
        self.assertEqual(caught.exception.code,'X401')
        self.assertEqual(caught.exception.stage,'login')
        self.assertFalse((self.root/'accounts').exists())

    def test_raw_downloader_error_redacted(self):
        def fail(*a):raise RuntimeError(RAW)
        client=provider.XtreamClient(URL,USER,PASSWORD,transport=fail)
        with self.assertRaises(provider.ProviderError) as caught:client.authenticate()
        self.assertEqual(caught.exception.code,'X490')
        self.assertNotIn(PASSWORD,str(caught.exception))
        self.assertNotIn(URL,str(caught.exception))

    def test_unknown_settings_failure_is_actionable_X411(self):
        with patch.object(application,'AccountStore',side_effect=RuntimeError(RAW)):
            with self.assertRaises(provider.ProviderError) as caught:self.prepare()
        self.assertEqual(caught.exception.code,'X411')
        self.assertIn('Check local storage',str(caught.exception))
        self.assertNotIn(PASSWORD,str(caught.exception))

    def test_worker_never_retains_raw_exception(self):
        def fail():raise RuntimeError(RAW)
        job=jobs.Job(fail);self.assertTrue(job.done.wait(2))
        with self.assertRaises(jobs.JobError) as caught:job.take()
        self.assertNotIn(PASSWORD,str(caught.exception))
        self.assertNotIn(PASSWORD,repr(job.__dict__))

    def test_header_timeout_has_network_code(self):
        dns=Mock();dns.resolve.return_value=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('203.0.113.1',443))]
        conn=Mock();conn.getresponse.side_effect=socket.timeout(RAW)
        with patch.object(transport,'_Connection',return_value=conn):
            with self.assertRaises(transport.TransportError) as caught:transport.request_bytes(RAW,dns=dns)
        self.assertEqual(caught.exception.code,'N432')

    def test_body_timeout_has_network_code(self):
        response=Response();response.read=Mock(side_effect=socket.timeout(RAW))
        with self.assertRaises(transport.TransportError) as caught:self.request_fixture(response)
        self.assertEqual(caught.exception.code,'N454')

    def test_tls_insecure_context_rejected(self):
        context=Mock(check_hostname=False,verify_mode=ssl.CERT_NONE)
        raw=Mock()
        with patch.object(transport.socket,'socket',return_value=raw):
            conn=transport._Connection('fixture.invalid',443,'203.0.113.1',True,transport.Deadline(12),context)
            with self.assertRaises(transport.TransportError) as caught:conn.connect()
        self.assertEqual(caught.exception.code,'N424')
        context.wrap_socket.assert_not_called()
        raw.close.assert_called_once()

    def test_tls_hostname_and_minimum_version_preserved(self):
        context=Mock(check_hostname=True,verify_mode=ssl.CERT_REQUIRED,minimum_version=ssl.TLSVersion.TLSv1)
        raw=Mock();wrapped=Mock();context.wrap_socket.return_value=wrapped
        with patch.object(transport.socket,'socket',return_value=raw):
            conn=transport._Connection('fixture.invalid',443,'203.0.113.1',True,transport.Deadline(12),context)
            conn.connect();conn.close()
        self.assertEqual(context.minimum_version,ssl.TLSVersion.TLSv1_2)
        context.wrap_socket.assert_called_once_with(raw,server_hostname='fixture.invalid')

    def test_http_requires_explicit_consent(self):
        with self.assertRaises(ValueError):provider.XtreamClient('http://fixture.invalid',USER,PASSWORD)
        with self.assertRaises(transport.TransportError) as caught:transport.request_bytes('http://fixture.invalid')
        self.assertEqual(caught.exception.code,'N400')

    def test_explicit_http_login_not_playback_permission(self):
        client=provider.XtreamClient('http://fixture.invalid',USER,PASSWORD,allow_insecure_http=True)
        with self.assertRaises(provider.ProviderError):client.live_playback_url('1')

    def test_private_redirect_targets_remain_blocked(self):
        with self.assertRaises(transport.TransportError) as caught:transport.checked_addresses([(2,1,6,'',('127.0.0.1',80))],public_only=True)
        self.assertEqual(caught.exception.code,'N413')

    def test_temporary_connection_uses_no_account_files(self):
        from test_regressions import client_factory
        c=application.prepare_connection(str(self.root),URL,USER,PASSWORD,client_factory=client_factory,temporary=True)
        self.assertEqual(list(self.root.iterdir()),[])
        c.close();self.assertEqual(c.prefs,{})

    def test_closed_credentials_cannot_authenticate(self):
        client=provider.XtreamClient(URL,USER,PASSWORD,transport=lambda *a:b'{}')
        client.close()
        with self.assertRaises(provider.ProviderError) as caught:client.authenticate()
        self.assertEqual(caught.exception.code,'X409')

    def test_api_redirect_rejection_never_reads_body_or_follows(self):
        response=Response(status=302,headers={'Location':RAW})
        response.read=Mock(side_effect=AssertionError('redirect body must not be imported'))
        conn=Mock();conn.getresponse.return_value=response
        dns=Mock();dns.resolve.return_value=[(2,1,6,'',('203.0.113.1',443))]
        with patch.object(transport,'_Connection',return_value=conn) as factory:
            with self.assertRaises(transport.TransportError) as caught:transport.request_bytes(RAW,dns=dns)
        self.assertEqual(caught.exception.code,'N440');self.assertEqual(factory.call_count,1)
        response.read.assert_not_called();self.assertNotIn(PASSWORD,str(caught.exception))

# HTTP status matrix exercises production transport -> provider -> app -> worker.
def status_test(status,code):
    def test(self):
        response=Response(status=status,body=RAW.encode())
        response.read=Mock(side_effect=AssertionError('error body must not be read'))
        conn=Mock();conn.getresponse.return_value=response
        dns=Mock();dns.resolve.return_value=[(2,1,6,'',('203.0.113.1',443))]
        def factory(*a,**k):return provider.XtreamClient(*a,transport=lambda url,timeout:transport.request_bytes(url,dns=dns),**k)
        with patch.object(transport,'_Connection',return_value=conn):
            job=jobs.Job(lambda:application.prepare_connection(str(self.root),URL,USER,PASSWORD,client_factory=factory))
            self.assertTrue(job.done.wait(2))
        with self.assertRaises(jobs.JobError) as caught:job.take()
        error=caught.exception
        self.assertEqual(error.code,code);self.assertEqual(error.http_status,status);self.assertEqual(error.stage,'login')
        text=safe_message(error.code,error.http_status)
        self.assertIn(str(status),text)
        for value in (URL,USER,PASSWORD):self.assertNotIn(value,text)
        response.read.assert_not_called();self.assertTrue(response.closed)
    return test
for status,code in [(500,'N500'),(502,'N502'),(503,'N503'),(504,'N504'),(599,'N443'),(401,'N441'),(403,'N441'),(429,'N442'),(404,'N445'),(418,'N444'),(301,'N440'),(302,'N440'),(303,'N440'),(307,'N440'),(308,'N440')]:
    setattr(ConnectivityTests,'test_http_'+str(status),status_test(status,code))

def payload_test(payload,code,method='authenticate'):
    def test(self):
        client=provider.XtreamClient(URL,USER,PASSWORD,transport=lambda *a:payload)
        with self.assertRaises(provider.ProviderError) as caught:getattr(client,method)()
        self.assertEqual(caught.exception.code,code)
        self.assertNotIn(PASSWORD,str(caught.exception));self.assertFalse(client.playback_session_valid())
    return test
for name,payload,code,method in [
 ('invalid_credentials',b'{"user_info":{"auth":0}}','X401','authenticate'),
 ('inactive',b'{"user_info":{"auth":1,"status":"Disabled"}}','X402','authenticate'),
 ('expired',b'{"user_info":{"auth":1,"exp_date":1}}','X406','authenticate'),
 ('missing_user',b'{}','X405','authenticate'),
 ('malformed_json',RAW.encode(),'X403','authenticate'),
 ('invalid_utf8',b'\xff','X403','authenticate'),
 ('non_bytes','{}','X403','authenticate'),
 ('wrong_categories',b'{}','X407','live_categories'),
 ('wrong_channels',b'{}','X408','live_streams')]:setattr(ConnectivityTests,'test_payload_'+name,payload_test(payload,code,method))

def socket_failure(error,code,tls=False):
    def test(self):
        raw=Mock()
        context=Mock(check_hostname=True,verify_mode=ssl.CERT_REQUIRED,minimum_version=ssl.TLSVersion.TLSv1_2)
        if tls:context.wrap_socket.side_effect=error
        else:raw.connect.side_effect=error
        with patch.object(transport.socket,'socket',return_value=raw):
            conn=transport._Connection('fixture.invalid',443,'203.0.113.1',True,transport.Deadline(12),context)
            with self.assertRaises(transport.TransportError) as caught:conn.connect()
        self.assertEqual(caught.exception.code,code)
        self.assertNotIn(PASSWORD,str(caught.exception));raw.close.assert_called_once()
    return test
for name,error,code,tls in [
 ('refused',ConnectionRefusedError(errno.ECONNREFUSED,RAW),'N420',False),
 ('connect_timeout',socket.timeout(RAW),'N421',False),
 ('socket_permission',PermissionError(errno.EACCES,RAW),'N427',False),
 ('tls_certificate',ssl.SSLCertVerificationError(RAW),'N422',True),
 ('tls_handshake',ssl.SSLError(RAW),'N423',True),
 ('tls_timeout',socket.timeout(RAW),'N426',True)]:setattr(ConnectivityTests,'test_'+name,socket_failure(error,code,tls))

def dns_failure(error,code):
    def test(self):
        resolver=Mock(side_effect=error)
        with self.assertRaises(transport.TransportError) as caught:transport.request_bytes(RAW,resolver=resolver)
        self.assertEqual(caught.exception.code,code);self.assertNotIn(PASSWORD,str(caught.exception))
    return test
for name,error,code in [('missing',socket.gaierror(socket.EAI_NONAME,RAW),'N414'),('temporary',socket.gaierror(socket.EAI_AGAIN,RAW),'N415'),('denied',PermissionError(errno.EACCES,RAW),'N416'),('unsupported',NotImplementedError(RAW),'N417'),('timeout',socket.timeout(RAW),'N411')]:setattr(ConnectivityTests,'test_dns_'+name,dns_failure(error,code))

class SanitisationTests(TestCase):
    def test_only_matching_builtin_numeric_status_allowed(self):
        for value in (True,'503',503.0,None,RAW,0,999,401):
            with self.subTest(value=repr(value)):
                self.assertIsNone(clean_http_status('N443',value))
                error=provider.ProviderError(RAW,code='N443',http_status=value)
                self.assertNotIn(PASSWORD,str(error))
                self.assertIsNone(error.http_status)
    def test_unknown_code_and_stage_redacted(self):
        error=provider.ProviderError(RAW,code=RAW,stage=RAW,http_status=503)
        self.assertEqual(error.code,'X499');self.assertEqual(error.stage,'connection')
        self.assertIsNone(error.http_status);self.assertNotIn(PASSWORD,str(error))

class AdditionalSanitisationTests(TestCase):
    def test_unhashable_codes_fail_safely(self):
        for code in ([],{},None,123):
            self.assertIsNone(clean_http_status(code,503))
            self.assertIsInstance(safe_message(code,503),str)

    def test_all_original45_status_codes_retained(self):
        for status in (500,501,502,503,504,505,506,507,508,510,511):
            code='N'+str(status)
            error=provider.ProviderError(code=code,http_status=status)
            self.assertEqual(error.code,code)
            self.assertEqual(error.http_status,status)
            self.assertIn('HTTP '+str(status),str(error))
