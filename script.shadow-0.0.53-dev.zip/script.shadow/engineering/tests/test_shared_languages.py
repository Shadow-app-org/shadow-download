"""Verify saved browsing language is shared by live channels and both catalogues."""
from unittest.mock import Mock
from test_regressions import DiskCase
import test_wizard
from shadow import xtream

class SharedLanguageTests(DiskCase):
    def window(self):
        w=test_wizard.WizardTests.window(self)
        w.session.connection.channels[:]=[
            {'stream_id':'1','name':'UK: News','category_id':'1'},
            {'stream_id':'2','name':'US: News','category_id':'1'},
            {'stream_id':'3','name':'French News','category_id':'2'},
            {'stream_id':'4','name':'Unlabelled','category_id':'3'}]
        w.session.connection.categories[:]=[
            {'category_id':'1','category_name':'UK News'},
            {'category_id':'2','category_name':'FR News'},
            {'category_id':'3','category_name':'Other'}]
        w.session.save({'approved_channel_ids':['1','2','3','4'],'browse_languages':['English']})
        w.catalogue_filters={};w.is_title_watched=Mock(return_value=False)
        w.run_job=lambda title, operation:operation()
        w.rows=[];w.render_rows=Mock();w.setFocusId=Mock()
        w.catalogue_connection=w.session.connection
        return w

    def load_rows(self,w,page):
        w.page=page
        kind='movies' if page=='Movies' else 'series'
        key='stream_id' if kind=='movies' else 'series_id'
        w.catalogue_rows=xtream.media_from_payload([
            {key:1,'name':'UK: One'}, {key:2,'name':'US: Two'},
            {key:3,'name':'Three','language':'FR'}, {key:4,'name':'Unlabelled'}],kind)
        w.apply_catalogue_filters()

    def test_live_movies_and_series_share_saved_english_selection(self):
        w=self.window()
        self.assertEqual([r['stream_id'] for r in w.session.visible()],['1','2'])
        for page in ('Movies','TV Series'):
            self.load_rows(w,page)
            self.assertEqual([r['id'] for r in w.rows],['1','2'])
            self.assertEqual(w.catalogue_filters[page]['languages'],['English'])

    def test_selection_survives_reload_and_applies_to_both_catalogues(self):
        w=self.window();w.session.save({'browse_languages':['French']});w.session.reload()
        self.assertEqual([r['stream_id'] for r in w.session.visible()],['3'])
        for page in ('Movies','TV Series'):
            self.load_rows(w,page);self.assertEqual([r['id'] for r in w.rows],['3'])

    def test_multiple_languages_apply_to_all_three_sections(self):
        w=self.window();w.session.save({'browse_languages':['English','French']})
        self.assertEqual([r['stream_id'] for r in w.session.visible()],['1','2','3'])
        for page in ('Movies','TV Series'):
            self.load_rows(w,page);self.assertEqual([r['id'] for r in w.rows],['1','2','3'])

    def test_all_languages_includes_unknown_without_expanding_channel_approval(self):
        w=self.window();w.session.save({'browse_languages':[],'approved_channel_ids':['1']})
        self.assertEqual([r['stream_id'] for r in w.session.visible()],['1'])
        for page in ('Movies','TV Series'):
            self.load_rows(w,page);self.assertEqual([r['id'] for r in w.rows],['1','2','3','4'])

    def test_changing_movies_language_updates_series_and_live(self):
        w=self.window();self.load_rows(w,'Movies')
        # Options: All, French, UK English, US English, Not supplied.
        w.dialog.select.return_value=1;w.filter_catalogue(321)
        self.assertEqual(w.session.prefs['browse_languages'],['French'])
        self.assertEqual([r['stream_id'] for r in w.session.visible()],['3'])
        self.load_rows(w,'TV Series');self.assertEqual([r['id'] for r in w.rows],['3'])

    def test_browsing_language_does_not_set_audio_language(self):
        w=self.window();w.session.save({'browse_languages':['French']})
        self.assertEqual(w.session.prefs['audio_language'],'')
