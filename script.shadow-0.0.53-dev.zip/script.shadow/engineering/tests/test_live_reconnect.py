"""Live retries with fake clocks, players, streams and providers; no network."""
import json
import threading
import types
import unittest
from unittest.mock import Mock, patch
from test_regressions import DiskCase, RAW, PASSWORD, jobs, preferences
import test_channel_switch
from shadow import playback, player_control, streaming, live_reconnect, settings_transfer
from shadow import kodi_ui, accounts, sqlite_accounts


def failure(code='N454', stage='read', status=None):
    return streaming.PlaybackError(code=code, stage=stage, http_status=status)


class RetryPolicyTests(unittest.TestCase):
    def test_three_attempts_then_exhausted_without_reset_on_success(self):
        budget=live_reconnect.RetryBudget()
        self.assertEqual([budget.next_delay(failure()) for _ in range(5)], [2,5,10,None,None])

    def test_auth_approval_security_and_unknown_failures_never_retry(self):
        for code in ('P401','P402','N441','N440','N442','N422','N423','N424','N413','P460','P461','P462','P481','P499','S430','P450','P451','P452'):
            with self.subTest(code=code):
                budget=live_reconnect.RetryBudget()
                self.assertIsNone(budget.next_delay(failure(code,'stream')))
                self.assertEqual(budget.attempts,0)

    def test_login_and_approval_stages_never_retry_even_for_transient_code(self):
        for stage in ('login','approval','address','preparation'):
            self.assertFalse(live_reconnect.retryable(failure('N454',stage)))

    def test_only_selected_http_server_statuses_retry(self):
        for status in (500,502,503,504):
            self.assertTrue(live_reconnect.retryable(failure('N443','stream',status)))
        for status in (None,501,505,599,'503',True,403):
            self.assertFalse(live_reconnect.retryable(failure('N443','stream',status)))

    def test_network_errors_retry_without_weakening_validation(self):
        for code in ('N409','N411','N415','N420','N421','N430','N431','N432','N453','N454','N455'):
            self.assertTrue(live_reconnect.retryable(failure(code,'stream')))
        self.assertTrue(live_reconnect.retryable(failure('P453','read')))
        self.assertFalse(live_reconnect.retryable(failure('P453','stream')))

    def test_diagnostics_discard_raw_exception_and_wrong_status_type(self):
        error=types.SimpleNamespace(code=RAW,stage=RAW,http_status=RAW)
        self.assertEqual(live_reconnect.diagnostic(error),('P499','preparation',None))
        self.assertNotIn(PASSWORD,str(failure('N443','stream',503)))


class ReconnectStorageTests(DiskCase):
    def test_old_preferences_default_off_and_preserve_selections(self):
        data=preferences._validate({'favourites':['1'],'approved_channel_ids':['1'],'theme':'charcoal'})
        self.assertIs(data['auto_reconnect_live'],False)
        self.assertEqual(data['favourites'],['1']);self.assertEqual(data['theme'],'charcoal')

    def test_only_a_boolean_is_accepted(self):
        for value in (None,0,1,'true',[],{}):
            with self.assertRaises(preferences.PreferencesError):
                preferences._validate({'auto_reconnect_live':value})

    def test_json_setting_survives_account_reopen(self):
        store=self.store();prefs=store.load();prefs.update(auto_reconnect_live=True,favourites=['1'])
        store.save(prefs,prefs['revision'])
        self.assertTrue(self.store().load()['auto_reconnect_live'])
        self.assertEqual(self.store().load()['favourites'],['1'])

    def test_sqlite_setting_survives_reopen(self):
        with patch.object(sqlite_accounts,'selected',return_value=True):
            store=self.store();prefs=store.load();prefs.update(auto_reconnect_live=True)
            store.save(prefs,prefs['revision'])
            self.assertTrue(self.store().load()['auto_reconnect_live'])

    def test_old_advanced_backup_imports_with_reconnect_off(self):
        prefs=preferences._defaults()
        data={'version':1,'scope':prefs['provider_scope'],
              'settings':{k:prefs[k] for k in settings_transfer.FIELDS if k!='auto_reconnect_live'}}
        path=self.root/'backup.json';path.write_text(json.dumps(data))
        result=settings_transfer.import_settings(str(path),prefs['provider_scope'])
        self.assertIs(result['auto_reconnect_live'],False)


class ReconnectWindowTests(DiskCase):
    def window(self, enabled=True):
        w=test_channel_switch.ChannelSwitchTests.window(self)
        w.session.save({'auto_reconnect_live':enabled})
        w.close_loading_cover=Mock();w.loading_cover=Mock();w.loading_cover.cancelled=False
        w.arm_reconnect('1')
        return w

    def scheduled(self):
        w=self.window()
        with patch.object(kodi_ui.time,'monotonic',return_value=100):
            self.assertTrue(w.schedule_reconnect(failure(),'old-loopback'))
        return w

    def test_off_does_not_schedule_or_open_network_worker(self):
        w=self.window(False)
        self.assertFalse(w.schedule_reconnect(failure(),'old-loopback'))
        w.switch_jobs.submit.assert_not_called()

    def test_schedule_is_delayed_and_does_not_open_window_during_stop(self):
        w=self.scheduled()
        self.assertEqual(w.switch_state['retry_at'],102)
        self.assertEqual(w.switch_state['retry_attempt'],1)
        w.show.assert_not_called();w.show_loading_cover.assert_not_called()
        w.switch_jobs.submit.assert_not_called()

    def test_waits_for_native_idle_then_countdown_then_prepares(self):
        w=self.scheduled();w.playback.player.getPlayingFile.return_value='old-loopback'
        with patch.object(kodi_ui.time,'monotonic',return_value=100):
            w.poll_switch();w.show.assert_not_called()
            w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
            w.poll_switch();w.poll_switch();w.show.assert_called_once()
            w.switch_jobs.submit.assert_not_called()
            self.assertIn('attempt 1 of 3 in 2 seconds',w.loading_cover.setProperty.call_args.args[1])
        with patch.object(playback,'prepare_playback',return_value=Mock()) as prepare:
            with patch.object(kodi_ui.time,'monotonic',return_value=102):
                w.poll_switch()
            operation,dispose=w.switch_jobs.submit.call_args.args
            value=operation();dispose(value)
            prepare.assert_called_once_with(w.session,'1',expected_connection=w.session.connection)
            value.close.assert_called_once()

    def test_transient_retry_preparation_error_uses_next_delay(self):
        w=self.scheduled();w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        job=Mock();job.done.is_set.return_value=True;job.take.side_effect=failure('N443','stream',503)
        w.switch_state.update(phase='preparing',job=job)
        with patch.object(kodi_ui.time,'monotonic',return_value=103):w.poll_switch()
        self.assertEqual(w.switch_state['retry_attempt'],2)
        self.assertEqual(w.switch_state['retry_at'],108)
        job.cancel.assert_called_once();w.return_from_playback.assert_not_called()

    def test_auth_failure_stops_retries_and_reports_it(self):
        w=self.scheduled();w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        job=Mock();job.done.is_set.return_value=True;job.take.side_effect=failure('N441','login',403)
        w.switch_state.update(phase='preparing',job=job)
        with patch.object(kodi_ui.time,'monotonic',return_value=103):w.poll_switch()
        self.assertIsNone(w.switch_state)
        self.assertEqual(w.return_from_playback.call_args.kwargs['error'].code,'N441')

    def test_three_rapid_drops_do_not_reset_retry_budget(self):
        w=self.window()
        for attempt in range(1,4):
            self.assertTrue(w.schedule_reconnect(failure(),'old-loopback'))
            self.assertEqual(w.switch_state['retry_attempt'],attempt)
            w.switch_state=None # Simulated successful handoff; same manual selection.
        self.assertFalse(w.schedule_reconnect(failure(),'old-loopback'))

    def test_new_manual_channel_selection_has_new_budget(self):
        w=self.scheduled();w.switch_state=None
        w.request_switch('2')
        self.assertEqual(w.reconnect_context['channel'],'2')
        self.assertEqual(w.reconnect_context['budget'].attempts,0)

    def test_account_change_cancels_without_preparing(self):
        w=self.scheduled();w.session.adopt(self.prepare());w.poll_switch()
        self.assertIsNone(w.switch_state);w.switch_jobs.submit.assert_not_called()

    def test_preference_revision_change_cancels_even_if_channel_still_approved(self):
        w=self.scheduled();w.session.save({'theme':'charcoal'});w.poll_switch()
        self.assertIsNone(w.switch_state);w.switch_jobs.submit.assert_not_called()
        self.assertEqual(w.return_from_playback.call_args.kwargs['error'].code,'P401')

    def test_disabled_live_content_cancels(self):
        w=self.scheduled();w.session.save({'content_types':['movies']});w.poll_switch()
        self.assertIsNone(w.switch_state);w.switch_jobs.submit.assert_not_called()

    def test_setting_disabled_during_countdown_cancels(self):
        w=self.scheduled();w.session.save({'auto_reconnect_live':False});w.poll_switch()
        self.assertIsNone(w.switch_state);w.switch_jobs.submit.assert_not_called()

    def test_storage_failure_blocks_reconnect(self):
        w=self.window()
        error=failure()
        with patch.object(w.session,'ensure_current',side_effect=preferences.PreferencesError('fixture','S430')):
            self.assertFalse(w.schedule_reconnect(error,'old-loopback'))
        self.assertEqual(error.code,'S430');self.assertEqual(error.stage,'approval')

    def test_unrelated_native_media_is_not_replaced(self):
        w=self.scheduled();w.playback.player.getPlayingFile.return_value='another-player-item'
        with patch.object(kodi_ui.time,'monotonic',return_value=101):w.poll_switch()
        self.assertIsNone(w.switch_state);w.switch_jobs.submit.assert_not_called();w.playback.stop.assert_not_called()

    def test_native_stop_callback_blocks_automatic_restart(self):
        w=self.window();event=threading.Event();event.set()
        w.playback.player.shadow_events={'stopped':event}
        self.assertFalse(w.schedule_reconnect(failure(),'old-loopback'))

    def test_vod_and_demo_do_not_reconnect(self):
        w=self.window();w.playing_media={'id':'1'}
        self.assertFalse(w.schedule_reconnect(failure(),'old-loopback'))
        w.playing_media=None;w.demo=True
        self.assertFalse(w.schedule_reconnect(failure(),'old-loopback'))

    def test_back_or_stop_during_retry_cancels_pending_job_and_budget(self):
        for action in (92,13):
            w=self.scheduled();job=Mock();w.switch_state['job']=job
            w.cancel_next_episode=Mock();w.sample_media=Mock();w.finish_media=Mock()
            w.stop_playback=types.MethodType(kodi_ui.ShadowWindow.stop_playback,w)
            w.onAction(types.SimpleNamespace(getId=lambda:action))
            self.assertIsNone(w.switch_state);self.assertIsNone(w.reconnect_context)
            job.cancel.assert_called_once();w.playback.stop.assert_called_once()

    def test_stop_without_playback_does_not_exit_or_navigate(self):
        w=self.window();w.switch_state=None;w._playback_return=None;w.playback.url=None
        w.shutdown=Mock();w.page='Home'
        w.onAction(types.SimpleNamespace(getId=lambda:13))
        w.shutdown.assert_not_called();w.open_page.assert_not_called()

    def test_retry_prepared_stream_is_rechecked_before_handoff(self):
        w=self.scheduled();w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        prepared=Mock();prepared.permitted.return_value=False
        job=Mock();job.done.is_set.return_value=True;job.take.return_value=prepared
        w.switch_state.update(phase='preparing',job=job)
        with patch.object(kodi_ui.time,'monotonic',return_value=103):w.poll_switch()
        prepared.close.assert_called_once();w.begin_playback.assert_not_called()

    def test_success_reuses_budget_and_hands_back_to_playback(self):
        w=self.scheduled();budget=w.reconnect_context['budget']
        w.playback.player.isPlaying.return_value=False;w.playback.return_ready.return_value=True
        prepared=Mock();prepared.permitted.return_value=True
        job=Mock();job.done.is_set.return_value=True;job.take.return_value=prepared
        w.switch_state.update(phase='preparing',job=job)
        with patch.object(kodi_ui.time,'monotonic',return_value=103):w.poll_switch()
        w.begin_playback.assert_called_once_with(prepared)
        self.assertIs(w.reconnect_context['budget'],budget)
        self.assertEqual(budget.attempts,1)

    def tick_window(self, enabled=True):
        w=self.window(enabled)
        for name in ('update_now_next','poll_next_episode','dismiss_startup_busy',
                     'update_playback_clock','sample_media'):
            setattr(w,name,Mock())
        w.poll_overlay_action=Mock(return_value=False);w.loading_cover=None
        w._overlay_stop_pending=None;w._playback_return=None;w.overlay=None
        w.playback.started=False;w.playback.tick.return_value='failed'
        w.playback.last_failure=('N454','read',None)
        w.watching_channel=None;w.playback_start_pending=False;w.media_last_sample=None
        return w

    def test_actual_ui_tick_routes_failure_into_reconnect(self):
        w=self.tick_window()
        with patch.object(kodi_ui.xbmc,'getCondVisibility',return_value=False,create=True):w.tick()
        self.assertEqual(w.switch_state['retry_attempt'],1)
        w.return_from_playback.assert_not_called()

    def test_actual_ui_tick_off_returns_exact_failure_without_retry(self):
        w=self.tick_window(False)
        with patch.object(kodi_ui.xbmc,'getCondVisibility',return_value=False,create=True):w.tick()
        self.assertIsNone(w.switch_state)
        self.assertEqual(w.return_from_playback.call_args.kwargs['error'].code,'N454')

    def test_clean_end_and_user_back_never_retry(self):
        for outcome in ('finished','back','replaced'):
            w=self.tick_window();w.playback.tick.return_value=outcome;w.playback.last_failure=None
            with patch.object(kodi_ui.xbmc,'getCondVisibility',return_value=False,create=True):w.tick()
            self.assertIsNone(w.switch_state)
            w.return_from_playback.assert_called_once_with(failed=False,error=None)

    def test_native_teardown_timeout_does_not_spend_more_retry_attempts(self):
        w=self.scheduled();w.switch_state['deadline']=0;w.poll_switch()
        self.assertIsNone(w.switch_state)
        self.assertEqual(w.return_from_playback.call_args.kwargs['error'].code,'P482')
        self.assertEqual(w.reconnect_context['budget'].attempts,1)

    def test_settings_menu_saves_opt_in(self):
        w=self.window(False);w.dialog.select.side_effect=[2,4,1]
        w.settings()
        self.assertIs(w.session.connection.store.load()['auto_reconnect_live'],True)

    def test_settings_menu_cancel_does_not_change_preference(self):
        w=self.window(False);w.dialog.select.side_effect=[2,4,-1]
        before=w.session.prefs.copy();w.settings()
        self.assertEqual(w.session.prefs,before)

    def test_playback_dialog_shows_precise_http_status_without_credentials(self):
        w=self.window();error=failure('N443','stream',503);error.reconnect_attempts=3
        w.playback_error(error)
        title,body=w.dialog.ok.call_args.args
        self.assertIn('HTTP 503',body);self.assertIn('3 attempt(s)',body)
        self.assertNotIn(PASSWORD,body);self.assertNotIn('fixture.invalid',body)


class PlaybackFailureTests(unittest.TestCase):
    def controller(self):
        player=Mock();player.isPlaying.return_value=True;player.getPlayingFile.return_value='loopback'
        relay=Mock();relay.status='streaming';relay.failure=None;relay.start.return_value='loopback'
        controller=player_control.PlaybackController(player,Mock(),relay_factory=lambda:relay,clock=lambda:100)
        prepared=Mock();prepared.permitted.return_value=True
        controller.start(prepared)
        return controller,relay,prepared

    def test_stream_timeout_retains_fixed_diagnostic_after_stop(self):
        c,r,p=self.controller();r.status='stream-failed';r.failure=('N454','read',None)
        self.assertEqual(c.tick(True),'failed')
        self.assertEqual(c.last_failure,('N454','read',None));self.assertIsNone(c.url)

    def test_permission_failure_takes_priority_over_stream_failure(self):
        c,r,p=self.controller();r.status='stream-failed';r.failure=('N454','read',None);p.permitted.return_value=False
        self.assertEqual(c.tick(True),'failed');self.assertEqual(c.last_failure,('P401','approval',None))

    def test_native_start_timeout_is_distinct_and_not_retryable(self):
        c,r,p=self.controller();c.player.isPlaying.return_value=False;c.deadline=99
        self.assertEqual(c.tick(False),'timeout');self.assertEqual(c.last_failure[0],'P480')

    def test_client_stop_and_normal_end_are_not_stream_failures(self):
        c,r,p=self.controller();r.status='client-ended'
        self.assertEqual(c.tick(False),'finished');self.assertIsNone(c.last_failure)
        c,r,p=self.controller();c.started=True;c.player.isPlaying.return_value=False
        self.assertEqual(c.tick(False),'finished');self.assertIsNone(c.last_failure)

    def test_relay_retains_source_error_and_cleans_source_without_sockets(self):
        r=playback.PlaybackRelay.__new__(playback.PlaybackRelay)
        r.lock=threading.RLock();r.closed=threading.Event();r.client=None;r.failure=None
        source=Mock();source.length=None;source.read.side_effect=failure()
        lease=playback._Lease(playback.PreparedPlayback(source,lambda:True),20)
        r.lease=lease;r.status='waiting';sock=Mock();sock.close.side_effect=r.closed.set
        r.listener=Mock();r.listener.accept.return_value=(sock,('127.0.0.1',123))
        r._request=Mock(return_value=lease.path);r._send=Mock()
        r._serve()
        self.assertEqual(r.status,'stream-failed');self.assertEqual(r.failure,('N454','read',None))
        source.close.assert_called_once();self.assertIsNone(r.lease)

    def test_late_relay_failure_cannot_overwrite_new_stream(self):
        r=playback.PlaybackRelay.__new__(playback.PlaybackRelay);r.lock=threading.RLock()
        r.lease=object();r.status='streaming';r.failure=None
        r.record_failure(object(),failure())
        self.assertEqual(r.status,'streaming');self.assertIsNone(r.failure)

    def test_unknown_relay_exception_is_sanitised_and_not_retried(self):
        r=playback.PlaybackRelay.__new__(playback.PlaybackRelay);r.lock=threading.RLock();r.lease=object()
        r.record_failure(r.lease,RuntimeError(RAW))
        self.assertEqual(r.failure,('P481','read',None));self.assertNotIn(PASSWORD,str(r.failure))

    def test_worker_retains_precise_stream_http_status(self):
        def operation():raise failure('N443','stream',503)
        job=jobs.Job(operation);self.assertTrue(job.done.wait(2))
        with self.assertRaises(jobs.JobError) as caught:job.take()
        self.assertEqual(caught.exception.http_status,503)
        self.assertTrue(live_reconnect.retryable(caught.exception))

    def test_stream_http_503_survives_input_error_cleanup(self):
        response=Mock(status=503);connection=Mock();connection.getresponse.return_value=response
        connection.sock.raw=Mock()
        dns=[(2,1,6,'',('203.0.113.1',443))]
        with patch.object(streaming._DNS,'resolve',return_value=dns),patch.object(streaming,'_Connection',return_value=connection):
            with self.assertRaises(streaming.PlaybackError) as caught:
                streaming.TSInput('https://fixture.invalid/live/1.ts')
        self.assertEqual(caught.exception.http_status,503)
        self.assertEqual(caught.exception.code,'N443');response.read.assert_not_called()
