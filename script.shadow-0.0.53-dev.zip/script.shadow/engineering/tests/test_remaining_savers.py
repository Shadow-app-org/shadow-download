"""Account-only release: verify other savers still fail safely on sync failure."""
from pathlib import Path
from unittest.mock import patch
from test_regressions import DiskCase, URL, USER, PASSWORD
from shadow.safe_errors import SafeError
from shadow import saved_login, connection_permissions, discovery, history, personal_backup, preferences


class RemainingSaverTests(DiskCase):
    def test_saved_login_sync_failure_preserves_existing_login(self):
        store = saved_login.SavedLogin(str(self.root))
        store.save((URL, USER, PASSWORD))
        before = Path(store.path).read_bytes()
        with patch.object(saved_login, 'sync_file', side_effect=SafeError('S420')):
            with self.assertRaises(saved_login.LoginStorageError):
                store.save((URL, USER, 'different-fixture-password'))
        self.assertEqual(Path(store.path).read_bytes(), before)

    def test_permission_sync_failure_preserves_prior_grants(self):
        store = connection_permissions.ConnectionPermissions(str(self.root))
        identity = connection_permissions.identity((URL, USER, PASSWORD))
        options = {'remember':False,'redirects':False,'http_redirects':False,'http_login':False}
        store.remember(identity, options)
        before = Path(store.path).read_bytes()
        with patch.object(connection_permissions, 'sync_file', side_effect=SafeError('S420')):
            with self.assertRaises(saved_login.LoginStorageError):
                store.remember(identity, dict(options, redirects=True))
        self.assertEqual(Path(store.path).read_bytes(), before)

    def test_history_failure_retains_previous_file_and_exposes_error(self):
        store = self.store()
        item = history.WatchHistory(store)
        try:
            item.remember_channel('1')
            item.queue.join()
            before = Path(item.path).read_bytes()
            with patch.object(history, 'atomic_bytes', side_effect=preferences.PreferencesError('blocked','S420')):
                item.remember_channel('2')
                item.queue.join()
                self.assertIsNotNone(item.error)
                self.assertTrue(item.dirty)
                self.assertEqual(Path(item.path).read_bytes(), before)
                item.close()
        finally:
            item.close()

    def test_discovery_failure_blocks_updates_and_preserves_file(self):
        store = self.store()
        item = discovery.Discovery(store)
        item.update('movies', [{'id':'1'}])
        before = Path(item.path).read_bytes()
        with patch.object(discovery, 'atomic_bytes', side_effect=preferences.PreferencesError('blocked','S420')):
            item.update('movies', [{'id':'1'},{'id':'2'}])
        self.assertTrue(item.blocked)
        self.assertEqual(Path(item.path).read_bytes(), before)

    def test_export_sync_failure_removes_only_its_new_reservation(self):
        from shadow.local_files import write_new_bytes
        target = self.root/'export.json'
        existing = self.root/'existing.json'
        existing.write_bytes(b'keep')
        with patch.object(preferences, 'sync_file', side_effect=SafeError('S420')):
            with self.assertRaises(preferences.PreferencesError):
                write_new_bytes(str(target), b'{}')
        self.assertFalse(target.exists())
        self.assertEqual(existing.read_bytes(), b'keep')
