"""Demonstrate the .47 exclusive-open assumption using disposable identities.

Pass the extracted .47 add-on directory as argv[1] outside the engineering
workspace. No existing account/profile or provider connection is used.
"""
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

root = Path(__file__).resolve().parent.parent
source = Path(sys.argv[1]) if len(sys.argv) > 1 else root/'work47/script.shadow'
assert (source/'resources/lib/shadow/build_info.py').is_file(), 'Supply the .47 source directory'
sys.path.insert(0, str(source/'resources/lib'))
from shadow import accounts, sqlite_accounts, build_info
assert build_info.VERSION == '0.0.47', 'This reproduction must use unchanged .47 source'
original = os.open
attempts = []
def kodi_create(path, flags, *args, **kwargs):
    if os.path.basename(os.fspath(path)) == sqlite_accounts.DATABASE and flags & os.O_CREAT:
        attempts.append(True)
        flags = (flags & ~os.O_EXCL) | os.O_TRUNC
    return original(path, flags, *args, **kwargs)
with tempfile.TemporaryDirectory(prefix='shadow47-reproduction-') as directory:
    with patch.object(sqlite_accounts, 'selected', return_value=True), patch.object(os, 'open', side_effect=kodi_create):
        first = accounts._scope_key(directory)
        second = accounts._scope_key(directory)
    changed = first != second
assert changed and len(attempts) == 2
print(json.dumps({'version':'0.0.47','result':'DEFECT REPRODUCED',
                  'assumption':'Kodi-style O_CREAT truncates despite O_EXCL',
                  'identity_changed_on_reopen':changed, 'database_create_calls':len(attempts),
                  'scope':'Synthetic private temporary folder; no actual Xbox failure attribution'},indent=2))
