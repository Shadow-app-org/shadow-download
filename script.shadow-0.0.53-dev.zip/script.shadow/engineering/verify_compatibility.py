"""Compile the complete deliverable with the invoking Python interpreter."""
import json
from pathlib import Path
import py_compile
import sqlite3
import sys
import tempfile

engineering = Path(__file__).resolve().parent
root = engineering.parent
source = root if (root/'addon.xml').exists() else root/'work53/script.shadow'
runtime = [p for p in source.rglob('*.py') if '__pycache__' not in p.parts
           and 'engineering' not in p.relative_to(source).parts]
files = runtime + list(engineering.glob('*.py')) + list((engineering/'tests').glob('*.py'))
with tempfile.TemporaryDirectory(prefix='shadow-compatibility-') as temporary:
    for i, path in enumerate(files):
        py_compile.compile(str(path), cfile=str(Path(temporary)/(str(i)+'.pyc')), doraise=True)
report = {'python':sys.version, 'platform':sys.platform, 'sqlite':sqlite3.sqlite_version,
          'compiled_files':len(files), 'runtime_files':len(runtime), 'result':'PASS',
          'limitation':'Native Linux interpreter, not the embedded Xbox Kodi runtime.'}
name = 'compatibility-' + str(sys.version_info[0]) + str(sys.version_info[1]) + '.json'
(engineering/'reports'/name).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
